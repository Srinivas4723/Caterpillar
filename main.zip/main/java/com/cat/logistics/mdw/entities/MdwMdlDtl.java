package com.cat.logistics.mdw.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * This class holds Machine Description data at entity level
 * @author ganamr
 *
 */
@Entity
@Table(name="MDW_SLS_MDL_DET_MO",schema="Z1DD001$")
public class MdwMdlDtl implements Serializable{

	private static final long serialVersionUID = 6444402531706896892L;

	@Id
	@Column(name="SER_NO_PFX")
	private String serialNumPrefix;
	
	@Column(name="PROD_FAM_DESC")
	private String machineDesc;
	
	@Column(name="SRC_FAC_CD")
	private String srcFacCd;

	/**
	 * @return the serialNumPrefix
	 */
	public String getSerialNumPrefix() {
		return serialNumPrefix;
	}

	/**
	 * @param serialNumPrefix the serialNumPrefix to set
	 */
	public void setSerialNumPrefix(String serialNumPrefix) {
		this.serialNumPrefix = serialNumPrefix;
	}

	/**
	 * @return the machineDesc
	 */
	public String getMachineDesc() {
		return machineDesc;
	}

	/**
	 * @param machineDesc the machineDesc to set
	 */
	public void setMachineDesc(String machineDesc) {
		this.machineDesc = machineDesc;
	}

	public String getSrcFacCd() {
		return srcFacCd;
	}

	public void setSrcFacCd(String srcFacCd) {
		this.srcFacCd = srcFacCd;
	}

}
