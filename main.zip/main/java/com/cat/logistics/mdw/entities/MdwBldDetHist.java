package com.cat.logistics.mdw.entities;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * This class holds Machine Description data at entity level
 * @author ganamr
 *
 */
@Entity
@Table(name="MDW_BLD_DET_HIST",schema="Z1DD001$")
public class MdwBldDetHist implements Serializable{

	private static final long serialVersionUID = -4692266436309395581L;
	
	@Id
	@Column(name="SER_NO_PFX")
	private String serialNumPrefix;
	
	@Column(name="SER_NO_BDY")
	private String serialNumBody;
	
	@Temporal(TemporalType.DATE)
	@Column(name="BLT_DT")
	private Date buildDate;

	/**
	 * @return the serialNumPrefix
	 */
	public String getSerialNumPrefix() {
		return serialNumPrefix;
	}

	/**
	 * @param serialNumPrefix the serialNumPrefix to set
	 */
	public void setSerialNumPrefix(String serialNumPrefix) {
		this.serialNumPrefix = serialNumPrefix;
	}

	/**
	 * @return the serialNumBody
	 */
	public String getSerialNumBody() {
		return serialNumBody;
	}

	/**
	 * @param serialNumBody the serialNumBody to set
	 */
	public void setSerialNumBody(String serialNumBody) {
		this.serialNumBody = serialNumBody;
	}

	/**
	 * @return the buildDate
	 */
	public Date getBuildDate() {
		return buildDate;
	}

	/**
	 * @param buildDate the buildDate to set
	 */
	public void setBuildDate(Date buildDate) {
		this.buildDate = buildDate;
	}


	

}
