package com.cat.logistics.mdw.dao;

import java.util.Date;

import com.cat.logistics.mdw.entities.MdwMdlDtl;
import com.cat.logistics.shared.dao.IGenericJpaDao;
import com.cat.logistics.shared.exception.DaoException;

/**
 * Interface for MdwReadDAO implementation class
 * @author chanda15
 *
 */
public interface IMdwReadDAO extends IGenericJpaDao<MdwMdlDtl, String> {

	/**
	 * @param serialPrfxNum
	 * @return Machine Description
	 * @throws DaoException
	 */
	MdwMdlDtl getMachineDesc(String serialPrfxNum) throws DaoException;

	/**
	 * @param serialPrfxNum
	 * @param serialNumBody
	 * @return Build date
	 * @throws DaoException
	 */
	Date getBldDtFrmMdwBldDetHist(String serialPrfxNum, String serialNumBody)
			throws DaoException;

}
