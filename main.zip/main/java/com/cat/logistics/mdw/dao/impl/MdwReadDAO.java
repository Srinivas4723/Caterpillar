package com.cat.logistics.mdw.dao.impl;

import java.util.Date;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.springframework.transaction.annotation.Transactional;

import com.cat.logistics.mdw.dao.IMdwReadDAO;
import com.cat.logistics.mdw.entities.MdwBldDetHist;
import com.cat.logistics.mdw.entities.MdwMdlDtl;
import com.cat.logistics.ods.dao.impl.OdsReadDAO;
import com.cat.logistics.shared.dao.impl.GenericJpaDao;
import com.cat.logistics.shared.exception.DaoException;
import com.cat.logistics.shared.utils.PersistenceConstants;

/**
 * This class act as a DAO layer to perform MDW database related operations
 * 
 * @author ganamr
 *
 */
public class MdwReadDAO extends GenericJpaDao<MdwMdlDtl, String> implements IMdwReadDAO {
	public static final Logger LOGGER = LogManager.getLogger(MdwReadDAO.class);

	/**
	 * fetches Machine description for given serial prefix number
	 */
	@SuppressWarnings("unchecked")
	@Override
	@Transactional
	public MdwMdlDtl getMachineDesc(String serialPrfxNum) throws DaoException {
		LOGGER.info("Entry method of getMachineDesc {}", PersistenceConstants.METHOD_ENTRY);
		MdwMdlDtl mdlDtl = null;
		try {
			Criteria criteria = getMdwSession().createCriteria(MdwMdlDtl.class);
			criteria.add(Restrictions.eq("serialNumPrefix", serialPrfxNum));

			List<MdwMdlDtl> mdlDtList = (List<MdwMdlDtl>) criteria.list();
			if (null != mdlDtList && mdlDtList.size() > 0) {
				mdlDtl = mdlDtList.get(0);
			}
			LOGGER.info("Exit method of getMachineDesc {}", PersistenceConstants.METHOD_EXIT);
		} catch (Exception exc) {
			LOGGER.error("Error in getMachineDesc {}", exc.getMessage(), exc);
			throw new DaoException(exc);
		}

		return mdlDtl;
	}

	/**
	 * Get Machine Build Date for order control number from MDS BILD DET HIST table
	 */
	@SuppressWarnings("unchecked")
	@Override
	@Transactional
	public Date getBldDtFrmMdwBldDetHist(String serialPrfxNum, String serialNumBody) throws DaoException {
		LOGGER.info("Entry method of getBldDtFrmMdwBldDetHist {} {}",PersistenceConstants.GET_BLD_DT_MDW_DET_HIST,
				PersistenceConstants.METHOD_ENTRY);
		Date bldDt = null;
		try {
			Criteria criteria = getMdwSession().createCriteria(MdwBldDetHist.class);
			criteria.add(Restrictions.eq(PersistenceConstants.SER_NUM_PRFIX, serialPrfxNum));
			criteria.add(Restrictions.eq(PersistenceConstants.SER_NUM_BODY, serialNumBody));

			ProjectionList proj = Projections.projectionList();
			proj.add(Projections.property(PersistenceConstants.BLD_DATE));

			criteria.setProjection(proj);

			List<Date> buildDtList = (List<Date>) criteria.list();
			if (null != buildDtList && buildDtList.size() > 0) {
				bldDt = (Date) buildDtList.get(0);
			}
			LOGGER.info("Exit method of getBldDtFrmMdwBldDetHist {} {}",PersistenceConstants.GET_BLD_DT_MDW_DET_HIST,
					PersistenceConstants.METHOD_EXIT);
		} catch (Exception daoExcn) {
			LOGGER.error("Error in getBldDtFrmMdwBldDetHist {}", daoExcn.getMessage(),
					daoExcn);
			throw new DaoException(daoExcn);
		}

		return bldDt;
	}

}
