package com.cat.logistics.tis.entities;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * This class holds HTS Code configuration details at entity level
 * @author chanda15
 *
 */
@Entity
@Table(name="CAT_ID_HTSUSA_XREF",schema="Z1TJ111$")
public class HTSCodes {

	@Id
	@Column(name="CAT_ID_NO_20")
	private String partId;
	

	@Column(name="HRMNZ_TRF_SCH_NO")
	private String htsCode;
	
	@Column(name="LAST_UPDT_TS")
	private Timestamp  lstTm;
	
	@Column(name="PART_TYP")
	private String partTyp;
	

	/**
	 * @return the Part id
	 */
	public String getPartId() {
		return partId;
	}

	/**
	 * @param partId
	 */
	public void setPartId(String partId) {
		this.partId = partId;
	}

	/**
	 * @return the Part id
	 */
	public String getHtsCode() {
		return htsCode;
	}

	/**
	 * @param htsCode
	 */
	public void setHtsCode(String htsCode) {
		this.htsCode = htsCode;
	}

	public Timestamp getLastUpdtTmstmp() {
		return lstTm;
	}

	public void setLastUpdtTmstmp(Timestamp lastUpdtTmstmp) {
		this.lstTm = lastUpdtTmstmp;
	}

	public String getPartTyp() {
		return partTyp;
	}

	public void setPartTyp(String partTyp) {
		this.partTyp = partTyp;
	}

	public Timestamp getLstTm() {
		return lstTm;
	}

	public void setLstTm(Timestamp lstTm) {
		this.lstTm = lstTm;
	}
}
