package com.cat.logistics.tis.entities;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.Table;

/**
 * This class holds Supplier Invoice item information
 * @author chanda15
 *
 */
@Entity
@Table(name="SUPP_INVC_ITM",schema="Z1TJ111$")
@NamedQuery(name="SupplierInvoiceItem.findAll", query="SELECT e FROM SupplierInvoiceItem e")
public class SupplierInvoiceItem {

	@EmbeddedId
	InvcPk invoicePk;
	
	@Column(name="LAST_UPDT_TS")
	Timestamp  lastUpdtTmstmp;
	
	@Column(name="RCVG_FAC_CD")
	String rcvgFac;
	
	@Column(name="PART_TYP")
	String partTyp;
	
	@OneToOne
	@JoinColumns(
			{
		@JoinColumn(name="SUPP_LD_TS",referencedColumnName="SUPP_LD_TS",insertable = false,updatable=false)
			}
			)
	SupplierLoad suppLoad;
	
	String desc;
	
	String prodSerNum;
	
	/**
	 * @return the supplier Load
	 */
	public SupplierLoad getSuppLoad() {
		return suppLoad;
	}

	/**
	 * @param suppLoad
	 */
	public void setSuppLoad(SupplierLoad suppLoad) {
		this.suppLoad = suppLoad;
	}


	/**
	 * @return the lstTm
	 */
	public Timestamp getLastUpdtTmstmp() {
		return lastUpdtTmstmp;
	}

	/**
	 * @param lstTm
	 */
	public void setLastUpdtTmstmp(Timestamp lastUpdtTmstmp) {
		this.lastUpdtTmstmp = lastUpdtTmstmp;
	}

	/**
	 * @return the invoicePk
	 */
	public InvcPk getInvoicePk() {
		return invoicePk;
	}

	/**
	 * @param invoicePk
	 */
	public void setInvoicePk(InvcPk invoicePk) {
		this.invoicePk = invoicePk;
	}

	/**
	 * @return the received facility
	 */
	public String getRcvgFac() {
		return rcvgFac;
	}

	/**
	 * @param rcvgFac
	 */
	public void setRcvgFac(String rcvgFac) {
		this.rcvgFac = rcvgFac;
	}

	public String getPartTyp() {
		return partTyp;
	}

	public void setPartTyp(String partTyp) {
		this.partTyp = partTyp;
	}

	/**
	 * @return the desc
	 */
	public String getDesc() {
		return desc;
	}

	/**
	 * @param desc the desc to set
	 */
	public void setDesc(String desc) {
		this.desc = desc;
	}

	/**
	 * @return the prodSerNum
	 */
	public String getProdSerNum() {
		return prodSerNum;
	}

	/**
	 * @param prodSerNum the prodSerNum to set
	 */
	public void setProdSerNum(String prodSerNum) {
		this.prodSerNum = prodSerNum;
	}
	
	

}
