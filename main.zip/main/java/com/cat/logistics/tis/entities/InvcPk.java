package com.cat.logistics.tis.entities;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Embeddable;

/**
 * This class holds Invoice primary key details
 * @author chanda15
 *
 */
@Embeddable
public class InvcPk implements Serializable{

	@Column(name="supp_itm_seq_no")
	String itmSeqNo;
	
	@Column(name="supp_invc_no_16")
	String invoiceNumber;	
	
	@Column(name="CAT_ID_NO_20")
	String partNum;
	
	//String machineManufactureName;
	
	@Column(name="supp_cd")
	String suppCd;
	
	
	@Column(name="SUPP_LD_TS")
	Timestamp suppLdTmstmp;


	/**
	 * @return the item sequence number
	 */
	public String getItmSeqNo() {
		return itmSeqNo;
	}


	/**
	 * @param itmSeqNo
	 */
	public void setItmSeqNo(String itmSeqNo) {
		this.itmSeqNo = itmSeqNo;
	}


	/**
	 * @return the invoice number
	 */
	public String getInvoiceNumber() {
		return invoiceNumber;
	}


	/**
	 * @param invoiceNumber
	 */
	public void setInvoiceNumber(String invoiceNumber) {
		this.invoiceNumber = invoiceNumber;
	}


	/**
	 * @return the part number
	 */
	public String getPartNum() {
		return partNum;
	}


	/**
	 * @param partNum
	 */
	public void setPartNum(String partNum) {
		this.partNum = partNum;
	}


	/**
	 * @return the supplier code
	 */
	public String getSuppCd() {
		return suppCd;
	}


	/**
	 * @param suppCd
	 */
	public void setSuppCd(String suppCd) {
		this.suppCd = suppCd;
	}


	/**
	 * @return the supplierLoad time stamp
	 */
	public Timestamp getSuppLdTmstmp() {
		return suppLdTmstmp;
	}


	/**
	 * @param suppLdTmstmp
	 */
	public void setSuppLdTmstmp(Timestamp suppLdTmstmp) {
		this.suppLdTmstmp = suppLdTmstmp;
	}
}
