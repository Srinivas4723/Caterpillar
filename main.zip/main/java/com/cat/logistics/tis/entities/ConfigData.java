package com.cat.logistics.tis.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * This class holds Configuration details for TIS codes
 * @author chanda15
 *
 */
@Entity
@Table(name="TIS_CODES",schema="Z1TJ111$")
public class ConfigData {
	
	@Id
	@Column(name="CD_TYP")
	String cdTyp;
	
	@Column(name="CD_KEY_QUAL")
	String cdKeyVal;
}
