package com.cat.logistics.tis.entities;

import java.io.Serializable;
import java.sql.Date;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * This class holds Supplier information at Entity level
 * @author chanda15
 *
 */
@Entity
@Table(name="SUPP_LD",schema="Z1TJ111$")
public class SupplierLoad implements Serializable{


	@Column(name="ORIG_FAC_CD")
	private String origFacCd;
	
	@Id
	@Column(name="SUPP_LD_TS",insertable = false,updatable=false)
	private Timestamp suppLoadTmstmp;
	
	@Column(name="ORIG_SHP_DT")
	private Date originshpDate;
	
	@Column(name="SUPP_CD")
	private String suppCd;
	
	@Column(name="ORIG_CTRY_CD")
	private String originCtry;
	
	@Column(name="DEST_CTRY_CD")
	private String destCtry;
	
	@Column(name="SUPP_LD_CTL_NO")
	private String loadNum;
	
	@Column(name="DLR_ORD_NO")
	private String dealerNumber;
	
	@Column(name="LAST_UPDT_TS")
	private Timestamp  lastUpdtTmstmp;
	
	@Column(name="SUPP_LD_CMDTY_TYP")
	private String SuppLdCmdtyCd;

	/**
	 * @return the OrigineFacCode
	 */
	public String getOrigFacCd() {
		return origFacCd;
	}

	/**
	 * @param origFacCd
	 */
	public void setOrigFacCd(String origFacCd) {
		this.origFacCd = origFacCd;
	}


	/**
	 * @return the origin Ship Date
	 */
	public Date getOriginshpDate() {
		return originshpDate;
	}

	/**
	 * @param originshpDate
	 */
	public void setOriginshpDate(Date originshpDate) {
		this.originshpDate = originshpDate;
	}

	/**
	 * @return the Supplier code
	 */
	public String getSuppCd() {
		return suppCd;
	}

	/**
	 * @param suppCd
	 */
	public void setSuppCd(String suppCd) {
		this.suppCd = suppCd;
	}

	/**
	 * @return the OriginContry
	 */
	public String getOriginCtry() {
		return originCtry;
	}

	/**
	 * @param originCtry
	 */
	public void setOriginCtry(String originCtry) {
		this.originCtry = originCtry;
	}

	/**
	 * @return the destCtry
	 */
	public String getDestCtry() {
		return destCtry;
	}

	/**
	 * @param destCtry
	 */
	public void setDestCtry(String destCtry) {
		this.destCtry = destCtry;
	}

	/**
	 * @return the loadNum
	 */
	public String getLoadNum() {
		return loadNum;
	}

	/**
	 * @param loadNum
	 */
	public void setLoadNum(String loadNum) {
		this.loadNum = loadNum;
	}

	/**
	 * @return the suppLoadTmstmp
	 */
	public Timestamp getSuppLoadTmstmp() {
		return suppLoadTmstmp;
	}

	/**
	 * @param suppLoadTmstmp
	 */
	public void setSuppLoadTmstmp(Timestamp suppLoadTmstmp) {
		this.suppLoadTmstmp = suppLoadTmstmp;
	}

	/**
	 * @return the dealerNumber
	 */
	public String getDealerNumber() {
		return dealerNumber;
	}

	/**
	 * @param dealerNumber
	 */
	public void setDealerNumber(String dealerNumber) {
		this.dealerNumber = dealerNumber;
	}

	/**
	 * Get Last Updated TimeStamp
	 * @return Timestamp
	 */
	public Timestamp getLastUpdtTmstmp() {
		return lastUpdtTmstmp;
	}

	/**
	 * Set Last Updated TimeStamp
	 * @param lastUpdtTmstmp
	 */
	public void setLastUpdtTmstmp(Timestamp lastUpdtTmstmp) {
		this.lastUpdtTmstmp = lastUpdtTmstmp;
	}

	/**
	 * @return the suppLdCmdtyCd
	 */
	public String getSuppLdCmdtyCd() {
		return SuppLdCmdtyCd;
	}

	/**
	 * @param suppLdCmdtyCd the suppLdCmdtyCd to set
	 */
	public void setSuppLdCmdtyCd(String suppLdCmdtyCd) {
		SuppLdCmdtyCd = suppLdCmdtyCd;
	}
	
}
