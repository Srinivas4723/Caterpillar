/**
 * Copyright (c) Caterpillar Inc. All Rights Reserved.
 * This work contains Caterpillar Inc.'s unpublished proprietary information
 * which may constitute a trade secret and/or be confidential. This work 
 * may be used only for the purposes for which it was provided, and may 
 * not be copied or disclosed to others. Copyright notice is precautionary 
 * only, and does not imply publication.
 *
 * Logger.java
 * Class Description  : 
 * Revision History
 * Version        Date         Changed By        Comments
 *  1.0           Oct 20, 2015      singhr9           Initial Creation
 */
package com.cat.logistics.tis.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 *
 * @author neelask 
 */
@Entity
@Table(name="CTRY",schema="Z1TJ111$")
public class Ctry implements Serializable{
	
	/**
	 * @author neelask
	 */
	private static final long serialVersionUID = -844323214690545505L;

	@Id
	@Column(name="CTRY_CD")
	private String ctryCd;

	@Column(name="CTRY_NM")
	private String ctryNm;

	@Column(name="CONTNT_CD")
	private String contntCd;

	/**
	 * @return the ctryCd
	 */
	public String getCtryCd() {
		return ctryCd;
	}

	/**
	 * @param ctryCd the ctryCd to set
	 */
	public void setCtryCd(String ctryCd) {
		this.ctryCd = ctryCd;
	}

	/**
	 * @return the ctryNm
	 */
	public String getCtryNm() {
		return ctryNm;
	}

	/**
	 * @param ctryNm the ctryNm to set
	 */
	public void setCtryNm(String ctryNm) {
		this.ctryNm = ctryNm;
	}

	/**
	 * @return the contntCd
	 */
	public String getContntCd() {
		return contntCd;
	}

	/**
	 * @param contntCd the contntCd to set
	 */
	public void setContntCd(String contntCd) {
		this.contntCd = contntCd;
	}

}
