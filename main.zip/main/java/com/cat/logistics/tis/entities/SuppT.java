
package com.cat.logistics.tis.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author ganamr
 *
 */
@Entity
@Table(name="SUPP_T",schema="Z1NX001$")
public class SuppT implements Serializable{
	
	
	private static final long serialVersionUID = -844323214690545505L;


	@Column(name="SUPP_CD")
	private String suppCd;
	
	@Id
	@Column(name="ADR_TYP")
	private String adrTyp;
	
	@Column(name="SUPP_CD_TYP")
	private String suppCdTyp;
	
	@Column(name="CTRY_CD")
	private String ctryCd;

	/**
	 * @return the suppCd
	 */
	public String getSuppCd() {
		return suppCd;
	}

	/**
	 * @param suppCd the suppCd to set
	 */
	public void setSuppCd(String suppCd) {
		this.suppCd = suppCd;
	}

	/**
	 * @return the adrTyp
	 */
	public String getAdrTyp() {
		return adrTyp;
	}

	/**
	 * @param adrTyp the adrTyp to set
	 */
	public void setAdrTyp(String adrTyp) {
		this.adrTyp = adrTyp;
	}

	/**
	 * @return the suppCdTyp
	 */
	public String getSuppCdTyp() {
		return suppCdTyp;
	}

	/**
	 * @param suppCdTyp the suppCdTyp to set
	 */
	public void setSuppCdTyp(String suppCdTyp) {
		this.suppCdTyp = suppCdTyp;
	}

	/**
	 * @return the ctryCd
	 */
	public String getCtryCd() {
		return ctryCd;
	}

	/**
	 * @param ctryCd the ctryCd to set
	 */
	public void setCtryCd(String ctryCd) {
		this.ctryCd = ctryCd;
	}

	

}
