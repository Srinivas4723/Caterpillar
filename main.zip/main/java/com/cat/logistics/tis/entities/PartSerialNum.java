package com.cat.logistics.tis.entities;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


/**
 * This class holds Part serial number information at entity level
 * @author chanda15
 *
 */
@Entity
@Table(name="SER_PROD",schema="Z1TJ111$")
public class PartSerialNum {

	@Id
	@Column(name="PROD_SER_NO")
	private String productSerialNum;
	
	@Column(name="SUPP_INVC_NO_16")
	private String invoiceNum;
	
	@Column(name="SUPP_ITM_SEQ_NO")
	private String seqNum ;
	
	@Column(name="SUPP_CD")
	private String suppCd;
	
	@Column(name="SLS_MDL_DESC")
	private String salesMdlNo;
	
	@Column(name="SUPP_LD_TS")
	private Timestamp suppLdTmstmp;

	/**
	 * @return the product serial number
	 */
	public String getProductSerialNum() {
		return productSerialNum;
	}

	/**
	 * @param productSerialNum
	 */
	public void setProductSerialNum(String productSerialNum) {
		this.productSerialNum = productSerialNum;
	}

	/**
	 * @return the invoice number
	 */
	public String getInvoiceNum() {
		return invoiceNum;
	}

	/**
	 * @param invoiceNum
	 */
	public void setInvoiceNum(String invoiceNum) {
		this.invoiceNum = invoiceNum;
	}

	/**
	 * @return the seqNum
	 */
	public String getSeqNum() {
		return seqNum;
	}

	/**
	 * @param seqNum
	 */
	public void setSeqNum(String seqNum) {
		this.seqNum = seqNum;
	}

	/**
	 * @return the Supplier Code
	 */
	public String getSuppCd() {
		return suppCd;
	}

	/**
	 * @param suppCd
	 */
	public void setSuppCd(String suppCd) {
		this.suppCd = suppCd;
	}

	/**
	 * @return the suppLdTmstmp
	 */
	public Timestamp getSuppLdTmstmp() {
		return suppLdTmstmp;
	}

	/**
	 * @param suppLdTmstmp
	 */
	public void setSuppLdTmstmp(Timestamp suppLdTmstmp) {
		this.suppLdTmstmp = suppLdTmstmp;
	}

	/**
	 * @return the sales model number
	 */
	public String getSalesMdlNo() {
		return salesMdlNo;
	}

	/**
	 * @param salesMdlNo
	 */
	public void setSalesMdlNo(String salesMdlNo) {
		this.salesMdlNo = salesMdlNo;
	}
	
	

}
