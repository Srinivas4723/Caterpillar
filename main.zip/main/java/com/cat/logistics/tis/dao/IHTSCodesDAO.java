package com.cat.logistics.tis.dao;

import java.sql.Timestamp;
import java.util.List;

import com.cat.logistics.shared.exception.DaoException;
import com.cat.logistics.tis.entities.HTSCodes;

/**
 * Interface class for HTSCodesDAO implementation class
 * @author ganamr
 *
 */
public interface IHTSCodesDAO {

	/**
	 * @param partNums
	 * @return list of HTS codes
	 * @throws DaoException
	 */
	List<HTSCodes> getHtsCodes(List<String> partNums) throws DaoException;
	/**
	 * This method reads PartNumber,HTSCode records from
	 * CAT_ID_USHTS_XREF table which were last updt in the last 24 hours.
	 * @return
	 * @throws DaoException
	 */
	List<HTSCodes> getHtsChngdParts(Timestamp tmstmp) throws DaoException;
	/**
	 * 
	 * @param partNum
	 * @param timestamp
	 * @return
	 * @throws DaoException
	 */
	public int updateHtsCd(String partNum,Timestamp timestamp) throws DaoException;
}
