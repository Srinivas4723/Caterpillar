package com.cat.logistics.tis.dao.impl;

import java.sql.Timestamp;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.criterion.Restrictions;
import org.springframework.transaction.annotation.Transactional;

import com.cat.logistics.shared.dao.impl.GenericJpaDao;
import com.cat.logistics.shared.exception.DaoException;
import com.cat.logistics.shared.utils.PersistenceConstants;
import com.cat.logistics.tis.dao.IHTSCodesDAO;
import com.cat.logistics.tis.entities.HTSCodes;

/**
 * This class act as DAO layer to perform HTS Code operations
 * @author ganamr
 *
 */
public class HTSCodesDAO extends GenericJpaDao< HTSCodes, String>implements IHTSCodesDAO {

	public static final Logger LOGGER = LogManager.getLogger(HTSCodesDAO.class);
	/**
	 * fetches the Hts code information
	 * @param partNums
	 * @return the list of HTS code
	 * @throws DaoException
	 */
	@SuppressWarnings("unchecked")
	@Override
	@Transactional
	public List<HTSCodes> getHtsCodes(List<String> partNums) throws DaoException {
		LOGGER.info("Entry method of getHtsCodes {}",PersistenceConstants.METHOD_ENTRY);
		Criteria criteria = null;
		List<HTSCodes> partHtsCodes = null;
		try{
			criteria = getTisSession().createCriteria(HTSCodes.class);
			criteria.add(Restrictions.in(PersistenceConstants.PRT_NUM_PART_ID_VAR, partNums));
			partHtsCodes =( List<HTSCodes>)criteria.list();
			
		}catch(Exception exception){
			LOGGER.error("Error in getHtsCodes ", exception);
			throw new DaoException(exception);
		}
		LOGGER.info("Exit method of getHtsCodes {}",PersistenceConstants.METHOD_EXIT);
		return partHtsCodes;
	}
	/**
	 * This method reads PartNumber,HTSCode records from
	 * CAT_ID_USHTS_XREF table which were last updt in the last 24 hours.
	 */
	@SuppressWarnings("unchecked")
	@Override
	@Transactional
	public List<HTSCodes> getHtsChngdParts(Timestamp tmstmp) throws DaoException {
		LOGGER.info("Entry method of getHtsChngdParts {}",PersistenceConstants.METHOD_ENTRY);
		List<HTSCodes> htsCodes = null;
		Criteria criteria = null;
		try{
			criteria = getTisSession().createCriteria(HTSCodes.class);
			criteria.add(Restrictions.gt(PersistenceConstants.LAST_UDT_TS_VAR, tmstmp));
			//criteria.add(Restrictions.eq(PersistenceConstants.PRT_NUM_PART_ID_VAR, "   4451443          "));
			//criteria.add(Restrictions.between(PersistenceConstants.LAST_UDT_TS_VAR,frmTm, toTm));
			htsCodes =( List<HTSCodes>)criteria.list();
			
		}catch(Exception exception){
			LOGGER.error("Error in getHtsChngdParts", exception);
			throw new DaoException(exception);
		}
		return htsCodes;
	}

	/**
	 * 
	 */
	@SuppressWarnings("unchecked")
	@Override
	@Transactional
	public int updateHtsCd(String partNum,Timestamp timestamp) throws DaoException{
		LOGGER.info("Entry method of updateHtsCd {}",PersistenceConstants.METHOD_ENTRY);
		int update = 0;
		try{
			Query query = getTisSession().createQuery("update com.cat.logistics.tis.entities.HTSCodes c set c.lstTm = :lstTm where c.partId = :partId");
			query.setParameter("lstTm", timestamp);
			query.setParameter("partId", partNum);
			
			update = query.executeUpdate();
		}catch(Exception exception){
			LOGGER.error("Error in updateHtsCd", exception);
			throw new DaoException(exception);
		}
		
		return update;
	}
	
}
