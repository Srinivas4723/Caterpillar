package com.cat.logistics.tis.dao.impl;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.springframework.transaction.annotation.Transactional;

import com.cat.logistics.epa.job.utils.BatchConstants;
import com.cat.logistics.shared.dao.impl.GenericJpaDao;
import com.cat.logistics.shared.exception.DaoException;
import com.cat.logistics.shared.utils.PersistenceConstants;
import com.cat.logistics.tis.dao.IConfigDataDAO;
import com.cat.logistics.tis.entities.ConfigData;
/**
 * 
 * @author chanda15
 *
 */
public class ConfigDataDAO extends GenericJpaDao<ConfigData, String> implements IConfigDataDAO {

	public static final Logger LOGGER = LogManager.getLogger(ConfigDataDAO.class);
	
	
	/**
	 * Reads the non classifiable parts on TIS codes table 271
	 * @param codeType
	 * @param partNums
	 * @return
	 * @throws DaoException
	 */
	@SuppressWarnings("unchecked")
	@Override
	@Transactional
	public List<String> getConfigData(String codeType,List<String> partNums)throws DaoException {
		LOGGER.info("Entry method of getConfigData {}",PersistenceConstants.METHOD_ENTRY);
		Criteria criteria = null;
		List<String> classifiableParts = null;
		try{
			 criteria = getTisSession().createCriteria(ConfigData.class);
			 criteria.add(Restrictions.eq(PersistenceConstants.CODE_TYP_VAR, codeType));
			 criteria.add(Restrictions.in(PersistenceConstants.CD_KEY_VAL_VAR, partNums));
			 ProjectionList projectionList = Projections.projectionList();
			 projectionList.add(Projections.property(PersistenceConstants.CD_KEY_VAL_VAR));
			 
			 criteria.setProjection(projectionList);
			 
			 classifiableParts = (List<String> )criteria.list();
			 
		}catch(Exception exception){
			LOGGER.error("Error in getConfigData ", exception);
			throw new DaoException(exception);
		}
		LOGGER.info("Exit method of getConfigData {}",PersistenceConstants.METHOD_EXIT);
		return classifiableParts;
	}

}
