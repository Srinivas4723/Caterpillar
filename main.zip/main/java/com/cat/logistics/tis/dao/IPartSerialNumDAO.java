package com.cat.logistics.tis.dao;

import com.cat.logistics.shared.exception.DaoException;
import com.cat.logistics.tis.entities.PartSerialNum;

/**
 * Interface for PartSerialNumDAO impl class
 * @author ganamr
 *
 */
public interface IPartSerialNumDAO {

	/**
	 * @param partSerialNum
	 * @return the PartSerialNum
	 * @throws DaoException
	 */
	PartSerialNum getPartSerNum(PartSerialNum partSerialNum) throws DaoException;
}
