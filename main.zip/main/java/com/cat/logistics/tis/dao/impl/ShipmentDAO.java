package com.cat.logistics.tis.dao.impl;

import java.sql.Timestamp;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Conjunction;
import org.hibernate.criterion.Disjunction;
import org.hibernate.criterion.Restrictions;
import org.springframework.transaction.annotation.Transactional;

import com.cat.logistics.epa.entities.EpaShipment;
import com.cat.logistics.epa.job.utils.BatchConstants;
import com.cat.logistics.shared.dao.impl.GenericJpaDao;
import com.cat.logistics.shared.exception.DaoException;
import com.cat.logistics.shared.utils.PersistenceConstants;
import com.cat.logistics.tis.dao.IShipmentDAO;
import com.cat.logistics.tis.entities.SupplierInvoiceItem;

/**
 * This class act as DAO layer to perform Shipment related operations
 * @author ganamr
 *
 */
public class ShipmentDAO  extends GenericJpaDao<SupplierInvoiceItem, String> implements IShipmentDAO{

	public static final Logger LOGGER = LogManager.getLogger(ShipmentDAO.class);
	
	
	/**
	 * fetches Supplier invoice items for given between last updated time stamp duration
	 * @param ignrFacList 
	 * @param allowOrgFacList 
	 * @param timeStamp
	 * @return list of SupplierInvoiceItems
	 * @throws DaoException
	 */
	@SuppressWarnings("unchecked")
	@Override
	@Transactional
	public List<SupplierInvoiceItem> getShipmentParts(Timestamp frmTm,Timestamp toTm, String[] ignrFacList, String[] allowOrgFacList) throws DaoException{
		
		LOGGER.info("Entry method of getShipmentParts {}",PersistenceConstants.METHOD_ENTRY);
		Session tisSession = null;
		List<SupplierInvoiceItem> parts = null;
		
		try{
		tisSession = getTisSession();
		Criteria criteria = tisSession.createCriteria(SupplierInvoiceItem.class);
		criteria.createAlias(PersistenceConstants.SUPP_LD_ALIAS, PersistenceConstants.SUPP_LD_ALIAS);
		criteria.add(Restrictions.between(PersistenceConstants.SUPP_LAST_UDT_TS_VAR,frmTm, toTm));
		criteria.add(Restrictions.eq(PersistenceConstants.SUPP_LD_DEST_CTRY_CD_VAR, PersistenceConstants.CTRY_CD_US));
		criteria.add(Restrictions.ne(PersistenceConstants.SUPP_LD_ORIG_CTRY_CD_VAR, PersistenceConstants.CTRY_CD_US));
		
		buildFacilityCriteria(ignrFacList, allowOrgFacList, criteria);
		
		parts = criteria.list();
		}catch(Exception exc) {
			LOGGER.error("Error in getShipmentParts {}", exc.getMessage(),  exc);
			throw new DaoException(exc);
	}
		return parts;
		
	}

	/**
	 * This method is used to build restriction criteria to ignore certain facility codes pulling from TIS
	 *  and to allow pulling the details if it contains the corresponding origin facility code which is in allowOrgFacList
	 * @param ignrFacList
	 * @param allowOrgFacList
	 * @param criteria
	 */
	private void buildFacilityCriteria(String[] ignrFacList, String[] allowOrgFacList, Criteria criteria) {
		Disjunction orCriteria = Restrictions.disjunction();
		orCriteria.add(Restrictions.in(PersistenceConstants.SUPP_LD_ORIG_FAC_CD_VAR, allowOrgFacList));
		orCriteria.add(Restrictions.not(Restrictions.in(PersistenceConstants.SUPP_RECV_FAC_CD_VAR, ignrFacList)));
		criteria.add(orCriteria);
	}
	
	/**
	 * fetches Engine shipment details for the given engine sequence seq number
	 * @param engineSeqNo
	 * @return the EpaShipment
	 */
	@Override
	@Transactional
	public EpaShipment getShipmentEngineInfo(long engineSeqNo) {
		LOGGER.info("Entry method of getShipmentEngineInfo {}",PersistenceConstants.METHOD_ENTRY);
		EpaShipment editEngInfo = null;
		
		try{
			Criteria criteria = getSession().createCriteria(EpaShipment.class);
			criteria.add(Restrictions.eq(PersistenceConstants.EPA_SEQ_NUM, engineSeqNo));
			editEngInfo = (EpaShipment) criteria.uniqueResult();
		}catch(Exception exc){
			LOGGER.error("Error in getShipmentEngineInfo {}", exc.getMessage(),  exc);
		}
		
		return editEngInfo;
	}

	/**
	 * Fetches part details from supp_invc_itm  table
	 * for the list of part numbers passed as input
	 */
	@SuppressWarnings("unchecked")
	@Override
	@Transactional
	public List<SupplierInvoiceItem> getPartsDetails(Map<String,String> partDetMap, String[] ignrFacList, String[] allowOrgFacList)
			throws DaoException {
		LOGGER.info("Entry method of getPartsDetails {}",PersistenceConstants.METHOD_ENTRY);
		Session session = null;
		List<SupplierInvoiceItem> htsParts = null;
		
		try{
		session = getTisSession();
		Criteria htsCriteria = session.createCriteria(SupplierInvoiceItem.class);
		htsCriteria.createAlias(PersistenceConstants.SUPP_LD_ALIAS, PersistenceConstants.SUPP_LD_ALIAS);

		Disjunction orCriteria = Restrictions.disjunction();
		for(Entry<String, String> entry : partDetMap.entrySet()){
	        Conjunction objConjunction = Restrictions.conjunction();
	        objConjunction.add(Restrictions.eq("invoicePk."+PersistenceConstants.PART_NUM, entry.getKey()));
	        objConjunction.add(Restrictions.eq("partTyp", entry.getValue()));
	        orCriteria.add(objConjunction);
		}
		htsCriteria.add(orCriteria);
		
		htsCriteria.add(Restrictions.eq(PersistenceConstants.SUPP_LD_DEST_CTRY_CD_VAR, PersistenceConstants.CTRY_CD_US));
		htsCriteria.add(Restrictions.ne(PersistenceConstants.SUPP_LD_ORIG_CTRY_CD_VAR, PersistenceConstants.CTRY_CD_US));

		buildFacilityCriteria(ignrFacList, allowOrgFacList, htsCriteria);
		
		htsParts = htsCriteria.list();
		System.out.println(htsParts.size());
		}catch(Exception exc) {
			LOGGER.error("Error in getPartsDetails {}", exc.getMessage(),  exc);
			throw new DaoException(exc);
	}
		return htsParts;
		
		
	}
	
}
