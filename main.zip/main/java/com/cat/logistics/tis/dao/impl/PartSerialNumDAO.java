package com.cat.logistics.tis.dao.impl;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.transaction.annotation.Transactional;

import com.cat.logistics.shared.dao.impl.GenericJpaDao;
import com.cat.logistics.shared.exception.DaoException;
import com.cat.logistics.shared.utils.PersistenceConstants;
import com.cat.logistics.tis.dao.IPartSerialNumDAO;
import com.cat.logistics.tis.entities.PartSerialNum;
/**
 * 
 * @author chanda15
 *
 */
public class PartSerialNumDAO extends GenericJpaDao<PartSerialNum, String> implements IPartSerialNumDAO {

	public static final Logger LOGGER = LogManager.getLogger(PartSerialNumDAO.class);
	/**
	 * @param partSerialNum
	 * @return
	 * @throws DaoException
	 */
	@Override
	@Transactional
	public PartSerialNum getPartSerNum(PartSerialNum partSerialNum)
			throws DaoException {
		LOGGER.info("Entry method of getPartSerNum {}",PersistenceConstants.METHOD_ENTRY);
		PartSerialNum partSerial = null;
		try{
			Criteria criteria = getTisSession().createCriteria(PartSerialNum.class);
			criteria.add(Restrictions.eq(PersistenceConstants.PRT_NUM_SEQ_VAR, partSerialNum.getSeqNum()));
			criteria.add(Restrictions.eq(PersistenceConstants.PRT_NUM_INVC_NUM_VAR, partSerialNum.getInvoiceNum()));
			criteria.add(Restrictions.eq(PersistenceConstants.PRT_NUM_SUPP_CD_VAR, partSerialNum.getSuppCd()));
			criteria.add(Restrictions.eq(PersistenceConstants.PRT_NUM_LD_TMSTMP_VAR, partSerialNum.getSuppLdTmstmp()));
			
			partSerial = (PartSerialNum)criteria.uniqueResult();

		}catch(Exception exception){
			LOGGER.error("Error in getPartSerNum", exception);
			throw new DaoException(exception);
		}
		LOGGER.info("Exit method of getPartSerNum {}",PersistenceConstants.METHOD_EXIT);
		return partSerial;
	}

}
