package com.cat.logistics.tis.dao;

import java.util.List;

import com.cat.logistics.shared.exception.DaoException;

/**
 * This class is Interface for ConfigDataDAO implementation class
 * @author ganamr
 *
 */
public interface IConfigDataDAO {

	/**
	 * @param codeType
	 * @param partNums
	 * @return the list of configuration data
	 * @throws DaoException
	 */
	List<String>  getConfigData(String codeType,List<String> partNums) throws DaoException;
}
