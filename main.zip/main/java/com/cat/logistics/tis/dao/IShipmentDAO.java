package com.cat.logistics.tis.dao;

import java.sql.Timestamp;
import java.util.List;
import java.util.Map;

import com.cat.logistics.epa.entities.EpaShipment;
import com.cat.logistics.shared.exception.DaoException;
import com.cat.logistics.tis.entities.SupplierInvoiceItem;

/**
 * Interface for ShipmentDAO implementation class
 * @author ganamr
 *
 */
public interface IShipmentDAO {

	/**
	 * @param allowOrgFacList 
	 * @param timeStamp
	 * @return the SupplierInvoiceItem
	 * @throws DaoException
	 */
	List<SupplierInvoiceItem> getShipmentParts(Timestamp frmTm,Timestamp toTm, String[] ignrFacList, String[] allowOrgFacList) throws DaoException;

	/**
	 * @param engineSeqNo
	 * @return the EpaShipment
	 */
	public EpaShipment getShipmentEngineInfo(long engineSeqNo);
	
	/**
	 * @param partDetMap
	 * @param ignrFacList
	 * @param allowOrgFacList
	 * @return
	 * @throws DaoException
	 */
	List<SupplierInvoiceItem> getPartsDetails(Map<String,String> partDetMap, String[] ignrFacList, String[] allowOrgFacList) throws DaoException;
	
}
