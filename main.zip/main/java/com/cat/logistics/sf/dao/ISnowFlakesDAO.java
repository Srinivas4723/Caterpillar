package com.cat.logistics.sf.dao;

import java.util.List;
import java.util.Map;

import com.cat.logistics.shared.exception.DaoException;
import com.cat.logistics.tis.entities.HTSCodes;
import com.cat.logistics.tis.entities.SupplierInvoiceItem;

/**
 *
 */
public interface ISnowFlakesDAO {

	/**
	 * @param allowOrgFacList 
	 * @param timeStamp
	 * @return the SupplierInvoiceItem
	 * @throws DaoException
	 */
	List<SupplierInvoiceItem> getShipmentParts(String frmTm,String toTm) throws DaoException;
	
	Map<String,String> getOrigCtryCodbyFaccd() throws DaoException;
	
	Map<String,String> getCommodityCdByDesc() throws DaoException;
	
	List<String> nonClassifiableParts(List<String> partsList) throws DaoException;

	List<HTSCodes> getHrmnzCodesList(List<String> partsList) throws DaoException;
}
