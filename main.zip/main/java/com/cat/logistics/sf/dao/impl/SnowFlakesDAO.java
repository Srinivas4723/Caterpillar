package com.cat.logistics.sf.dao.impl;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;

import com.cat.logistics.epa.job.utils.Utils;
import com.cat.logistics.sf.dao.ISnowFlakesDAO;
import com.cat.logistics.shared.exception.DaoException;
import com.cat.logistics.shared.utils.PersistenceConstants;
import com.cat.logistics.tis.entities.HTSCodes;
import com.cat.logistics.tis.entities.InvcPk;
import com.cat.logistics.tis.entities.SupplierInvoiceItem;
import com.cat.logistics.tis.entities.SupplierLoad;

/**
 * This class act as DAO layer to perform snowflakes related operations
 * 
 * @author neelask
 *
 */
public class SnowFlakesDAO implements ISnowFlakesDAO {

	private final static Logger logger = LogManager.getLogger(SnowFlakesDAO.class);

	private static final String GET_SHIP_PARTS1 = "select a.DESC, b.INVC_NO , a.ORG_FAC_CD, b.LN_SEQ_NO, b.PART_NO, b.SUPP_CD, a.ISRT_TS, a.UPDT_TS,b.RCVG_FAC_CD, b.PART_TYP, a.RCPT_LOC_DT, b.ORD_NO, b.PROD_SER_NO "
			+ "from OUTPUT_ONESRC.HDR_CNFGR a, OUTPUT_ONESRC.DET_CNFGR b " + " where a.UPDT_TS between '";

	private static final String GET_SHIP_PARTS2 = "' and '";
	private static final String GET_SHIP_PARTS3 = "' "
			+ "and a.isrt_ts = (select max(c.isrt_ts) from OUTPUT_ONESRC.HDR_CNFGR C where a.INVC_NO = c.INVC_NO) and b.INVC_NO = a.INVC_NO and a.SUPP_CD=b.SUPP_CD and a.IMP_EXP_FLG = 'I' "
			+ " and a.EXPT_CTRY != 'US' " + " and b.LN_SEQ_NO != 0 ";

	private static final String ORG_CTRY_CODE_QUERY = "SELECT FAC_ID,FAC_CTRY_CD FROM STG_MST.FAC";

	private static final String COMD_CODE = "select TYP_DESC, TYP_PARM from BASE.CNFGR_DTA where CNFGR_TYP = 'CMDTY-INFO' ";

	private static final String hrmnzbyPartNo = "select PART_NO, HRMNZ_TRF_SCH_NO, UPDT_TS, ENTY from BASE.PROD_CLSF where CTRY_CD = 'US' and PART_NO in (?)";

	private static final String NON_CLASS = "select TYP_PARM from BASE.CNFGR_DTA where CNFGR_TYP = 'BYPS-PART' and TYP_PARM IN (?)";

	/*
	 * (non-Javadoc) Gets shipment parts from snowflakes
	 * 
	 * @see
	 * com.cat.logistics.sf.dao.ISnowFlakesDAO#getShipmentParts(java.lang.String,
	 * java.lang.String)
	 */
	public List<SupplierInvoiceItem> getShipmentParts(String frmTm, String toTm) throws DaoException {

		logger.info(SnowFlakesDAO.class + PersistenceConstants.MTD_GET_SHIP_PARTS + PersistenceConstants.METHOD_ENTRY);
		Connection conn = null;
		PreparedStatement prepStmt = null;
		List<SupplierInvoiceItem> partsList = new ArrayList<SupplierInvoiceItem>();

		try {

			conn = getSnowflakesConnection();
			prepStmt = conn.prepareStatement(GET_SHIP_PARTS1 + frmTm + GET_SHIP_PARTS2 + toTm + GET_SHIP_PARTS3);

			ResultSet rs = prepStmt.executeQuery();
			while (rs.next()) {

				SupplierInvoiceItem suppInvc = new SupplierInvoiceItem();
				InvcPk invoicePk = new InvcPk();
				SupplierLoad suppLoad = new SupplierLoad();

				invoicePk.setInvoiceNumber(rs.getString(2));
				invoicePk.setItmSeqNo(rs.getString(4));
				if (rs.getString(5) != null) {
					invoicePk.setPartNum(rs.getString(5).trim());
				}
				invoicePk.setSuppCd(rs.getString(6));
				invoicePk.setSuppLdTmstmp(rs.getTimestamp(7));

				suppInvc.setLastUpdtTmstmp(rs.getTimestamp(8));
				suppInvc.setRcvgFac(rs.getString(9));
				suppInvc.setPartTyp(rs.getString(10));

				suppLoad.setOrigFacCd(rs.getString(3));
				suppLoad.setOriginshpDate(rs.getDate(11));
				suppLoad.setLoadNum(rs.getString(12));

				suppInvc.setDesc(rs.getString(1));
				if (rs.getString(13) == null || rs.getString(13).trim().equals("")) {
					suppInvc.setProdSerNum(null);
				} else {
					suppInvc.setProdSerNum(rs.getString(13));
				}

				suppInvc.setInvoicePk(invoicePk);
				suppInvc.setSuppLoad(suppLoad);

				partsList.add(suppInvc);
			}

		} catch (Exception exc) {
			logger.error(this.getClass() + PersistenceConstants.MTD_GET_SHIP_PARTS + exc.getMessage());
			throw new DaoException(exc);
		} finally {
			clearSysProperties();
		}
		logger.info(SnowFlakesDAO.class + "number of parts retrieved" + partsList.size());
		logger.info(SnowFlakesDAO.class + PersistenceConstants.MTD_GET_SHIP_PARTS + PersistenceConstants.METHOD_EXIT);
		return partsList;

	}

	/**
	 * Gets snowflakes connection
	 * 
	 * @return
	 * @throws SQLException
	 */
	public Connection getSnowflakesConnection() throws SQLException {

		try {
			Class.forName("net.snowflake.client.jdbc.SnowflakeDriver");
		} catch (ClassNotFoundException e) {
			logger.error(this.getClass() + "Get snowflakes connection error " + e.getMessage());

		}

		Properties config = Utils.loadPropertiesFile();
		Properties properties = new Properties();
		properties.put("user", config.getProperty("snowflakes.user"));
		properties.put("password", config.getProperty("snowflakes.key"));
		properties.put("schema", config.getProperty("snowflakes.schema"));
		properties.put("db", config.getProperty("snowflakes.db"));
		properties.put("warehouse", config.getProperty("snowflakes.warehouse"));

		System.getProperties().put("http.proxySet", "true");
		System.getProperties().put("http.proxyHost", "proxy.cat.com");
		System.getProperties().put("https.proxyHost", "proxy.cat.com");
		System.getProperties().put("http.proxyPort", "80");
		System.getProperties().put("https.proxyPort", "80");
		System.getProperties().put("http.nonProxyHosts", "*.cat.com | localhost");

		String connectStr = System.getenv("SF_JDBC_CONNECT_STRING");
		if (connectStr == null) {
			connectStr = config.getProperty("snowflakes_connectStr");
		}
		return DriverManager.getConnection(connectStr, properties);
	}

	/*
	 * (non-Javadoc) Gets origin country code by facility code
	 * 
	 * @see com.cat.logistics.sf.dao.ISnowFlakesDAO#getOrigCtryCodbyFaccd()
	 */
	public Map<String, String> getOrigCtryCodbyFaccd() throws DaoException {

		Connection conn = null;
		PreparedStatement prepStmt = null;
		Map<String, String> facCdOrigCtryCdMap = new HashMap<String, String>();

		try {

			conn = getSnowflakesConnection();
			prepStmt = conn.prepareStatement(ORG_CTRY_CODE_QUERY);

			ResultSet rs = prepStmt.executeQuery();
			while (rs.next()) {
				facCdOrigCtryCdMap.put(rs.getString(1), rs.getString(2));
			}

		} catch (Exception exc) {
			logger.error(this.getClass() + "getOrigCtryCodbyFaccd" + exc.getMessage());
			throw new DaoException(exc);
		} finally {
			clearSysProperties();
		}

		return facCdOrigCtryCdMap;
	}

	/*
	 * (non-Javadoc) gets the commodity code by descritption
	 * 
	 * @see com.cat.logistics.sf.dao.ISnowFlakesDAO#getCommodityCdByDesc()
	 */
	public Map<String, String> getCommodityCdByDesc() throws DaoException {
		Connection conn = null;
		PreparedStatement prepStmt = null;
		Map<String, String> descAndComdCdMap = new HashMap<String, String>();

		try {

			conn = getSnowflakesConnection();
			prepStmt = conn.prepareStatement(COMD_CODE);

			ResultSet rs = prepStmt.executeQuery();
			while (rs.next()) {
				descAndComdCdMap.put(rs.getString(1), rs.getString(2));
			}

		} catch (Exception exc) {
			logger.error(this.getClass() + PersistenceConstants.MTD_GET_SHIP_PARTS + exc.getMessage());
			throw new DaoException(exc);
		} finally {
			clearSysProperties();
		}

		return descAndComdCdMap;
	}

	/*
	 * (non-Javadoc) Gets non classifialle parts list
	 * 
	 * @see
	 * com.cat.logistics.sf.dao.ISnowFlakesDAO#nonClassifiableParts(java.util.List)
	 */
	public List<String> nonClassifiableParts(List<String> partsList) throws DaoException {
		Connection conn = null;
		PreparedStatement prepStmt = null;
		List<String> nonClasPartsList = new ArrayList<String>();

		String queryPart = "";
		for (String str : partsList) {
			queryPart = queryPart + "'" + str + "',";
		}
		queryPart = NON_CLASS;

		try {

			conn = getSnowflakesConnection();
			prepStmt = conn.prepareStatement(queryPart);
			prepStmt.setString(1, queryPart.substring(0, queryPart.length() - 1));

			ResultSet rs = prepStmt.executeQuery();
			while (rs.next()) {
				nonClasPartsList.add(rs.getString(1));

			}

		} catch (Exception exc) {
			logger.error(this.getClass() + "nonClassifiableParts" + exc.getMessage());
			throw new DaoException(exc);
		} finally {
			clearSysProperties();
		}

		return nonClasPartsList;
	}


	public List<HTSCodes> getHrmnzCodesList(List<String> partsList) throws DaoException {

		Connection conn = null;
		PreparedStatement prepStmt = null;
		List<HTSCodes> hrmnzHtsCodeList = new ArrayList<HTSCodes>();
		String updatedQuery = null;
		updatedQuery = "select PART_NO, HRMNZ_TRF_SCH_NO, UPDT_TS, ENTY from BASE.PROD_CLSF where CTRY_CD = 'US' and PART_NO IN ";
		StringBuilder parameterBuilder = new StringBuilder();
        parameterBuilder.append(" (");
        for (int i = 0; i < partsList.size(); i++) {
            parameterBuilder.append("?");
            if (partsList.size() > i + 1) {
                parameterBuilder.append(",");
            }
        }
        parameterBuilder.append(")");
		try {
			conn = getSnowflakesConnection();
			prepStmt = conn.prepareStatement(updatedQuery+parameterBuilder);
			for (int i = 1; i < partsList.size() + 1; i++) {
				prepStmt.setString(i, partsList.get(i - 1));
	        }
			ResultSet rs = prepStmt.executeQuery();
			while (rs.next()) {
				String partType = rs.getString(4);
				if (partType != null && partType.equalsIgnoreCase("")) {
					HTSCodes hTSCodes = new HTSCodes();
					hTSCodes.setPartId(rs.getString(1));
					String hrmzCode = rs.getString(2);
					if (hrmzCode != null && hrmzCode.length() == 10) {
						String newString = hrmzCode.substring(0, 4) + "." + hrmzCode.substring(4, 6) + "."
								+ hrmzCode.substring(6, 10);
						hTSCodes.setHtsCode(newString);
					}
					hTSCodes.setLstTm(rs.getTimestamp(3));
					hTSCodes.setPartTyp(partType);
					hrmnzHtsCodeList.add(hTSCodes);
				}
			}

		} catch (Exception exc) {
			logger.error(this.getClass() + "getHrmnzCodesList" + exc.getMessage());
			throw new DaoException(exc);
		} finally {
			clearSysProperties();
		}

		return hrmnzHtsCodeList;
	}

	private void clearSysProperties() {

		System.clearProperty("http.proxySet");
		System.clearProperty("http.proxyHost");
		System.clearProperty("https.proxyHost");
		System.clearProperty("http.proxyPort");
		System.clearProperty("https.proxyPort");
		System.clearProperty("http.nonProxyHosts");
	}

}
