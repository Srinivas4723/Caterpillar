package com.cat.logistics.epa.tis.service;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Map.Entry;
import java.util.Set;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import com.cat.logistics.epa.dao.IEpaConfigDAO;
import com.cat.logistics.epa.dao.IEpaDataConfigDAO;
import com.cat.logistics.epa.dao.impl.EpaEngineDAO;
import com.cat.logistics.epa.dto.EpaShipmentDTO;
import com.cat.logistics.epa.entities.EpaConfig;
import com.cat.logistics.epa.entities.EpaDataCnfgr;
import com.cat.logistics.epa.job.tis.ITISService;
import com.cat.logistics.epa.job.utils.BatchConstants;
import com.cat.logistics.epa.job.utils.BatchContext;
import com.cat.logistics.epa.job.utils.Utils;
import com.cat.logistics.sf.dao.ISnowFlakesDAO;
import com.cat.logistics.shared.exception.DaoException;
import com.cat.logistics.shared.exception.ServiceException;
import com.cat.logistics.shared.utils.EPAUtils;
import com.cat.logistics.shared.utils.PersistenceConstants;
import com.cat.logistics.tis.dao.IConfigDataDAO;
import com.cat.logistics.tis.dao.IHTSCodesDAO;
import com.cat.logistics.tis.dao.IPartSerialNumDAO;
import com.cat.logistics.tis.dao.IShipmentDAO;
import com.cat.logistics.tis.entities.HTSCodes;
import com.cat.logistics.tis.entities.PartSerialNum;
import com.cat.logistics.tis.entities.SupplierInvoiceItem;
import com.cat.logistics.tis.entities.SupplierLoad;


/**
 * 
 * @author chanda15
 *
 */
public class TISService implements ITISService{

	@Autowired
	private IShipmentDAO  shipmentDao;
	
	@Autowired
	private IConfigDataDAO configDataDao;
	
	@Autowired
	private IHTSCodesDAO htsCodesDao;
	
	@Autowired
	private IPartSerialNumDAO partSerialDao;
	
	@Autowired
	private IEpaConfigDAO epaConfigDAO;
	
	@Autowired
	IEpaDataConfigDAO dataConfgDAO;
	
	@Autowired
	ISnowFlakesDAO snowFlakeDAO;
	
	//private ILogger logger = Logger.getInstance();
	private final static Logger logger = LogManager.getLogger(TISService.class);
	
	/** 
	 * Fetches Part info from TIS 
	 * @see com.cat.logistics.epa.job.tis.ITISService#getPartsFrmTIS()
	 */
	public Map<String,EpaShipmentDTO> getPartsFrmTIS() throws ServiceException{
		//logger.informationalEvent(this.getClass(), BatchConstants.MTD_GET_PARTS_FRM_TIS, BatchConstants.EXE_LITERAL+BatchConstants.MTD_GET_PARTS_FRM_TIS);
		logger.info(this.getClass()+ BatchConstants.MTD_GET_PARTS_FRM_TIS+ BatchConstants.EXE_LITERAL+BatchConstants.MTD_GET_PARTS_FRM_TIS);
		List<SupplierInvoiceItem>  shpmntParts = null;
		List<String> partNumbrs  = new ArrayList<String>();
		Map<String,EpaShipmentDTO>  partShipments = new HashMap<String,EpaShipmentDTO>();
		try{
			shpmntParts = getShpmntParts();
		if(shpmntParts != null){
			extractPartNumbers(partNumbrs,shpmntParts,partShipments); //no changes
			//pending wednesday
			filterNonClassifiableParts(partNumbrs,partShipments);
			//getPartSerialNumbers(partShipments); to be deleted
			getHTSCodes(partNumbrs,partShipments);
		}else{
			//logger.informationalEvent(this.getClass(),BatchConstants.MTD_GET_PARTS_FRM_TIS, BatchConstants.NO_INVOCS_TO_PRCS_FR_EPA);
			logger.info(this.getClass() + BatchConstants.MTD_GET_PARTS_FRM_TIS + BatchConstants.NO_INVOCS_TO_PRCS_FR_EPA);
		}
		
		}catch(Exception exception){
			//logger.fatalEvent(getClass(), BatchConstants.MTD_GET_PARTS_FRM_TIS, BatchConstants.FAIL_TO_FETCH_PARTS_FM_TIS, exception);
			logger.error(getClass() + BatchConstants.MTD_GET_PARTS_FRM_TIS + BatchConstants.FAIL_TO_FETCH_PARTS_FM_TIS + exception.getMessage());
			throw new ServiceException(exception);
		}
		
		return partShipments;
	}
	
	/**
	 * The parts which are present in TIS_CODES 237 are NON CLASSIFIABLE. If a part is not 
	 * present then it is CLASSIFIABLE
	 * @param partNums
	 * @param partShipments
	 * @throws ServiceException
	 */
	@SuppressWarnings("rawtypes")
	public void filterNonClassifiableParts(List<String> partNums,Map<String,EpaShipmentDTO>  partShipments) throws ServiceException{
		//logger.informationalEvent(this.getClass(), BatchConstants.MTD_FILTR_NON_CLASIFD_PARTS, BatchConstants.EXE_LITERAL+BatchConstants.MTD_FILTR_NON_CLASIFD_PARTS);
		logger.info(this.getClass() + BatchConstants.MTD_FILTR_NON_CLASIFD_PARTS + BatchConstants.EXE_LITERAL+BatchConstants.MTD_FILTR_NON_CLASIFD_PARTS);
		List<String> existingParts = new ArrayList<String>();
		int strtIndx = 0;
		int offSet = 500;
		int endIndx = offSet;
		int loopCount = 0;
		List<String> subList = null;
		try {
			if(partNums != null && partNums.size() > 0  && partShipments != null && partShipments.size() > 0){
				//logger.informationalEvent(this.getClass(), "filterNonClassifiableParts", "partNums size "+partNums.size());
				logger.info(this.getClass() + "filterNonClassifiableParts" + "partNums size "+partNums.size());
				if (partNums.size() < offSet) {
				offSet = partNums.size();
				endIndx = offSet;
			}
			loopCount = partNums.size() / offSet;

			if (loopCount * offSet < partNums.size()) {
				loopCount++;
			}
			
			while (loopCount > 0) {
				subList = partNums.subList(strtIndx, endIndx);
				validateParts(subList);
				// wednesday bhushan suggested non classifiable query change select * from "ILS_GTI_DEV_DB"."BASE"."CNFGR_DTA" where CNFGR_TYP = 'BYPS-PART' and TYP_PARM = 'OBG001';
			
				
				//existingParts = configDataDao.getConfigData(PersistenceConstants.CD_TYP_237, subList);
				
				if(subList.size() > 0){
					existingParts = snowFlakeDAO.nonClassifiableParts(subList);
				}
			partNums.removeAll(existingParts);
			Set<Entry<String,EpaShipmentDTO>> entries = partShipments.entrySet();
			Iterator entryItr = entries.iterator();
			while(entryItr.hasNext()){
				Entry entry = (Entry) entryItr.next();
				String partNum = (String)entry.getKey();
				
				if(!partNums.contains(Utils.getPartNum(partNum))){
					entryItr.remove();
				}
			}
			loopCount--;
			strtIndx = endIndx + 1;
			endIndx = endIndx + offSet;
			if(endIndx > partNums.size()){
				endIndx = partNums.size();
			}
			}
			//logger.informationalEvent(this.getClass(), "filterNonClassifiableParts", "Number of shipments after filtering non classifiable parts size "+partShipments.size());
			logger.info(this.getClass()+ "filterNonClassifiableParts"+ "Number of shipments after filtering non classifiable parts size "+partShipments.size());
			}
			
		} catch (DaoException daoExcp) {
			//logger.fatalEvent(getClass(), BatchConstants.MTD_FILTR_NON_CLASIFD_PARTS, BatchConstants.FAIL_TP_FILTR_PARTS, daoExcp);
			logger.error(getClass()+ BatchConstants.MTD_FILTR_NON_CLASIFD_PARTS+ BatchConstants.FAIL_TP_FILTR_PARTS+ daoExcp.getMessage());
			//throw new ServiceException(daoExcp);
			
		}catch(Exception exception){
			//logger.fatalEvent(getClass(), BatchConstants.MTD_FILTR_NON_CLASIFD_PARTS,BatchConstants.FAIL_TP_FILTR_PARTS, exception);
			logger.error(getClass()+ BatchConstants.MTD_FILTR_NON_CLASIFD_PARTS +BatchConstants.FAIL_TP_FILTR_PARTS + exception.getMessage());
			//throw new ServiceException(exception);
		}
		
	}
	
	
	/**
	 * @param partNumbers
	 */
	@SuppressWarnings("rawtypes")
	public void validateParts(List<String> partNumbers){
		
		Iterator itr = partNumbers.iterator();
		while(itr.hasNext()){
			String part = (String)  itr.next();
			if(part.length() > 20){
				itr.remove();
			}
		}
	}
	
	/**
	 * @param parts
	 * @param partShpmnts
	 * @throws ServiceException
	 */
	@SuppressWarnings({ "rawtypes" })
	public void getHTSCodes(List<String> partList,Map<String,EpaShipmentDTO>  partShpmnts) throws ServiceException{
		//logger.informationalEvent(this.getClass(), BatchConstants.MTD_GET_HTS_CODES, BatchConstants.EXE_LITERAL+BatchConstants.MTD_GET_HTS_CODES);
		logger.info(this.getClass() + BatchConstants.MTD_GET_HTS_CODES + BatchConstants.EXE_LITERAL+BatchConstants.MTD_GET_HTS_CODES);
		List<HTSCodes> htsCodes = null;
		EpaShipmentDTO shpmntdto = null;
		int startIdx = 0;
		int offSet = 500;
		int endIndex = offSet;
		int loopCnt = 0;
		List<String> subList = null;
		try{
			if(null !=partList && partList.size() > 0){
				//logger.informationalEvent(this.getClass(), BatchConstants.MTD_GET_HTS_CODES, BatchConstants.EXE_LITERAL+BatchConstants.MTD_GET_HTS_CODES +partList.size() );
				logger.info(this.getClass() + BatchConstants.MTD_GET_HTS_CODES + BatchConstants.EXE_LITERAL+BatchConstants.MTD_GET_HTS_CODES +partList.size() );
				if (partList.size() < offSet) {
					offSet = partList.size();
					endIndex = offSet;
				}
				loopCnt = partList.size() / offSet;

				if (loopCnt * offSet < partList.size()) {
					loopCnt++;
				}
				
				while (loopCnt > 0) {
				
					//logger.informationalEvent(this.getClass(), BatchConstants.MTD_GET_HTS_CODES, BatchConstants.EXE_LITERAL+BatchConstants.MTD_GET_HTS_CODES +startIdx+endIndex);
					logger.info(this.getClass()+ BatchConstants.MTD_GET_HTS_CODES+ BatchConstants.EXE_LITERAL+BatchConstants.MTD_GET_HTS_CODES +startIdx+endIndex);
					subList = partList.subList(startIdx, endIndex);
					
					// wednesday changes snow flakes changes select HRMNZ_TRF_SCH_NO from "ILS_GTI_DEV_DB"."OUTPUT_ONESRC"."PROD_CLSF" where CTRY_CD = 'US' and PART_NO = '302';
					//htsCodes = htsCodesDao.getHtsCodes(subList);
					
					if(subList.size() > 0){
						htsCodes = snowFlakeDAO.getHrmnzCodesList(subList);
					}
		
			for(HTSCodes htsCode : htsCodes){
				Iterator keyIterator = partShpmnts.keySet().iterator();
				while(keyIterator.hasNext()){
					String key = keyIterator.next().toString();
					shpmntdto = partShpmnts.get(key);
					if(Utils.getPartNum(key).equalsIgnoreCase(htsCode.getPartId())){
						if(htsCode.getPartTyp().equals(shpmntdto.getPartType())){
							shpmntdto.setHtsCode(htsCode.getHtsCode());
						}else{
							keyIterator.remove();
					}					
				}
			}
			}
			loopCnt--;
			startIdx = endIndex + 1;
			endIndex = endIndex + offSet;
			if(endIndex > partList.size()){
				endIndex = partList.size();
			}
			
		BatchContext.put(BatchConstants.PART_NUM_LIST, partList);
			}
			}
		}catch(Exception exception){
			//logger.fatalEvent(getClass(), BatchConstants.MTD_GET_HTS_CODES, BatchConstants.FAIL_TO_FETCH_HTS_CODES, exception);
			logger.error(getClass() + BatchConstants.MTD_GET_HTS_CODES + BatchConstants.FAIL_TO_FETCH_HTS_CODES+ exception.getMessage());
			throw new ServiceException(exception);
		}
		
	}
	
	/**
	 * This method reads the serial number for a particular part.
	 * @param partShipments
	 * @throws ServiceException
	 */
	@SuppressWarnings("unchecked")
	public void getPartSerialNumbers(Map<String,EpaShipmentDTO>  partShipments) throws ServiceException{
		//logger.informationalEvent(this.getClass(), BatchConstants.MTD_GET_PART_SER_NUM, BatchConstants.EXE_LITERAL+BatchConstants.MTD_GET_PART_SER_NUM);
		logger.info(this.getClass()+ BatchConstants.MTD_GET_PART_SER_NUM+ BatchConstants.EXE_LITERAL+BatchConstants.MTD_GET_PART_SER_NUM);
		PartSerialNum partSerialNum = null;
		EpaShipmentDTO shpmntdto = null;
		List<String> serialNumList = null;
		String prodSerNum = null;
		
		Set<Entry<String,EpaShipmentDTO>> partShpmtEntries = partShipments.entrySet();
		Iterator<Entry<String,EpaShipmentDTO>> partShpMntIterator =  partShpmtEntries.iterator();
		while(partShpMntIterator.hasNext()){
			try{
			Entry<String,EpaShipmentDTO> partShmtEntry = partShpMntIterator.next();
			shpmntdto = partShmtEntry.getValue();
			partSerialNum = populatePartSerialNum(shpmntdto);
/*			
 * wednesday
 * partSerialNum = partSerialDao.getPartSerNum(partSerialNum);
*/			
			if(shpmntdto.getProductSerialNum() != null){
				prodSerNum = shpmntdto.getProductSerialNum();
				//shpmntdto.setProductSerialNum(prodSerNum);
			/*
			 * wednesday
			 * shpmntdto.setSalesMdlNo(partSerialNum.getSalesMdlNo());*/
				
			System.out.println(shpmntdto.getEpaProdTypeCode());
			System.out.println("part serialnum "+prodSerNum);
			serialNumList = (List<String>) BatchContext.getValue(shpmntdto.getEpaProdTypeCode());
			if (prodSerNum != null ) {
				serialNumList.add(prodSerNum);
			}
			}
		}/*catch(DaoException exception){
			logger.fatalEvent(getClass(), BatchConstants.MTD_GET_PART_SER_NUM, BatchConstants.FAIL_TO_FETCH_PART_SERNUM + shpmntdto.getInvoiceNum()+", seqNum :"+shpmntdto.getItmSeqNo(), exception);
			throw new ServiceException(exception);
		}*/catch(Exception exc){
			//logger.fatalEvent(getClass(), BatchConstants.MTD_GET_PART_SER_NUM, BatchConstants.TECH_EXCP_FETCH_PART_SERNUM + shpmntdto.getInvoiceNum()+", seqNum :"+shpmntdto.getItmSeqNo(), exc);
			logger.error(getClass()+ BatchConstants.MTD_GET_PART_SER_NUM+ BatchConstants.TECH_EXCP_FETCH_PART_SERNUM + shpmntdto.getInvoiceNum()+", seqNum :"+shpmntdto.getItmSeqNo() + exc.getMessage());
			throw new ServiceException(exc);
			
		}
		}
		
	}
	
	/**
	 * this method populate partserialnum object based on the values from EpaShipmentDTO
	 * @param shpmntDTO
	 * @return
	 */
	public PartSerialNum populatePartSerialNum(EpaShipmentDTO shpmntDTO){
		//logger.informationalEvent(this.getClass(), BatchConstants.MTD_POPULATE_PART_SER_NUM,BatchConstants.EXE_LITERAL+BatchConstants.MTD_POPULATE_PART_SER_NUM);
		logger.info(this.getClass() + BatchConstants.MTD_POPULATE_PART_SER_NUM +BatchConstants.EXE_LITERAL+BatchConstants.MTD_POPULATE_PART_SER_NUM);
		PartSerialNum partSerialNum = new PartSerialNum();
		partSerialNum.setInvoiceNum(shpmntDTO.getInvoiceNum());
		partSerialNum.setSeqNum(shpmntDTO.getItmSeqNo());
		partSerialNum.setSuppCd(shpmntDTO.getSuppCd());
		partSerialNum.setSuppLdTmstmp(shpmntDTO.getSuppLdTmstmp());
		
		return partSerialNum;
	}
	
	/**
	 * @param invcItm
	 * @return
	 */
	public EpaShipmentDTO populateEpaShpmnt(SupplierInvoiceItem invcItm){
		//logger.informationalEvent(this.getClass(), BatchConstants.MTD_POPULATE_EPA_SHIPMNT, BatchConstants.EXE_LITERAL+BatchConstants.MTD_POPULATE_EPA_SHIPMNT);
		logger.info(this.getClass() + BatchConstants.MTD_POPULATE_EPA_SHIPMNT + BatchConstants.EXE_LITERAL+BatchConstants.MTD_POPULATE_EPA_SHIPMNT);
		EpaShipmentDTO epaShpmnt = new EpaShipmentDTO();
		epaShpmnt.setPartNum(invcItm.getInvoicePk().getPartNum());
		epaShpmnt.setInvoiceNumber(invcItm.getInvoicePk().getInvoiceNumber());
		epaShpmnt.setSuppCd(invcItm.getInvoicePk().getSuppCd());
		epaShpmnt.setRcvgFacCd(invcItm.getRcvgFac());
		epaShpmnt.setPartType(invcItm.getPartTyp());
	if(invcItm.getSuppLoad() != null){
		epaShpmnt.setLoadNum(invcItm.getSuppLoad().getLoadNum());
		
		if(invcItm.getSuppLoad().getSuppLdCmdtyCd().equalsIgnoreCase(BatchConstants.Q_LITERAL)){
			epaShpmnt.setOrigFacCd(BatchConstants.FAC_CD_1111);
		}else{
			epaShpmnt.setOrigFacCd(invcItm.getSuppLoad().getOrigFacCd());
		}
		
		epaShpmnt.setOriginshpDate(invcItm.getSuppLoad().getOriginshpDate());
		epaShpmnt.setDealerCode(invcItm.getSuppLoad().getDealerNumber());
	}
		epaShpmnt.setItmSeqNo(invcItm.getInvoicePk().getItmSeqNo());
		epaShpmnt.setSuppLdTmstmp(invcItm.getInvoicePk().getSuppLdTmstmp());
		
		if(invcItm.getProdSerNum() != null && invcItm.getProdSerNum() !=""){
		epaShpmnt.setProductSerialNum(invcItm.getProdSerNum().toUpperCase().trim());
		}
		return epaShpmnt;
	}
	
	
	/**
	 * @param partNumbers
	 * @param shpmntParts
	 * @param partShipments
	 * @throws Exception 
	 */
	public void extractPartNumbers(List<String> partNumbers,List<SupplierInvoiceItem> shpmntParts,Map<String,EpaShipmentDTO>  partShipments) throws Exception {
		//logger.informationalEvent(this.getClass(), BatchConstants.MTD_EXTRACT_PART_NUMS, BatchConstants.EXE_LITERAL+BatchConstants.MTD_EXTRACT_PART_NUMS);
		logger.info(this.getClass()+ BatchConstants.MTD_EXTRACT_PART_NUMS+ BatchConstants.EXE_LITERAL+BatchConstants.MTD_EXTRACT_PART_NUMS);
		EpaShipmentDTO shmntdto = null;
		Set<String> setSuppCds=null;
		Set<String> setOrgFacCds=null;
		
		Map<String,Set<String>> excluMap=getExcluSuppCdOrgFacCd();
		
		if(null!=excluMap){
			setSuppCds=excluMap.get(BatchConstants.EXCLUSION_SUPP_CD);
			setOrgFacCds=excluMap.get(BatchConstants.EXCLUSION_ORG_FAC_CD);
		}
		
		for(SupplierInvoiceItem invcItm :shpmntParts ){
			
			shmntdto = populateEpaShpmnt(invcItm);
			if((null == setSuppCds || (null!=setSuppCds && !setSuppCds.contains(shmntdto.getSuppCd()))) &&
					(null == setOrgFacCds || (null!=setOrgFacCds && !setOrgFacCds.contains(shmntdto.getOrigFacCd())))){
				partNumbers.add(invcItm.getInvoicePk().getPartNum());
				partShipments.put(getShpmntKey(invcItm), shmntdto);
			}
			//logger.informationalEvent(this.getClass(), BatchConstants.MTD_EXTRACT_PART_NUMS, getLogKey(invcItm)+getShpmntKey(invcItm));
			logger.info(this.getClass()+ BatchConstants.MTD_EXTRACT_PART_NUMS+ getLogKey(invcItm)+getShpmntKey(invcItm));
		}
	}
	
	/**
	 * generating key value for loggging
	 * @param invcItm
	 * @return
	 */
	public String getShpmntKey(SupplierInvoiceItem invcItm){
		StringBuilder key = new StringBuilder();
		key.append(invcItm.getInvoicePk().getPartNum());
		key.append(BatchConstants.HYPHEN);
		key.append(invcItm.getInvoicePk().getInvoiceNumber());
		key.append(BatchConstants.HYPHEN);
		key.append(invcItm.getInvoicePk().getItmSeqNo());
		key.append(BatchConstants.HYPHEN);
		key.append(invcItm.getInvoicePk().getSuppLdTmstmp());
		key.append(BatchConstants.HYPHEN);
		key.append(invcItm.getSuppLoad().getLoadNum());
		
		return key.toString();
	}
	
	/**
	 * generating key value from sup invc itm for logging
	 * @param invcItm
	 * @return
	 */
	public String getLogKey(SupplierInvoiceItem invcItm){
		StringBuilder logkey = new StringBuilder();
		logkey.append(BatchConstants.INVOICE_PART_UNDRSCR);
		logkey.append(BatchConstants.HYPHEN);
		logkey.append(BatchConstants.UNDRSCR_INVOICE_UNDRSCR);
		logkey.append(BatchConstants.HYPHEN);
		logkey.append(BatchConstants.UNDRSCR_SEQNUM_UNDERSCR);
		logkey.append(BatchConstants.HYPHEN);
		logkey.append(BatchConstants.UNDRSCR_LOADNUM_UNDRSCR);
		
		return logkey.toString();
	}
	
	
	/**
	 * This method reads the shipments in TIS between batch job's last successfully
	 * run timestamp and current timestamp. 
	 * @return
	 * @throws Exception
	 */
	public List<SupplierInvoiceItem> getShpmntParts() throws Exception{
		List<SupplierInvoiceItem>  partsList = null;
		List<SupplierInvoiceItem>  newpartsList = new ArrayList<SupplierInvoiceItem>();
		String lstSccsTm = null;
		String currTm = null;
		//Map<String,String> facCdOrigCtryCdMap = null;
		Map<String,String> descAndComdCdMap = null;
		EpaConfig config = null;
		Map<String, String[]> constraintMap = null;
		String[] ignrFacList = null;
		String[] allowOrgFacList = null;
		config = getLstSccsTm(BatchConstants.APPLICATION_WND);
		
		if(config != null && config.getKeyDesc().equals(BatchConstants.YES_LITERAL)){
			String tmstmp = config.getValueType2();
			
			if(tmstmp != null){
				

				lstSccsTm = tmstmp;
				}else{
					int tim = Integer.parseInt(Utils.getProperty(BatchConstants.READ_TIME));
					lstSccsTm = Utils.getTmStmpinString(tim);
				}
			currTm = Utils.getTmStmpinString(0);
		}else if (config != null && config.getKeyDesc().equals(BatchConstants.NO_LITERAL)){
			
			config = getRunTms();
			if(config != null){
				lstSccsTm = config.getId().getValueType1();
				currTm = config.getValueType2();
			}
		}
		try {
			//constraintMap = getFacConstrtVal();
			/*
			 * wednesday
			 * ignrFacList = constraintMap.get(PersistenceConstants.IGNR_FAC_LIST);
			allowOrgFacList = constraintMap.get(PersistenceConstants.ALLOW_ORG_FAC_LIST);
			partsList = shipmentDao.getShipmentParts(lstSccsTm,currTm, ignrFacList, allowOrgFacList); */
			/* snow flakes main query*/
			/* testing code */
			
			
			//"2021-03-22 18:40:48.672", "2021-03-22 18:48:48.672"
			
			partsList = snowFlakeDAO.getShipmentParts(lstSccsTm, currTm);
			//partsList = snowFlakeDAO.getShipmentParts("2021-03-22 18:40:48.672", "2021-03-22 18:48:48.672");
			//facCdOrigCtryCdMap = snowFlakeDAO.getOrigCtryCodbyFaccd();
			descAndComdCdMap = snowFlakeDAO.getCommodityCdByDesc();
			
			for(SupplierInvoiceItem supp : partsList){
				SupplierLoad suppload= supp.getSuppLoad();
				
				/*String origFacCD = suppload.getOrigFacCd();
				
				if(origFacCD != null && origFacCD != ""){
					String orgctryCd = facCdOrigCtryCdMap.get(origFacCD);
					suppload.setOrigFacCd(orgctryCd);
					
					
				}*/
				
				String desc = supp.getDesc();
				
				if(desc != null && desc != ""){
					String commdityCd = descAndComdCdMap.get(desc);
					suppload.setSuppLdCmdtyCd(commdityCd);
				}
				
				supp.setSuppLoad(suppload);
				newpartsList.add(supp);
				
			}
			
			
		} catch (DaoException exception) {
			//logger.fatalEvent(getClass(), BatchConstants.MTD_GET_SHIP_PARTS, BatchConstants.FAIL_TO_FETCH_SHIP_PARTS, exception);
			logger.error(getClass()+ BatchConstants.MTD_GET_SHIP_PARTS + BatchConstants.FAIL_TO_FETCH_SHIP_PARTS+ exception.getMessage());
			throw new Exception(exception);
		}
		
		
		//logger.informationalEvent(this.getClass(), BatchConstants.MTD_GET_SHP_PARTS, BatchConstants.EXCP_GET_SHP_PARTS+partsList.size());
		logger.info(this.getClass()+ BatchConstants.MTD_GET_SHP_PARTS+ BatchConstants.EXCP_GET_SHP_PARTS+partsList.size());
		return newpartsList;
	}
	
	

	
	
	/**
	 * This method reads the shiments in TIS between batch job's last successfully
	 * run timestamp and current timestamp . If last successfull tmstmp is not available tmstmp less than 
	 * 30 mins from curr tmstmp is set.
	 * @return
	 */
	public EpaConfig getLstSccsTm(String jobName) throws Exception{
		EpaConfig epaCnfg = null;
		try {
			epaCnfg = epaConfigDAO.getLstSccsTm(jobName);
			
		} catch (DaoException exception) {
			//logger.fatalEvent(getClass(), BatchConstants.MTD_GET_LST_SCCS_TM, BatchConstants.FAIL_LST_SCCS_TM, exception);
			logger.error(getClass()+ BatchConstants.MTD_GET_LST_SCCS_TM+ BatchConstants.FAIL_LST_SCCS_TM + exception.getMessage());
			throw new Exception(exception);
		}
		
		return epaCnfg;
	}
	
	/**
	 * This method reads the facility codes from config data for any shipment which needs to be ignored pulling from TIS
	 *  and origin facility codes list which needs to be allowed
	 * @return epaDataCnfgr
	 * @throws Exception
	 */
	public Map<String, String[]> getFacConstrtVal() throws Exception{
		List<EpaDataCnfgr> epaDataCnfgrs = null;
		String[] tempArray =null;
		String[] queryConfig = {PersistenceConstants.IGNR_FAC_LIST,PersistenceConstants.ALLOW_ORG_FAC_LIST};

		Map<String,String[]> constraintVal=null;
		try {
			epaDataCnfgrs = dataConfgDAO.getValueByCnfgrTypes(queryConfig);

			if (!EPAUtils.isListEmpty(epaDataCnfgrs)) {
				constraintVal = new HashMap<String, String[]>();
				for(EpaDataCnfgr dataCfg: epaDataCnfgrs){
					String value = dataCfg.getCnfgrVal();
					tempArray = (value == null) ? null : value.split(",");
					constraintVal.put(dataCfg.getId().getCnfgrTyp(), tempArray);
				}
			}
			
		} catch (DaoException exception) {
			//logger.fatalEvent(getClass(), BatchConstants.MTD_GET_FAC_CONSTRAINTS_VALUES, BatchConstants.FAIL_GET_FAC_CONSTRAINTS_VALUES, exception);
			logger.error(getClass() + BatchConstants.MTD_GET_FAC_CONSTRAINTS_VALUES+ BatchConstants.FAIL_GET_FAC_CONSTRAINTS_VALUES+ exception.getMessage());
			throw new Exception(exception);
		}
		
		return constraintVal;
	}
		
	/**
	 * This method reads the shiments in TIS between batch job's last successfully
	 * run timestamp and current timestamp . If last successfull tmstmp is not available tmstmp less than 
	 * 30 mins from curr tmstmp is set.
	 * @return
	 */
	public EpaConfig getRunTms() throws Exception{
		EpaConfig config = null;
		try {
			config = epaConfigDAO.getRunTms();
			
		} catch (DaoException exception) {
			//logger.fatalEvent(getClass(), BatchConstants.MTD_GET_RN_TMS, BatchConstants.FAIL_GET_RUN_TM, exception);
			logger.error(getClass() + BatchConstants.MTD_GET_RN_TMS+ BatchConstants.FAIL_GET_RUN_TM+ exception.getMessage());
			throw new Exception(exception);
		}
		
		return config;
	}
	
	/**
	 * Retrieve exclusion supp_cd and Fac_cd
	 * @return Map<String,Set<String>> map
	 * @throws Exception
	 */
	private Map<String,Set<String>> getExcluSuppCdOrgFacCd() throws Exception{
		String excSuppList=null;
		String excFacCdList=null;
		String[] arrExclSupp=null;	
		String[] arrExclFac=null;
		List<EpaDataCnfgr> dataCfgList=null;
		Set<String> setSuppCds=null;
		Set<String> setOrgFacCds=null;
		Map<String,Set<String>> map=null;
		
		//logger.informationalEvent(getClass(), BatchConstants.MTD_GET_EXCL_SUPP_FAC_CDS,null);
		logger.info(getClass()+ BatchConstants.MTD_GET_EXCL_SUPP_FAC_CDS);
		
		try {
			dataCfgList = dataConfgDAO.getValueByCnfgrTypes(BatchConstants.EXCLUSION_SUPP_CD, BatchConstants.EXCLUSION_ORG_FAC_CD);
		} catch (DaoException e) {
			//logger.fatalEvent(getClass(), BatchConstants.MTD_GET_EXCL_SUPP_FAC_CDS, BatchConstants.FAIL_TO_EXTRACT_EXCLU_SUPP_CD, e);
			logger.error(getClass()+ BatchConstants.MTD_GET_EXCL_SUPP_FAC_CDS+ BatchConstants.FAIL_TO_EXTRACT_EXCLU_SUPP_CD+ e.getMessage());
			throw new Exception(e);
		}
		
		if(null!=dataCfgList && dataCfgList.size()>0){
			map= new HashMap<String,Set<String>>();
			for(EpaDataCnfgr dataCfg:dataCfgList){
				if(BatchConstants.EXCLUSION_SUPP_CD.equalsIgnoreCase(dataCfg.getId().getCnfgrTyp())){
					excSuppList = dataCfg.getCnfgrVal();
				}else if(BatchConstants.EXCLUSION_ORG_FAC_CD.equalsIgnoreCase(dataCfg.getId().getCnfgrTyp())){
					excFacCdList = dataCfg.getCnfgrVal();
				}
			}
			
			if(null != excSuppList && ""!=excSuppList){
				arrExclSupp=excSuppList.split(BatchConstants.COMMA);
				if(arrExclSupp.length>0){
					List<String> list=Arrays.asList(arrExclSupp);
					setSuppCds = new HashSet<String>(list);
					map.put(BatchConstants.EXCLUSION_SUPP_CD, setSuppCds);
				}
			}
			
			if(null != excFacCdList && ""!=excFacCdList){
				arrExclFac=excFacCdList.split(BatchConstants.COMMA);
				if(arrExclFac.length>0){
					List<String> list=Arrays.asList(arrExclFac);
					setOrgFacCds = new HashSet<String>(list);
					map.put(BatchConstants.EXCLUSION_ORG_FAC_CD, setOrgFacCds);
				}
			}
			
		}
		return map;
		
	}
	/**
	 * 
	 */
	@Override
	public List<HTSCodes> getHtsCdChngs() throws Exception {
		Timestamp lstSccsTm = null;
		EpaConfig	epaConfig = null;
		String tmstmp = null;
		List<HTSCodes> htsCodes = null;
		//logger.informationalEvent(this.getClass(), BatchConstants.MTD_GET_HTS_CODES_CHNGS, BatchConstants.EXE_LITERAL+BatchConstants.MTD_GET_HTS_CODES_CHNGS);
		logger.info(this.getClass() + BatchConstants.MTD_GET_HTS_CODES_CHNGS+ BatchConstants.EXE_LITERAL+BatchConstants.MTD_GET_HTS_CODES_CHNGS);
		try{
			epaConfig = getLstSccsTm(BatchConstants.HTS_JOB_NAME);
			if(epaConfig != null ){
				tmstmp = epaConfig.getValueType2();
			}
			if(tmstmp != null){
			lstSccsTm = Utils.getFrmTmstmp(Timestamp.valueOf(tmstmp));
			}else{
				lstSccsTm = Utils.getHtsTmStmp();
			}
			htsCodes = htsCodesDao.getHtsChngdParts(lstSccsTm);
		}catch(DaoException ex){
			//logger.fatalEvent(this.getClass(), BatchConstants.MTD_GET_HTS_CODES_CHNGS, ex.getMessage(), ex);
			logger.error(this.getClass() + BatchConstants.MTD_GET_HTS_CODES_CHNGS + ex.getMessage());
			throw new Exception(ex);
		}catch(Exception ex){
			//logger.fatalEvent(this.getClass(), BatchConstants.MTD_GET_HTS_CODES_CHNGS, ex.getMessage(), ex);
			logger.error(this.getClass()+ BatchConstants.MTD_GET_HTS_CODES_CHNGS + ex.getMessage());
			throw ex;
		}
		
		return htsCodes;
	}

	
	/**
	 * 
	 */
	@Override
	public Map<String, EpaShipmentDTO> getPartsFrmTIS(Map<String, String> partDetMap)
			throws ServiceException {
		//logger.informationalEvent(this.getClass(), BatchConstants.MTD_GET_PARTS, BatchConstants.EXE_LITERAL+BatchConstants.MTD_GET_PARTS);
		logger.info(this.getClass() + BatchConstants.MTD_GET_PARTS + BatchConstants.EXE_LITERAL+BatchConstants.MTD_GET_PARTS);
		List<SupplierInvoiceItem> invcItms = null;
		List<String> partNumbrs  = new ArrayList<String>();
		Map<String,EpaShipmentDTO>  partShipments = new HashMap<String,EpaShipmentDTO>();

		Map<String, String[]> constraintMap = null;
		String[] ignrFacList = null;
		String[] allowOrgFacList = null;
		
		if(partDetMap != null && !partDetMap.isEmpty())
			try {

				constraintMap = getFacConstrtVal();
				ignrFacList = constraintMap.get(PersistenceConstants.IGNR_FAC_LIST);
				allowOrgFacList = constraintMap.get(PersistenceConstants.ALLOW_ORG_FAC_LIST);
				invcItms = shipmentDao.getPartsDetails(partDetMap, ignrFacList, allowOrgFacList);
			} catch (DaoException e) {
				//logger.fatalEvent(this.getClass(), BatchConstants.MTD_GET_PARTS, e.getMessage(), e);
				logger.error(this.getClass() + BatchConstants.MTD_GET_PARTS + e.getMessage());
				throw new ServiceException(e);
			} catch (Exception e) {
				//logger.fatalEvent(this.getClass(), BatchConstants.MTD_GET_PARTS, e.getMessage(), e);
				logger.error(this.getClass() + BatchConstants.MTD_GET_PARTS + e.getMessage());
			}
			try {
				extractPartNumbers(partNumbrs,invcItms,partShipments);
			} catch (Exception e) {
				e.printStackTrace();
			}
			filterNonClassifiableParts(partNumbrs,partShipments);
			
			
		return partShipments;
	}
	/**
	 * 
	 * @param partShipments
	 */
	public void setHtsCdValidated(Map<String,EpaShipmentDTO>  partShipments){
		Collection<EpaShipmentDTO> shpmntCollection =  partShipments.values();
		for(EpaShipmentDTO shpmntDto : shpmntCollection){
			shpmntDto.setValidHtsCd(true);
		}
	}
}
