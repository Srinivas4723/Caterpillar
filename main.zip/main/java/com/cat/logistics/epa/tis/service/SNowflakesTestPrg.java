package com.cat.logistics.epa.tis.service;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import com.cat.logistics.epa.job.utils.Utils;
import com.cat.logistics.tis.entities.InvcPk;
import com.cat.logistics.tis.entities.SupplierInvoiceItem;
import com.cat.logistics.tis.entities.SupplierLoad;


public class SNowflakesTestPrg {

	public static void main(String[] args) {

			Connection conn = null;
			PreparedStatement prepStmt = null;
			boolean isexist=false;
			List<SupplierInvoiceItem>  partsList = new ArrayList<SupplierInvoiceItem>();
			try {
			//conn = getSnowflakesConnection();
			/*prepStmt = conn.prepareStatement("select a.DESC, b.INVC_NO , a.ORG_FAC_CD, b.LN_SEQ_NO, b.PART_NO, b.SUPP_CD, a.ISRT_TS, a.UPDT_TS,b.RCVG_FAC_CD, b.PART_TYP, a.RCPT_LOC_DT, b.ORD_NO, b.PROD_SER_NO from OUTPUT_ONESRC.HDR_CNFGR a, OUTPUT_ONESRC.DET_CNFGR b "
			+" where a.UPDT_TS between '2021-03-22 18:40:48.672' and '2021-03-22 18:48:48.672' "
		    +" and b.INVC_NO = a.INVC_NO and a.SUPP_CD=b.SUPP_CD and a.IMP_EXP_FLG = 'I' "
			+" and a.EXPT_CTRY != 'US' "
		    +" and b.LN_SEQ_NO != 0 ");*/
			
			
			
			//"2021-03-22 18:40:48.672", "2021-03-22 18:48:48.672"
			
			//prepStmt = conn.prepareStatement("SELECT FAC_ID,FAC_CTRY_CD FROM ILS_GTI_DEV_DB.STG_MST.FAC where FAC_ID='DX'");
			
			//prepStmt = conn.prepareStatement("select TYP_DESC, TYP_PARM from ILS_GTI_DEV_DB.BASE.CNFGR_DTA where CNFGR_TYP = 'CMDTY-INFO' ");
			
			//prepStmt = conn.prepareStatement("select HRMNZ_TRF_SCH_NO from BASE.PROD_CLSF where CTRY_CD = 'US'");]
			
				/* String hrmzCode = "8431499044";
				 String newString = hrmzCode.substring(0, 4)+ "."+ hrmzCode.substring(4,8)+"."+hrmzCode.substring(8,10);
				 System.out.println(newString);*/
				 
			String query = "select TYP_PARM from BASE.CNFGR_DTA where CNFGR_TYP = 'BYPS-PART' and TYP_PARM IN (";
			
			List<String> partsListNew = new ArrayList<String>();
			
			partsListNew.add("abc");
			partsListNew.add("def");
			
			String queryPart = "";
			for(String str : partsListNew){
				queryPart = queryPart+"'"+str+"',";
			}
			queryPart = query+queryPart.substring(0,queryPart.length()-1)+")";
			
			
			prepStmt = conn.prepareStatement("select * from BASE.CNFGR_DTA where CNFGR_TYP = 'BYPS-PART' and TYP_PARM = 'OBG001'");
			    ResultSet rs = prepStmt.executeQuery();
			    
			    while (rs.next()) {
			    	
			    	System.out.println(rs.getString(1));
			    /*	SupplierInvoiceItem suppInvc = new SupplierInvoiceItem();
			    	InvcPk invoicePk = new InvcPk();
			    	SupplierLoad suppLoad = new SupplierLoad();
			    	
			    	invoicePk.setInvoiceNumber(rs.getString(2));
			    	invoicePk.setItmSeqNo(rs.getString(4));
			    	invoicePk.setPartNum(rs.getString(5));
			    	invoicePk.setSuppCd(rs.getString(6));
			    	invoicePk.setSuppLdTmstmp(rs.getTimestamp(7));
			    	
			    	suppInvc.setLastUpdtTmstmp(rs.getTimestamp(8));
			    	suppInvc.setRcvgFac(rs.getString(9));
			    	suppInvc.setPartTyp(rs.getString(10));
			    	
			    	suppLoad.setOrigFacCd(rs.getString(3));
			    	suppLoad.setOriginshpDate(rs.getDate(11));
			    	suppLoad.setLoadNum(rs.getString(12));*/
			    	
			    	
			    	
			    }
			    
			    
			    if ( rs.next() ) {
			    	
			    	System.out.println( rs.getString(1));
			    }
			}catch(Exception e){
				System.out.println("error");
				    /*logger.fatalEvent(EpaEngineDAO.class, PersistenceConstants.CHECK_ENGINE_NO_EXIST, e.getMessage(), e);
				    emailFacade.sendEmail(appProperties.getProperty("MAIN_MSG_SUB_EXCE"),
							PersistenceConstants.CHECK_ENGINE_NO_EXIST + e.getMessage(),appProperties);*/
			}finally {
				try {
					if(prepStmt !=null){
					prepStmt.close();
					}
				} catch (SQLException e) {
					System.out.println("error");
				//	logger.fatalEvent(EpaEngineDAO.class, PersistenceConstants.CHECK_ENGINE_NO_EXIST, e.getMessage(), e);
					
				}
			}
			
		
	}
	
	
public static Connection getSnowflakesConnection() throws SQLException {
		
		try {
			Class.forName("net.snowflake.client.jdbc.SnowflakeDriver");
		} catch (ClassNotFoundException e) {
			System.out.println("error");
			//logger1.fatalEvent(EpaEngineDAO.class, PersistenceConstants.GET_SNOW_FLAKES_CONNECTION, e.getMessage(), e);
			
		}

		//Properties config = DatabaseUtils.loadPropertiesFile();
		Properties properties = new Properties();
		
		/* DEV DB config
		properties.put("user", "ILS_GTI_DEV_APP");
		properties.put("schema", "BASE");
		properties.put("db", "ILS_GTI_DEV_DB");
		properties.put("warehouse", "ILS_APP_GTI_TEST_WH");*/
		
		// QA DB config
		properties.put("user", "ILS_GTI_QA_APP");
		properties.put("password", "KoRvRtDxRYFcPO0@gtggw36K");
		properties.put("schema", "BASE");
		properties.put("db", "ILS_GTI_QA_DB");
		properties.put("warehouse", "ILS_APP_GTI_TEST_WH");

		System.getProperties().put("http.proxySet", "true");
		System.getProperties().put("http.proxyHost", "proxy.cat.com");
		System.getProperties().put("https.proxyHost", "proxy.cat.com");
		System.getProperties().put("http.proxyPort", "80");
		System.getProperties().put("https.proxyPort", "80");
		System.getProperties().put("http.nonProxyHosts", "*.cat.com | localhost");

		String connectStr = System.getenv("SF_JDBC_CONNECT_STRING");
		if (connectStr == null) {
			connectStr = "jdbc:snowflake://cat.east-us-2.azure.snowflakecomputing.com";
		}
		return DriverManager.getConnection(connectStr, properties);
	}

public boolean checkEngineNoExist(){
	
	Connection conn = null;
	PreparedStatement prepStmt = null;
	boolean isexist=false;
	
	try {
	conn = getSnowflakesConnection();
	prepStmt = conn.prepareStatement("select TYP_DESC, TYP_PARM from ILS_GTI_DEV_DB.BASE.CNFGR_DTA where CNFGR_TYP = 'CMDTY-INFO' ");
	    //prepStmt.setString(1,  epaSnowFlake.getEpaEngSerNo());
	    ResultSet rs = prepStmt.executeQuery();
	   // int n = 0;
	    if ( rs.next() ) {
	        String s = rs.getString(1);
	    }
	    /*if ( n > 0 ) {
	    	isexist=true;
	    }*/
	}catch(Exception e){
		System.out.println("error");
		    /*logger.fatalEvent(EpaEngineDAO.class, PersistenceConstants.CHECK_ENGINE_NO_EXIST, e.getMessage(), e);
		    emailFacade.sendEmail(appProperties.getProperty("MAIN_MSG_SUB_EXCE"),
					PersistenceConstants.CHECK_ENGINE_NO_EXIST + e.getMessage(),appProperties);*/
	}finally {
		try {
			if(prepStmt !=null){
			prepStmt.close();
			}
		} catch (SQLException e) {
			System.out.println("error");
		//	logger.fatalEvent(EpaEngineDAO.class, PersistenceConstants.CHECK_ENGINE_NO_EXIST, e.getMessage(), e);
			
		}
	}
	/*logger.informationalEvent(EpaEngineDAO.class, PersistenceConstants.CHECK_ENGINE_NO_EXIST,
			PersistenceConstants.METHOD_EXIT);*/
	return isexist;
}

}
