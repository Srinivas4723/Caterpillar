package com.cat.logistics.epa.dao;


import java.util.List;

import com.cat.logistics.epa.entities.EpaHtsConfgr;
import com.cat.logistics.shared.dao.IGenericJpaDao;
import com.cat.logistics.shared.exception.DaoException;

public interface IEpaHtsConfgrDAO extends IGenericJpaDao<EpaHtsConfgr, String>{
	/**
	 * @param htsCode
	 * @return
	 * @throws DaoException
	 */
	public EpaHtsConfgr getHtsConfgrByCode(List<String> htsCode) throws DaoException;
	/**
	 * 
	 * @return
	 * @throws DaoException
	 */
	public List<EpaHtsConfgr> getEpaHtsCds() throws DaoException;
}
