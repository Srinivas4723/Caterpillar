package com.cat.logistics.epa.dao.impl;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.FetchMode;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.springframework.transaction.annotation.Transactional;

import com.cat.logistics.epa.dao.IEpaFacilityDAO;
import com.cat.logistics.epa.entities.EpaFac;
import com.cat.logistics.epa.job.utils.BatchConstants;
import com.cat.logistics.shared.dao.impl.GenericJpaDao;
import com.cat.logistics.shared.exception.DaoException;
import com.cat.logistics.shared.utils.PersistenceConstants;

public class EpaFacilityDAO extends GenericJpaDao<EpaFac, String> implements IEpaFacilityDAO {
	public static final Logger LOGGER = LogManager.getLogger(EpaFacilityDAO.class);

	/**
	 * 
	 * @return
	 */
	@SuppressWarnings("unchecked")
	@Override
	@Transactional
	public List<EpaFac> getAllFacilities() {
		LOGGER.info("Entry method of getAllFacilities {}",
				PersistenceConstants.METHOD_ENTRY);
		Criteria criteria = getSession().createCriteria(EpaFac.class);
		LOGGER.info("Exit method of getAllFacilities {}",
				PersistenceConstants.METHOD_EXIT);
		return criteria.list();
	}

	/**
	 * 
	 * @return
	 */
	@Override
	@Transactional
	public List<String> getAllFacilityCodes() {
		LOGGER.info("Entry method of getAllFacilityCodes {}",
				PersistenceConstants.METHOD_ENTRY);
		Criteria criteria = getSession().createCriteria(EpaFac.class);
		ProjectionList p1 = Projections.projectionList();
		p1.add(Projections.property(PersistenceConstants.FAC_CD));
		criteria.setProjection(p1);
		List<String> facilityCodes = criteria.list();
		LOGGER.info("Exit method of getAllFacilityCodes {}",
				PersistenceConstants.METHOD_EXIT);
		return facilityCodes;
	}

	/**
	 * 
	 * @param facilityCode
	 * @return
	 * @throws DaoException
	 */
	@SuppressWarnings("unchecked")
	@Override
	@Transactional
	public EpaFac getFacilityDetail(String facilityCode) throws DaoException {
		LOGGER.info("Entry method of getFacilityDetail {}",
				PersistenceConstants.METHOD_ENTRY);
		EpaFac facility = null;
		try {
			Criteria criteria = getSession().createCriteria(EpaFac.class);
			criteria.add(Restrictions.eq(PersistenceConstants.FAC_CD, facilityCode));
			facility = (EpaFac) criteria.uniqueResult();
			List<EpaFac> facList = (List<EpaFac>) criteria.list();
			if (null != facList && facList.size() > 0) {
				facility = facList.get(0);
			}
			LOGGER.info("Exit method of getFacilityDetail {}",
					PersistenceConstants.METHOD_EXIT);
		} catch (Exception exc) {
			LOGGER.error("Error in getFacilityDetail {}", exc.getMessage(), exc);
			throw new DaoException(exc);
		}

		return facility;
	}

	/**
	 * 
	 * @param facilityCode
	 * @return
	 * @throws DaoException
	 */
	@Override
	@Transactional
	public EpaFac getFacility(String facilityCode) throws DaoException {
		LOGGER.info("Entry method of getFacility {}",
				PersistenceConstants.METHOD_ENTRY);
		EpaFac facility = null;
		try {
			Criteria criteria = getSession().createCriteria(EpaFac.class);
			criteria.add(Restrictions.eq(PersistenceConstants.FAC_CD, facilityCode));
			criteria.setFetchMode(PersistenceConstants.EPA_USER_ATHS, FetchMode.JOIN);
			facility = (EpaFac) criteria.uniqueResult();
			// Get EpaUserAths
			if (facility != null) {
				facility.getEpaUsrAth().size();
			}
			LOGGER.info("Exit method of getFacility {}",
					PersistenceConstants.METHOD_EXIT);
		} catch (Exception exc) {
			LOGGER.error("Error in getFacility {}", exc.getMessage(), exc);
			throw new DaoException(exc);
		}
		return facility;
	}

	/**
	 * fetch description of facility
	 * 
	 * @param provisionCd
	 * @return
	 * @throws DaoException
	 */
	@Override
	@Transactional
	public String getfacilityDesc(String facCd) throws DaoException {
		LOGGER.info("Entry method of getfacilityDesc {}",
				PersistenceConstants.METHOD_ENTRY);
		try {
			Criteria criteria = getSession().createCriteria(EpaFac.class);
			criteria.add(Restrictions.eq(PersistenceConstants.FAC_CD, facCd));
			criteria.setProjection(
					Projections.projectionList().add(Projections.property(PersistenceConstants.FAC_NAME)));

			String facDesc = (String) criteria.uniqueResult();
			LOGGER.info("Exit method of getfacilityDesc {}",
					PersistenceConstants.METHOD_EXIT);
			return facDesc;
		} catch (Exception daoExc) {
			LOGGER.error("Error in getfacilityDesc {}", daoExc.getMessage(), daoExc);
			throw new DaoException(daoExc);
		}
	}

	/**
	 * 
	 * @param suppCd
	 * @return
	 * @throws DaoException
	 */
	@Override
	@Transactional
	public EpaFac getFacBySuppCd(String suppCd) throws DaoException {
		LOGGER.info("Entry method of getFacBySuppCd {}",
				PersistenceConstants.METHOD_ENTRY);
		EpaFac facility = null;
		try {
			Criteria criteria = getSession().createCriteria(EpaFac.class);
			criteria.add(Restrictions.eq(PersistenceConstants.PRT_NUM_SUPP_CD_VAR, suppCd));
			facility = (EpaFac) criteria.uniqueResult();
			LOGGER.info("Exit method of getFacBySuppCd {}",
					PersistenceConstants.METHOD_EXIT);
		} catch (Exception exc) {
			LOGGER.error("Error in getFacBySuppCd {} ", exc.getMessage(), exc);
			throw new DaoException(exc);
		}
		return facility;
	}

}
