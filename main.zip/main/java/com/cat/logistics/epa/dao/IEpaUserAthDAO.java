package com.cat.logistics.epa.dao;

import java.util.List;
import java.util.Map;

import com.cat.logistics.epa.entities.EpaUserAth;
import com.cat.logistics.epa.entities.EpaUserAthPK;
import com.cat.logistics.shared.dao.IGenericJpaDao;

public interface IEpaUserAthDAO  extends IGenericJpaDao<EpaUserAth, EpaUserAthPK> {
/**
 * 
 * @param pageNumber
 * @param pageSize
 * @param dataValue
 * @return
 */
	public List<EpaUserAth> getPaginationLstEpaUserAth(Integer pageNumber,Integer pageSize, String dataValue);
	/**
	 * 
	 * @param cwsId
	 * @return
	 */
	public List<EpaUserAth> getLstEpaUserAthByCwsId(String cwsId);
	/**
	 * 
	 * @return
	 */
	public Long getRowCount();
	/**
	 * 
	 * @param cwsId
	 * @param facilityCode
	 * @return
	 */
	public List<EpaUserAth> getLstEpaUserAthByCwsIdAndFacilty(String cwsId,String facilityCode);
	/**
	 * 
	 * @param dataMap
	 * @return
	 */
	public List<EpaUserAth> getEPAUserAuthorities(
			Map<String, List> dataMap);

	/**
	 * 
	 * @param cwsId
	 * @param roleCode
	 * @return
	 */
	public List<EpaUserAth> getFacilitiesByCwsIdRole(String cwsId, String roleCode);


	/**
	 * 
	 * @param roleCodes
	 * @param masterFacilitiesList
	 * @param logonId
	 * @return
	 */
	List<EpaUserAth> getLstEpaUserAthByCwsIdRoleFacility(
			List<String> roleCodes, List<String> masterFacilitiesList,
			String logonId);
	/**
	 * 
	 * @param deleteAuthorities
	 * @param addUserAuthorities
	 */
	public void saveUserAuthorties(List<EpaUserAth> deleteAuthorities,
			List<EpaUserAth> addUserAuthorities);
	/**
	 * 
	 * @param cwsId
	 */
	public void deleteByUserId(String cwsId);
	/**
	 * 
	 * @param cwsId
	 * @param masterFacilitiesList
	 * @return
	 */
	public List<EpaUserAth> getNonAdminFacilityAuthorities(String cwsId,
			List<String> masterFacilitiesList);

}
