package com.cat.logistics.epa.dao.impl;

import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.Criteria;
import org.springframework.transaction.annotation.Transactional;

import com.cat.logistics.epa.dao.IEpaStatusDAO;
import com.cat.logistics.epa.entities.EpaStatus;
import com.cat.logistics.epa.job.utils.BatchConstants;
import com.cat.logistics.shared.dao.impl.GenericJpaDao;
import com.cat.logistics.shared.exception.DaoException;
import com.cat.logistics.shared.utils.PersistenceConstants;

@SuppressWarnings("unchecked")
@Transactional
public class EpaStatusDAO extends GenericJpaDao<EpaStatus, String> implements IEpaStatusDAO{
	public static final Logger LOGGER = LogManager.getLogger(EpaStatusDAO.class);
	/**
	 * 
	 * @return
	 * @throws DaoException
	 */
	@Override
	public List<EpaStatus> getAllStatus() throws DaoException {
		LOGGER.info("Entry method of getAllStatus {}",PersistenceConstants.METHOD_ENTRY);
		List<EpaStatus> statusList;
		try{
		Criteria criteria = getSession().createCriteria(EpaStatus.class);
		
			statusList = criteria.list();
			LOGGER.info("Exit method of getAllStatus {}",PersistenceConstants.METHOD_EXIT);
		}
		catch (Exception e) {
			LOGGER.error("Error in getAllStatus {}",PersistenceConstants.EXCP_GET_ALL_STATUS, e);
			throw new DaoException(e);
		}
		return statusList; 
	}
	/**
	 * 
	 * @return
	 */
	@Override
	public List<String> getAllStatusCdDesc() {
		LOGGER.info("Entry method of getAllStatusCdDesc {}",PersistenceConstants.METHOD_ENTRY);
		List<String> stCdDescList = new ArrayList<String>();
		String concatString = null;
		List<EpaStatus> statusList;
		Criteria criteria = getSession().createCriteria(EpaStatus.class);
		statusList = criteria.list();
		for(EpaStatus epaStatus: statusList){
			concatString= epaStatus.getEpaStatusCd()+"."+epaStatus.getEpaStatusDesc();
			stCdDescList.add(concatString);
		}
		LOGGER.info("Exit method of getAllStatusCdDesc {}",PersistenceConstants.METHOD_EXIT);
		return stCdDescList;
	}
		
	
}
