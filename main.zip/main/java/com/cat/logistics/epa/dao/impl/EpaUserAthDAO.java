package com.cat.logistics.epa.dao.impl;

import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.springframework.transaction.annotation.Transactional;

import com.cat.logistics.epa.dao.IEpaUserAthDAO;
import com.cat.logistics.epa.entities.EpaUser;
import com.cat.logistics.epa.entities.EpaUserAth;
import com.cat.logistics.epa.entities.EpaUserAthPK;
import com.cat.logistics.epa.job.utils.BatchConstants;
import com.cat.logistics.shared.dao.impl.GenericJpaDao;
import com.cat.logistics.shared.utils.PersistenceConstants;

/**
 * EPA user with role and facility association DAO
 * 
 * @author sebastian.g.ducci
 *
 */
public class EpaUserAthDAO extends GenericJpaDao<EpaUserAth, EpaUserAthPK> implements IEpaUserAthDAO {

	public static final Logger LOGGER = LogManager.getLogger(EpaUserAthDAO.class);

	/**
	 * Gets users according to the cwsId received as parameter
	 * 
	 * @param cwsId
	 */
	@SuppressWarnings("unchecked")
	@Override
	@Transactional
	public List<EpaUserAth> getLstEpaUserAthByCwsId(String cwsId) {
		LOGGER.info("Entry method of getLstEpaUserAthByCwsId {}", PersistenceConstants.METHOD_ENTRY);
		Criteria criteria = getSession().createCriteria(EpaUserAth.class);
		criteria.createAlias(PersistenceConstants.EPA_USER, PersistenceConstants.EPA_USER);
		criteria.add(Restrictions.eq(PersistenceConstants.EPAUSER_EPA_USER_CWSID, cwsId));
		LOGGER.info("Exit method of getLstEpaUserAthByCwsId {}", PersistenceConstants.METHOD_EXIT);
		return (List<EpaUserAth>) criteria.list();
	}

	/**
	 * 
	 * @param cwsId
	 * @param facilityCode
	 * @return
	 */
	@Override
	@Transactional
	public List<EpaUserAth> getLstEpaUserAthByCwsIdAndFacilty(String cwsId, String facilityCode) {
		LOGGER.info("Entry method of getLstEpaUserAthByCwsIdAndFacilty {}", PersistenceConstants.METHOD_ENTRY);
		Criteria criteria = getSession().createCriteria(EpaUserAth.class);
		criteria.createAlias(PersistenceConstants.EPA_USER, PersistenceConstants.EPA_USER);
		criteria.createAlias(PersistenceConstants.EPA_FAC, PersistenceConstants.EPA_FAC);

		criteria.add(Restrictions.eq(PersistenceConstants.EPAUSER_EPA_USER_CWSID, cwsId));
		criteria.add(Restrictions.eq(PersistenceConstants.EPAFAC_FAC_CD, facilityCode));
		LOGGER.info("Exit method of getLstEpaUserAthByCwsIdAndFacilty {}", PersistenceConstants.METHOD_EXIT);
		return (List<EpaUserAth>) criteria.list();
	}

	/**
	 * Gets all users with their associations with roles and facilities using
	 * pagination logic
	 * 
	 * @param pageNumber
	 * @param pageSize
	 * @param dataValue  , to filter the CWS id
	 */
	@SuppressWarnings("unchecked")
	@Override
	@Transactional
	public List<EpaUserAth> getPaginationLstEpaUserAth(Integer pageNumber, Integer pageSize, String dataValue) {
		LOGGER.info("Entry method of getPaginationLstEpaUserAth {}",
				PersistenceConstants.METHOD_ENTRY);
		Criteria criteria = getSession().createCriteria(EpaUserAth.class);
		criteria.createAlias(PersistenceConstants.EPA_USER, PersistenceConstants.EPA_USER);
		criteria.setFirstResult((pageNumber - 1) * pageSize);
		criteria.setMaxResults(pageSize);

		if (dataValue != null && !"".equals(dataValue)) {
			criteria.add(Restrictions.like(PersistenceConstants.EPAUSER_EPA_USER_CWSID, dataValue, MatchMode.ANYWHERE));
		}
		LOGGER.info("Exit method of getPaginationLstEpaUserAth {}",
				PersistenceConstants.METHOD_EXIT);
		return (List<EpaUserAth>) criteria.list();
	}

	/**
	 * 
	 * @return
	 */
	@Override
	@Transactional
	public Long getRowCount() {
		LOGGER.info("Entry method of getRowCount {}",
				PersistenceConstants.METHOD_ENTRY);
		Criteria criteria = getSession().createCriteria(EpaUserAth.class);
		criteria.setProjection(Projections.rowCount());
		LOGGER.info("Exit method of getRowCount {}",
				PersistenceConstants.METHOD_EXIT);
		return (Long) criteria.list().get(0);
	}

	/**
	 * 
	 * @param dataMap
	 * @return
	 */
	@Override
	@Transactional
	public List<EpaUserAth> getEPAUserAuthorities(Map<String, List> dataMap) {
		LOGGER.info("Entry method of getEPAUserAuthorities {}",
				PersistenceConstants.METHOD_ENTRY);
		List<EpaUserAth> epaUserAthList = null;
		Criteria criteria = getSession().createCriteria(EpaUserAth.class);
		boolean searchFlag = false;
		if (dataMap.get(PersistenceConstants.VALID_EPA_USERS) != null
				&& dataMap.get(PersistenceConstants.VALID_EPA_USERS).size() > PersistenceConstants.ZERO) {
			criteria.createAlias(PersistenceConstants.EPA_USER, PersistenceConstants.EPA_USER);
			criteria.add(Restrictions.in(PersistenceConstants.EPAUSER_EPA_USER_CWSID,
					dataMap.get(PersistenceConstants.VALID_EPA_USERS)));
			searchFlag = true;
		}
		if (dataMap.get(PersistenceConstants.FACILITIES) != null
				&& dataMap.get(PersistenceConstants.FACILITIES).size() > PersistenceConstants.ZERO) {
			criteria.createAlias(PersistenceConstants.EPA_FAC, PersistenceConstants.EPA_FAC);
			criteria.add(
					Restrictions.in(PersistenceConstants.EPAFAC_FAC_CD, dataMap.get(PersistenceConstants.FACILITIES)));
			searchFlag = true;
		}
		if (dataMap.get(PersistenceConstants.ROLES) != null
				&& dataMap.get(PersistenceConstants.ROLES).size() > PersistenceConstants.ZERO) {
			criteria.createAlias(PersistenceConstants.EPA_ATH_LVL, PersistenceConstants.EPA_ATH_LVL);
			criteria.add(Restrictions.in(PersistenceConstants.EPA_ATHLVL_EPA_ATHLVL_CD,
					dataMap.get(PersistenceConstants.ROLES)));
			searchFlag = true;
		}
		if (searchFlag)
			epaUserAthList = criteria.list();
		LOGGER.info("Exit method of getEPAUserAuthorities {}",
				PersistenceConstants.METHOD_EXIT);
		return epaUserAthList;
	}

	/**
	 * 
	 * @param cwsId
	 * @param roleCode
	 * @return
	 */
	@Override
	@Transactional
	public List<EpaUserAth> getFacilitiesByCwsIdRole(String cwsId, String roleCode) {
		LOGGER.info("Entry method of getFacilitiesByCwsIdRole {}",
				PersistenceConstants.METHOD_ENTRY);
		Criteria criteria = getSession().createCriteria(EpaUserAth.class);
		criteria.add(Restrictions.eq(PersistenceConstants.ID_EPA_USER_CWSID, cwsId));
		criteria.add(Restrictions.eq(PersistenceConstants.ID_EPA_ATHLVL_CD, roleCode));
		LOGGER.info("Exit method of getFacilitiesByCwsIdRole {}",
				PersistenceConstants.METHOD_EXIT);
		return (List<EpaUserAth>) criteria.list();
	}

	/**
	 * Gets users according to the cwsId and roles received as parameter
	 * 
	 * @param cwsId
	 */
	@Override
	@Transactional
	public List<EpaUserAth> getLstEpaUserAthByCwsIdRoleFacility(List<String> roleCodes,
			List<String> masterFacilitiesList, String logonId) {
		LOGGER.info("Entry method of getLstEpaUserAthByCwsIdRoleFacility {}", PersistenceConstants.METHOD_ENTRY);
		Criteria criteria = getSession().createCriteria(EpaUserAth.class);
		criteria.createAlias(PersistenceConstants.EPA_ATH_LVL, PersistenceConstants.EPA_ATH_LVL);
		criteria.createAlias(PersistenceConstants.EPA_FAC, PersistenceConstants.EPA_FAC);
		criteria.createAlias(PersistenceConstants.EPA_USER, PersistenceConstants.EPA_USER);
		criteria.add(Restrictions.in(PersistenceConstants.EPAFAC_FAC_CD, masterFacilitiesList));
		criteria.add(Restrictions.in(PersistenceConstants.EPA_ATHLVL_EPA_ATHLVL_CD, roleCodes));
		criteria.add(Restrictions.eq(PersistenceConstants.EPAUSER_EPA_USER_CWSID, logonId));
		LOGGER.info("Exit method of getLstEpaUserAthByCwsIdRoleFacility {}", PersistenceConstants.METHOD_EXIT);
		return (List<EpaUserAth>) criteria.list();
	}

	/**
	 * 
	 * Deletes the deleteAuthorities from db and inserts the addUserAuthorities to
	 * db
	 *
	 * @param deleteAuthorities
	 * @param addUserAuthorities
	 * @see com.cat.logistics.epa.dao.IEpaUserAthDAO#saveUserAuthorties(java.util.List,
	 *      java.util.List)
	 * @since 1.0 Jun 23, 2015 12:04:22 AM badamrr
	 */
	@Override
	@Transactional(value = "transactionManagerEPA")
	public void saveUserAuthorties(List<EpaUserAth> deleteAuthorities, List<EpaUserAth> addUserAuthorities) {
		LOGGER.info("Entry method of saveUserAuthorties {}",
				PersistenceConstants.METHOD_ENTRY);
		for (EpaUserAth deleteAuthority : deleteAuthorities) {
			EpaUserAth authToBeRemoved = getEntityManager().getReference(EpaUserAth.class, deleteAuthority.getId());
			getEntityManager().remove(authToBeRemoved);
			// getSession().delete(deleteAuthority);
		}
		for (EpaUserAth addAuthority : addUserAuthorities) {
			getSession().persist(addAuthority);
		}
		LOGGER.info("Exit method of saveUserAuthorties {}",
				PersistenceConstants.METHOD_EXIT);
	}

	/**
	 * 
	 * @param cwsId
	 */
	@Override
	@Transactional(value = "transactionManagerEPA")
	public void deleteByUserId(String cwsId) {
		LOGGER.info("Entry method of saveUserAuthorties {}",
				PersistenceConstants.METHOD_ENTRY);
		List<EpaUserAth> userAthList = getSession().createCriteria(EpaUserAth.class)
				.add(Restrictions.eq(PersistenceConstants.ID_EPA_USER_CWSID, cwsId)).list();
		if (userAthList.size() > 0) {
			for (EpaUserAth ath : userAthList) {
				getSession().delete(ath);
			}
			EpaUser user = (EpaUser) getSession().createCriteria(EpaUser.class)
					.add(Restrictions.eq(PersistenceConstants.EPA_USER_CWSID, cwsId)).list()
					.get(PersistenceConstants.ZERO);
			user.setActiveIndicator(PersistenceConstants.ALPHA_N);
			getSession().persist(user);
		}
		LOGGER.info("Exit method of saveUserAuthorties {}",
				PersistenceConstants.METHOD_ENTRY);

	}

	/**
	 * 
	 * Here we are pulling non admin facilties because we want to show the non admin
	 * facilties as disabled on screen As well once the form is submmitted we will
	 * not be getting diabled facilities on view object, so pulling from database
	 * evertime we return model
	 *
	 * @param cwsId
	 * @param masterFacilitiesList
	 * @return
	 * @see com.cat.logistics.epa.dao.IEpaUserAthDAO#getNonAdminFacilityAuthorities(java.lang.String,
	 *      java.util.List)
	 * @since 1.0 Jun 22, 2015 11:46:51 PM badamrr
	 */
	@Override
	@Transactional
	public List<EpaUserAth> getNonAdminFacilityAuthorities(String cwsId, List<String> masterFacilitiesList) {
		LOGGER.info("Enter method of getNonAdminFacilityAuthorities {}", PersistenceConstants.METHOD_ENTRY);
		Criteria criteria = getSession().createCriteria(EpaUserAth.class);
		criteria.add(Restrictions.eq(PersistenceConstants.ID_EPA_USER_CWSID, cwsId));
		criteria.add(Restrictions.not(Restrictions.in(PersistenceConstants.ID_FAC_CD, masterFacilitiesList.toArray())));
		LOGGER.info("Exit method of getNonAdminFacilityAuthorities {}",PersistenceConstants.METHOD_EXIT);
		return criteria.list();
	}

}
