package com.cat.logistics.epa.dao;

import java.util.List;

import com.cat.logistics.epa.entities.EpaStatus;
import com.cat.logistics.shared.dao.IGenericJpaDao;
import com.cat.logistics.shared.exception.DaoException;

public interface IEpaStatusDAO  extends IGenericJpaDao<EpaStatus, String> {
/**
 * 
 * @return
 * @throws DaoException
 */
	public List<EpaStatus> getAllStatus() throws DaoException;
	/**
	 * 
	 * @return
	 */
	public List<String> getAllStatusCdDesc();
	}
	

