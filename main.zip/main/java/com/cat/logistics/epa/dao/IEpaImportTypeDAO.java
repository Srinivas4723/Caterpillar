package com.cat.logistics.epa.dao;

import java.util.List;

import com.cat.logistics.epa.entities.EpaImportType;
import com.cat.logistics.shared.dao.IGenericJpaDao;

public interface IEpaImportTypeDAO  extends IGenericJpaDao<EpaImportType, String> {
	
	/**
	 * @return
	 */
	public List<EpaImportType> getAllImportCodeList();

	/**
	 * @param importCd
	 * @return
	 */
	public String getImportDesc(String importCd);

}
