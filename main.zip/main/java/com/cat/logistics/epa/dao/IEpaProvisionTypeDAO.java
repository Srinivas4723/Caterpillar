package com.cat.logistics.epa.dao;

import java.util.List;

import com.cat.logistics.epa.entities.EpaProvisionType;
import com.cat.logistics.shared.dao.IGenericJpaDao;
import com.cat.logistics.shared.exception.DaoException;

public interface IEpaProvisionTypeDAO  extends IGenericJpaDao<EpaProvisionType, String> {
	
	/**
	 * @return
	 */
	public List<EpaProvisionType> getAllImportProvisionList();

	/**
	 * @param provisionCd
	 * @return
	 * @throws DaoException
	 */
	public String getImportProvisionDesc(String provisionCd) throws DaoException;


}
