package com.cat.logistics.epa.dao;

import com.cat.logistics.epa.entities.EpaUser;
import com.cat.logistics.shared.dao.IGenericJpaDao;

public interface IEpaUserDAO extends IGenericJpaDao<EpaUser, String> {
/**
 * 
 * @param name
 * @return
 */
	public EpaUser getEpaUserByUserName(String name);

/**
 * 
 * @param cwsId
 * @return
 */
	public Long userExists(String cwsId);
}
