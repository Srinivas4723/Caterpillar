package com.cat.logistics.epa.dao;

import java.util.List;

import com.cat.logistics.epa.entities.EpaDataCnfgr;
import com.cat.logistics.epa.entities.EpaDataCnfgrPK;
import com.cat.logistics.shared.dao.IGenericJpaDao;
import com.cat.logistics.shared.exception.DaoException;

/**
 * Interface for EpaDataConfigDAO class
 * @author ganamr 
 *
 */
public interface IEpaDataConfigDAO extends IGenericJpaDao<EpaDataCnfgr, EpaDataCnfgrPK> {
	
	/**
	 * @param dataConfigType
	 * @return List of EpaData configuration
	 * @throws DaoException 
	 */
	public List<EpaDataCnfgr> getValueByCnfgrType(String dataConfigType) throws DaoException;
	
	/**
	 * 
	 * @param exluSuppCd
	 * @param exluFacCd
	 * @return List<EpaDataCnfgr> 
	 * @throws DaoException
	 */
	public List<EpaDataCnfgr> getValueByCnfgrTypes(String exluSuppCd, String exluFacCd) throws DaoException;

	/**
	 * 
	 * @param exluSuppCd
	 * @param exluFacCd
	 * @return List<EpaDataCnfgr> 
	 * @throws DaoException
	 */
	public List<EpaDataCnfgr> getValueByCnfgrTypes(String[] dataConfigTypes) throws DaoException;


}
