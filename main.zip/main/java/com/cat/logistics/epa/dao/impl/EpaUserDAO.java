package com.cat.logistics.epa.dao.impl;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.springframework.transaction.annotation.Transactional;

import com.cat.logistics.epa.dao.IEpaUserDAO;
import com.cat.logistics.epa.entities.EpaUser;
import com.cat.logistics.shared.dao.impl.GenericJpaDao;
import com.cat.logistics.shared.utils.PersistenceConstants;

public class EpaUserDAO extends GenericJpaDao<EpaUser, String> implements IEpaUserDAO{
	public static final Logger LOGGER = LogManager.getLogger(EpaUserDAO.class);
	/**
	 * 
	 * @param name
	 * @return
	 */
	@Override
	@Transactional
	public EpaUser getEpaUserByUserName(String name) {
		LOGGER.info("Enter method of getEpaUserByUserName {}",PersistenceConstants.METHOD_ENTRY);
		List<EpaUser> epaUsers = null;
		EpaUser epaUser = null;
		Criteria criteria = getSession().createCriteria(EpaUser.class);
		criteria.add(Restrictions.eq(PersistenceConstants.EPA_USER_CWSID,name));
		epaUsers = criteria.list();
		if(epaUsers != null && epaUsers.size() > 0)
			epaUser = epaUsers.get(0);
		LOGGER.info("Exit method of getEpaUserByUserName {}",PersistenceConstants.METHOD_EXIT);
		return epaUser;
	}
	/**
	 * 
	 * @param cwsId
	 * @return
	 */
	@Override
	@Transactional
	public Long userExists(String cwsId) {
		LOGGER.info("Enter method of userExists {}",PersistenceConstants.METHOD_ENTRY);
		Criteria criteria = getSession().createCriteria(EpaUser.class);
		criteria.add(Restrictions.eq(PersistenceConstants.EPA_USER_CWSID,cwsId));
		criteria.setProjection(Projections.rowCount());
		LOGGER.info("Exit method of userExists {}",PersistenceConstants.METHOD_EXIT);
		return (Long)criteria.list().get(0);
	}
}
