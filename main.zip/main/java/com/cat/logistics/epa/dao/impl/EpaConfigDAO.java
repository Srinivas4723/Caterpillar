package com.cat.logistics.epa.dao.impl;

import java.util.Calendar;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.transaction.annotation.Transactional;

import com.cat.logistics.epa.dao.IEpaConfigDAO;
import com.cat.logistics.epa.entities.EpaConfig;
import com.cat.logistics.epa.entities.EpaConfigPK;
import com.cat.logistics.epa.job.utils.BatchConstants;
import com.cat.logistics.shared.dao.impl.GenericJpaDao;
import com.cat.logistics.shared.exception.DaoException;
import com.cat.logistics.shared.utils.PersistenceConstants;

/**
 * @author singhr9
 *
 */

public class EpaConfigDAO extends GenericJpaDao<EpaConfig, EpaConfigPK> implements IEpaConfigDAO {
	
	public static final Logger LOGGER = LogManager.getLogger(EpaConfigDAO.class);	
	
	
	/**
	 * Based on the cnfgtyp return list of EpaConnfig objects.
	 */
	@SuppressWarnings("unchecked")
	@Override
	@Transactional
	public List<EpaConfig> getEpaConfig(String cnfgTyp) throws DaoException{
		LOGGER.info("Entry method of getEpaConfig  {}", BatchConstants.METHOD_ENTRY);
		List<EpaConfig> importProvConfigLst = null;
		
		try{
			Criteria criteria = getSession().createCriteria(EpaConfig.class);
			criteria.add(Restrictions.eq(PersistenceConstants.ID_CONFIG_TYPE,cnfgTyp).ignoreCase());			
			
			importProvConfigLst = (List<EpaConfig>) criteria.list();
			LOGGER.info("Exit method of getEpaConfig  {}", BatchConstants.METHOD_EXIT);
	   }catch(Exception exc){
		   LOGGER.error("Error in getEpaConfig {}",PersistenceConstants.EXCP_GET_EPA_CNFG, exc);
		   throw new DaoException(exc);
	   }		
		
		return importProvConfigLst;
	}
	
	/**
	 * Reads support Mail values and returns in EPAConfig
	 */
	@SuppressWarnings("unchecked")
	@Override
	@Transactional
	public EpaConfig getSupportMails() throws DaoException{
		LOGGER.info("Enter method of getSupportMails  {}", BatchConstants.METHOD_ENTRY);
		List<EpaConfig> mailIdLst = null;
		EpaConfig supportMail = null;
		
		try{
			Criteria criteria = getSession().createCriteria(EpaConfig.class);
			criteria.add(Restrictions.eq(PersistenceConstants.ID_KEY_TYPE,PersistenceConstants.SUPPORT_MAIL_IDS).ignoreCase());
			criteria.add(Restrictions.eq(PersistenceConstants.ID_CONFIG_TYPE,PersistenceConstants.EPA_BATCH_JOB).ignoreCase());
			
			mailIdLst = (List<EpaConfig>) criteria.list();	
			if(mailIdLst != null && !mailIdLst.isEmpty()){
				supportMail = mailIdLst.get(0);
			}
			LOGGER.info("Exit method of getSupportMails  {}", BatchConstants.METHOD_EXIT);
	   }catch(Exception exc){
		   LOGGER.error("Error in getSupportMails {}", PersistenceConstants.EXCP_GET_SUPRT_MAILS, exc);
		   throw new DaoException(exc);
	   }		
		
		return supportMail;
	}

	/**
	 *  This method accepts end timestamp and calls logProcessTimes method
	 */
	@Override
	@Transactional
	public void logEndTime(String timeStamp,String jobName) throws DaoException  {

		logProcessTimes(timeStamp,true,jobName);
	}

	
	/**
	 * This method accepts start timestamp and calls logProcessTimes method
	 */
	@Override
	@Transactional
	public void logStartTime(String timeStamp,String jobName) throws DaoException {
	
		logProcessTimes(timeStamp,false,jobName);
	}
	
	
	/**
	 * @param timestamp
	 * @param endTime
	 * @throws DaoException
	 */
	@Transactional(value="transactionManagerEPA")
	public void logProcessTimes(String timestamp,boolean endTime,String jobNamee) throws DaoException{
		LOGGER.info("Enter method of logProcessTimes  {}", BatchConstants.METHOD_ENTRY);
		EpaConfig config = new EpaConfig();
		EpaConfigPK configPk = new EpaConfigPK();
		configPk.setConfigType(jobNamee);
		configPk.setKeyType(PersistenceConstants.JOB_PROCESS_TIMES);
		configPk.setValueType1(timestamp);
		config.setId(configPk);
		config.setKeyDesc(PersistenceConstants.KEY_DESC);
		if(endTime){
			config.setValueType2(getTimestamp());
		}
		try {
			getSession().merge(config);
		} catch (Exception e) {
			LOGGER.error("Error in logProcessTimes {}", PersistenceConstants.EXCP_GET_SUPRT_MAILS, e);
			throw new DaoException();
		}
		LOGGER.info("Exit method of logProcessTimes  {} {}",PersistenceConstants.MTD_GET_SUPRT_MAILS, BatchConstants.METHOD_EXIT);
	}
	
	/**
	 * @return
	 */
	public String getTimestamp(){
		Calendar cal = Calendar.getInstance();
		java.sql.Timestamp timeStamp = new java.sql.Timestamp(cal.getTimeInMillis());
		return timeStamp.toString();
	}

	/**
	 * Reads epa batch job run frequency
	 */
	@Override
	@SuppressWarnings("unchecked")
	@Transactional
	public int getJobFreq(String jobName) throws DaoException {
		LOGGER.info("Enter method of getJobFreq  {}", BatchConstants.METHOD_ENTRY);
		List<EpaConfig> epaConfigList = null;
		EpaConfig epaConfig ; 
		String freq = null;
		int frequency = 0;
		
		try{
			Criteria criteria = getSession().createCriteria(EpaConfig.class);
			criteria.add(Restrictions.eq(PersistenceConstants.ID_CONFIG_TYPE,jobName).ignoreCase());
			criteria.add(Restrictions.eq(PersistenceConstants.ID_KEY_TYPE,PersistenceConstants.JOB_RUN_FREQ).ignoreCase());
			
			epaConfigList =  criteria.list();	
			if(epaConfigList != null && epaConfigList.size() > 0){
				epaConfig = epaConfigList.get(0);
				freq = epaConfig.getId().getValueType1();
				if(freq != null)
					frequency = Integer.parseInt(freq);
			}
			LOGGER.info("Exit method of getJobFreq  {}", BatchConstants.METHOD_EXIT);
	   }catch(Exception exc){
		   LOGGER.error("Error in getJobFreq {}", exc.getMessage(), exc);
		   throw new DaoException(exc);
	   }	
	   return frequency;
	}
	
	

	/**
	 * Reads epa batch job run frequency
	 */
	@Override
	@SuppressWarnings("unchecked")
	@Transactional
	public int getEpaDataRefFreq(String jobName) throws DaoException {
		LOGGER.info("Enter method of getEpaDataRefFreq  {}",PersistenceConstants.METHOD_ENTRY);
		List<EpaConfig> epaConfigList = null;
		EpaConfig epaConfig ; 
		String freq = null;
		int frequency = 0;
		
		try{
			Criteria criteria = getSession().createCriteria(EpaConfig.class);
			criteria.add(Restrictions.eq(PersistenceConstants.ID_CONFIG_TYPE,jobName).ignoreCase());
			criteria.add(Restrictions.eq(PersistenceConstants.ID_KEY_TYPE,"JOB_FETCH_DAYS").ignoreCase());
			
			epaConfigList =  criteria.list();	
			if(epaConfigList != null && epaConfigList.size() > 0){
				epaConfig = epaConfigList.get(0);
				freq = epaConfig.getId().getValueType1();
				if(freq != null)
					frequency = Integer.parseInt(freq);
			}
			LOGGER.info("Exit method of getEpaDataRefFreq  {}",PersistenceConstants.METHOD_EXIT);
	   }catch(Exception exc){
		   LOGGER.error("Error in getEpaDataRefFreq  {}", exc.getMessage(), exc);
		   throw new DaoException(exc);
	   }	
	   return frequency;
	}
	
	
	
	/**
	 * Reads epa batch job run frequency
	 */
	@Override
	@SuppressWarnings("unchecked")
	@Transactional
	public String getHtsJobFreq() throws DaoException {
		LOGGER.info("Enter method of getHtsJobFreq  {}",PersistenceConstants.METHOD_ENTRY);
		List<EpaConfig> epaConfigList = null;
		EpaConfig epaConfig ; 
//		String freq = null;
		String schedules = null;
		
		try{
			Criteria criteria = getSession().createCriteria(EpaConfig.class);
			criteria.add(Restrictions.eq(PersistenceConstants.ID_CONFIG_TYPE,PersistenceConstants.HTS_BATCH_JOB).ignoreCase());
			criteria.add(Restrictions.eq(PersistenceConstants.ID_KEY_TYPE,PersistenceConstants.JOB_RUN_TIMES).ignoreCase());
			
			epaConfigList =  criteria.list();	
			if(epaConfigList != null && epaConfigList.size() > 0){
				epaConfig = epaConfigList.get(0);
				schedules = epaConfig.getId().getValueType1();
				
			}
			LOGGER.info("Exit method of getHtsJobFreq  {}",PersistenceConstants.METHOD_EXIT);
	   }catch(Exception exc){
		   LOGGER.error("Error in getHtsJobFreq  {}", exc.getMessage(), exc);
		   throw new DaoException(exc);
	   }	
	   return schedules;
	}
	
	
	/**
	 * Reads the epa batch job last successful timestamp
	 * @return
	 * @throws DaoException
	 */
	@Transactional
	public EpaConfig getLstSccsTm(String jobName) throws DaoException{
		LOGGER.info("Enter method of getLstSccsTm  {}",PersistenceConstants.METHOD_ENTRY);
		//String tmstmp = null;
		EpaConfig epaConfig = null;
		try{
			Criteria lstSessionCriteria = getSession().createCriteria(EpaConfig.class);
			lstSessionCriteria.add(Restrictions.eq(PersistenceConstants.ID_CONFIG_TYPE,jobName).ignoreCase());
			lstSessionCriteria.add(Restrictions.eq(PersistenceConstants.ID_KEY_TYPE,PersistenceConstants.LST_SUCCS_TM).ignoreCase());
			epaConfig = (EpaConfig) lstSessionCriteria.uniqueResult();
		/*	if(epaConfig != null){
				tmstmp = epaConfig.getValueType2();
			}*/
			LOGGER.info("Exit method of getLstSccsTm  {}",PersistenceConstants.METHOD_EXIT);
	   }catch(Exception exc){
		   LOGGER.error("Error in getLstSccsTm {}", exc.getMessage(), exc);
		   throw new DaoException(exc);
	   }	
		
		return epaConfig;
	}
	
	
	/**
	 * Reads the epa batch job last successful timestamp
	 * @return
	 * @throws DaoException
	 */
	@Transactional
	public EpaConfig getRunTms() throws DaoException{
		LOGGER.info("Enter method of getRunTms  {}",PersistenceConstants.METHOD_ENTRY);
		EpaConfig epaConfig = null;
		try{
			Criteria cfgSessionCriteria = getSession().createCriteria(EpaConfig.class);
			cfgSessionCriteria.add(Restrictions.eq(PersistenceConstants.ID_CONFIG_TYPE,PersistenceConstants.EPA_BATCH_JOB_WND).ignoreCase());
			cfgSessionCriteria.add(Restrictions.eq(PersistenceConstants.ID_KEY_TYPE,PersistenceConstants.RUN_TIMES).ignoreCase());
			epaConfig = (EpaConfig) cfgSessionCriteria.uniqueResult();
			
			LOGGER.info("Exit method of getRunTms  {}",PersistenceConstants.METHOD_EXIT);
	   }catch(Exception e){
		   LOGGER.error("Error in getRunTms {}", e.getMessage(), e);
		   throw new DaoException(e);
	   }	
		
		return epaConfig;
	}
	
	
	
	/**
	 *saves the epa batch job lasst succesful run timestamp
	 * @return
	 * @throws DaoException
	 */
	@Transactional(value="transactionManagerEPA")
	public void saveLstSccsTm(EpaConfig epaConfig) throws DaoException{
		LOGGER.info("Entry method of saveLstSccsTm  {}",PersistenceConstants.METHOD_ENTRY);
		try{
			getSession().merge(epaConfig);
			
			LOGGER.info("Exit method of saveLstSccsTm  {}",PersistenceConstants.METHOD_EXIT);
	   }catch(Exception exc){
		   LOGGER.error("Error in saveLstSccsTm {}", exc.getMessage(), exc);
		   throw new DaoException(exc);
	   }	
		
	}
	
}
