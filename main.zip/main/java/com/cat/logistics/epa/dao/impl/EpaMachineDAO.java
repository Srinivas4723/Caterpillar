package com.cat.logistics.epa.dao.impl;

import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

import com.cat.logistics.epa.dao.IEpaMachineDAO;
import com.cat.logistics.epa.entities.EpaEngine;
import com.cat.logistics.epa.entities.EpaMachine;
import com.cat.logistics.epa.entities.EpaShipment;
import com.cat.logistics.epa.helper.CriteriaHelper;
import com.cat.logistics.epa.helper.FacilityWorkQueueHelper;
import com.cat.logistics.epa.job.utils.BatchConstants;
import com.cat.logistics.shared.dao.impl.GenericJpaDao;
import com.cat.logistics.shared.exception.DaoException;
import com.cat.logistics.shared.utils.PersistenceConstants;

/**
 * @author pallel
 *
 */
public class EpaMachineDAO extends GenericJpaDao<EpaMachine, String> implements IEpaMachineDAO {
	public static final Logger LOGGER = LogManager.getLogger(EpaMachineDAO.class);

	@Autowired
	CriteriaHelper critHelp;

	/**
	 * 
	 * @param machineSerialNumber
	 * @return
	 */
	@Override
	@Transactional
	public Boolean isEpaMachineNumber(String machineSerialNumber) {
		LOGGER.info("Entry method of isEpaMachineNumber {}",
				PersistenceConstants.METHOD_ENTRY);
		Criteria criteria = getSession().createCriteria(EpaMachine.class);
		Boolean result = criteria.add(Restrictions.eq(PersistenceConstants.MCH_SER_NUM_ID, machineSerialNumber))
				.setProjection(Projections.property(PersistenceConstants.MCH_SER_NUM_ID)).uniqueResult() == null ? false
						: true;
		LOGGER.info("Exit method of isEpaMachineNumber {}",
				PersistenceConstants.METHOD_EXIT);
		return result;
	}

	/**
	 * 
	 * @param machineSerialNo
	 * @param epaSeqNum
	 * @return
	 */

	@SuppressWarnings("unchecked")
	@Override
	@Transactional(value = "transactionManagerEPA")
	public int updateMachineNumber(String machineSerialNo, String epaSeqNum) {
		LOGGER.info("Entry method of updateMachineNumber {}",
				PersistenceConstants.METHOD_ENTRY);
		Query query = getSession().getNamedQuery(PersistenceConstants.EPAMCH_UPD_MCHNUM);
		query.setString(PersistenceConstants.MCH_NUM, machineSerialNo);
		query.setLong(PersistenceConstants.EPA_SEQ_NO, Long.parseLong(epaSeqNum));

		int recordUpdtCnt = query.executeUpdate();
		LOGGER.info("Exit method of updateMachineNumber {}",
				PersistenceConstants.METHOD_EXIT);
		return recordUpdtCnt;
	}

	/**
	 * 
	 * @param facilityWorkQueueHelper
	 * @return List of Shipments
	 * @throws DaoException
	 */
	@Override
	@Transactional
	public List<EpaShipment> searchMachineShipments(FacilityWorkQueueHelper facWrkQueHelper, boolean missingData)
			throws DaoException {
		LOGGER.info("Entry method of searchMachineShipments {}",
				PersistenceConstants.METHOD_ENTRY);
		List<EpaShipment> machinesList = new ArrayList<EpaShipment>();
		try {
			Criteria criteria = getSession().createCriteria(EpaShipment.class);
			boolean fetch = false;
			fetch = buildMchSearchCritria(facWrkQueHelper, criteria, missingData, fetch);
			if (fetch) {
				machinesList = criteria.list();
			}
			LOGGER.info("Exit method of searchMachineShipments {}",
					PersistenceConstants.METHOD_EXIT);
		} catch (Exception e) {
			LOGGER.error("Error in searchMachineShipments {}", e.getMessage(), e);
			throw new DaoException(e);
		}
		return machinesList;
	}

	/**
	 * @param facWrkQueHelper facWrkQueHelper
	 * @param criteria        criteria
	 * @param missingData     boolean check
	 * @param fetch           boolean check
	 * @return true or false
	 */
	private boolean buildMchSearchCritria(FacilityWorkQueueHelper facWrkQueHelper, Criteria criteria,
			boolean missingData, boolean fetch) {
		if (!missingData) {
			fetch = critHelp.statusCriteria(facWrkQueHelper.getWrkQueSFormStatus(), criteria);
		} else {
			fetch = critHelp.fetchMsngInfo(facWrkQueHelper, criteria, PersistenceConstants.M_VAR);
		}

		fetch = addMchShmntCrit(facWrkQueHelper, criteria, fetch);
		criteria.add(Restrictions.eq(PersistenceConstants.EPA_PROD_TYP, PersistenceConstants.M_VAR));
		return fetch;
	}

	public boolean addMachBuild(FacilityWorkQueueHelper facilityWorkQueueHelper, Criteria criteria, boolean fetch) {
		if (null != facilityWorkQueueHelper.getFromBuildDate() && null != facilityWorkQueueHelper.getToBuildDate()) {
			criteria.createAlias(PersistenceConstants.EPA_MACHINS, PersistenceConstants.EPA_MCH);
		}
		fetch = critHelp.addDtCrit(facilityWorkQueueHelper.getFromBuildDate(), facilityWorkQueueHelper.getToBuildDate(),
				criteria, PersistenceConstants.EPA_MCH_MFR_DATE, fetch);
		return fetch;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.cat.logistics.epa.dao.IEpaMachineDAO#getEnginesListByStatusList(java.util
	 * .List)
	 */
	/**
	 * 
	 * @param statusCdList
	 * @return
	 */
	@Override
	@Transactional
	public List<EpaEngine> getEnginesListByStatusList(List<String> statusCdList) {
		LOGGER.info("Entry method of getEnginesListByStatusList {}",
				PersistenceConstants.METHOD_ENTRY);
		Criteria criteria = getSession().createCriteria(EpaEngine.class);
		criteria.createAlias(PersistenceConstants.EPA_STATUS, PersistenceConstants.EPA_STAT);
		criteria.add(Restrictions.in(PersistenceConstants.EPA_STATCD, statusCdList));
		List<EpaEngine> engineList = criteria.list();
		LOGGER.info("Exit method of getEnginesListByStatusList {}",
				PersistenceConstants.METHOD_EXIT);
		return engineList;
	}

	/**
	 * fetches engine info for the given machine serial number
	 * 
	 * @see com.cat.logistics.epa.dao.IEpaMachineDAO#getEngines(java.lang.String)
	 */
	/**
	 * 
	 * @param mchSerNo
	 * @return
	 */
	@Override
	@Transactional
	public List<EpaEngine> getEngines(String mchSerNo) {
		LOGGER.info("Entry method of getEngines {}",
				PersistenceConstants.METHOD_ENTRY);
		Criteria criteriaEng = getSession().createCriteria(EpaEngine.class);
		criteriaEng.add(Restrictions.eq(PersistenceConstants.MACH_SER_NUM_VAR, mchSerNo));
		List<EpaEngine> engineList = criteriaEng.list();
		LOGGER.info("Exit method of getEngines {}",
				PersistenceConstants.METHOD_EXIT);
		return engineList;
	}

	public boolean addMchShmntCrit(FacilityWorkQueueHelper facWrkQueHelper, Criteria criteria, boolean fetch) {

		fetch = critHelp.addShmntCrit(facWrkQueHelper, criteria, PersistenceConstants.MACH_SER_NUM_VAR,
				PersistenceConstants.FALSE);

		fetch = addMachBuild(facWrkQueHelper, criteria, fetch);

		return fetch;
	}

	/**
	 * Fetches the count of Machine shipments
	 * 
	 * @param facilityWorkQueueHelper
	 * @return List of Shipments
	 * @throws DaoException
	 */
	@Override
	@Transactional
	public int getMchShipCntBySearch(FacilityWorkQueueHelper facWrkQueHelper, boolean missingData) {
		boolean fetch = false;
		int count = 0;
		Criteria criteria = getSession().createCriteria(EpaShipment.class);
		fetch = buildMchSearchCritria(facWrkQueHelper, criteria, missingData, fetch);
		if (fetch) {
			count = criteria.list().size();
		}
		return count;
	}
}
