package com.cat.logistics.epa.dao.impl;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Restrictions;
import org.springframework.transaction.annotation.Transactional;

import com.cat.logistics.epa.dao.IEpaDataConfigDAO;
import com.cat.logistics.epa.entities.EpaDataCnfgr;
import com.cat.logistics.epa.entities.EpaDataCnfgrPK;
import com.cat.logistics.epa.job.utils.BatchConstants;
import com.cat.logistics.shared.dao.impl.GenericJpaDao;
import com.cat.logistics.shared.exception.DaoException;
import com.cat.logistics.shared.utils.PersistenceConstants;

/**
 * This class act as Persistent layer to perform conditional based operations
 * Based on the dataCnfgtyp return list of EpaDataConnfig objects.
 * @author ganamr
 *
 */
@Transactional
public class EpaDataConfigDAO extends GenericJpaDao<EpaDataCnfgr, EpaDataCnfgrPK> implements IEpaDataConfigDAO {
	
	public static final Logger LOGGER = LogManager.getLogger(EpaDataConfigDAO.class);
	/**
	 * Fetches the manufacturer list for the given data config type
	 * @param dataConfigType 
	 * @return List of Data Config objects
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<EpaDataCnfgr> getValueByCnfgrType(String dataConfigType) throws DaoException {
		LOGGER.info("Entry method of getValueByCnfgrType {} {}",PersistenceConstants.MTD_GET_ENG_MFR_LST,PersistenceConstants.METHOD_ENTRY);
		List<EpaDataCnfgr> engMfrList = null;
		try{
		Criteria cfgrCriteria = getSession().createCriteria(EpaDataCnfgr.class);
		cfgrCriteria.add(Restrictions.eq(PersistenceConstants.DATA_CONFIG_TYPE,dataConfigType));
		engMfrList= (List<EpaDataCnfgr>) cfgrCriteria.list();
		LOGGER.info("Exit method of getValueByCnfgrType {} {}",PersistenceConstants.MTD_GET_ENG_MFR_LST,PersistenceConstants.METHOD_EXIT);
		}catch(Exception excConf){
			LOGGER.error("Error in getValueByCnfgrType {}", PersistenceConstants.EXCP_GET_EPA_CNFG, excConf);
		   throw new DaoException(excConf);
	   }		
		return engMfrList;
	}
	
	
	/**
	 * Fetches the manufacturer list for the given data config type
	 * @param dataConfigType 
	 * @return List of Data Config objects
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<EpaDataCnfgr> getValueByCnfgrTypes(String exluSuppCd,
			String exluFacCd) throws DaoException {
		LOGGER.info("Enter method of getValueByCnfgrTypes {}",PersistenceConstants.METHOD_ENTRY);
		List<EpaDataCnfgr> engMfrList = null;
		try {
			Criteria criteria = getSession().createCriteria(EpaDataCnfgr.class);
			Criterion suppCdExcld= Restrictions.eq(PersistenceConstants.DATA_CONFIG_TYPE, exluSuppCd);	
			Criterion facCdExcld = Restrictions.eq(PersistenceConstants.DATA_CONFIG_TYPE, exluFacCd);	
			criteria.add(Restrictions.or(suppCdExcld, facCdExcld));
			engMfrList = (List<EpaDataCnfgr>) criteria.list();
			LOGGER.info("Exit method of getValueByCnfgrTypes {}",PersistenceConstants.METHOD_EXIT);
		} catch (Exception ex) {
			LOGGER.error("Error in getValueByCnfgrTypes {}",PersistenceConstants.EXCP_GET_EPA_CNFG, ex);
			throw new DaoException(ex);
		}		
		return engMfrList;
	}
	

	/**
	 * Fetches the value for the given data config types
	 * @param dataConfigTypes
	 * @return List of Data Config objects
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<EpaDataCnfgr> getValueByCnfgrTypes(String[] dataConfigTypes) throws DaoException {
		LOGGER.info("Enter method of getValueByCnfgrTypes {}",PersistenceConstants.METHOD_ENTRY);
		List<EpaDataCnfgr> engMfrLists = null;
		try{
		Criteria cfgrCriteriaByVal = getSession().createCriteria(EpaDataCnfgr.class);
		cfgrCriteriaByVal.add(Restrictions.in(PersistenceConstants.DATA_CONFIG_TYPE,dataConfigTypes));
		engMfrLists= (List<EpaDataCnfgr>) cfgrCriteriaByVal.list();
		LOGGER.info("Exit method of getValueByCnfgrTypes {}",PersistenceConstants.METHOD_EXIT);
		}catch(Exception exConf){
			LOGGER.error("Error in getValueByCnfgrTypes {}", PersistenceConstants.EXCP_GET_VAL_BY_CFG_TYP, exConf);
		   throw new DaoException(exConf);
	   }		
		return engMfrLists;
	}

}
