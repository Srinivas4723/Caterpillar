package com.cat.logistics.epa.dao.impl;

import java.util.Calendar;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.FetchMode;
import org.hibernate.Query;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.LogicalExpression;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.springframework.transaction.annotation.Transactional;

import com.cat.logistics.epa.dao.IEpaShipmentDAO;
import com.cat.logistics.epa.entities.EpaEngine;
import com.cat.logistics.epa.entities.EpaMachine;
import com.cat.logistics.epa.entities.EpaShipment;
import com.cat.logistics.shared.dao.impl.GenericJpaDao;
import com.cat.logistics.shared.exception.DaoException;
import com.cat.logistics.shared.utils.EPAUtils;
import com.cat.logistics.shared.utils.PersistenceConstants;


/**
 *  This class act as DAO layer to perform Shipment related operations
 * @author ganamr
 *
 */
public class EpaShipmentDAO extends GenericJpaDao<EpaShipment, Long> implements IEpaShipmentDAO{	
	
	//private ILogger logger = Logger.getInstance();

	private final static Logger logger = LogManager.getLogger(EpaShipmentDAO.class);
	/**
	 * fetches shipment info for the given serial number
	 * @param machNum
	 * @param epaSeqNum
	 * @return list of Shipment objects
	 * @throws DaoException
	 */
	@SuppressWarnings("unchecked")  
	@Override
	@Transactional
	public List<EpaShipment> getEpaShipmentbyMachOrEngNum(String machNum,String epaSeqNum) throws DaoException {
	
		logger.info(EpaShipmentDAO.class+ PersistenceConstants.MTD_GET_EPA_SHIP_BY_MCHORENG+ PersistenceConstants.METHOD_ENTRY
				+ PersistenceConstants.PROCESS_SER_SEQ_NO+machNum+PersistenceConstants.FRW_SLASH+epaSeqNum);
		List<EpaShipment> epaShpmnts = null;
		try{
		Criteria criteria = getSession().createCriteria(EpaShipment.class);
		criteria.setFetchMode(PersistenceConstants.EPA_MACHINS, FetchMode.JOIN);			
			Criterion machNumCr = Restrictions.eq(PersistenceConstants.MACH_SER_NUM_VAR, machNum).ignoreCase();
			Criterion engNumCr = Restrictions.eq(PersistenceConstants.ENG_SER_NUM_VAR,machNum).ignoreCase();			
			LogicalExpression machOrEng = Restrictions.or(machNumCr, engNumCr);
			criteria.add( machOrEng );
			if(!EPAUtils.isNullOrEmpty(epaSeqNum)){
				criteria.add(Restrictions.ne(PersistenceConstants.EPA_SEQ_NUM, Long.parseLong(epaSeqNum)));
			}
			criteria.addOrder(Order.desc(PersistenceConstants.RCDLOG_LASTUDT_TS));
			epaShpmnts  = criteria.list();
			//logger.informationalEvent(EpaShipmentDAO.class, PersistenceConstants.MTD_GET_EPA_SHIP_BY_MCHORENG, PersistenceConstants.METHOD_EXIT);
		}catch(Exception daoExc){
			//logger.fatalEvent(EpaShipmentDAO.class, PersistenceConstants.MTD_GET_EPA_SHIP_BY_MCHORENG, daoExc.getMessage(), daoExc);
			logger.error(this.getClass() + PersistenceConstants.MTD_GET_EPA_SHIP_BY_MCHORENG+ daoExc.getMessage());
			throw new DaoException(daoExc);
		}		
		return epaShpmnts;
	}
	/**
	 * @return
	 */
	
	@SuppressWarnings("unchecked")
	@Override
	@Transactional
	public List<String> getAllInvoiceNo() {
		logger.info(EpaShipmentDAO.class+ PersistenceConstants.MTD_GET_ALL_INVC+ PersistenceConstants.METHOD_ENTRY);
		Criteria criteria = getSession().createCriteria(EpaShipment.class);
		criteria.setProjection( Projections.distinct( Projections.projectionList()
				.add( Projections.property(PersistenceConstants.PRT_NUM_INVC_NUM_VAR), PersistenceConstants.PRT_NUM_INVC_NUM_VAR)));
		List<String> invoiceList=criteria.list();	
		invoiceList.remove(null);
		logger.info(EpaShipmentDAO.class+ PersistenceConstants.MTD_GET_ALL_INVC+PersistenceConstants.METHOD_EXIT);
		return invoiceList;
	}
	
	/**
	 * @return
	 */
	@SuppressWarnings("unchecked")
	@Override
	@Transactional
	public List<String> getAllEsos() {
		logger.info(EpaShipmentDAO.class+ PersistenceConstants.MTD_GET_ALL_ESO+PersistenceConstants.METHOD_ENTRY);
		Criteria criteria = getSession().createCriteria(EpaShipment.class);
		criteria.setProjection( Projections.distinct( Projections.projectionList()
				.add( Projections.property(PersistenceConstants.ORD_NUM_VAR), PersistenceConstants.ORD_NUM_VAR)));
		List<String> esoList=	criteria.list();
		esoList.remove(null);
		logger.info(EpaShipmentDAO.class+ PersistenceConstants.MTD_GET_ALL_ESO+ PersistenceConstants.METHOD_EXIT);
		return esoList;
	}


	/* Insert record in Shipment, Machine and engine table in EPA
	 *  (non-Javadoc)
	 * @see IEpaShipmentDAO#insertShipmentEngMch(com.cat.logistics.epa.entities.EpaShipment)
	 */
	/**
	 * @param epaShipment
	 * @return
	 * @throws DaoException
	 */
	@Override
	@Transactional(value="transactionManagerEPA")
	public Long insertShipmentEngMch(EpaShipment epaShipment) throws DaoException {
		logger.info(EpaShipmentDAO.class+ PersistenceConstants.MTD_INSERT_SHIP_ENGMCH+ PersistenceConstants.METHOD_ENTRY
				+ PersistenceConstants.PROCESS_SER_SEQ_NO+epaShipment.getMachineSerialNum()+PersistenceConstants.FRW_SLASH+epaShipment.getEngineSerialNum());
		
		try{
			setEngMach(epaShipment);
			getSession().persist(epaShipment);
			logger.info(EpaShipmentDAO.class+ PersistenceConstants.MTD_INSERT_SHIP_ENGMCH+ PersistenceConstants.METHOD_EXIT);
		}catch(Exception daoExc){
			//logger.fatalEvent(EpaShipmentDAO.class, PersistenceConstants.MTD_INSERT_SHIP_ENGMCH, daoExc.getMessage(), daoExc);
			logger.error(this.getClass() +PersistenceConstants.MTD_INSERT_SHIP_ENGMCH+ daoExc.getMessage());
			throw new DaoException(daoExc);
		}	
		return epaShipment.getEpaSeqNum();
	}
	
	
	/**
	 * insert ShipmentEngMchList
	 * @param epaShipmentLst epaShipmentLst
	 * @throws DaoException
	 */
	@Override
	@Transactional(value="transactionManagerEPA")
	public void insertShipmentEngMchList(List<EpaShipment> epaShipmentLst) throws DaoException {
		logger.info(EpaShipmentDAO.class+ PersistenceConstants.MTD_INSERT_SHIP_ENGMCH_LIST+PersistenceConstants.METHOD_ENTRY);
		EpaShipment epaShipment = null;
		for ( int idx=1; idx<= epaShipmentLst.size(); idx++ ) {	
			epaShipment = epaShipmentLst.get(idx-1);
			getSession().persist(epaShipment);
		    if ( idx % 20 == 0 ) { 
		    	getSession().flush();
		    	getSession().clear();
		    }
		}
		logger.info(EpaShipmentDAO.class+ PersistenceConstants.MTD_INSERT_SHIP_ENGMCH_LIST+ PersistenceConstants.METHOD_EXIT);
	}
	
	/**
	 * save Engine/Machine record
	 * @param epaShpm epaShpm
	 * @return
	 * @throws DaoException
	 */
	@Override
	@Transactional(value="transactionManagerEPA")
	public Long saveEngMch(EpaShipment epaShpm) throws DaoException {
		logger.info(EpaShipmentDAO.class+ PersistenceConstants.MTD_SAVE_ENGMCH+ PersistenceConstants.METHOD_ENTRY
				+ PersistenceConstants.PROCESS_SER_SEQ_NO+epaShpm.getMachineSerialNum()+PersistenceConstants.FRW_SLASH+epaShpm.getEngineSerialNum());
		
		try{
			setEngMach(epaShpm);
			getSession().merge(epaShpm);
			logger.info(EpaShipmentDAO.class+ PersistenceConstants.MTD_SAVE_ENGMCH+ PersistenceConstants.METHOD_EXIT);
		}catch(Exception daoExc){
			//logger.fatalEvent(EpaShipmentDAO.class, PersistenceConstants.MTD_SAVE_ENGMCH, daoExc.getMessage(), daoExc);
			logger.error(this.getClass() + PersistenceConstants.MTD_SAVE_ENGMCH + daoExc.getMessage());
			throw new DaoException(daoExc);
		}	
		return epaShpm.getEpaSeqNum();
	}
	
	
	/**
	 * Set the shipment record on engine/machine
	 * @param epaShipment epaShipment
	 */
	public void setEngMach(EpaShipment epaShipment){
		logger.info(EpaShipmentDAO.class+ PersistenceConstants.MTD_SET_ENGMCH+ PersistenceConstants.METHOD_ENTRY);
		EpaMachine epaMach= epaShipment.getEpaMachines();
		EpaEngine  epaEng = epaShipment.getEpaEngines();
		if(epaMach != null){
			epaMach.setEpaShipment(epaShipment);
			epaMach.getId().setEpaSeqNo(epaShipment.getEpaSeqNum());
		}
		
		if(epaEng != null){
			epaEng.setEpaShipment(epaShipment);
			epaEng.getId().setEpaSeqNo(epaShipment.getEpaSeqNum());
		}
		
		if(epaMach != null)
		epaShipment.setEpaMachines(epaMach);
		
		epaShipment.setEpaEngines(epaEng);
		
	}
	/**
	 * @param epaShipment
	 * @return
	 * @throws DaoException
	 */
	@Override
	@Transactional(value="transactionManagerEPA")
	public Long mergeShipmentEngMch(EpaShipment epaShipment) throws DaoException {
		
		logger.info(EpaShipmentDAO.class+ PersistenceConstants.MTD_MERGE_SHIP_ENGMCH+ PersistenceConstants.METHOD_ENTRY
				+ PersistenceConstants.PROCESS_SER_SEQ_NO+epaShipment.getMachineSerialNum()+PersistenceConstants.FRW_SLASH+epaShipment.getEngineSerialNum());
		EpaMachine epaMach= epaShipment.getEpaMachines();
		EpaEngine  epaEng = epaShipment.getEpaEngines();
		epaMach.setEpaShipment(epaShipment);
		epaEng.setEpaShipment(epaShipment);
		epaShipment.setEpaMachines(epaMach);
		epaShipment.setEpaEngines(epaEng);
		
		try{
			getSession().merge(epaShipment);
			logger.info(EpaShipmentDAO.class+ PersistenceConstants.MTD_MERGE_SHIP_ENGMCH + PersistenceConstants.METHOD_EXIT);
		}catch(Exception daoExc){
			//logger.fatalEvent(EpaShipmentDAO.class,PersistenceConstants.MTD_MERGE_SHIP_ENGMCH, daoExc.getMessage(), daoExc);
			logger.error(this.getClass() + PersistenceConstants.MTD_MERGE_SHIP_ENGMCH+ daoExc.getMessage());
			throw new DaoException(daoExc);
		}	
		return epaShipment.getEpaSeqNum();
	}

	/**
	 * @param epaSeqNum
	 * @return
	 * @throws DaoException
	 */
	@SuppressWarnings("unchecked")
	@Override
	@Transactional
	public List<EpaShipment> getEpaShipmentBySeqNum(String epaSeqNum)
			throws DaoException {
		logger.info(EpaShipmentDAO.class+ PersistenceConstants.MTD_EPA_SHIP_BY_SEQNO+ PersistenceConstants.METHOD_ENTRY);
		Criteria criteria = getSession().createCriteria(EpaShipment.class);
		List<EpaShipment> epaShipmentList=null;
		try{
			
			criteria.setFetchMode(PersistenceConstants.EPA_MACHINS, FetchMode.JOIN);
			criteria.setFetchMode(PersistenceConstants.EPA_ENGINES, FetchMode.JOIN);
			criteria.add(Restrictions.eq(PersistenceConstants.EPA_SEQ_NUM, Long.parseLong(epaSeqNum)));
			epaShipmentList= criteria.list();
		}catch(Exception daoExc){
			//logger.fatalEvent(EpaShipmentDAO.class, PersistenceConstants.MTD_EPA_SHIP_BY_SEQNO, daoExc.getMessage(), daoExc);
			logger.error(this.getClass() + PersistenceConstants.MTD_EPA_SHIP_BY_SEQNO+ daoExc.getMessage());
			throw new DaoException(daoExc);
		}
		logger.info(EpaShipmentDAO.class+ PersistenceConstants.MTD_EPA_SHIP_BY_SEQNO+ PersistenceConstants.METHOD_EXIT);	
		return epaShipmentList;

	}

	/**
	 * 
	 * @param epaShpmnt
	 * @return
	 * @throws DaoException
	 */
	@SuppressWarnings("unchecked")
	@Transactional
	public EpaShipment checkForShpmnt(EpaShipment epaShpmnt)
			throws DaoException {
		logger.info(EpaShipmentDAO.class+ PersistenceConstants.MTD_CHECK_FOR_SHIP+ PersistenceConstants.METHOD_ENTRY);
		List<EpaShipment> epaShList = null;
		EpaShipment epaShipment = null;
		Criteria criteria = getSession().createCriteria(EpaShipment.class);
		try{
			criteria.add(Restrictions.eq(PersistenceConstants.PART_NUM, epaShpmnt.getPartNum()));
			criteria.add(Restrictions.eq(PersistenceConstants.PRT_NUM_INVC_NUM_VAR, epaShpmnt.getInvoiceNum()));
			criteria.add(Restrictions.eq(PersistenceConstants.SUPP_LD_TS,epaShpmnt.getSuppLdTs()));
			criteria.add(Restrictions.eq(PersistenceConstants.ORD_NUM_VAR,epaShpmnt.getOrderNum()));
			criteria.add(Restrictions.eq(PersistenceConstants.SUPP_ITEM_SEQNO,epaShpmnt.getSuppItemSeqNum()));
			criteria.addOrder(Order.desc(PersistenceConstants.RCDLOG_LASTUDT_TS));
			epaShList = criteria.list(); 
			if(epaShList != null && epaShList.size() > 0){
				epaShipment = epaShList.get(0); 
			}
			
		}catch(Exception daoExc){
			//logger.fatalEvent(EpaShipmentDAO.class,PersistenceConstants.MTD_CHECK_FOR_SHIP, daoExc.getMessage(), daoExc);
			logger.error(this.getClass() + PersistenceConstants.MTD_CHECK_FOR_SHIP+ daoExc.getMessage());
			throw new DaoException(daoExc);
		}		
		logger.info(EpaShipmentDAO.class+ PersistenceConstants.MTD_CHECK_FOR_SHIP+ PersistenceConstants.METHOD_EXIT);
		return epaShipment;

	}
	
	@Override
	@Transactional
	public String getCountOfSerilNumExist(String engineSerialNum,
			String machinSerialNum) {
		Criteria criteria = getSession().createCriteria(EpaShipment.class);
		if(null!=engineSerialNum){
			criteria.add(Restrictions.eq("engineSerialNum", engineSerialNum));
			criteria.add(Restrictions.eq("epaProdTypeCode","E"));
		}
		if(null != machinSerialNum){
			criteria.add(Restrictions.eq("machineSerialNum", machinSerialNum));
			criteria.add(Restrictions.eq("epaProdTypeCode","M"));
		}
		Integer totalResult = ((Number)criteria.setProjection(Projections.rowCount()).uniqueResult()).intValue();
		String serNumCheck=String.valueOf(totalResult);
		return serNumCheck;
	}
	
	/**
	 * this method is to check the status of selected engine shipment record to be deleted and returns true if the status is CMP or STB
	 * @param seqNumList sequence list
	 * @return true if status is CMP or STB else false
	 */
	@Override
	@Transactional
	public boolean checkEngShipIsCMPORSTB(List<Long> seqNumList) {
		logger.info(EpaShipmentDAO.class+ PersistenceConstants.CHCK_ENGSHIP_CMP_STB+ PersistenceConstants.METHOD_ENTRY);
		Criteria criteria = getSession().createCriteria(EpaShipment.class);
		criteria.createAlias(PersistenceConstants.ALIS_EPA_STATUS, PersistenceConstants.EPA_STAT);
		criteria.add(Restrictions.in(PersistenceConstants.EPA_SEQ_NUM, seqNumList));
		Criterion cmpStatus = Restrictions.eq(PersistenceConstants.EPA_STATCD, PersistenceConstants.CMP_VAR);	
		Criterion stbStatus = Restrictions.eq(PersistenceConstants.EPA_STATCD, PersistenceConstants.SUBMITTEDTOBROKER);	
		criteria.add(Restrictions.or(cmpStatus, stbStatus));
		boolean isShipExistAsCMPSTB=criteria.uniqueResult() == null ? false : true;
		logger.info(EpaShipmentDAO.class+ PersistenceConstants.CHCK_ENGSHIP_CMP_STB+ PersistenceConstants.METHOD_ENTRY);
		return isShipExistAsCMPSTB;
	}
	
	/**
	 * This method is to delete shipments by passing sequence number list
	 * @param seqNumList sequence list
	 * @return true in case of successful deletion
	 */
	@SuppressWarnings("unchecked")
	@Override
	@Transactional(value="transactionManagerEPA")
	public boolean deleteShipmtsbySeqNum(List<Long> seqNumList) {
		logger.info(EpaShipmentDAO.class+ PersistenceConstants.DEL_SHIPMNTS_BY_SEQNUM+ PersistenceConstants.METHOD_ENTRY);
		boolean deleteSucc=false;
		List<EpaShipment> shipmntList = getSession().createCriteria(EpaShipment.class)
		        .add(Restrictions.in(PersistenceConstants.EPA_SEQ_NUM, seqNumList)).list();
		if (shipmntList.size() > PersistenceConstants.ZERO) {
			for(EpaShipment shipmnt: shipmntList) {
				getSession().delete(shipmnt);
			}
			deleteSucc= true;
		}
		logger.info(EpaShipmentDAO.class+ PersistenceConstants.DEL_SHIPMNTS_BY_SEQNUM+ PersistenceConstants.METHOD_EXIT);
		return deleteSucc;
	}
	
	@Override
	@Transactional
	public List<EpaShipment> getShipmentListByStatusList(List<String> statusCdList,int freqDay){
		Calendar calDate = Calendar.getInstance();
		calDate.add(Calendar.DATE, -freqDay);
		logger.info(EpaMachineDAO.class+ PersistenceConstants.MTD_GET_ENG_BY_STATUS+PersistenceConstants.METHOD_ENTRY);
		Criteria criteria=getSession().createCriteria(EpaShipment.class);
		criteria.createAlias("epaEngines.epaStatus" , PersistenceConstants.EPA_STAT);
		criteria.add(Restrictions.in(PersistenceConstants.EPA_STATCD,statusCdList));
		criteria.add(Restrictions.gt("rcdLog.crteTm", calDate.getTime()));
		List<EpaShipment> shipmentList = criteria.list();
		logger.info(EpaMachineDAO.class+ PersistenceConstants.MTD_GET_ENG_BY_STATUS+PersistenceConstants.METHOD_EXIT);
		return shipmentList;
	}
	
	
}
