package com.cat.logistics.epa.dao.impl;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.transaction.annotation.Transactional;

import com.cat.logistics.epa.dao.IEpaHtsExcpCnfgrDAO;
import com.cat.logistics.epa.entities.EpaHtsExcpConfgr;
import com.cat.logistics.epa.job.utils.BatchConstants;
import com.cat.logistics.shared.dao.impl.GenericJpaDao;
import com.cat.logistics.shared.exception.DaoException;
import com.cat.logistics.shared.utils.PersistenceConstants;

public class EpaHtsExcpCnfgrDAO extends GenericJpaDao<EpaHtsExcpCnfgrDAO, String> implements IEpaHtsExcpCnfgrDAO{
	public static final Logger LOGGER = LogManager.getLogger(EpaHtsExcpCnfgrDAO.class);
	/**
	 * 
	 * @param excptCnfgr
	 * @return
	 * @throws DaoException
	 */
	@Override
	@Transactional
	public EpaHtsExcpConfgr getEpHtsExcpConfgr(EpaHtsExcpConfgr excptCnfgr) throws DaoException {
		LOGGER.info("Entry method of getEpHtsExcpConfgr {}",PersistenceConstants.METHOD_ENTRY);
		EpaHtsExcpConfgr epaHtsCnfgr = null;
		try{
		Criteria criteria = getSession().createCriteria(EpaHtsExcpConfgr.class);
		criteria.add(Restrictions.eq(PersistenceConstants.EXCPT_HTS_CD,excptCnfgr.getExcpHtsCode()));
		criteria.add(Restrictions.eq(PersistenceConstants.PRT_NUM_VAR,excptCnfgr.getPartNumber().trim()));
		epaHtsCnfgr = (EpaHtsExcpConfgr) criteria.uniqueResult();
		LOGGER.info("Exit method of getEpHtsExcpConfgr {}",PersistenceConstants.METHOD_EXIT);
		}catch(Exception exception){
			LOGGER.error("Error in getEpHtsExcpConfgr {} ", PersistenceConstants.EXCP_EP_HTS_EXCP_CONFGR, exception);
			throw new DaoException("SQLException while fetching HTS Exception cofiguration",exception);
		}
		
		
		return epaHtsCnfgr;
	}
}
