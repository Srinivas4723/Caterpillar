package com.cat.logistics.epa.dao;

import java.util.List;

import com.cat.logistics.epa.entities.EpaEngine;
import com.cat.logistics.epa.entities.EpaShipment;
import com.cat.logistics.epa.entities.EpaState;
import com.cat.logistics.epa.helper.FacilityWorkQueueHelper;
import com.cat.logistics.shared.exception.DaoException;


/**
 * @author ganamr
 *
 */
public interface IEpaEngineDAO {


	/**
	 * @return
	 */
	public List<EpaState> getStateOfIssueList();

	/**
	 * @param engine
	 * @return
	 * @throws DaoException
	 */
	public EpaEngine saveEngineInfo(EpaEngine engine) throws DaoException;

	/**
	 * @param engineList
	 * @param SeqNum
	 * @return
	 * @throws DaoException
	 */
	List<String> getEpaEnginesNumbers(List<String> engineList, String seqNum) throws DaoException;
	
	/**
	 * @param engineSerialNumber
	 * @return
	 */
	public Boolean isEpaEngineNumber(String engineSerialNumber);
	
	/**
	 * @param facWrkQueHelper
	 * @return
	 * @throws DaoException
	 */
	public List<EpaShipment> searchEngineShipments(FacilityWorkQueueHelper facWrkQueHelper,boolean missingData) throws DaoException;
	
	/**
	 * @param enginSerialNo
	 * @return
	 */
	public List<EpaEngine> getEngineInfo(String enginSerialNo);

	/**
	 * @param enginSerialNo
	 * @param epaSeqNum
	 * @return
	 */
	public int updateEngineNumber(String enginSerialNo, String epaSeqNum);

	/**
	 * @param epaUserCwsId
	 * @return
	 */
	public Boolean isRecordsExists(String epaUserCwsId);
	
	/**
	 * 
	 * @param engineList
	 * @throws DaoException
	 */
	public void saveEngineInfoList(List<EpaEngine> engineList)throws DaoException;

	/**
	 * @param facWrkQueHelper
	 * @param missingData
	 * @return count of records
	 */
	public int getEngShipCntBySearch(FacilityWorkQueueHelper facWrkQueHelper,
			boolean missingData);
	
}
