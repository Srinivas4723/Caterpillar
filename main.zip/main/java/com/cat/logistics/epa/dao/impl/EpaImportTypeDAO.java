package com.cat.logistics.epa.dao.impl;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.springframework.transaction.annotation.Transactional;

import com.cat.logistics.epa.dao.IEpaImportTypeDAO;
import com.cat.logistics.epa.entities.EpaImportType;
import com.cat.logistics.epa.job.utils.BatchConstants;
import com.cat.logistics.shared.dao.impl.GenericJpaDao;
import com.cat.logistics.shared.utils.PersistenceConstants;

/**
 * EPA Import Type Code DAO
 * 
 * @author singhr9
 *
 */
public class EpaImportTypeDAO extends GenericJpaDao<EpaImportType, String> implements IEpaImportTypeDAO {

	public static final Logger LOGGER = LogManager.getLogger(EpaImportTypeDAO.class);
	/**
	 * Gets list of Import Type codes
	 * @param 
	 */
	@SuppressWarnings("unchecked")
	@Override
	@Transactional
	public List<EpaImportType> getAllImportCodeList() {
		LOGGER.info("Entry method of getAllImportCodeList {}",PersistenceConstants.METHOD_ENTRY);
		Criteria criteria = getSession().createCriteria(EpaImportType.class);
		LOGGER.info("Exit method of getAllImportCodeList {}",PersistenceConstants.METHOD_EXIT);
		return (List<EpaImportType>)criteria.list();
	}
	
	/**
	 * fetch description of import code
	 * @param provisionCd
	 * @return
	 */
	@Override
	@Transactional
	public String getImportDesc(String importCd) {
		LOGGER.info("Entry method of getImportDesc {}",PersistenceConstants.METHOD_ENTRY);
		Criteria criteria = getSession().createCriteria(EpaImportType.class);
		criteria.add(Restrictions.eq(PersistenceConstants.IMPORT_TYPE_CD, importCd));			
		criteria.setProjection(Projections.projectionList()
				.add( Projections.property( PersistenceConstants.IMPORT_TYPE_DESC ) ));
		
		String importDesc = (String) criteria.uniqueResult();
		LOGGER.info("Exit method of getImportDesc {}",PersistenceConstants.METHOD_EXIT);
		return importDesc;
	}
	
}


