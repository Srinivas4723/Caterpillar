package com.cat.logistics.epa.dao.impl;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

import com.cat.logistics.epa.dao.IEpaEngineDAO;
import com.cat.logistics.epa.dao.IEpaShipmentDAO;
import com.cat.logistics.epa.entities.EpaEngine;
import com.cat.logistics.epa.entities.EpaShipment;
import com.cat.logistics.epa.entities.EpaState;
import com.cat.logistics.epa.helper.CriteriaHelper;
import com.cat.logistics.epa.helper.FacilityWorkQueueHelper;
import com.cat.logistics.shared.dao.impl.GenericJpaDao;
import com.cat.logistics.shared.exception.DaoException;
import com.cat.logistics.shared.utils.EPAUtils;
import com.cat.logistics.shared.utils.PersistenceConstants;

/** 
 * This class act as DAO layer to perform engine related operations
 * @author ganamr
 * 
 */ 

public class EpaEngineDAO extends GenericJpaDao<EpaEngine, String>implements IEpaEngineDAO {	
	
	//private ILogger logger = Logger.getInstance();
	
	@Autowired
	CriteriaHelper critHelp;
	
	@Autowired
	private IEpaShipmentDAO epaShipmentDAO;
	
	private final static Logger logger = LogManager.getLogger(EpaEngineDAO.class);

	/*@Value("${hibernate.jdbc.batch_size}")
	private int batchSize;*/

	
	/** 
	 * fetches EPA state of issue list from EPA database and returns stateOfIssuelist object
	 * return list Epa state info
	 */
	@SuppressWarnings("unchecked")
	@Override  
	@Transactional 
	public List<EpaState> getStateOfIssueList(){
		//logger.informationalEvent(EpaEngineDAO.class,PersistenceConstants.MTD_GET_STATEOF_ISSUE_LIST,PersistenceConstants.METHOD_ENTRY);
		logger.info(this.getClass() + PersistenceConstants.MTD_GET_STATEOF_ISSUE_LIST + PersistenceConstants.METHOD_ENTRY);
			List<EpaState> stateOfIssueList= null;
			stateOfIssueList=getSession().getNamedQuery(PersistenceConstants.EPA_STATE_FINDALL).list();
			//logger.informationalEvent(EpaEngineDAO.class, PersistenceConstants.MTD_GET_STATEOF_ISSUE_LIST,PersistenceConstants.METHOD_EXIT);
			
			logger.info(this.getClass() +PersistenceConstants.MTD_GET_STATEOF_ISSUE_LIST + PersistenceConstants.METHOD_EXIT);
			
			return stateOfIssueList;
	} 

	
	/** 
	 * This method is to persist engine info into EPA Database
	 * @engine
	 * @return Persisted engine data
	 */
	@Override
	@Transactional(value="transactionManagerEPA")
	public EpaEngine saveEngineInfo(EpaEngine engine)
			throws DaoException {
		/*logger.informationalEvent(EpaEngineDAO.class,PersistenceConstants.MTD_SAVE_ENGINE_INFO,PersistenceConstants.METHOD_ENTRY);*/
		logger.info(this.getClass() +PersistenceConstants.MTD_SAVE_ENGINE_INFO+PersistenceConstants.METHOD_ENTRY);
		EpaEngine persistEngine =(EpaEngine) getSession().merge(engine);
		//logger.informationalEvent(EpaEngineDAO.class,PersistenceConstants.MTD_SAVE_ENGINE_INFO,PersistenceConstants.METHOD_EXIT);
		logger.info(this.getClass() +PersistenceConstants.MTD_SAVE_ENGINE_INFO+PersistenceConstants.METHOD_EXIT);
		return persistEngine;
	}
	
	/** 
	 * This method is to update engine info record if it already exist in Engine import table
	 * @enginSerialNo
	 * @epaSeqNum
	 *@return count of no of records updated 
	 */
	@Override
	@Transactional(value="transactionManagerEPA")
	public int updateEngineNumber(String enginSerialNo, String epaSeqNum) {
		//logger.informationalEvent(EpaEngineDAO.class,PersistenceConstants.MTD_UPDATE_ENGINE_NUMBER,PersistenceConstants.METHOD_ENTRY);
		logger.info(this.getClass() +PersistenceConstants.MTD_UPDATE_ENGINE_NUMBER+PersistenceConstants.METHOD_ENTRY);
	    Query query = getSession().getNamedQuery(PersistenceConstants.EPA_ENGINE_UPDATE_ENGINENUM);  
	    query.setString(PersistenceConstants.ENGINE_NUMBER, enginSerialNo); 
	    query.setLong(PersistenceConstants.EPA_SEQ_NO, Long.parseLong(epaSeqNum));
		int recordUpdtCnt = query.executeUpdate();
		logger.info(EpaEngineDAO.class + PersistenceConstants.MTD_UPDATE_ENGINE_NUMBER+PersistenceConstants.METHOD_EXIT);
		return recordUpdtCnt;
	}
	
	/** 
	 * fetches the Engine details from EPA database
	 * @return edit Eng Info
	 */
	@Override
	@Transactional
	public List<EpaEngine> getEngineInfo(String enginSerialNo) {
		logger.info(EpaEngineDAO.class + PersistenceConstants.MTD_GET_ENGINE_INFO + PersistenceConstants.METHOD_ENTRY);
		
		List<EpaEngine> engines = null;
		Criteria criteria = getSession().createCriteria(EpaEngine.class);
		criteria.add(Restrictions.eq(PersistenceConstants.ENG_SER_NUM, enginSerialNo));

		engines =  criteria.list();
		
		logger.info(EpaEngineDAO.class + PersistenceConstants.MTD_GET_ENGINE_INFO + PersistenceConstants.METHOD_EXIT);
		return engines;
	}

	/** 
	 * fetches EPA engine serial number
	 *@return list of engine serial numbers 
	 */
	@SuppressWarnings("unchecked")
	@Override
	@Transactional
	public List<String> getEpaEnginesNumbers(List<String> engineList, String seqNum) throws DaoException {
		logger.info(EpaEngineDAO.class + PersistenceConstants.MTD_GET_EPAENGINE_NUMBERS + PersistenceConstants.METHOD_ENTRY);
		List<String> engList = null;
		try{
				Criteria criteria = getSession().createCriteria(EpaEngine.class);
				criteria.add(Restrictions.in(PersistenceConstants.ENG_SER_NUM, engineList));
				if(!EPAUtils.isNullOrEmpty(seqNum)){
					criteria.createAlias(PersistenceConstants.EPA_SHIPMENT, PersistenceConstants.EPA_SHIPMENT);
					criteria.add(Restrictions.ne(PersistenceConstants.EPA_SHIPMENT_SEQ_NO, Long.parseLong(seqNum)));
				}
				criteria.setProjection(Projections.projectionList()
						.add( Projections.property(PersistenceConstants.ENG_SER_NUM ) ));	
				criteria.setProjection(Projections.projectionList()
						.add( Projections.property(PersistenceConstants.MACH_SER_NUM_VAR) ));
				engList = criteria.list();			
				logger.info(EpaEngineDAO.class + PersistenceConstants.MTD_GET_EPAENGINE_NUMBERS + PersistenceConstants.METHOD_EXIT);
		   }catch(Exception exc){	
			  // logger.fatalEvent(EpaEngineDAO.class, PersistenceConstants.MTD_GET_EPAENGINE_NUMBERS, exc.getMessage(), exc);
			   logger.error(this.getClass() + PersistenceConstants.MTD_GET_EPAENGINE_NUMBERS + exc.getMessage());
			   throw new DaoException(exc);
		   }			
		return engList;
	}
	

	/** 
	 * checks the given serial number is belongs to engine or not
	 * @return boolean value like if match true else false
	 */
	@Override
	@Transactional
	public Boolean isEpaEngineNumber(String engineSerialNumber) {
		logger.info(EpaEngineDAO.class + PersistenceConstants.MTD_IS_EPAENG_NUM + PersistenceConstants.METHOD_ENTRY);
		Criteria criteria = getSession().createCriteria(EpaEngine.class);
		Boolean result = criteria
				.add(Restrictions.eq(PersistenceConstants.ENG_SER_NUM, engineSerialNumber))
				.setProjection(Projections.property(PersistenceConstants.ENG_SER_NUM))
				.uniqueResult() == null ? false : true;	
		logger.info(EpaEngineDAO.class + PersistenceConstants.MTD_IS_EPAENG_NUM + PersistenceConstants.METHOD_EXIT);
		return result;			
	}
	
	/** 
	 * fetches Engine shipment details from EPA database for the given search criteria in the facility workQ Engine screen
	 * @param facWrkQueHelper facWrkQueHelper
	 * @param missingData missingData
	 *@return list of Epa shipment info
	 */
	@Override
	@Transactional
	public List<EpaShipment> searchEngineShipments(FacilityWorkQueueHelper facWrkQueHelper,boolean missingData) throws DaoException {
		List<EpaShipment> shipments=null;
	logger.info(EpaEngineDAO.class + PersistenceConstants.MTD_SEARCH_ENG_SHIPMNTS + PersistenceConstants.METHOD_ENTRY);
	boolean fetch = false;
	
	try {
	Criteria criteria = getSession().createCriteria(EpaShipment.class);
	fetch = buildSearchCriteria(facWrkQueHelper, criteria,missingData,fetch);
	if(fetch){
		shipments=criteria.list();	
	}
	logger.info(EpaEngineDAO.class + PersistenceConstants.MTD_SEARCH_ENG_SHIPMNTS + PersistenceConstants.METHOD_EXIT);
	} catch (Exception e) {
		//logger.fatalEvent(EpaEngineDAO.class, PersistenceConstants.MTD_SEARCH_ENG_SHIPMNTS, e.getMessage(), e);
		logger.error(this.getClass() + PersistenceConstants.MTD_SEARCH_ENG_SHIPMNTS + e.getMessage());
		throw new DaoException(e);
	}
	return shipments;
	}
	
	private boolean buildSearchCriteria(FacilityWorkQueueHelper facWrkQueHelper,
			Criteria criteria, boolean missingData,boolean fetch) {
		if(!missingData){
			fetch = critHelp.statusCriteria(facWrkQueHelper.getWrkQueSFormStatus(), criteria);
			}else{
			fetch=critHelp.fetchMsngInfo(facWrkQueHelper,criteria,PersistenceConstants.E_VAR);
			}
		fetch = addEngShmntCrit(facWrkQueHelper, criteria);
		criteria.add(Restrictions.eq(PersistenceConstants.EPA_PROD_TYP, PersistenceConstants.E_VAR));
		return fetch;
	}


	public boolean addBuild(FacilityWorkQueueHelper facilityWorkQueueHelper,Criteria criteria,boolean fetch){	
		if(null != facilityWorkQueueHelper.getFromBuildDate() && null != facilityWorkQueueHelper.getToBuildDate()){
			criteria.createAlias(PersistenceConstants.EPA_ENGINES, PersistenceConstants.EPA_ENG);}
		fetch =	critHelp.addDtCrit(facilityWorkQueueHelper.getFromBuildDate(),facilityWorkQueueHelper.getToBuildDate(),criteria,PersistenceConstants.EPA_ENG_MNF_DATE,fetch);
		return fetch;
	}
	
	
	public boolean addEngShmntCrit(FacilityWorkQueueHelper facWrkQueHelper,Criteria criteria){
		logger.info(EpaEngineDAO.class + PersistenceConstants.MTD_ADD_ENG_SHIPNT_CRI + PersistenceConstants.METHOD_ENTRY);
		boolean fetch = false;
		fetch = critHelp.addShmntCrit(facWrkQueHelper, criteria, PersistenceConstants.ENG_SER_NUM_VAR,PersistenceConstants.TRUE);
		fetch = addBuild(facWrkQueHelper, criteria,fetch);
		logger.info(EpaEngineDAO.class + PersistenceConstants.MTD_ADD_ENG_SHIPNT_CRI + PersistenceConstants.METHOD_EXIT);
		return fetch;
	}
	
	
	

	/** 
	 * checks whether record is existed or not for the given cws id in the Engine import table
	 * @return boolean value if record exist true else false
	 */
	@Override
	@Transactional
	public Boolean isRecordsExists(String epaUserCwsId) {
		logger.info(EpaEngineDAO.class + PersistenceConstants.MTD_IS_RCRD_EXIST + PersistenceConstants.METHOD_ENTRY);
		Boolean result = false;
		List<String> engList = null;
		Criteria criteria = getSession().createCriteria(EpaEngine.class);
		criteria.add(Restrictions.eq(PersistenceConstants.RCD_LAST_UPD_LOGON_ID, epaUserCwsId));	
		criteria.add(Restrictions.ne(PersistenceConstants.EPA_STATUS_CD,PersistenceConstants.SUBMITTEDTOBROKER));	
		criteria.setProjection(Projections.projectionList()
				.add( Projections.property(PersistenceConstants.RCD_LAST_UPD_LOGON_ID) ));
		engList = criteria.list();	
		if (engList != null && engList.size() > 0) {
			result = true;
		}
		logger.info(EpaEngineDAO.class + PersistenceConstants.MTD_IS_RCRD_EXIST + PersistenceConstants.METHOD_EXIT);
		return result;	
	}
	
	
	/**
	 * save EngineInfoList
	 * @param engineList engineList
	 * @throws DaoException
	 */
	@Override
	@Transactional(value="transactionManagerEPA")
	public void saveEngineInfoList(List<EpaEngine> engineList)
			throws DaoException {
		logger.info(EpaEngineDAO.class + PersistenceConstants.MTD_SAVE_ENGINE_INFO_LIST + PersistenceConstants.METHOD_ENTRY);
		EpaEngine epaEngine = null;
		for ( int idx=1; idx<= engineList.size(); idx++ ) {	
			epaEngine = engineList.get(idx-1);
			getSession().persist(epaEngine);
		    if ( idx % 20 == 0 ) { 
		    	getSession().flush();
		    	getSession().clear();
		    }
		}
		logger.info(EpaEngineDAO.class + PersistenceConstants.MTD_SAVE_ENGINE_INFO_LIST + PersistenceConstants.METHOD_EXIT);
	}
	/** 
	 * Fetches the count of Engine shipments
	 * @param facWrkQueHelper facWrkQueHelper
	 * @param missingData missingData
	 *@return list of Epa shipment info
	 */
	@Override
	@Transactional
	public int getEngShipCntBySearch(FacilityWorkQueueHelper facWrkQueHelper,boolean missingData){
		boolean fetch=false;
		int count =0;
		Criteria criteria = getSession().createCriteria(EpaShipment.class);
		fetch = buildSearchCriteria(facWrkQueHelper, criteria,missingData,fetch);
		if(fetch){
			count=criteria.list().size();	
		}
		return count;	
	}
}

