package com.cat.logistics.epa.dao;

import com.cat.logistics.epa.entities.EpaHtsExcpConfgr;
import com.cat.logistics.shared.exception.DaoException;

public interface IEpaHtsExcpCnfgrDAO {
	/**
	 * @param excptCnfgr
	 * @return
	 * @throws DaoException
	 */
	EpaHtsExcpConfgr getEpHtsExcpConfgr(EpaHtsExcpConfgr excptCnfgr) throws DaoException;
}
