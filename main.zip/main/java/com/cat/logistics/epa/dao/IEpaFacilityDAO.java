package com.cat.logistics.epa.dao;

import java.util.List;

import com.cat.logistics.epa.entities.EpaFac;
import com.cat.logistics.shared.dao.IGenericJpaDao;
import com.cat.logistics.shared.exception.DaoException;

public interface IEpaFacilityDAO  extends IGenericJpaDao<EpaFac, String> {

	/**
	 * @return
	 */
	List<EpaFac> getAllFacilities();
	/**
	 * @return
	 */
	public List<String> getAllFacilityCodes();
	
	/**
	 * @param facilityCode
	 * @return
	 * @throws DaoException
	 */
	public EpaFac getFacilityDetail(String facilityCode) throws DaoException;
	
	/**
	 * @param facilityCode
	 * @return
	 * @throws DaoException
	 */
	public EpaFac getFacility(String facilityCode) throws DaoException;
	/**
	 * @param facCd
	 * @return
	 * @throws DaoException
	 */
	public String getfacilityDesc(String facCd) throws DaoException;
	
	/**
	 * @param suppCd
	 * @return
	 * @throws DaoException
	 */
	public EpaFac getFacBySuppCd(String suppCd) throws DaoException ;

}
