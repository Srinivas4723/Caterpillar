package com.cat.logistics.epa.dao.impl;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.springframework.transaction.annotation.Transactional;

import com.cat.logistics.epa.dao.IEpaProvisionTypeDAO;
import com.cat.logistics.epa.entities.EpaProvisionType;
import com.cat.logistics.epa.job.utils.BatchConstants;
import com.cat.logistics.shared.dao.impl.GenericJpaDao;
import com.cat.logistics.shared.exception.DaoException;
import com.cat.logistics.shared.utils.PersistenceConstants;

/**
 * EPA Import Provision Type Code DAO
 * 
 * @author singhr9
 *
 */
public class EpaProvisionTypeDAO extends GenericJpaDao<EpaProvisionType, String> implements IEpaProvisionTypeDAO {
	public static final Logger LOGGER = LogManager.getLogger(EpaProvisionTypeDAO.class);

	/**
	 * Gets list of Import Provision Type codes
	 * @param 
	 */
	@SuppressWarnings("unchecked")
	@Override
	@Transactional
	public List<EpaProvisionType> getAllImportProvisionList() {
		LOGGER.info("Entry method of getAllImportProvisionList {}",PersistenceConstants.METHOD_ENTRY);
		Criteria criteria = getSession().createCriteria(EpaProvisionType.class);
		LOGGER.info("Exit method of getAllImportProvisionList {}",PersistenceConstants.METHOD_EXIT);
		return (List<EpaProvisionType>)criteria.list();
	}
	

	/**
	 * fetch description of provision code
	 * @param provisionCd
	 * @return
	 * @throws DaoException 
	 */
	@Override
	@Transactional
	public String getImportProvisionDesc(String provisionCd) throws DaoException {
		LOGGER.info("Entry method of getImportProvisionDesc {}",PersistenceConstants.METHOD_ENTRY);
		try{
			Criteria criteria = getSession().createCriteria(EpaProvisionType.class);
			criteria.add(Restrictions.eq(PersistenceConstants.PROVISION_TYPE_CD, provisionCd));			
			criteria.setProjection(Projections.projectionList()
					.add( Projections.property( PersistenceConstants.PROVISION_TYPE_DESC) ));
			
			String provDesc = (String) criteria.uniqueResult();
			LOGGER.info("Exit method of getImportProvisionDesc {}",PersistenceConstants.METHOD_EXIT);
		 return provDesc;
		}catch (Exception daoExc){
			LOGGER.error("Error in getImportProvisionDesc {}", daoExc.getMessage(), daoExc);
			throw new DaoException(daoExc);
		}
	}
}


