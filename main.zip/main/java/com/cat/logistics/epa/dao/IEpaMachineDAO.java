package com.cat.logistics.epa.dao;

import java.util.List;

import com.cat.logistics.epa.entities.EpaEngine;
import com.cat.logistics.epa.entities.EpaMachine;
import com.cat.logistics.epa.entities.EpaShipment;
import com.cat.logistics.epa.helper.FacilityWorkQueueHelper;
import com.cat.logistics.shared.dao.IGenericJpaDao;
import com.cat.logistics.shared.exception.DaoException;

public interface IEpaMachineDAO extends IGenericJpaDao<EpaMachine, String> {
	/**
	 * @param machineSerialNumber
	 * @return
	 */
	Boolean isEpaMachineNumber(String machineSerialNumber);
	/**
	 * @param facilityWorkQueueHelper
	 * @return
	 * @throws DaoException
	 */
	public List<EpaShipment> searchMachineShipments(FacilityWorkQueueHelper facilityWorkQueueHelper,boolean missingData)throws DaoException ;
	/**
	 * @param statusCdList
	 * @return
	 */
	public List<EpaEngine> getEnginesListByStatusList(List<String> statusCdList);
	/**
	 * @param mchSerNo
	 * @return
	 */
	public List<EpaEngine> getEngines(String mchSerNo);

	/**
	 * @param machineSerialNo
	 * @param epaSeqNum
	 * @return Integer value
	 */
	public int updateMachineNumber(String machineSerialNo,
			String epaSeqNum);
	/**
	 * @param facWrkQueHelper
	 * @param missingData
	 * @return Integer value
	 */
	public int getMchShipCntBySearch(FacilityWorkQueueHelper facWrkQueHelper,
			boolean missingData);
	
}
