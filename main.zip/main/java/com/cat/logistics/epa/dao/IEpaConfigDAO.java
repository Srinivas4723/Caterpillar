package com.cat.logistics.epa.dao;

import java.util.List;

import com.cat.logistics.epa.entities.EpaConfig;
import com.cat.logistics.shared.exception.DaoException;


/**
 * @author singhr9
 *
 */
public interface IEpaConfigDAO  {

	/**
	 * @param configType
	 * @return
	 * @throws DaoException
	 */
	List<EpaConfig> getEpaConfig(String configType)
			throws DaoException;
	
	/**
	 * @return
	 * @throws DaoException
	 */
	public EpaConfig getSupportMails() throws DaoException;
	
	
	/**
	 * 
	 * @param timeStamp
	 * @param jobName
	 * @throws DaoException
	 */
	public void logStartTime(String timeStamp,String jobName) throws DaoException;
	
	/**
	 * @param timeStamp
	 * @throws DaoException
	 */
	public void logEndTime(String timeStamp,String jobName) throws DaoException;
	
	/**
	 * @return
	 * @throws DaoException
	 */
	public int getJobFreq(String jobName) throws DaoException;
	
	/**
	 * Reads the epa batch job last successfull timestamp
	 * @return
	 * @throws DaoException
	 */
	public EpaConfig getLstSccsTm(String jobName) throws DaoException;
	
	/**
	 * saves the epa batch job lasst succesful run timestamp
	 * @return
	 * @throws DaoException
	 */
	public void saveLstSccsTm(EpaConfig epaConfig) throws DaoException;
	
	/**
	 * 
	 * @return
	 * @throws DaoException
	 */
	public EpaConfig getRunTms() throws DaoException;
	
	/**
	 * 
	 * @return
	 * @throws DaoException
	 */
	public String getHtsJobFreq() throws DaoException;
	
	/**
	 * @param jobName
	 * @return
	 * @throws DaoException
	 */
	public int getEpaDataRefFreq(String jobName) throws DaoException;
	

}
