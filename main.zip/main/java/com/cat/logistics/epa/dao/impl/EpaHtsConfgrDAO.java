package com.cat.logistics.epa.dao.impl;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.transaction.annotation.Transactional;

import com.cat.logistics.epa.dao.IEpaHtsConfgrDAO;
import com.cat.logistics.epa.entities.EpaHtsConfgr;
import com.cat.logistics.epa.job.utils.BatchConstants;
import com.cat.logistics.shared.dao.impl.GenericJpaDao;
import com.cat.logistics.shared.exception.DaoException;
import com.cat.logistics.shared.utils.PersistenceConstants;

@SuppressWarnings("unchecked")
public class EpaHtsConfgrDAO extends GenericJpaDao<EpaHtsConfgr, String> implements IEpaHtsConfgrDAO{
	public static final Logger LOGGER = LogManager.getLogger(EpaHtsConfgrDAO.class);
	
	/**
	 * Gets htsConfiguration entity by hts code attribute
	 *  
	 * @param part
	 * @return
	 */

	@Override
	@Transactional
	public EpaHtsConfgr getHtsConfgrByCode(List<String> htsCode) throws DaoException {
		LOGGER.info("Entry method of getHtsConfgrByCode {}",PersistenceConstants.METHOD_ENTRY);
		EpaHtsConfgr epaHtsCnfgr = null;
		List<EpaHtsConfgr> epaHtsConfgrs = null;
		try{
		Criteria htsCfgcriteria = getSession().createCriteria(EpaHtsConfgr.class);
		htsCfgcriteria.add(Restrictions.in(PersistenceConstants.HTS_CD,htsCode));
		epaHtsConfgrs =  htsCfgcriteria.list();
		if(!epaHtsConfgrs.isEmpty()) {
			epaHtsCnfgr = epaHtsConfgrs.get(0);
		}
		LOGGER.info("Exit method of getHtsConfgrByCode {}",PersistenceConstants.METHOD_EXIT);
		}catch(Exception exHtsCfg){
			LOGGER.error("Error in getHtsConfgrByCode {} ", PersistenceConstants.EXCP_HTS_CONFGR_BY_CD, exHtsCfg);
			throw new DaoException("SQLException while fetching HTS Exception cofiguration",exHtsCfg);
		}
		return epaHtsCnfgr;
	}

	/**
	 * Reads all configured EPA HTS codes to determins
	 * part to be engine or machine
	 */ 
	@Override
	@Transactional
	public List<EpaHtsConfgr> getEpaHtsCds() throws DaoException {
		List<EpaHtsConfgr> epaHtsConfgrList = null;
		try{
			Criteria epaHtsCriteria = getSession().createCriteria(EpaHtsConfgr.class);
			epaHtsConfgrList =  epaHtsCriteria.list();
			LOGGER.info("Entry method of getEpaHtsCds {} {}",PersistenceConstants.MTD_HTS_CONFGR_BY_CDS,PersistenceConstants.METHOD_EXIT);
			}catch(Exception exHts){
				LOGGER.error("Error in getEpaHtsCds {}", PersistenceConstants.EXCP_HTS_CONFGR_BY_CDS, exHts);
				throw new DaoException("SQLException while fetching HTS Exception cofiguration",exHts);
			}
			return epaHtsConfgrList;
	}
	
	


}
