package com.cat.logistics.epa.dao;

import java.util.List;

import com.cat.logistics.epa.entities.EpaShipment;
import com.cat.logistics.shared.dao.IGenericJpaDao;
import com.cat.logistics.shared.exception.DaoException;

public interface IEpaShipmentDAO extends IGenericJpaDao<EpaShipment, Long> {
	/**
	 * @param machNum
	 * @param epaSeqNum
	 * @return
	 * @throws DaoException
	 */
	public List<EpaShipment> getEpaShipmentbyMachOrEngNum(String machNum, String epaSeqNum) throws DaoException;
	/**
	 * @return
	 */
	public List<String> getAllInvoiceNo();
	/**
	 * @return
	 */
	public List<String> getAllEsos();
	/**
	 * @param epaShipment
	 * @return
	 * @throws DaoException
	 */
	public Long insertShipmentEngMch(EpaShipment epaShipment) throws DaoException;
	/**
	 * @param epaSeqNum
	 * @return
	 * @throws DaoException
	 */
	public List<EpaShipment> getEpaShipmentBySeqNum(String epaSeqNum) throws DaoException;
	/**
	 * @param epaShipment
	 * @return
	 * @throws DaoException
	 */
	Long mergeShipmentEngMch(EpaShipment epaShipment) throws DaoException;
	/**
	 * 
	 * @param epaShpmnt
	 * @return
	 * @throws DaoException
	 */
	public EpaShipment checkForShpmnt(EpaShipment epaShpmnt)
	throws DaoException ;
	/**
	 * 
	 * @param epaShipment
	 * @return
	 * @throws DaoException
	 */
	public Long saveEngMch(EpaShipment epaShipment) throws DaoException;
	
	/**
	 * @param engineSerialNum
	 * @param machinSerialNum
	 * @return the count serilNum exist in form of String
	 */
	String getCountOfSerilNumExist(String engineSerialNum,
			String machinSerialNum); 
	
	/**
	 * 
	 * @param epaShipmentLst
	 * @throws DaoException
	 */
	public void insertShipmentEngMchList(List<EpaShipment> epaShipmentLst) throws DaoException;
	
	/**
	 * @param seqNumList
	 * @return true or false
	 */
	public boolean checkEngShipIsCMPORSTB(List<Long> seqNumList);
	
	/**
	 * @param seqNumList
	 * @return true or false
	 */
	public boolean deleteShipmtsbySeqNum(List<Long> seqNumList) throws DaoException;
	
	List<EpaShipment> getShipmentListByStatusList(List<String> statusCdList,int freqDay);
}
