/**
 * Copyright (c) Caterpillar Inc. All Rights Reserved.
 * This work contains Caterpillar Inc.'s unpublished proprietary information
 * which may constitute a trade secret and/or be confidential. This work 
 * may be used only for the purposes for which it was provided, and may 
 * not be copied or disclosed to others. Copyright notice is precautionary 
 * only, and does not imply publication.
 *
 * Logger.java
 * Class Description  : 
 * Revision History
 * Version        Date         Changed By        Comments
 *  1.0           Oct 9, 2015      kk3           Initial Creation
 */
package com.cat.logistics.epa.service.impl;

import org.apache.commons.net.ftp.FTPFile;
import org.apache.commons.net.ftp.FTPFileFilter;

import com.cat.logistics.epa.job.utils.BatchConstants;


/**
 * it act as a DailyStmtFileFilter
 *
 */
public class AutoECCNFileFilter implements FTPFileFilter{

	/** This method used to retrieve files which is starting with ACH daily
	 *@param ftpFile FTPFile
	 */
	
	@Override
	public boolean accept(FTPFile ftpFile) {
	 
	        return (ftpFile.isFile() && ftpFile.getName().startsWith(BatchConstants.ECCN_OUT)
	        			&& (ftpFile.getName().endsWith(".xlsx") || ftpFile.getName().endsWith(".xls") || 
	        					ftpFile.getName().endsWith(".zip") ));
	}



}
