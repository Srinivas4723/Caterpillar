package com.cat.logistics.epa.service.impl;

import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import com.cat.logistics.epa.dao.IEpaFacilityDAO;
import com.cat.logistics.epa.dao.IEpaShipmentDAO;
import com.cat.logistics.epa.dto.EpaShipmentDTO;
import com.cat.logistics.epa.entities.EpaEngine;
import com.cat.logistics.epa.entities.EpaFac;
import com.cat.logistics.epa.entities.EpaMachine;
import com.cat.logistics.epa.entities.EpaShipment;
import com.cat.logistics.epa.entities.EpaStatus;
import com.cat.logistics.epa.entities.RcrdUpdtLog;
import com.cat.logistics.epa.job.service.IMachCreateService;
import com.cat.logistics.epa.job.utils.BatchConstants;
import com.cat.logistics.epa.job.utils.Utils;
import com.cat.logistics.epa.populators.IEnginePopulator;
import com.cat.logistics.epa.populators.IMachPopulator;
import com.cat.logistics.epa.populators.IShpmntPopulator;
import com.cat.logistics.shared.dto.EngineDTO;
import com.cat.logistics.shared.dto.MachineDTO;
import com.cat.logistics.shared.exception.DaoException;
import com.cat.logistics.shared.exception.ServiceException;
import com.cat.logistics.shared.utils.PersistenceConstants;
import com.cat.logistics.shared.utils.ServiceConstants;
import com.cat.logistics.shared.utils.ServiceUtils;

/**
 * 
 * @author chanda15
 *
 */
public class MachineCreateService extends EngMachService implements IMachCreateService {

	@Autowired
	private IShpmntPopulator shpPopulator;

	@Autowired
	private IEnginePopulator enginePopulator;

	@Autowired
	private IMachPopulator machPopulator;

	@Autowired
	private IEpaShipmentDAO epaShipmentDAO;

	@Autowired
	private IEpaFacilityDAO epaFacilityDAO;

	public static final Logger LOGGER = LogManager.getLogger(MachineCreateService.class);

	/**
	 * This is abstract method to create machine , machine's engine and shipment
	 * information This method determines if a new machine to be created , or to
	 * update an existing machine or create a duplicate machine
	 * 
	 * @param engineShpmntDTO engineShpmntDTO
	 * @param engineDTO       engineDTO
	 * @param machineDTO      machineDTO
	 * @throws ServiceException ServiceException
	 */
	public void createMachineShipment(EpaShipmentDTO engineShpmntDTO, EngineDTO engineDTO, MachineDTO machineDTO)
			throws ServiceException {

		LOGGER.info("Entry method of createMachineShipment {} {} {} {} {}",
				BatchConstants.CRET_MCH_INFO, engineShpmntDTO.getItmSeqNo(), engineShpmntDTO.getInvoiceNum(),
				engineShpmntDTO.getPartNum(), engineShpmntDTO.getProductSerialNum());
		if (null != machineDTO) {

			setMfrName(machineDTO, engineShpmntDTO);
			String engNum = null;

			Set<String> engines = machineDTO.getEngineNumbers();
			if (engines != null && !engines.isEmpty()) {
				Iterator<String> itr = engines.iterator();

				if (itr.hasNext()) {
					engNum = itr.next();
					List<EpaEngine> engineList = getEngine(engNum.trim());

					processMachine(engineList, engineShpmntDTO, engineDTO, machineDTO);
				}
			} else {
				updateMachine(null, engineShpmntDTO, engineDTO, machineDTO);
			}
		} else if (null != engineShpmntDTO) {

			updateMachine(null, engineShpmntDTO, engineDTO, machineDTO);
		}
		LOGGER.info("Exit method of createMachineShipment{} {}", BatchConstants.MTD_CRET_MCH_SHIPMT,
				BatchConstants.METHOD_EXIT);

	}

	/**
	 * 
	 * @param machineDto      machineDto
	 * @param engineShpmntDTO engineShpmntDTO
	 * @throws ServiceException ServiceException
	 */
	public void setMfrName(MachineDTO machineDto, EpaShipmentDTO engineShpmntDTO) throws ServiceException {
		LOGGER.info("Entry method of setMfrName {}", BatchConstants.METHOD_ENTRY);
		String srcFcCd = null;
		srcFcCd = machineDto.getMachineSrcFac();
		EpaFac epaFac = null;
		String mfrNm = null;

		if (null != srcFcCd) {
			try {
				epaFac = epaFacilityDAO.getFacility(srcFcCd);
			} catch (DaoException daoex) {
				LOGGER.error("Error in setMfrName {} {}", BatchConstants.MTD_FAC_VALIDATIONS, daoex);
				throw new ServiceException(daoex);
			}
			if (null != epaFac) {
				mfrNm = getMachMfrName(epaFac);
				machineDto.setMachineMfrName(mfrNm);
			} else {
				machineDto.setMachineSrcFac(null);
			}
		}
		LOGGER.info("Exit method of setMfrName {}", BatchConstants.METHOD_EXIT);
	}

	/**
	 * @param epaFac epaFac
	 * @return mfrname manufactur name
	 */
	public String getMachMfrName(EpaFac epaFac) {
		String mfrName = null;
		if (!ServiceUtils.isNullOrEmpty(epaFac.getMachineMfrName())) {
			mfrName = epaFac.getMachineMfrName();
		} else if (!ServiceUtils.isNullOrEmpty(epaFac.getFacilityName())) {
			mfrName = epaFac.getFacilityName();
		}

		return mfrName;
	}

	/**
	 * 
	 * @param engineList      engineList
	 * @param engineShpmntDTO engineShpmntDTO
	 * @param engineDTO       engineDTO
	 * @param machineDTO      machineDTO
	 * @throws ServiceException ServiceException
	 */
	public void processMachine(List<EpaEngine> engineList, EpaShipmentDTO engineShpmntDTO, EngineDTO engineDTO,
			MachineDTO machineDTO) throws ServiceException {
		EpaEngine existEng = null;
		LOGGER.info("Entry method of processMachine {}", BatchConstants.METHOD_ENTRY);
		if (null != engineList && !engineList.isEmpty()) {
			LOGGER.info("Entry method of processMachine {} {} {} {}",
					BatchConstants.METHOD_ENTRY, engineShpmntDTO.getItmSeqNo(), engineShpmntDTO.getInvoiceNum(),
					engineShpmntDTO.getPartNum());
			existEng = chkEngFrUpdt(engineList);
			if (null != existEng) {
				updtMchEng(existEng, engineShpmntDTO, engineDTO, machineDTO);
			} else {
				// method has been commented to remove duplicates been created from batch job-
				// CHG0054700
				// crteDupMchEng(engineShpmntDTO, engineDTO,machineDTO,engineList);

			}
		} else {
			updateMachine(null, engineShpmntDTO, engineDTO, machineDTO);
		}
		LOGGER.info("Exit method of processMachine {}", BatchConstants.METHOD_EXIT);
	}

	/**
	 * 
	 * @param existEng        existEng
	 * @param engineShpmntDTO engineShpmntDTO
	 * @param engineDTO       engineDTO
	 * @param machineDTO      machineDTO
	 * @throws ServiceException ServiceException
	 */
	public void updtMchEng(EpaEngine existEng, EpaShipmentDTO engineShpmntDTO, EngineDTO engineDTO,
			MachineDTO machineDTO) throws ServiceException {

		if (valUpdtEng(existEng)) {
			updateMachine(existEng, engineShpmntDTO, engineDTO, machineDTO);
		}

	}

	/**
	 * Updates and creates Machine , engine and shipment entities
	 * 
	 * @param existEng        existEng
	 * @param engineShpmntDTO engineShpmntDTO
	 * @param engineDTO       engineDTO
	 * @param machineDTO      machineDTO
	 * @throws ServiceException ServiceException
	 */
	public void updateMachine(EpaEngine existEng, EpaShipmentDTO engineShpmntDTO, EngineDTO engineDTO,
			MachineDTO machineDTO) throws ServiceException {
		LOGGER.info("Entry method of updateMachine {}", BatchConstants.METHOD_ENTRY);
		EpaShipment epaMchShp = null;
		EpaShipment existShpmt = null;
		EpaEngine epaEngine = null;
		EpaMachine epaMachine = null;
		boolean invldEngNum = false;

		epaMchShp = shpPopulator.populateEpaShipment(engineShpmntDTO);

		LOGGER.info("Entry method of updateMachine {} {} {} {}", BatchConstants.METHOD_ENTRY,engineShpmntDTO.getItmSeqNo(),
				engineShpmntDTO.getInvoiceNum(),engineShpmntDTO.getProductSerialNum());

		if (null != existEng) {
			existShpmt = existEng.getEpaShipment();
			epaMchShp.setEpaSeqNum(existShpmt.getEpaSeqNum());
			LOGGER.info("Entry method of updateMachine {} {} {} {}",BatchConstants.MTD_CREATE_ENG_SHIPMT, epaMchShp.getEpaSeqNum(),
					epaMchShp.getInvoiceNum(),
					epaMchShp.getPartNum());
		} else {
			boolean notNewEntry = true;
			existShpmt = checkShpExist(engineShpmntDTO);
			if (null != existShpmt && null != existShpmt.getEpaEngines()) {
				String statusVal = existShpmt.getEpaEngines().getEpaStatus().getEpaStatusCd();
				if ((statusVal.equals(ServiceConstants.STB) || statusVal.equals(ServiceConstants.CMP))) {
					notNewEntry = false;
				}
			}
			if (null != existShpmt && notNewEntry) {
				epaMchShp.setEpaSeqNum(existShpmt.getEpaSeqNum());
			}
		}

		if (null != engineDTO) {
			invldEngNum = valEngNum(epaMchShp, engineDTO.getEngineSerialNumber());
			if (!invldEngNum) {
				epaEngine = enginePopulator.populateEpaEngine(engineDTO, true);
				if (engineDTO.getEngineSerialNumber() != null) {
					epaMchShp.setEngineSerialNum(engineDTO.getEngineSerialNumber().toUpperCase());
				}
				if (epaMchShp.getMachineSerialNum() != null) {
					epaEngine.setMachineSerialNum(epaMchShp.getMachineSerialNum().trim().toUpperCase());
				}
				epaMchShp.setEpaEngines(epaEngine);
				epaEngine.setEpaShipment(epaMchShp);
				if (epaMchShp.getEpaSeqNum() != 0) {
					epaEngine.getId().setEpaSeqNo(epaMchShp.getEpaSeqNum());
				}
			}
		}

		if (null != machineDTO) {
			// If the engine info (engineDTO) not available but machine has engine numbers
			// from ODS then
			// following loop will execute
			if (engineDTO == null
					&& (machineDTO.getEngineNumbers() != null && !machineDTO.getEngineNumbers().isEmpty())) {
				for (String engNum : machineDTO.getEngineNumbers()) {
					invldEngNum = valEngNum(epaMchShp, engNum);
					if (!invldEngNum) {
						epaEngine = enginePopulator.populateEpaEngine(null, true);
						enginePopulator.validateEngSerNum(epaEngine, engNum.trim().toUpperCase());
						enginePopulator.valEngMacNum(epaEngine, machineDTO.getMachineSerialNum().trim().toUpperCase());
						EpaStatus status = new EpaStatus(BatchConstants.MISSING_DATA);
						epaEngine.setEpaStatus(status);
						epaMchShp.setEpaEngines(epaEngine);
						epaEngine.setEpaShipment(epaMchShp);
						break;
					}
				}
			}
			epaMachine = machPopulator.populateEpaMachine(machineDTO);
			machPopulator.setMachStatus(epaMachine, epaEngine);
			enginePopulator.valEngMacNum(epaEngine, machineDTO.getMachineSerialNum().trim().toUpperCase());
			if (epaMchShp.getEpaSeqNum() != 0) {
				epaMachine.getId().setEpaSeqNo(epaMchShp.getEpaSeqNum());
				if (null != epaEngine) {
					epaEngine.getId().setEpaSeqNo(epaMchShp.getEpaSeqNum());
				}
			}
			epaMchShp.setEpaMachines(epaMachine);

		} else if (null != engineShpmntDTO.getProductSerialNum()) {
			EpaMachine machine = new EpaMachine();
			machPopulator.validateMchSerNum(machine, epaMchShp.getMachineSerialNum().trim().toUpperCase());
			RcrdUpdtLog updtLog = Utils.getRcdUpLg();
			machine.setRcdLog(updtLog);
			epaMchShp.setEpaMachines(machine);
		}

		try {
			LOGGER.info("Entry method of updateMachine {} {}",BatchConstants.MTD_CRET_MCH_SHIPMT,
					BatchConstants.SAVING_ENG_MCH);
			epaShipmentDAO.saveEngMch(epaMchShp);
		} catch (DaoException e) {
			LOGGER.error ("Error in getConfigData {} {} {} {} {} {}", BatchConstants.MTD_CRET_MCH_SHIPMT,
					BatchConstants.FAIL_INSERT_SHIP_ENGMCH,epaMchShp.getInvoiceNum(), epaMchShp.getMachineSerialNum(),epaMchShp.getPartNum(),e);
			throw new ServiceException(e);
		}
		LOGGER.info("Exit method of updateMachine {}", BatchConstants.METHOD_EXIT);

	}

	/**
	 * @param epaMchShp epaMchShp
	 * @param engSerNum engSerNum
	 * @return true or false
	 */
	public boolean valEngNum(EpaShipment epaMchShp, String engSerNum) {
		boolean valEng = false;
		LOGGER.info("Entry method of valEngNum {}", BatchConstants.METHOD_ENTRY);
		shpPopulator.valShpEng(epaMchShp, engSerNum.trim());
		valEng = epaMchShp.getEngineSerialNum().equals(BatchConstants.INVALID_INPUT);
		LOGGER.info("Exit method of valEngNum {}", BatchConstants.METHOD_EXIT);
		return valEng;
	}

}
