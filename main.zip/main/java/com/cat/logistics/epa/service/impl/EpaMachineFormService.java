package com.cat.logistics.epa.service.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cat.logistics.epa.dao.IEpaEngineDAO;
import com.cat.logistics.epa.dao.IEpaFacilityDAO;
import com.cat.logistics.epa.dao.IEpaMachineDAO;
import com.cat.logistics.epa.dao.IEpaShipmentDAO;
import com.cat.logistics.epa.entities.EpaFac;
import com.cat.logistics.epa.entities.EpaShipment;
import com.cat.logistics.epa.entities.RcrdUpdtLog;
import com.cat.logistics.epa.helper.ServiceUtilHelper;
import com.cat.logistics.epa.service.IEngineDataBusiness;
import com.cat.logistics.epa.service.IEngineEmissionService;
import com.cat.logistics.epa.service.IEpaMachineFormService;
import com.cat.logistics.epa.service.IMachineDataConverter;
import com.cat.logistics.mdw.dao.IMdwReadDAO;
import com.cat.logistics.mdw.entities.MdwMdlDtl;
import com.cat.logistics.ods.dao.IOdsReadDAO;
import com.cat.logistics.ods.entities.OdsSerialProduct;
import com.cat.logistics.shared.dto.EngineDTO;
import com.cat.logistics.shared.dto.MachineDTO;
import com.cat.logistics.shared.exception.DaoException;
import com.cat.logistics.shared.exception.ServiceException;
import com.cat.logistics.shared.utils.EPAUtils;
import com.cat.logistics.shared.utils.MessageConstants;
import com.cat.logistics.shared.utils.PersistenceConstants;
import com.cat.logistics.shared.utils.ServiceConstants;
import com.cat.logistics.shared.utils.ServiceUtils;

/**
 * Service for logistics EPA machine Form business rules
 * 
 * @author singhr9
 *
 */

@Service("epaMachineFormService")
public class EpaMachineFormService implements IEpaMachineFormService {

	@Autowired
	private IEpaShipmentDAO epaMachShipmentDAO;

	@Autowired
	private IOdsReadDAO mchOdsReadDAO;

	@Autowired
	private IMdwReadDAO mdwReadDAO;

	@Autowired
	private IEpaEngineDAO epaEngineDAO;

	@Autowired
	private IEpaMachineDAO epaMachineDAO;

	@Autowired
	private MessageSource messageSource;

	@Autowired
	private IEngineEmissionService engineEmissionService;

	@Autowired
	private IEpaFacilityDAO epaFacilityDAO;

	public static final Logger LOGGER = LogManager.getLogger(EpaMachineFormService.class);

	@Autowired
	private IMachineDataConverter machineDataConverter;

	@Autowired
	private IEngineDataBusiness engDataBusiness;

	@Autowired
	private ServiceUtilHelper serHelper;

	/**
	 * This method checks if the given number already exist as machine or engine
	 * number in EPA not linked to given sequence number If it exists, it returns
	 * error message
	 * 
	 * @return the message
	 */
	@Override
	public MachineDTO checkEpaSerialNum(String serialNum, String oldSerilNum, String partType, String epaSeqNum,
			Locale locale) throws ServiceException {

		// logger.informationalEvent(EpaMachineFormService.class,
		// "checkEpaSerialNum",ServiceConstants.METHOD_ENTRY+
		// ServiceConstants.PROCESS_SER_SEQ_NO+serialNum+ServiceConstants.FRW_SLASH+epaSeqNum);
		String message = null;
		MachineDTO mchView = null;
		List<EpaShipment> epaShipmentList = null;
		boolean isValidRequrd = ServiceUtils.isRequiredValidation(serialNum, oldSerilNum);
		try {
			if (!isValidRequrd) {
				epaShipmentList = epaMachShipmentDAO.getEpaShipmentbyMachOrEngNum(serialNum, epaSeqNum);
			}
			if (null != epaShipmentList && epaShipmentList.size() > 0) {
				EpaShipment epaShpm = epaShipmentList.get(0);
				mchView = new MachineDTO();
				if (ServiceConstants.MACHINE.equalsIgnoreCase(partType)) {
					engDataBusiness.populateSerilErrMsg(epaShpm, mchView, ServiceConstants.STRING_M, locale, serialNum);
				} /*
					 * else{ message = getMessageBasedOnSerialNum(epaShpm,serialNum,locale);
					 * mchView.addMessage(message); }
					 */

			}
			LOGGER.info("Exit method of checkEpaSerialNum {}", ServiceConstants.METHOD_EXIT);
		} catch (DaoException daoExc) {
			LOGGER.error("Error in checkEpaSerialNum {}", daoExc.getMessage(), daoExc);
			throw new ServiceException(daoExc);
		}

		return mchView;
	}

	/**
	 * Fetches messages for the given serial numbers
	 * 
	 * @param epaShpm  epaShpm
	 * @param partType part Type
	 * @param locale   locale
	 * @return Message based on serial number
	 */
	public String getMessageBasedOnSerialNum(EpaShipment epaShpm, String partType, Locale locale) {
		LOGGER.info("Entry method of getMessageBasedOnSerialNum {}", ServiceConstants.METHOD_ENTRY);
		String message = null;
		String mchNum = epaShpm.getMachineSerialNum();
		EpaFac facility = epaShpm.getEpaFac();
		String facilityDetail = getFacilityDetails(facility);
		if (ServiceConstants.STRING_M.equalsIgnoreCase(epaShpm.getEpaProdTypeCode())) {
			message = messageSource.getMessage(MessageConstants.LOGISTICS_ERROR_ENGASMCH, null, locale)
					.replace(ServiceConstants.FAC_DET, facilityDetail);
			message = message.replace(ServiceConstants.MCH_SER, epaShpm.getMachineSerialNum());
		} else if (null == mchNum) {
			message = messageSource.getMessage(MessageConstants.LOGISTICS_ERROR_INDIDUAL_ENG, null, locale)
					.replace(ServiceConstants.FAC_DET, facilityDetail);
		}
		LOGGER.info("Exit method of getMessageBasedOnSerialNum {}", ServiceConstants.METHOD_EXIT);
		return message;
	}

	/**
	 * This method fetched machine info from ODS/MDW
	 * 
	 * @return Machine DTO
	 */
	@Override
	public MachineDTO getOdsMachineInfo(String machineSerialNum) throws ServiceException {
		LOGGER.info("Entry method of getOdsMachineInfo{} {}", ServiceConstants.METHOD_ENTRY, machineSerialNum);
		MachineDTO mchDTO = null;
		MdwMdlDtl mdlDtl = null;
		try {
			OdsSerialProduct serProduct = mchOdsReadDAO.getControlNum(machineSerialNum);

			if (null != serProduct) {
				String orderControlNum = serProduct.getOrderControlNum();
				mchDTO = new MachineDTO(new EngineDTO());
				mchDTO.setMachineSerialNum(machineSerialNum);
				List<String> engineNumbers = getOdsEngineNumber(orderControlNum);

				if (null != engineNumbers && engineNumbers.size() > 0) {
					mchDTO.setEngineNumbers(new HashSet<String>(engineNumbers));
				}
				mchDTO.setMachineModelNum(mchOdsReadDAO.getModelNum(orderControlNum));
				mchDTO.setMachinebuildDt(
						getOdsMchBuildDate(orderControlNum, serProduct.getSerNumPrefix(), machineSerialNum));
				mdlDtl = mdwReadDAO.getMachineDesc(serProduct.getSerNumPrefix());
				if (mdlDtl != null) {
					mchDTO.setMachineDescription(mdlDtl.getMachineDesc());
					mchDTO.setMachineSrcFac(mdlDtl.getSrcFacCd());
				}
			}
			LOGGER.info("Exit method of getOdsMachineInfo {}", ServiceConstants.METHOD_EXIT);
		} catch (DaoException daoExc) {
			LOGGER.error("Error in getOdsMachineInfo {}", daoExc.getMessage(), daoExc);
			throw new ServiceException(daoExc);
		} catch (Exception exc) {
			LOGGER.error("Error in getOdsMachineInfo {}", exc.getMessage(), exc);
			throw new ServiceException(exc);
		}
		return mchDTO;
	}

	/**
	 * This method fetch engine number from ODS
	 * 
	 * @param orderCntrlNum
	 * @return List serial numbers from ODS
	 * @throws ServiceException
	 */
	public List<String> getOdsEngineNumber(String orderCntrlNum) throws ServiceException {
		LOGGER.info("Entry method of getOdsEngineNumber{} {}", ServiceConstants.METHOD_ENTRY, orderCntrlNum);
		List<String> engineNumbers = null;
		try {
			engineNumbers = mchOdsReadDAO.getEngineNumbers(orderCntrlNum);
			if (null == engineNumbers || engineNumbers.size() == 0) {
				engineNumbers = mchOdsReadDAO.getEngineNumbersFrmHist(orderCntrlNum);
			}
			LOGGER.info("Exit method of getOdsEngineNumber  {}", ServiceConstants.METHOD_EXIT);
		} catch (DaoException daoExc) {
			LOGGER.error("Error in getOdsEngineNumber {}", daoExc.getMessage(), daoExc);
			throw new ServiceException(daoExc);
		} catch (Exception exc) {
			LOGGER.error("Error in getOdsEngineNumber {}", exc.getMessage(), exc);
			throw new ServiceException(exc);
		}
		return engineNumbers;
	}

	/**
	 * This method fetch Manufacturer Name based on facility Coode
	 * 
	 * @return Manufacturer name for the given facility
	 * @throws ServiceException
	 */
	@Override
	public String getManufacturerNameByFacility(String facCd) throws ServiceException {

		LOGGER.info("Entry method of getManufacturerNameByFacility {}", ServiceConstants.METHOD_ENTRY);
		String mfrName = null;
		try {
			if (!ServiceUtils.isNullOrEmpty(facCd)) {
				facCd = ServiceUtils.splitNgetNthValue(facCd, ServiceConstants.HIPHEN, 0);
				EpaFac facility = epaFacilityDAO.getFacilityDetail(facCd);
				if (null != facility && !ServiceUtils.isNullOrEmpty(facility.getMachineMfrName())) {
					mfrName = facility.getMachineMfrName();
				} else if (null != facility && !ServiceUtils.isNullOrEmpty(facility.getFacilityName())) {
					mfrName = facility.getFacilityName();
				}
			}
			LOGGER.info("Exit method of getManufacturerNameByFacility {}", ServiceConstants.METHOD_EXIT);
		} catch (DaoException daoExc) {
			LOGGER.error("Error in getManufacturerNameByFacility {}", daoExc.getMessage(), daoExc);
			throw new ServiceException(daoExc);
		}
		return mfrName;
	}

	/**
	 * This method fetch machine build date from ODS
	 * 
	 * @param orderCntrlNum
	 * @param serialBody
	 * @param serNumPrfix
	 * @return Build date
	 * @throws ServiceException
	 */
	public Date getOdsMchBuildDate(String orderCntrlNum, String serNumPrfix, String machineSerialNum)
			throws ServiceException {
		LOGGER.info("Entry method of getOdsMchBuildDate {} {}",
				ServiceConstants.METHOD_ENTRY, orderCntrlNum);
		Date buildDate = null;
		try {
			buildDate = mchOdsReadDAO.getBuildDate(orderCntrlNum);
			if (null == buildDate) {
				buildDate = mchOdsReadDAO.getBuildDateFrmHist(orderCntrlNum);
			}
			if (null == buildDate) {
				// Fetch build date from ODS_STG_VW
				buildDate = mchOdsReadDAO.getBldDtFrmOdsStgVw(orderCntrlNum);
			}
			if (null == buildDate) {
				// Fetch build date from ODS_STG_HIST_VW
				buildDate = mchOdsReadDAO.getBldDtFrmOdsStgHistVw(orderCntrlNum);
			}
			if (null == buildDate) {
				// Fetch build date from MDW_BLD_DET_HIST
				String serialBody = ServiceUtils.getSubStrByPrfix(serNumPrfix, machineSerialNum);
				buildDate = mdwReadDAO.getBldDtFrmMdwBldDetHist(serNumPrfix, serialBody);
			}
			LOGGER.info("Exit method of getOdsMchBuildDate {}" ,
					ServiceConstants.METHOD_EXIT);
		} catch (DaoException daoExc) {
			LOGGER.error("Error in getConfigData {}", daoExc.getMessage(),
					daoExc);
			throw new ServiceException(daoExc);
		} catch (Exception exc) {
			LOGGER.error("Error in getConfigData {}", exc.getMessage(),
					exc);
			throw new ServiceException(exc);
		}
		return buildDate;
	}

	/**
	 * This method checks if engine number already exist in EPA or not. It not, it
	 * returns the engine number
	 * 
	 * @return engine serial number
	 */
	@Override
	public String getNonEpaEngineNumbers(Set<String> odsEngines, String mchSerilNum, String seqNum)
			throws ServiceException {
		LOGGER.info("Entry method of getNonEpaEngineNumbers {}",ServiceConstants.METHOD_ENTRY);
		String newEngNum = null;
		try {
			List<String> epaEngines = epaEngineDAO.getEpaEnginesNumbers(new ArrayList<String>(odsEngines), seqNum);
			newEngNum = checkIsNonEPASerial(odsEngines, epaEngines, mchSerilNum);
			LOGGER.info("Exit method of getNonEpaEngineNumbers {}",ServiceConstants.METHOD_EXIT);
		} catch (DaoException daoExc) {
			LOGGER.error("Error in getNonEpaEngineNumbers {}", daoExc.getMessage(), daoExc);
			throw new ServiceException(daoExc);
		} catch (Exception exc) {
			LOGGER.error("Error in getNonEpaEngineNumbers {}", exc.getMessage(), exc);
			throw new ServiceException(exc);
		}
		return newEngNum;
	} 

	/**
	 * @param odsEngines
	 * @param epaEngines
	 * @param mchSerilNum
	 * @return engine serial number
	 */
	private String checkIsNonEPASerial(Set<String> odsEngines, List<String> epaEngines, String mchSerilNum) {
		String newEngNum = null;
		boolean engMchExists = false;
		for (String engNum : odsEngines) {
			if (epaEngines.contains(engNum) && epaEngines.contains(mchSerilNum)) {
				newEngNum = engNum;
				engMchExists = true;
				break;
			}
		}
		if (!engMchExists) {
			for (String engNo : odsEngines) {
				if (!epaEngines.contains(engNo)) {
					newEngNum = engNo;
					break;
				}
			}
		}
		return newEngNum;
	}

	/**
	 * This method checks if given machine exist in ODS or not. If exist returns the
	 * details of it.
	 * 
	 * @return Machine DTO
	 */
	@Override
	public MachineDTO fetchOdsMachineDetl(MachineDTO machineDTO, Locale locale) throws ServiceException {
		LOGGER.info("Entry method of fetchOdsMachineDetl {} {}",ServiceConstants.METHOD_ENTRY,machineDTO.getMachineSerialNum());
		MachineDTO odsMachineDto = null;
		String machSrcDes = null;
		String facCdDesc = machineDTO.getOriginFacility();
		try {
			odsMachineDto = getOdsMachineInfo(machineDTO.getMachineSerialNum());
			if (null == odsMachineDto) {
				machineDTO = new MachineDTO(machineDTO.getMachineSerialNum(), new EngineDTO(),
						machineDTO.isUpdateOperation(), machineDTO.isDisplayShipInfo(), machineDTO.getEpaSeqNo(),
						machineDTO.getShipmentDate(), machineDTO.getOrderNumber(), machineDTO.getInvoiceNumber(),
						machineDTO.getArPartNumber());
				machineDTO.addMessage(
						messageSource.getMessage(MessageConstants.LOGISTICS_MESSAGE_NO_IMPORTINFO, null, locale));

			} else {
				String machSrcCd = odsMachineDto.getMachineSrcFac();
				machSrcDes = getManufacturerNameByFacility(machSrcCd);
				machineDTO.setMachineSrcFac(machSrcCd + ServiceConstants.HIPHEN + machSrcDes);
				machineDTO.setMachineMfrName(machSrcDes);
				setMachineInfo(odsMachineDto, machineDTO);
				if (null == odsMachineDto.getEngineNumbers() || odsMachineDto.getEngineNumbers().size() == 0) {
					machineDTO.setMchEngine(new EngineDTO());
					machineDTO.addMessage(
							messageSource.getMessage(MessageConstants.LOGISTICS_MESSAGE_NO_ENGNUMBER, null, locale));
					return machineDTO;
				}

				populateMacineEngineDetails(machineDTO, odsMachineDto, locale);
			}
			machineDTO.setOriginFacility(facCdDesc);
			LOGGER.info("Exit method of fetchOdsMachineDetl {}",ServiceConstants.METHOD_EXIT);
		} catch (Exception exc) {
			LOGGER.error("Error in fetchOdsMachineDetl {}", exc.getMessage(), exc);
			throw new ServiceException(exc);
		}
		return machineDTO;
	}

	/**
	 * 
	 * @param engDto
	 * @param machineDTO
	 * @param newEngineNum
	 * @param locale
	 * @throws ServiceException
	 */
	private void setDTOValuesIfExists(IEngineEmissionService engineEmissionService, EngineDTO engDto,
			MachineDTO machineDTO, String newEngineNum, Locale locale) throws ServiceException {
		LOGGER.info("Entry method of setDTOValuesIfExists {}",ServiceConstants.METHOD_ENTRY);
		Map<String, EngineDTO> engineDetailMap = engineEmissionService
				.getEngineInfo(new ArrayList<String>(Arrays.asList(newEngineNum)));
		if (null != engineDetailMap && engineDetailMap.size() != 0) {
			engDto = engineDetailMap.get(newEngineNum);
		}

		if (null == engDto) {
			machineDTO.setMchEngine(new EngineDTO(newEngineNum));
			machineDTO.addMessage(
					messageSource.getMessage(MessageConstants.LOGISTICS_MESSAGE_NO_IMPORTINFO, null, locale));
		} else {
			engDto.setEngineProvisionTypeCode(engDto.getEngProvEqu());
			engDataBusiness.getCodeDescription(engDto);

			machineDTO.setMchEngine(engDto);
		}
		LOGGER.info("Exit method of setDTOValuesIfExists {}",ServiceConstants.METHOD_EXIT);
	}

	/**
	 * @param odsMachine
	 * @param mchDTO
	 */
	public void setMachineInfo(MachineDTO odsMachine, MachineDTO mchDTO) {
		
		LOGGER.info("Entry method of setMachineInfo {}",ServiceConstants.METHOD_ENTRY);
		if (null != odsMachine.getMachineModelNum()) {
			mchDTO.setMachineModelNum(odsMachine.getMachineModelNum().trim());
		}
		if (null != odsMachine.getMachineDescription()) {
			mchDTO.setMachineDescription(odsMachine.getMachineDescription().trim());
		}
		mchDTO.setMachinebuildDt(odsMachine.getMachinebuildDt());
		LOGGER.info("Exit method of setMachineInfo {}",ServiceConstants.METHOD_EXIT);
	}

	/**
	 * This method checks if engine already exist in EPA or not. If yes, return
	 * error message If not, returns details from engine emission, (if exist in
	 * engine emission)
	 * 
	 */
	@Override
	public void getEngineInfo(MachineDTO machineDto, Locale locale) throws ServiceException {

		LOGGER.info("Entry method of getEngineInfo {} {}",ServiceConstants.METHOD_ENTRY,machineDto.getMchEngine().getEngineSerialNumber());
		List<String> engineList = new ArrayList<String>();
		try {
			String engineNumber = machineDto.getMchEngine().getEngineSerialNumber().toUpperCase();
			String oldEngSerilNum = machineDto.getMchEngine().getOldEngSerilNum();
			String mchSerialNum = machineDto.getMachineSerialNum();
			MachineDTO mchDto = checkEpaSerialNum(engineNumber, oldEngSerilNum, ServiceConstants.ENGINE,
					machineDto.getEpaSeqNo(), locale);
			machineDto.setMchEngine(new EngineDTO(engineNumber));
			boolean errCheck = checkInvaliErrMsg(mchDto, mchSerialNum);
			if (errCheck) { 
				mchDto.setMessage(null);
			}
			engineList.add(engineNumber);
			if (null == mchDto || null == mchDto.getMessage()) {
				Map<String, EngineDTO> engineDetailMap = engineEmissionService
						.getEngineInfo(new ArrayList<String>(engineList));
				if (null != engineDetailMap && 0 != engineDetailMap.size()) {
					EngineDTO engDto = engineDetailMap.get(engineNumber);
					if (null != engDto) {
						engDto.setEngineProvisionTypeCode(engDto.getEngProvEqu());
						engDataBusiness.getCodeDescription(engDto);
						machineDto.setMchEngine(engDto);
					}

				} else {
					machineDto.addMessage(
							messageSource.getMessage(MessageConstants.LOGISTICS_ERROR_NO_SERIALNUM_EED, null, locale));
				}
			} else {
				List<String> li = new ArrayList<String>();
				li.addAll(mchDto.getMessage());
				machineDto.addMessage(li.get(0));
			}
			LOGGER.info("Exit method of getEngineInfo {}",ServiceConstants.METHOD_EXIT);
		} catch (Exception exc) {
			LOGGER.error("Error in getEngineInfo {}", exc.getMessage(), exc);
			throw new ServiceException(exc);
		}
	}

	/**
	 * @param mchDto       machineDTO
	 * @param mchSerialNum mchSerial num
	 * @return true or false
	 */
	private boolean checkInvaliErrMsg(MachineDTO mchDto, String mchSerialNum) {
		boolean invalid = false;
		List<String> errList = new ArrayList<String>();
		if (null != mchDto) {
			errList = mchDto.getMessage();
		}
		if (null != errList) {
			for (String eMsg : errList) {
				if (eMsg.contains(mchSerialNum)) {
					invalid = true;
				}
			}
		}
		return invalid;
	}

	/**
	 * Insert the record in EPA DB with status code as 5/9/7
	 * 
	 * @return true or false
	 */
	@Override
	@Transactional
	public boolean saveSubmitApproveNewForm(MachineDTO mchView, Locale locale) throws ServiceException {

		LOGGER.info("Entry method of saveSubmitApproveNewForm {} {} {}",ServiceConstants.METHOD_ENTRY,mchView.getMachineSerialNum(),
				mchView.getMchEngine().getEngineSerialNumber());
		String status = null;
		try {
			if (!validateSerialNum(mchView, locale)) {
				return false;
			}
			if (!validImportProvisionCode(mchView, locale)) {
				return false;
			}

			status = getStatusOrMsgByAction(mchView.getMachineFormAction(), true, locale);

			EpaShipment epaShipment = machineDataConverter.convertMachineDTOtoEpaShipment(mchView, status);
			getCrteLog(epaShipment.getRcdLog());
			getCrteLog(epaShipment.getEpaEngines().getRcdLog());
			getCrteLog(epaShipment.getEpaMachines().getRcdLog());

			epaShipment.setEpaProdTypeCode(ServiceConstants.STRING_M);
			epaMachShipmentDAO.insertShipmentEngMch(epaShipment);
			mchView.setSuccessMessage(getStatusOrMsgByAction(mchView.getMachineFormAction(), false, locale));

			LOGGER.info("Exit method of saveSubmitApproveNewForm {}",ServiceConstants.METHOD_EXIT);
		} catch (DaoException daoExc) {
			LOGGER.error("Error in saveSubmitApproveNewForm {}", daoExc.getMessage(), daoExc);
			throw new ServiceException(daoExc);
		} catch (Exception exc) {
			LOGGER.error("Error in saveSubmitApproveNewForm {}", exc.getMessage(), exc);
			throw new ServiceException(exc);
		}
		return true;
	}

	/**
	 * @param rcdLog
	 */
	private void getCrteLog(RcrdUpdtLog rcdLog) {
		String userId = serHelper.getLogOnId();
		rcdLog.setCrteTm(new Date());
		rcdLog.setCrteLogin(userId);
	}

	/**
	 * validates the serial number
	 * 
	 * @param mchView machine form
	 * @param locale  locale
	 * @return boolean value for valid serial num
	 * @throws Service Exception
	 */
	private boolean validateSerialNum(MachineDTO mchView, Locale locale) throws ServiceException {
		LOGGER.info("Entry method of validateSerialNum {}",ServiceConstants.METHOD_ENTRY);
		boolean valid = true;
		MachineDTO mchDto = null;
		if (!ServiceConstants.YES.equalsIgnoreCase(mchView.getMchEngine().getIsSkipValidtion())) {
			String mchSerilNum = mchView.getMachineSerialNum();
			String oldMchSerNum = mchView.getOldMchSerilNumber();
			mchDto = checkEpaSerialNum(mchSerilNum, oldMchSerNum, ServiceConstants.MACHINE, mchView.getEpaSeqNo(),
					locale);
			if (null != mchDto && null != mchDto.getMchEngine() && isErrExist(mchDto.getMchEngine())) {
				mchView.getMchEngine().setErrMessage(mchDto.getMchEngine().getErrMessage());
				mchView.getMchEngine().setErrPopupMsg(mchDto.getMchEngine().getErrPopupMsg());
				mchView.getMchEngine().setEpaSeqNum(mchDto.getMchEngine().getEpaSeqNum());
				mchView.getMchEngine().setIsUpdRedirct(mchDto.getMchEngine().getIsUpdRedirct());
				return false;
			}
			String engSerilNum = mchView.getMchEngine().getEngineSerialNumber();
			String oldEngSerNum = mchView.getMchEngine().getOldEngSerilNum();
			mchDto = checkEpaSerialNum(engSerilNum, oldEngSerNum, ServiceConstants.ENGINE, mchView.getEpaSeqNo(),
					locale);
			if (null != mchDto && null != mchDto.getMessage()) {
				List<String> li = new ArrayList<String>();
				li.addAll(mchDto.getMessage());
				mchView.addMessage(li.get(0));
				return false;
			}
		}
		LOGGER.info("Exit method of validateSerialNum {}",ServiceConstants.METHOD_EXIT);
		return valid;
	}

	/**
	 * checks the Error exist or not
	 * 
	 * @param mchEngine
	 * @return true or false
	 */
	private boolean isErrExist(EngineDTO mchEngine) {
		boolean check = false;
		if (null != mchEngine.getErrMessage() || null != mchEngine.getErrPopupMsg()
				|| null != mchEngine.getIsUpdRedirct()) {
			check = true;
		}
		return check;
	}

	/**
	 * This method fetch the shipment/engine/machine info from EPA for given
	 * sequence number
	 * 
	 * @return Machine DTO
	 */
	@Override
	public MachineDTO getShipmentInfo(String epaSeqNum) throws ServiceException {

		LOGGER.info("Entry method of getShipmentInfo {} {}",ServiceConstants.METHOD_ENTRY,epaSeqNum);
		MachineDTO machineDto = null;
		try {
			if (!EPAUtils.isNullOrEmpty(epaSeqNum) && !"0".equals(epaSeqNum)) {
				List<EpaShipment> epaShpmLst = epaMachShipmentDAO.getEpaShipmentBySeqNum(epaSeqNum);

				if (!EPAUtils.isListEmpty(epaShpmLst)) {
					machineDto = machineDataConverter.convertEpaShipmentToMachineDTO(epaShpmLst.get(0));
					String machineNum = machineDto.getMachineSerialNum();
					String engineNum = machineDto.getMchEngine().getEngineSerialNumber();
					String mchSourcFacCd = machineDto.getMachineSrcFac();
					if (!ServiceUtils.isNullOrEmpty(machineNum)) {
						machineDto.setMchInfoVisible(ServiceConstants.TRUE);
						machineDto.setDisableEngine(ServiceConstants.FALSE);
						setUpdateAttributes(machineDto, engineNum);
						setMchSrcFacDes(machineDto, mchSourcFacCd);
					}
				}
			}
			LOGGER.info("Exit method of getShipmentInfo {}",ServiceConstants.METHOD_EXIT);
		} catch (DaoException daoExc) {
			LOGGER.error("Error in getShipmentInfo {}", daoExc.getMessage(), daoExc);
			throw new ServiceException(daoExc);
		} catch (Exception exc) {
			LOGGER.error("Error in getShipmentInfo {}", exc.getMessage(), exc);
			throw new ServiceException(exc);
		}
		return machineDto;
	}

	/**
	 * @param machineDto    machineDto
	 * @param mchSourcFacCd mchSourcFacCd
	 * @throws ServiceException ServiceException
	 */
	private void setMchSrcFacDes(MachineDTO machineDto, String mchSourcFacCd) throws ServiceException {
		if (!ServiceUtils.isNullOrEmpty(mchSourcFacCd)) {
			String mchSrcFacName = getManufacturerNameByFacility(mchSourcFacCd);
			machineDto.setMachineSrcFac(mchSourcFacCd + ServiceConstants.HIPHEN + mchSrcFacName);
		}
	}

	/**
	 * @param machineDto machineDto
	 * @param engineNum  engineNum
	 */
	private void setUpdateAttributes(MachineDTO machineDto, String engineNum) {
		if (!ServiceUtils.isNullOrEmpty(engineNum)) {
			machineDto.setUpdateOperation(ServiceConstants.TRUE);
			machineDto.setEngInfoVisible(ServiceConstants.TRUE);
		}
	}

	/**
	 * Update the record in EPA DB with status code as 5/9/7
	 * 
	 * @return true or false
	 */
	@Override
	public boolean saveSubmitApproveExistingMachineForm(MachineDTO mchView, Locale locale) throws ServiceException {

		LOGGER.info("Entry method of saveSubmitApproveExistingMachineForm {} {}",ServiceConstants.METHOD_ENTRY, mchView.getEpaSeqNo());
		EpaShipment epaShipment = null;
		Long epaSeq = null;

		try {

			validEpaSeqNo(mchView);
			epaSeq = Long.parseLong(mchView.getEpaSeqNo());
			if (!validateSerialNum(mchView, locale)) {
				return false;
			}

			if (!validImportProvisionCode(mchView, locale)) {
				return false;
			}
			epaShipment = machineDataConverter.convertMachineDTOtoEpaShipment(mchView,
					getStatusOrMsgByAction(mchView.getMachineFormAction(), true, locale));
			getCrteLog(epaShipment.getEpaMachines().getRcdLog());
			getCrteLog(epaShipment.getEpaEngines().getRcdLog());
			epaShipment.setEpaProdTypeCode(ServiceConstants.STRING_M);
			epaShipment.setEpaSeqNum(epaSeq);
			epaEngineDAO.updateEngineNumber(mchView.getMchEngine().getEngineSerialNumber(), mchView.getEpaSeqNo());
			epaMachineDAO.updateMachineNumber(mchView.getMachineSerialNum(), mchView.getEpaSeqNo());
			epaMachShipmentDAO.mergeShipmentEngMch(epaShipment);
			LOGGER.info("Exit method of saveSubmitApproveExistingMachineForm {}",ServiceConstants.METHOD_EXIT);
		} catch (DaoException daoExc) {
			LOGGER.error("Error in saveSubmitApproveExistingMachineForm {}", daoExc.getMessage(),
					daoExc);
			throw new ServiceException(daoExc);
		} catch (Exception exc) {
			LOGGER.error("Error in saveSubmitApproveExistingMachineForm {}", exc.getMessage(),
					exc);
			throw new ServiceException(exc);
		}
		return true;
	}

	/**
	 * validates sequence number
	 * 
	 * @param mchView
	 * @throws ServiceException
	 */
	private void validEpaSeqNo(MachineDTO mchView) throws ServiceException {
		LOGGER.info("Entry method of validEpaSeqNo{}",ServiceConstants.METHOD_ENTRY);
		if (ServiceUtils.isNullOrEmpty(mchView.getEpaSeqNo())) {
			throw new ServiceException("Missing EPA Sequence Number");
		}
		LOGGER.info("Exit method of validEpaSeqNo{}",ServiceConstants.METHOD_EXIT);
	}

	/**
	 * validates import provision type code
	 * 
	 * @param mchView
	 * @param locale
	 * @return boolean value
	 * @throws ServiceException
	 */
	private boolean validImportProvisionCode(MachineDTO mchView, Locale locale) throws ServiceException {
		LOGGER.info("Entry method of validImportProvisionCode {}",ServiceConstants.METHOD_ENTRY);
		boolean isValid = true;
		String importCd = ServiceUtils.splitNgetNthValue(mchView.getMchEngine().getEngineImportTypeCode(),
				ServiceConstants.SLASH_STOP, 0);
		String provCd = ServiceUtils.splitNgetNthValue(mchView.getMchEngine().getEngineProvisionTypeCode(),
				ServiceConstants.SLASH_STOP, 0);

		if (!engDataBusiness.isImportProvisionCodeValid(importCd, provCd)) {
			mchView.addMessage(
					messageSource.getMessage(MessageConstants.LOGISTICS_ERROR_INVALID_IMPORTPROVISION, null, locale));
			return false;
		}
		LOGGER.info("Exit method of validImportProvisionCode {}",ServiceConstants.METHOD_EXIT);
		return isValid;
	}

	/**
	 * @return facility detail
	 * @throws ServiceException
	 */
	public String getFacilityDetails(EpaFac facility) {
		String facilityDetail = ServiceConstants.EMPTY;
		if (null != facility) {
			facilityDetail = facility.getFacCd() + ServiceConstants.HIPHEN + facility.getFacilityName();
		}
		return facilityDetail;
	}

	/**
	 * @param action
	 * @return status or message
	 */
	@Override
	public String getStatusOrMsgByAction(String action, boolean setStatus, Locale locale) {

		String status = null;
		String msg = null;
		String returnValue = null;
		if (ServiceConstants.SAVE_FORM.equalsIgnoreCase(action)) {
			status = ServiceConstants.WIP;
			msg = messageSource.getMessage(MessageConstants.LOGISTICS_MESSAGE_SAVESUCCESS, null, locale);
		} else if (ServiceConstants.SUBMIT_FORM.equalsIgnoreCase(action)) {
			status = ServiceConstants.RFA;
			msg = messageSource.getMessage(MessageConstants.LOGISTICS_MESSAGE_SUBMITSUCCESS, null, locale);
		} else if (ServiceConstants.APPROVE_FORM.equalsIgnoreCase(action)) {
			status = ServiceConstants.CMP;
			msg = messageSource.getMessage(MessageConstants.LOGISTICS_MESSAGE_APPROVESUCCESS, null, locale);
		}
		if (setStatus) {
			returnValue = status;
		} else {
			returnValue = msg;
		}
		return returnValue;
	}

	/**
	 * @return the machineDataConverter
	 */
	public IMachineDataConverter getMachineDataConverter() {
		return machineDataConverter;
	}

	/**
	 * @param machineDataConverter the machineDataConverter to set
	 */
	public void setMachineDataConverter(IMachineDataConverter machineDataConverter) {
		this.machineDataConverter = machineDataConverter;
	}

	/**
	 * This method is used to set the machine engine details
	 * 
	 * @param machineDTO    machine object
	 * @param odsMachineDto machine object
	 * @throws ServiceException service Exception
	 */
	private void populateMacineEngineDetails(MachineDTO machineDTO, MachineDTO odsMachineDto, Locale locale)
			throws ServiceException {
		EngineDTO engDto = null;
		String newEngineNum = null;
		if (null != odsMachineDto.getEngineNumbers() && odsMachineDto.getEngineNumbers().size() != 0) {
			String seqNum = null;
			if (machineDTO.isDisplayShipInfo()) {
				seqNum = machineDTO.getEpaSeqNo();
			}
			odsMachineDto.setEngineNumbers(ServiceUtils.trimSetValues(odsMachineDto.getEngineNumbers()));
			newEngineNum = getValidEngSeriNum(machineDTO, odsMachineDto, seqNum);
		}

		if (!ServiceUtils.isNullOrEmpty(newEngineNum)) {
			setDTOValuesIfExists(engineEmissionService, engDto, machineDTO, newEngineNum, locale);

		} else {
			machineDTO.setMchEngine(new EngineDTO());
			if (odsMachineDto.getEngineNumbers().size() > 0) {
				String odsFac = null;
				for (String fac : odsMachineDto.getEngineNumbers()) {
					odsFac = fac;
					break;
				}
				machineDTO.addMessage(
						messageSource.getMessage(MessageConstants.LOGISTICS_MESSAGE_INVALID_ENGMCH, null, locale)
								.replace(ServiceConstants.ENG_SER_NO, odsFac));
			} else {
				machineDTO.addMessage(
						messageSource.getMessage(MessageConstants.LOGISTICS_MESSAGE_INVALID_ENGMCH2, null, locale));
			}
		}

	}

	/**
	 * validates the engine serial number is epa or non epa
	 * 
	 * @param machineDTO    machine DTO
	 * @param odsMachineDto OdsMachine
	 * @param seqNum        seqNum
	 * @return engine serial number
	 * @throws ServiceException
	 */
	private String getValidEngSeriNum(MachineDTO machineDTO, MachineDTO odsMachineDto, String seqNum)
			throws ServiceException {
		String newEngineNum = null;
		String isSkipValidion = machineDTO.getMchEngine().getIsSkipValidtion();
		String mchSeriNum = machineDTO.getMachineSerialNum();
		String oldMchSerNum = machineDTO.getOldMchSerilNumber();
		if ((null != isSkipValidion && !ServiceConstants.YES.equalsIgnoreCase(isSkipValidion))
				|| (null != oldMchSerNum && !mchSeriNum.equalsIgnoreCase(oldMchSerNum))) {
			newEngineNum = getNonEpaEngineNumbers(odsMachineDto.getEngineNumbers(), mchSeriNum, seqNum);
		} else {
			for (String engNum : odsMachineDto.getEngineNumbers()) {
				newEngineNum = engNum;
				break;
			}
		}
		return newEngineNum;
	}

}
