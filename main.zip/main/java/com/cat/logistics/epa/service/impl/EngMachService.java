package com.cat.logistics.epa.service.impl;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import com.cat.logistics.epa.dao.IEpaEngineDAO;
import com.cat.logistics.epa.dao.IEpaShipmentDAO;
import com.cat.logistics.epa.dto.EpaShipmentDTO;
import com.cat.logistics.epa.entities.EpaEngine;
import com.cat.logistics.epa.entities.EpaShipment;
import com.cat.logistics.epa.job.utils.BatchConstants;
import com.cat.logistics.epa.job.utils.BatchConstants.STATUS_CDS;
import com.cat.logistics.shared.exception.DaoException;
import com.cat.logistics.shared.exception.ServiceException;
import com.cat.logistics.shared.utils.ServiceConstants;
/**
 * This class contains common methods for Engine and Machine create service classes
 * @author chanda15
 *
 */
public  class EngMachService {

	@Autowired
	private IEpaEngineDAO epaEngineDAO;
	
	//private ILogger logger = Logger.getInstance();
	
	@Autowired
	private IEpaShipmentDAO epaShipmentDAO;
	
	private final static Logger logger = LogManager.getLogger(EngMachService.class);
	
	/**
	 * This method retrieves engine info from db based on engine serial number
	 * @param engNum engNum
	 * @return List<EpaEngine> List<EpaEngine>
	 */
	public List<EpaEngine> getEngine( String engNum){
		/*logger.informationalEvent(this.getClass(), BatchConstants.MTD_GET_ENG, BatchConstants.METHOD_ENTRY);*/
		
		logger.info(this.getClass() + BatchConstants.MTD_GET_ENG+ BatchConstants.METHOD_ENTRY);
		List<EpaEngine> engines = null;
		engines = epaEngineDAO.getEngineInfo(engNum);
		//logger.informationalEvent(this.getClass(), BatchConstants.MTD_GET_ENG, BatchConstants.METHOD_EXIT);
		
		logger.info(this.getClass() + BatchConstants.MTD_GET_ENG+ BatchConstants.METHOD_EXIT);
		return engines;
	}
	
	/**
	 * This method determines if the engine should be updated or not
	 * @param engines engines
	 * @return the chkEngFrUpdt
	 */
	public EpaEngine chkEngFrUpdt(List<EpaEngine> engines){
		//logger.informationalEvent(this.getClass(), BatchConstants.MTD_CHECK_ENG_FR_UPD, BatchConstants.METHOD_ENTRY);
		logger.info(this.getClass() + BatchConstants.MTD_CHECK_ENG_FR_UPD+ BatchConstants.METHOD_ENTRY);
		EpaEngine epaEng = null;
		for(EpaEngine eng : engines){
			String status = eng.getEpaStatus().getEpaStatusCd();
			if(! (status.equals(ServiceConstants.STB) ||  status.equals(ServiceConstants.CMP))){
				epaEng = eng;
			}
		}
		//logger.informationalEvent(this.getClass(), BatchConstants.MTD_CHECK_ENG_FR_UPD, BatchConstants.METHOD_EXIT);
		logger.info(this.getClass() + BatchConstants.MTD_CHECK_ENG_FR_UPD+ BatchConstants.METHOD_EXIT);
		return epaEng;
	}
	
	
	/**
	 * This method validated if a another engine record should be created for the same engine number
	 * @param engineShpmntDTO engineShpmntDTO
	 * @param engine engine
	 * @return boolean true false
	 * @throws ServiceException
	 */
	public boolean valDupEng(EpaShipmentDTO engineShpmntDTO,EpaEngine engine) throws ServiceException{
		boolean flag = false;
		//logger.informationalEvent(this.getClass(), BatchConstants.MTD_VAL_DUP_ENG, BatchConstants.METHOD_ENTRY);
		logger.info(this.getClass() + BatchConstants.MTD_VAL_DUP_ENG+ BatchConstants.METHOD_ENTRY);
		String status = engine.getEpaStatus().getEpaStatusCd();
			if( statusSTB(status) ){
				flag = true;
		}
			//logger.informationalEvent(this.getClass(), BatchConstants.MTD_VAL_DUP_ENG, BatchConstants.METHOD_EXIT);
			
			logger.info(this.getClass() + BatchConstants.MTD_VAL_DUP_ENG+ BatchConstants.METHOD_EXIT);
		return flag;
	}
	
	/**
	 * checks the engine status for updation , if status is WIP or RFA engine details
	 * need not update. 
	 * 
	 * @param engine engine
	 * @return boolean true or false
	 */
	public boolean valUpdtEng(EpaEngine engine){
		/*logger.informationalEvent(this.getClass(), BatchConstants.MTD_VAL_UPD_ENG, BatchConstants.METHOD_ENTRY);*/
		logger.info(this.getClass() + BatchConstants.MTD_VAL_UPD_ENG+ BatchConstants.METHOD_ENTRY);
		boolean updt = true; 
		String statCd = engine.getEpaStatus().getEpaStatusCd();
		if( statCd.equals(STATUS_CDS.WIP.toString()) || statCd.equals(STATUS_CDS.RFA.toString()) ){
			updt = false;
		}
		/*logger.informationalEvent(this.getClass(), BatchConstants.MTD_VAL_UPD_ENG, BatchConstants.METHOD_EXIT);*/
		logger.info(this.getClass() + BatchConstants.MTD_VAL_UPD_ENG+ BatchConstants.METHOD_EXIT);
		return updt;
	}
	
	/**
	 * 
	 * checks if the status is STB or CMP
	 * @param status status
	 * @return boolean true or false
	 */
	public boolean statusSTB(String status){
		boolean statFlg = false;
		if(status.equals(ServiceConstants.STB) ||  status.equals(ServiceConstants.CMP)){
			statFlg = true;
		}
		return statFlg;
	}
	
	/**
	 * check if the shipment coming from TIS is same as already existing shipment in EPA
	 * @param epaShm epaShm
	 * @param engineShpmntDTO engineShpmntDTO
	 * @return boolean true or false
	 */
	public boolean sameShp(EpaShipment epaShm ,EpaShipmentDTO engineShpmntDTO){
		boolean shpFlg = false;
		if(engineShpmntDTO.getInvoiceNum().trim().equals(epaShm.getInvoiceNum()) && engineShpmntDTO.getLoadNum().trim().equals(epaShm.getOrderNum()) &&
				engineShpmntDTO.getPartNum().trim().equals(epaShm.getPartNum())){
			shpFlg = true;
			}
		return shpFlg;
	}
	
	
	/**
	 * @param epaShipment epaShipment
	 * @return EpaShipment object
	 */
	public EpaShipment checkShpExist(EpaShipmentDTO epaShipment) {
		EpaShipment result = null;
		EpaShipment epaShpm = new EpaShipment();
		epaShpm.setPartNum(epaShipment.getPartNum().trim());
		epaShpm.setInvoiceNum(epaShipment.getInvoiceNum().trim());
		epaShpm.setSuppLdTs(epaShipment.getSuppLdTmstmp());
		epaShpm.setOrderNum(epaShipment.getLoadNum().trim());
		epaShpm.setSuppItemSeqNum(epaShipment.getItmSeqNo());

		try {
			result = epaShipmentDAO.checkForShpmnt(epaShpm);
		} catch (DaoException e) {
			/*logger.fatalEvent(this.getClass(),
					BatchConstants.MTD_CHECK_SHIP_EXIST,
					BatchConstants.CHECK_SHIP_EXIST_FAILED, e);*/
			
			logger.error(this.getClass() + BatchConstants.MTD_CHECK_SHIP_EXIST+
					BatchConstants.CHECK_SHIP_EXIST_FAILED+ e.getMessage());
		}

		return result;
	}
	
	
}
