package com.cat.logistics.epa.service.impl;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import com.cat.logistics.epa.dao.IEpaEngineDAO;
import com.cat.logistics.epa.dao.IEpaShipmentDAO;
import com.cat.logistics.epa.dto.EpaShipmentDTO;
import com.cat.logistics.epa.entities.EpaEngine;
import com.cat.logistics.epa.entities.EpaShipment;
import com.cat.logistics.epa.entities.EpaStatus;
import com.cat.logistics.epa.entities.RcrdUpdtLog;
import com.cat.logistics.epa.job.service.IEngineCreateService;
import com.cat.logistics.epa.job.utils.BatchConstants;
import com.cat.logistics.epa.job.utils.Utils;
import com.cat.logistics.epa.populators.IEnginePopulator;
import com.cat.logistics.epa.populators.IShpmntPopulator;
import com.cat.logistics.shared.dto.EngineDTO;
import com.cat.logistics.shared.exception.DaoException;
import com.cat.logistics.shared.exception.ServiceException;
import com.cat.logistics.shared.utils.ServiceConstants;
/**
 * This class creates or updates Engine shipment information in EPA
 * @author chanda15
 *
 */
public class EngineCreateService extends EngMachService  implements IEngineCreateService{

	@Autowired
	private IEnginePopulator enginePopulator;
	
	@Autowired
	private IShpmntPopulator shpPopulator;
	
	@Autowired
	private  IEpaEngineDAO epaEngineDAO;
	
	@Autowired
	private IEpaShipmentDAO epaShipmentDAO;
	
	//private ILogger logger = Logger.getInstance();
	
	private final static Logger logger = LogManager.getLogger(EngineCreateService.class);
	
	/**
	 * This method determines if a new engine to be created , or to update an existing engine
	 * or create a duplicate engine
	 * @param engineShpmntDTO engineShpmntDTO
	 * @param engineDTO engineDTO
	 * @throws ServiceException ServiceException
	 * @see com.cat.logistics.epa.job.service.IEPAService#createEngineShipment(com.cat.logistics.epa.dto.EpaShipmentDTO,
	 *      com.cat.logistics.shared.dto.EngineDTO)
	 */
	
	public void createEngineShipment(EpaShipmentDTO engineShpmntDTO,
			EngineDTO engineDTO) throws ServiceException {
		/*logger.informationalEvent(this.getClass(),
				BatchConstants.MTD_CREATE_ENG_SHIPMT,
				BatchConstants.EXE_CREATE_ENG_SHIPMT);*/
		
		logger.info(this.getClass() + BatchConstants.MTD_CREATE_ENG_SHIPMT+
				BatchConstants.EXE_CREATE_ENG_SHIPMT);
		
		
		EpaEngine existEng = null;
		List<EpaEngine> engines = null;

		// check for engine if exists and in submitted status
		engines = getEngine( engineShpmntDTO.getProductSerialNum());
		
		/*logger.informationalEvent(this.getClass(),
				BatchConstants.MTD_CREATE_ENG_SHIPMT,
				BatchConstants.EXE_CREATE_ENG_SHIPMT +":: ItmSeqNo: " +engineShpmntDTO.getItmSeqNo()+
				",InvoiceNo: "+engineShpmntDTO.getInvoiceNum()+ ", PartNo: "+engineShpmntDTO.getPartNum()+ ", ProductSerNum:"+engineShpmntDTO.getProductSerialNum());*/
		
		logger.info(this.getClass() + BatchConstants.MTD_CREATE_ENG_SHIPMT +
				BatchConstants.EXE_CREATE_ENG_SHIPMT +":: ItmSeqNo: " +engineShpmntDTO.getItmSeqNo()+
				",InvoiceNo: "+engineShpmntDTO.getInvoiceNum()+ ", PartNo: "+engineShpmntDTO.getPartNum()+ ", ProductSerNum:"+engineShpmntDTO.getProductSerialNum());
		
		if(null != engines && !engines.isEmpty()){
		existEng = chkEngFrUpdt(engines);
		if(null != existEng){
			updtExstEng(existEng, engineShpmntDTO, engineDTO);
		}else{
			engineShpmntDTO.setNewEngShmt(true);
			//method has been commented to remove duplicates been created from batch job- 	CHG0054700
			//crteDupEng(engineShpmntDTO, engineDTO,engines);
			
		}
		}else{
			updateEngine(null, engineShpmntDTO, engineDTO);
		}

		/*logger.informationalEvent(this.getClass(),
				BatchConstants.MTD_CREATE_ENG_SHIPMT,
				BatchConstants.EXT_CREATE_ENG_SHIPMT);*/
		
		logger.info(this.getClass() + 
				BatchConstants.MTD_CREATE_ENG_SHIPMT+
				BatchConstants.EXT_CREATE_ENG_SHIPMT);
	}
	
	
	/**
	 * it updates the existing engine record
	 * @param existEng existEng
	 * @param engineShpmntDTO engineShpmntDTO
	 * @param engineDTO engineDTO
	 * @throws ServiceException ServiceException
	 */
	public void updtExstEng(EpaEngine existEng,EpaShipmentDTO engineShpmntDTO,
			EngineDTO engineDTO) throws ServiceException {
	/*	logger.informationalEvent(this.getClass(),
				BatchConstants.MTD_UPD_EXST_ENG,
				BatchConstants.METHOD_ENTRY);*/
		
		logger.info(this.getClass() + BatchConstants.MTD_UPD_EXST_ENG+
				BatchConstants.METHOD_ENTRY);
		if(valUpdtEng(existEng)){
			updateEngine(existEng, engineShpmntDTO, engineDTO);
		}
		/*logger.informationalEvent(this.getClass(),
				BatchConstants.MTD_UPD_EXST_ENG,
				BatchConstants.METHOD_EXIT);*/
		
		logger.info(this.getClass() + BatchConstants.MTD_UPD_EXST_ENG+
				BatchConstants.METHOD_EXIT);
	}
	
	/**
	 * 
	 * @param existEng existEng
	 * @param engineShpmntDTO engineShpmntDTO
	 * @param engineDTO engineDTO
	 * @throws ServiceException ServiceException
	 */
	
	public void updateEngine(EpaEngine existEng,EpaShipmentDTO engineShpmntDTO,
			EngineDTO engineDTO) throws ServiceException{
		EpaShipment existingShipmt = null;
		EpaShipment epaShipment = null;
		EpaEngine epaEngine = null;
		epaShipment = shpPopulator.populateEpaShipment(engineShpmntDTO);
		if(null != existEng){
			existingShipmt = existEng.getEpaShipment();
			epaShipment.setEpaSeqNum(existingShipmt.getEpaSeqNum());
			/*logger.informationalEvent(getClass(), BatchConstants.MTD_CREATE_ENG_SHIPMT, ""+
					epaShipment.getEpaSeqNum()+epaShipment.getInvoiceNum()+epaShipment.getPartNum());*/
			
			logger.info(this.getClass() + BatchConstants.MTD_CREATE_ENG_SHIPMT+ ""+
					epaShipment.getEpaSeqNum()+epaShipment.getInvoiceNum()+epaShipment.getPartNum());
			
		}else{
			if(!engineShpmntDTO.isNewEngShmt()){
				boolean newshmt=false;
				existingShipmt = checkShpExist(engineShpmntDTO);
				if(null != existingShipmt && null !=existingShipmt.getEpaEngines()){
					String status = existingShipmt.getEpaEngines().getEpaStatus().getEpaStatusCd();
					if((status.equals(ServiceConstants.STB) ||  status.equals(ServiceConstants.CMP))){
						newshmt=true;
					}
				}
				if(null != existingShipmt && !newshmt){
					epaShipment.setEpaSeqNum(existingShipmt.getEpaSeqNum());
				}
			}
		}
		
		/*logger.informationalEvent(getClass(), BatchConstants.MTD_CREATE_ENG_SHIPMT, "" +":: ItmSequenceNo: " +engineShpmntDTO.getItmSeqNo()+
				",InvoiceNumber: "+engineShpmntDTO.getInvoiceNum()+ ", PartNumbr: "+
					engineShpmntDTO.getPartNum()+ ", ProductSerialNum:"+engineShpmntDTO.getProductSerialNum());*/
		
		logger.info(this.getClass() + BatchConstants.MTD_CREATE_ENG_SHIPMT+ "" +":: ItmSequenceNo: " +engineShpmntDTO.getItmSeqNo()+
				",InvoiceNumber: "+engineShpmntDTO.getInvoiceNum()+ ", PartNumbr: "+
				engineShpmntDTO.getPartNum()+ ", ProductSerialNum:"+engineShpmntDTO.getProductSerialNum());
		
		if (null != engineDTO) {
			logger.info(this.getClass() + "engineDTO not null");
			
			epaEngine = enginePopulator.populateEpaEngine(engineDTO,false);
			setShpmnt(epaEngine, epaShipment);
			saveEngine(epaEngine);
		} else {
			logger.info(this.getClass() + "engineDTO  null");
			
			
			if(engineShpmntDTO.getProductSerialNum() == null || engineShpmntDTO.getProductSerialNum().trim().equals("")){
				logger.info(this.getClass() + "ProductSerialNum  null or empty");
				saveShipment(epaShipment);
			}else if(null != engineShpmntDTO.getProductSerialNum()){
				logger.info(this.getClass() + "ProductSerialNum  not null"+" PRod serial number value :"+engineShpmntDTO
						.getProductSerialNum()+" epa seq num:"+epaShipment.getEpaSeqNum() );
				epaEngine = new EpaEngine();
				epaEngine.addEngNum(engineShpmntDTO
						.getProductSerialNum().toUpperCase());
				// set seq num
				epaEngine.getId().setEpaSeqNo(epaShipment.getEpaSeqNum());
				RcrdUpdtLog updtLog = Utils.getRcdUpLg();
				epaEngine.setRcdLog(updtLog);
				epaEngine.setEpaShipment(epaShipment);
				epaEngine.setEpaStatus(new EpaStatus(
						BatchConstants.MISSING_DATA));
				logger.info(this.getClass() + "EPA engine primary key "+" Engserial num :"+epaEngine.getId().getEngineSerialNum()+" epa seq num:"+epaEngine.getId().getEpaSeqNo() );
				saveEngine(epaEngine);
			}
			/*if (null != engineShpmntDTO.getProductSerialNum()) {
				epaEngine = new EpaEngine();
				epaEngine.addEngNum(engineShpmntDTO
						.getProductSerialNum().toUpperCase());
				// set seq num
				epaEngine.getId().setEpaSeqNo(epaShipment.getEpaSeqNum());
				RcrdUpdtLog updtLog = Utils.getRcdUpLg();
				epaEngine.setRcdLog(updtLog);
				epaEngine.setEpaShipment(epaShipment);
				epaEngine.setEpaStatus(new EpaStatus(
						BatchConstants.MISSING_DATA));
				saveEngine(epaEngine);
			} else {
				saveShipment(epaShipment);
			}*/
		}
		
	}
	
	
	/**
	 * 
	 * @param epaEng epaEng
	 * @param shpmnt shpmnt
	 */
	public void setShpmnt(EpaEngine epaEng,EpaShipment shpmnt){
		
		epaEng.setEpaShipment(shpmnt);
		if(0 != shpmnt.getEpaSeqNum()){
			epaEng.getId().setEpaSeqNo(shpmnt.getEpaSeqNum());
		}
	}
	

	
	/**
	 * @param engine engine
	 * @throws ServiceException ServiceException
	 */
	public void saveEngine(EpaEngine engine) throws ServiceException {
		/*logger.informationalEvent(this.getClass(), BatchConstants.MTD_SAVE_ENG,
				BatchConstants.EXE_SAVE_ENG);*/
		
		logger.info(this.getClass() + BatchConstants.MTD_SAVE_ENG+
				BatchConstants.EXE_SAVE_ENG);
		try {
			epaEngineDAO.saveEngineInfo(engine);
		} catch (DaoException e) {
			/*logger.fatalEvent(getClass(), BatchConstants.MTD_SAVE_ENG,
					BatchConstants.ENG_CUD_NT_SAVE + ",Engine :"+engine.getEngPk().getEngineSerialNum(), e);*/
			
			logger.error(this.getClass() + BatchConstants.MTD_SAVE_ENG+
					BatchConstants.ENG_CUD_NT_SAVE + ",Engine :"+engine.getEngPk().getEngineSerialNum()+e.getMessage(),e);
			throw new ServiceException("", e);
		}
		
	}
	
	/**
	 * persist the shipment info
	 * @param epaShipment epaShipment
	 * @throws ServiceException ServiceException
	 */
	public void saveShipment(EpaShipment epaShipment) throws ServiceException {
		/*logger.informationalEvent(this.getClass(),
				BatchConstants.MTD_SAVE_SHIP, BatchConstants.EXE_SAVE_SHIP);*/
		
		logger.info(this.getClass() + BatchConstants.MTD_SAVE_SHIP+ BatchConstants.EXE_SAVE_SHIP);

		try {

			epaShipmentDAO.merge(epaShipment);
			
		} catch (Exception exception) {
			/*logger.fatalEvent(this.getClass(), BatchConstants.MTD_SAVE_SHIP,
					BatchConstants.EXCEPN_WHILE_SAVING_SHIP, exception);*/
			
			logger.error(this.getClass() + BatchConstants.MTD_SAVE_SHIP+
					BatchConstants.EXCEPN_WHILE_SAVING_SHIP+exception.getMessage());
			throw new ServiceException(exception);
		}
		/*logger.informationalEvent(this.getClass(),
				BatchConstants.MTD_SAVE_SHIP, BatchConstants.METHOD_EXIT);*/
		
		logger.info(this.getClass() + BatchConstants.MTD_SAVE_SHIP+ BatchConstants.METHOD_EXIT);
	}
	
	/**
	 * This method updates the engine information
	 * @param exisEpaEngine
	 * @param updatedEpaEng
	 * @throws ServiceException
	 */
	public void updateExisEngine(EpaEngine exisEpaEngine,EngineDTO updatedEpaEngDto) throws ServiceException{
		EpaEngine updatedEpaEngine = null;
		
		if(null != exisEpaEngine.getMachineSerialNum()){
			updatedEpaEngine = enginePopulator.populateEpaEngine(updatedEpaEngDto,true);
			updatedEpaEngine.setMachineSerialNum(exisEpaEngine.getMachineSerialNum().toUpperCase());
		}else{
			updatedEpaEngine = enginePopulator.populateEpaEngine(updatedEpaEngDto,false);
		}
		EpaShipment existingshipment = exisEpaEngine.getEpaShipment();
		if (exisEpaEngine.getId() != null && exisEpaEngine.getId().getEngineSerialNum() != null) {
			existingshipment.setEngineSerialNum(exisEpaEngine.getId()
					.getEngineSerialNum().toUpperCase());
		}
		updatedEpaEngine.setEpaShipment(existingshipment);
		updatedEpaEngine.getId().setEpaSeqNo(exisEpaEngine.getEpaShipment().getEpaSeqNum());
		updatedEpaEngine.setCaseNo(exisEpaEngine.getCaseNo());
		updatedEpaEngine.setCcrNo(exisEpaEngine.getCcrNo());
		
		saveEngine(updatedEpaEngine);
		
	}
	
	
}
