package com.cat.logistics.epa.service.impl;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArrayList;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;


import com.cat.logistics.epa.job.dto.AutoEccnDTO;
import com.cat.logistics.epa.job.dto.ECCNDetails;
import com.cat.logistics.epa.job.service.IAutoEccnService;
import com.cat.logistics.epa.job.service.IMqMessageSender;
import com.cat.logistics.epa.job.service.MqMessageSender;
import com.cat.logistics.epa.job.utils.ApplicationException;
import com.cat.logistics.epa.job.utils.BatchConstants;
import com.cat.logistics.epa.job.utils.Utils;
import com.cat.logistics.shared.utils.PersistenceConstants;

public class AutoEccnServiceImpl implements IAutoEccnService {

	IMqMessageSender messageSender = new MqMessageSender();
	public static final Logger LOGGER = LogManager.getLogger(AutoEccnServiceImpl.class);
	
	@Autowired
	AutoEccnDTO autoEccnDTO;
	@Autowired
	private ECCNDetails achDtls;

	public void readExcel(List<String> seqNo, String fileType) throws IOException, ApplicationException {
		LOGGER.info("Entry method of readExcel {}", BatchConstants.METHOD_ENTRY);
		boolean emptyExcelSheet = true;
		FileInputStream inputStream = null;
		for (String seqNum : seqNo) {
			File downloadFile = getFileForDownload(seqNum, fileType);
			if (null != downloadFile) {
				inputStream = new FileInputStream(new File(downloadFile.getPath()));

				Workbook workbook = new XSSFWorkbook(inputStream);
				Sheet firstSheet = workbook.getSheetAt(0);
				emptyExcelSheet = validateHeaderAndBlankSheet(firstSheet);
				if (!emptyExcelSheet) {
					Map<String, AutoEccnDTO> autoEccnMap = getautoEccnDTOsFromExcel(firstSheet, fileType);
					prepareGTSFile(autoEccnMap, fileType);
				}
				LOGGER.info("Exit method of readExcel {}", BatchConstants.METHOD_EXIT);
			}
		}
	}
	

	/**
	 * This Method is used to check empty rows in the excel
	 * 
	 * @param Sheet
	 * @return
	 */
	private Map<String, AutoEccnDTO> getautoEccnDTOsFromExcel(Sheet sheet, String fileType) {
		LOGGER.info("Entry method of getautoEccnDTOsFromExcel {}", BatchConstants.METHOD_ENTRY);
		int rowIndx = 1;
		int lastRow = sheet.getLastRowNum();
		AutoEccnDTO autoEccnDTO = null;
		Map<String, AutoEccnDTO> autoEccnDTOsInpMap = new HashMap<String, AutoEccnDTO>();
		while (rowIndx <= lastRow) {
			Row row = sheet.getRow(rowIndx);
			if (null != row) {
				autoEccnDTO = getautoEccnDTOFromExcelRow(row, fileType);
				if(!autoEccnDTOsInpMap.containsKey(autoEccnDTO.getPartNo())) {
				autoEccnDTOsInpMap.put(autoEccnDTO.getPartNo(), autoEccnDTO);
				}
			} else {
				break;
			}
			rowIndx++;
		} // end of while loop
		LOGGER.info("Exit method of getautoEccnDTOsFromExcel {}", BatchConstants.METHOD_EXIT);
		return autoEccnDTOsInpMap;
	}

	/**
	 * This method converts a given excel row to autoEccnDTOs DTO object
	 * 
	 * @param row
	 *            the Row
	 * @param userRole
	 *            the role
	 * @return autoEccnDTOsDTO the {@link autoEccnDTOsDTO}
	 */
	private AutoEccnDTO getautoEccnDTOFromExcelRow(Row row, String fileType) {
		AutoEccnDTO autoEccnDTO = new AutoEccnDTO();
		if (null != row) {
			autoEccnDTO.setRjn(Utils.trimString(Utils.getCellValue(row.getCell(BatchConstants.CONSTANT_ZERO))));
			autoEccnDTO.setFacCd(Utils.trimString(Utils.getCellValue(row.getCell(BatchConstants.CONSTANT_ONE))));
			autoEccnDTO.setPartNo(Utils.trimString(Utils.getCellValue(row.getCell(BatchConstants.CONSTANT_TWO))));
			autoEccnDTO.setVers(Utils.trimString(Utils.getCellValue(row.getCell(BatchConstants.CONSTANT_THREE))));
			autoEccnDTO.setChgLvl(Utils.trimString(Utils.getCellValue(row.getCell(BatchConstants.CONSTANT_FOUR))));
			autoEccnDTO.setPartTyp(Utils.trimString(Utils.getCellValue(row.getCell(BatchConstants.CONSTANT_FIVE))));
			autoEccnDTO.setNtceTyp(Utils.trimString(Utils.getCellValue(row.getCell(BatchConstants.CONSTANT_SIX))));
			autoEccnDTO.setPartNm(Utils.trimString(Utils.getCellValue(row.getCell(BatchConstants.CONSTANT_SEVEN))));
			autoEccnDTO.setDsgnCtlCd(Utils.trimString(Utils.getCellValue(row.getCell(BatchConstants.CONSTANT_EIGHT))));
			autoEccnDTO.seteMdl(Utils.trimString(Utils.getCellValue(row.getCell(BatchConstants.CONSTANT_NINE))));
			autoEccnDTO.setEngrMdlNm(Utils.trimString(Utils.getCellValue(row.getCell(BatchConstants.CONSTANT_TEN))));
			autoEccnDTO.setProdFamDesc(Utils.trimString(Utils.getCellValue(row.getCell(BatchConstants.CONSTANT_ELEVEN))));
			autoEccnDTO.setSlsMdl(Utils.trimString(Utils.getCellValue(row.getCell(BatchConstants.CONSTANT_TWELVE))));
			autoEccnDTO.setDccDesc(Utils.trimString(Utils.getCellValue(row.getCell(BatchConstants.CONSTANT_THIRTEEN))));
			autoEccnDTO.setDccEmail(Utils.trimString(Utils.getCellValue(row.getCell(BatchConstants.CONSTANT_FOURTEEN))));
			autoEccnDTO.setDccDeptNm(Utils.trimString(Utils.getCellValue(row.getCell(BatchConstants.CONSTANT_FIFTEEN))));
			autoEccnDTO.setDccSectNm(Utils.trimString(Utils.getCellValue(row.getCell(BatchConstants.CONSTANT_SIXTEEN))));
			autoEccnDTO.setPrdctEccn(Utils.trimString(Utils.getCellValue(row.getCell(BatchConstants.CONSTANT_SEVENTEEN))));
			autoEccnDTO.setDrftTnl(Utils.trimString(Utils.getCellValue(row.getCell(BatchConstants.CONSTANT_EIGHTEEN))));
			if ("output1".equalsIgnoreCase(fileType)) {
				autoEccnDTO.setClsBy(Utils.trimString(Utils.getCellValue(row.getCell(BatchConstants.CONSTANT_NINETEEN))));
			} else if ("reviewed".equalsIgnoreCase(fileType)) {
				autoEccnDTO.setRvwBy(Utils.trimString(Utils.getCellValue(row.getCell(BatchConstants.CONSTANT_NINETEEN))));
				autoEccnDTO.setLastRvwDt(Utils.trimString(Utils.getCellValue(row.getCell(BatchConstants.CONSTANT_TWENTY))));
			}
		}
		return autoEccnDTO;
	}

	private boolean validateHeaderAndBlankSheet(Sheet excelSheet) {
		LOGGER.info("Entry method of validateHeaderAndBlankSheet {}", BatchConstants.METHOD_ENTRY);
		boolean emptyExcel = false;
		try {
			Row muHeader = excelSheet.getRow(BatchConstants.CONSTANT_ZERO);
			int headerCols = (muHeader == null) ? BatchConstants.CONSTANT_ZERO : muHeader.getLastCellNum();
			emptyExcel = (headerCols < 3) ? true : false;

			int beginIndx = 1;
			int endIndx = (excelSheet.getLastRowNum() > excelSheet.getPhysicalNumberOfRows())
					? excelSheet.getLastRowNum() : excelSheet.getPhysicalNumberOfRows();

			List<Row> rows = getAllRowsInSheet(excelSheet, beginIndx, endIndx);
			if (rows.isEmpty()) {
				emptyExcel = true;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		LOGGER.info("Exit method of validateHeaderAndBlankSheet {} {} ",emptyExcel, BatchConstants.METHOD_EXIT);
		return emptyExcel;
	}

	/**
	 * Method to return all rows in excel
	 * 
	 * @param excelSheet
	 * @param beginIndx
	 * @param endIndx
	 * @param errMsg
	 * @return
	 */
	private List<Row> getAllRowsInSheet(Sheet excelSheet, int beginIndx, int endIndx) {
		List<Row> rows = new ArrayList<Row>();
		while (beginIndx <= endIndx) {

			Row row = excelSheet.getRow(beginIndx);
			if (null != row) {
				for (short c = 0; c < row.getLastCellNum(); c++) {

					if (null != row.getCell(c) && row.getCell(c).getCellType() != HSSFCell.CELL_TYPE_BLANK) {
						rows.add(row);
						break;
					}
				}
			}

			beginIndx++;
		}

		return rows;
	}

	/**
	 * get file for download
	 * 
	 * @param sNo
	 *            the sequence number
	 * @param fileType
	 *            the file type
	 * @return the file
	 */
	@Override
	public File getFileForDownload(String sNo, String fileType) {
		LOGGER.info("Entry method of getFileForDownload {} ",BatchConstants.METHOD_ENTRY);
		String currentEnv = System.getProperty("ENVIRONMENT");
		String tmpLocation = achDtls.getTmpFldrLocDly();
		if(tmpLocation!=null){
			if(!currentEnv.equalsIgnoreCase("DEV")){
				tmpLocation=Utils.getNASpath()+tmpLocation;
			}
		File seqDir = new File(tmpLocation + BatchConstants.BACK_SLASH + sNo);
		String fileName = null;
		LOGGER.info("getFilePath -  {}",seqDir.getAbsolutePath());
		if (seqDir.isDirectory()) {
			if (BatchConstants.OUTPUT.equalsIgnoreCase(fileType)) {
				fileName = BatchConstants.OUTPUT1_FILE;
			} else if (BatchConstants.REVIEWED.equalsIgnoreCase(fileType)) {
				fileName = BatchConstants.REVIEWED_FILE;
			}
		}
		if (null != fileName) {
			File downloadFile = new File(seqDir.getPath() + BatchConstants.BACK_SLASH + fileName);
			if (downloadFile.exists()) {
				LOGGER.info("Entry method of getFileForDownload {}", downloadFile.getAbsolutePath());
				return downloadFile;
			}
		}
		}
		LOGGER.info("Exit method of getFileForDownload {}", BatchConstants.METHOD_EXIT);
		return null;
	}
		

	private String prepareGTSFile(Map<String, AutoEccnDTO> autoEccnMap, String fileType) throws ApplicationException {
		LOGGER.info("Entry method of prepareGTSFile {}", BatchConstants.METHOD_ENTRY);
		String mqMessage = null;
		String fileName = null;

		for (AutoEccnDTO eccnMsg : autoEccnMap.values()) {
			if (BatchConstants.OUTPUT.equalsIgnoreCase(fileType)) {
				mqMessage = BatchConstants.OUTPUT + BatchConstants.DELIMITER + eccnMsg.getRjn() + BatchConstants.DELIMITER + eccnMsg.getFacCd() + BatchConstants.DELIMITER + eccnMsg.getPartNo()
						+ BatchConstants.DELIMITER + eccnMsg.getVers() + BatchConstants.DELIMITER + eccnMsg.getChgLvl() + BatchConstants.DELIMITER + eccnMsg.getPartTyp() + BatchConstants.DELIMITER
						+ eccnMsg.getNtceTyp() + BatchConstants.DELIMITER + eccnMsg.getPartNm() + BatchConstants.DELIMITER + eccnMsg.getDsgnCtlCd() + BatchConstants.DELIMITER
						+ eccnMsg.geteMdl() + BatchConstants.DELIMITER + eccnMsg.getEngrMdlNm() + BatchConstants.DELIMITER + eccnMsg.getProdFamDesc() + BatchConstants.DELIMITER
						+ eccnMsg.getSlsMdl() + BatchConstants.DELIMITER + eccnMsg.getDccDesc() + BatchConstants.DELIMITER + eccnMsg.getDccEmail() + BatchConstants.DELIMITER
						+ eccnMsg.getDccDeptNm() + BatchConstants.DELIMITER + eccnMsg.getDccSectNm() + BatchConstants.DELIMITER + eccnMsg.getPrdctEccn() + BatchConstants.DELIMITER
						+ eccnMsg.getDrftTnl() + BatchConstants.DELIMITER + eccnMsg.getClsBy()  + BatchConstants.DELIMITER  + BatchConstants.DELIMITER + BatchConstants.DELIMITER;
				fileName = "OUTPUT_1";
			} else {
				mqMessage = BatchConstants.REVIEWED + BatchConstants.DELIMITER + eccnMsg.getRjn() + BatchConstants.DELIMITER + eccnMsg.getFacCd() + BatchConstants.DELIMITER + eccnMsg.getPartNo()
						+ BatchConstants.DELIMITER + eccnMsg.getVers() + BatchConstants.DELIMITER + eccnMsg.getChgLvl() + BatchConstants.DELIMITER + eccnMsg.getPartTyp() + BatchConstants.DELIMITER
						+ eccnMsg.getNtceTyp() + BatchConstants.DELIMITER + eccnMsg.getPartNm() + BatchConstants.DELIMITER + eccnMsg.getDsgnCtlCd() + BatchConstants.DELIMITER
						+ eccnMsg.geteMdl() + BatchConstants.DELIMITER + eccnMsg.getEngrMdlNm() + BatchConstants.DELIMITER + eccnMsg.getProdFamDesc() + BatchConstants.DELIMITER
						+ eccnMsg.getSlsMdl() + BatchConstants.DELIMITER + eccnMsg.getDccDesc() + BatchConstants.DELIMITER + eccnMsg.getDccEmail() + BatchConstants.DELIMITER
						+ eccnMsg.getDccDeptNm() + BatchConstants.DELIMITER + eccnMsg.getDccSectNm() + BatchConstants.DELIMITER + eccnMsg.getPrdctEccn() + BatchConstants.DELIMITER
						+ eccnMsg.getDrftTnl() + BatchConstants.DELIMITER + BatchConstants.DELIMITER + eccnMsg.getRvwBy() + BatchConstants.DELIMITER + eccnMsg.getLastRvwDt()  + BatchConstants.DELIMITER;
				fileName = BatchConstants.REVIEWED;
			}
			LOGGER.info("prepareGTSFile - {}", autoEccnDTO.toString());
			messageSender.sendMQMsgToSrcQueue(mqMessage, fileName, fileType, autoEccnDTO);
			LOGGER.info("Exit method of prepareGTSFile- {}", BatchConstants.METHOD_EXIT);
		}
		return null;

	}

}
