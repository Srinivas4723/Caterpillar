package com.cat.logistics.epa.service;

import java.util.List;
import java.util.Map;
import java.util.Set;

import com.cat.logistics.epa.entities.EpaConfig;
import com.cat.logistics.epa.entities.EpaMachine;
import com.cat.logistics.epa.entities.EpaShipment;
import com.cat.logistics.shared.dto.MachineDTO;
import com.cat.logistics.shared.exception.DaoException;

/**
 *  Interface for MachineDataConverterEpaImpl
 * @author ganamr
 *
 */
public interface IMachineDataConverter
{
	/**
	 * @param epaMchShpmt
	 * @return EPA Shipment
	 */
	MachineDTO convertEpaShipmentLstToMachineDTO(List<EpaShipment> epaMchShpmt);
	/**
	 * @param mchDto
	 * @param status
	 * @return Machine DTO
	 */
	EpaShipment convertMachineDTOtoEpaShipment(MachineDTO mchDto,String status) throws DaoException;
	/**
	 * @param epaImpProvConfig
	 * @return  the EPA config
	 */
	Map<String, Set<String>> convertEpaConfigToMap(List<EpaConfig> epaImpProvConfig);
	/**
	 * @param epaShipment
	 * @return the EPA shipment
	 */
	MachineDTO convertEpaShipmentToMachineDTO(EpaShipment epaShipment) ;
	/**
	 * @param epaMach
	 * @param machDto
	 * @return the EPA Machine
	 */
	MachineDTO convertEpaMachineToMachineDTO(EpaMachine epaMach, MachineDTO machDto);
	/**
	 * @param machDto
	 * @param epaMach
	 * @return the Machine DTO
	 */
	EpaMachine convertMachineDTOtoEpaMachine(MachineDTO machDto,EpaMachine epaMach);

}
