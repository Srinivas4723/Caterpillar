package com.cat.logistics.epa.service;

import java.util.List;
import java.util.Map;

import com.cat.logistics.shared.dto.EngineDTO;
import com.cat.logistics.shared.exception.ServiceException;

/**
 * interface for EngineEmissionService
 * @author ganamr
 *
 */
public interface IEngineEmissionService {

	
	/**
	 * @param serialNums
	 * @return Engine dto for given serial number
	 * @throws ServiceException
	 */
	public Map<String,EngineDTO> getEngineInfo(List<String> serialNums) throws ServiceException;
}
