package com.cat.logistics.epa.service.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import com.cat.logistics.epa.dao.IEpaConfigDAO;
import com.cat.logistics.epa.dao.IEpaFacilityDAO;
import com.cat.logistics.epa.dao.IEpaHtsConfgrDAO;
import com.cat.logistics.epa.dao.IEpaHtsExcpCnfgrDAO;
import com.cat.logistics.epa.dao.IEpaMachineDAO;
import com.cat.logistics.epa.dao.IEpaShipmentDAO;
import com.cat.logistics.epa.dto.EpaShipmentDTO;
import com.cat.logistics.epa.entities.EpaConfig;
import com.cat.logistics.epa.entities.EpaConfigPK;
import com.cat.logistics.epa.entities.EpaEngine;
import com.cat.logistics.epa.entities.EpaFac;
import com.cat.logistics.epa.entities.EpaHtsConfgr;
import com.cat.logistics.epa.entities.EpaHtsExcpConfgr;
import com.cat.logistics.epa.entities.EpaShipment;
import com.cat.logistics.epa.entities.EpaUserAth;
import com.cat.logistics.epa.entities.RcrdUpdtLog;
import com.cat.logistics.epa.job.dto.MailDTO;
import com.cat.logistics.epa.job.service.IEPAService;
import com.cat.logistics.epa.job.service.IEngineCreateService;
import com.cat.logistics.epa.job.service.IMachCreateService;
import com.cat.logistics.epa.job.tvs.IErrorMessageCreator;
import com.cat.logistics.epa.job.utils.BatchConstants;
import com.cat.logistics.epa.job.utils.BatchContext;
import com.cat.logistics.epa.job.utils.Utils;
import com.cat.logistics.shared.dto.EngineDTO;
import com.cat.logistics.shared.dto.MachineDTO;
import com.cat.logistics.shared.exception.DaoException;
import com.cat.logistics.shared.exception.ServiceException;
import com.cat.logistics.shared.exception.ValidatorException;
import com.cat.logistics.shared.utils.EPAUtils;
import com.cat.logistics.shared.utils.PersistenceConstants;
import com.cat.logistics.tis.entities.HTSCodes;



/**
 * @author chanda15
 * 
 */
public class EPAService implements IEPAService {

	@Autowired
	private IEpaHtsConfgrDAO epaHtsConfgrDAO;

	@Autowired
	private IEpaHtsExcpCnfgrDAO excptCfngrDao;

	@Autowired
	private IEpaShipmentDAO epaShipmentDAO;

	@Autowired
	private IEpaConfigDAO epaConfigDAO;

	@Autowired
	private IErrorMessageCreator errorMessageCreator;

	@Autowired
	private IEpaFacilityDAO epaFacilityDAO;
	
	@Autowired
	private IEngineCreateService engineCreateService;
	
	@Autowired
	private IMachCreateService mchCreateService;
	
	@Autowired
	private IEpaMachineDAO epaMachineDAO;

	private String startTime;

	//private ILogger logger = Logger.getInstance();
	private final static Logger logger = LogManager.getLogger(EPAService.class);

	/**
	 * This method determines the Part belongs to engine or machine
	 * 
	 * @see com.cat.logistics.epa.job.service.IEPAService#partDetermination(java.util.Map)
	 */
	public void partDetermination(Map<String, EpaShipmentDTO> partShpmnts,boolean checkEpaRqurd)
			throws Exception {
		/*logger.informationalEvent(this.getClass(),
				BatchConstants.MTD_PART_DETERMIN,
				BatchConstants.EXE_PART_DETERMIN);*/
		logger.info(this.getClass()+
				BatchConstants.MTD_PART_DETERMIN+
				BatchConstants.EXE_PART_DETERMIN);
		boolean epaRequired = false;
		
		Set<Entry<String, EpaShipmentDTO>> partShpmntEntry = partShpmnts
				.entrySet();
		Iterator<Entry<String, EpaShipmentDTO>> partIterator = partShpmntEntry
				.iterator();
		while (partIterator.hasNext()) {
			try {
				Entry<String, EpaShipmentDTO> entry = partIterator.next();
				EpaShipmentDTO epaShipmentDTO = entry.getValue();
				if(checkEpaRqurd){
				epaRequired = isEpaRequired(epaShipmentDTO);
				if (!epaRequired) {
					partIterator.remove();
					continue;
				}
				}else{
					setEpaPartType(epaShipmentDTO, epaShipmentDTO.getEpaProdTypeCode(), false);
				}
				facilityValidations(epaShipmentDTO);
			} catch (Exception exc) {
			exc.printStackTrace();
				/*logger.fatalEvent(this.getClass(),
						BatchConstants.MTD_PART_DETERMIN,
						BatchConstants.DETERMING_PART_FAILED, exc);*/
				logger.error(this.getClass()+
					BatchConstants.MTD_PART_DETERMIN+
					BatchConstants.DETERMING_PART_FAILED+ exc);
			}
		}
		Map<String,List<String>> invMap = getInvcMapObj(partShpmnts);
		filterMchEngs(partShpmnts, invMap);
	}
	
	
	/**
	 * This function collects invoice number and engine and machine records of same invoice
	 * and populates the Map which has invoice and related objects
	 * @param partShpmnts partShpmnts
	 * @return Map Map
	 */
	public Map<String,List<String>> getInvcMapObj(Map<String, EpaShipmentDTO> partShpmnts){
		//logger.informationalEvent(this.getClass(), BatchConstants.MTD_GET_INVOICE_MAP, BatchConstants.METHOD_ENTRY);
		logger.info(this.getClass()+ BatchConstants.MTD_GET_INVOICE_MAP+ BatchConstants.METHOD_ENTRY);
		Map<String,List<String>> invMap = new HashMap<String, List<String>>();
		Set<String> keyset = partShpmnts.keySet();
		String invoice = null;
		String[] arrStr = null;
		List<String> strList= null;
		List<String> listObj = null;
		for(String key: keyset){
			arrStr = key.split(BatchConstants.HYPHEN);
			invoice = arrStr[1];
			strList = invMap.get(invoice);
			if(null != strList){
				strList.add(key);
				invMap.put(invoice, strList);
			}else{
				listObj = new ArrayList<String>();
				listObj.add(key);
				invMap.put(invoice, listObj);
			}
		}
		//logger.informationalEvent(this.getClass(), BatchConstants.MTD_GET_INVOICE_MAP, BatchConstants.METHOD_EXIT);
		logger.info(this.getClass() + BatchConstants.MTD_GET_INVOICE_MAP + BatchConstants.METHOD_EXIT);
		return invMap;
	}
	
	/**
	 * Filter engine records if same invoice is having machine
	 * @param partShpmnts partShpmnts
	 * @param invoiceMap invoiceMap
	 */
	public void filterMchEngs(Map<String, EpaShipmentDTO> partShpmnts, Map<String,List<String>> invoiceMap ){
		//logger.informationalEvent(this.getClass(), BatchConstants.MTD_FILTER_ENGMCH_INVOICE, BatchConstants.METHOD_ENTRY);
		logger.info(this.getClass()+ BatchConstants.MTD_FILTER_ENGMCH_INVOICE+ BatchConstants.METHOD_ENTRY);
		Set<Entry<String,List<String>>> entrySet= null;
		List<String> partShmtkeyLst = null;
		if(null != invoiceMap){
			entrySet = invoiceMap.entrySet();
			for(Entry<String,List<String>> entryObj: entrySet){
				partShmtkeyLst = entryObj.getValue();
				if(partShmtkeyLst.size()>1){
					delEngEntry(partShmtkeyLst, partShpmnts);
				}
			}
		}
		productSerialNumValidations(partShpmnts);
		//logger.informationalEvent(this.getClass(), BatchConstants.MTD_FILTER_ENGMCH_INVOICE, BatchConstants.METHOD_EXIT);
		logger.info(this.getClass()+ BatchConstants.MTD_FILTER_ENGMCH_INVOICE+ BatchConstants.METHOD_EXIT);
	}
	
	/**
	 * Filter engine records having same invoice number as machine
	 * @param partShmtkeyLst partShmtkeyList
	 * @param partShpmnts partShpmnts
	 */
	private void delEngEntry(List<String> partShmtkeyLst, Map<String, EpaShipmentDTO> partShpmnts){
		//logger.informationalEvent(this.getClass(), BatchConstants.MTD_DEL_INV_ENGS, BatchConstants.METHOD_ENTRY);
		logger.info(this.getClass() + BatchConstants.MTD_DEL_INV_ENGS + BatchConstants.METHOD_ENTRY);
		EpaShipmentDTO shmtRec= null;
		String mchKey = null;
		List<String> engKeys = new ArrayList<String>();
		for(String shmtpartsKey: partShmtkeyLst){
			shmtRec = partShpmnts.get(shmtpartsKey);
			if(BatchConstants.MACHINE_LITERAL.equalsIgnoreCase(shmtRec.getEpaProdTypeCode())){
				mchKey = shmtpartsKey;
			}else if(BatchConstants.ENGINE_LITERAL.equalsIgnoreCase(shmtRec.getEpaProdTypeCode())){
				engKeys.add(shmtpartsKey);
			}
		}
		if(!EPAUtils.isNullOrEmpty(mchKey) && engKeys.size()>0){
			for(String engkey: engKeys){
				partShpmnts.remove(engkey);
			}
		}
		//logger.informationalEvent(this.getClass(), BatchConstants.MTD_DEL_INV_ENGS, BatchConstants.METHOD_EXIT);
		logger.info(this.getClass()+ BatchConstants.MTD_DEL_INV_ENGS + BatchConstants.METHOD_EXIT);
	}

	/**
	 * This method validates the facility code
	 * 
	 * @param epaShpmntDto
	 * @throws ServiceException
	 */
	public void facilityValidations(EpaShipmentDTO epaShpmntDto)
			throws ServiceException {
		/*logger.informationalEvent(this.getClass(),
				BatchConstants.MTD_FAC_VALIDATIONS,
				BatchConstants.EXE_FAC_VALIDATIONS);*/
		logger.info(this.getClass()+
				BatchConstants.MTD_FAC_VALIDATIONS+
				BatchConstants.EXE_FAC_VALIDATIONS);
		EpaFac epaFac = null;
		List<EpaUserAth> epaUserAths = null;
		String facility = epaShpmntDto.getOrigFacCd();
		if (!Utils.checkForNullAndNoLength(facility)) {
			try {
				epaFac = epaFacilityDAO.getFacility(facility);
			} catch (DaoException e) {
				/*logger.fatalEvent(this.getClass(),
						BatchConstants.MTD_FAC_VALIDATIONS,
						BatchConstants.READING_FAC_FAILED + facility, e);*/
				logger.error(this.getClass()+
						BatchConstants.MTD_FAC_VALIDATIONS+
						BatchConstants.READING_FAC_FAILED + facility + e.getMessage());
				throw new ServiceException(e);
			}
			if (epaFac != null) {
				
				epaUserAths = epaFac.getEpaUsrAth();
				if (epaUserAths != null && epaUserAths.size() == 0) {
					errorMessageCreator.userNotAssgndFac(epaShpmntDto);
					return;
				}
			} else {
				EpaFac fac = new EpaFac(facility);
				fac.setFacilityName(BatchConstants.UNKNOWN_FAC);
				RcrdUpdtLog updtLg = Utils.getRcdUpLg();
				fac.setRcdLog(updtLg);
				try {
					epaFacilityDAO.persist(fac);
				} catch (DaoException e) {
					/*logger.fatalEvent(this.getClass(),
							BatchConstants.MTD_FAC_VALIDATIONS,
							BatchConstants.FAC_VALIDATION_FAILED, e);*/
					logger.error(this.getClass()+
							BatchConstants.MTD_FAC_VALIDATIONS+
							BatchConstants.FAC_VALIDATION_FAILED+ e.getMessage());
				}
				errorMessageCreator.originFacNotCnfgrEPA(epaShpmntDto);
			}

		} else {
			prepareEPAShipmentDTO(epaShpmntDto);
		}
	}


	/**
	 * @param epaShpmntDto
	 */
	public void setOrigFac(EpaShipmentDTO epaShpmntDto) {
		String rcvgFac = epaShpmntDto.getRcvgFacCd();
		if (!Utils.checkForNullAndNoLength(rcvgFac)
				&& rcvgFac.equals(BatchConstants.FAC_CD_68)) {
			epaShpmntDto.setOrigFacCd(BatchConstants.FAC_CD_1111);
			//epaShpmntDto.setMachineManufactureName(BatchConstants.REMAN_FAC);
		} else if (!Utils.checkForNullAndNoLength(rcvgFac)
				&& rcvgFac.equals(BatchConstants.FAC_CD_47)) {
			epaShpmntDto.setOrigFacCd(BatchConstants.FAC_CD_2222);
			/*epaShpmntDto
					.setMachineManufactureName(BatchConstants.SERV_PARTS_FAC);*/
		} else {
			epaShpmntDto.setOrigFacCd(BatchConstants.FAC_CD_3333);
			//epaShpmntDto.setMachineManufactureName(BatchConstants.UNASG_FAC);
			errorMessageCreator.invalidOrigFacSuppCode(epaShpmntDto);
		}
	}

	/**
	 * It validates product serial numbers
	 * @param partShpmnts
	 */
	public void productSerialNumValidations(Map<String, EpaShipmentDTO> partShpmnts) {
		/*logger.informationalEvent(this.getClass(),
				BatchConstants.MTD_PR_SER_NUM_VALIDATIONS,
				BatchConstants.EXE_PR_SER_NUM_VALIDATIONS);*/
		logger.info(this.getClass()+
				BatchConstants.MTD_PR_SER_NUM_VALIDATIONS+
				BatchConstants.EXE_PR_SER_NUM_VALIDATIONS);
		Set<Entry<String, EpaShipmentDTO>> partshmtEntry = partShpmnts.entrySet();
		Iterator<Entry<String, EpaShipmentDTO>> partItr = partshmtEntry.iterator();
		while (partItr.hasNext()) {
			try {
				Entry<String, EpaShipmentDTO> entry = partItr.next();
				EpaShipmentDTO epaShpmntDto = entry.getValue();
				if (epaShpmntDto.getProductSerialNum() == null
						&& epaShpmntDto.getEpaProdTypeCode() != null) {
					if (epaShpmntDto.getEpaProdTypeCode()
							.equals(BatchConstants.ENGINE_LITERAL)) {
						errorMessageCreator.engineSerialNumMissing(epaShpmntDto);
					} else if (epaShpmntDto.getEpaProdTypeCode().equals(
							BatchConstants.MACHINE_LITERAL)) {
						errorMessageCreator.machineSerialNumMissing(epaShpmntDto);
					}
				}
			}catch(Exception ex){
				ex.printStackTrace();
				/*logger.fatalEvent(this.getClass(),
						BatchConstants.MTD_FILTER_ENGMCH_INVOICE,
						ex.getMessage(), ex);*/
				logger.error(this.getClass()+
						BatchConstants.MTD_FILTER_ENGMCH_INVOICE+
						ex.getMessage());
			}
		}
	}

	/**
	 * CHECKS is EPA required or not
	 * 
	 * @param epaShpmntDto
	 * @return boolean value true or false
	 * @throws ServiceException
	 */
	public boolean isEpaRequired(EpaShipmentDTO epaShpmntDto)
			throws ServiceException {
		/*logger.informationalEvent(this.getClass(),
				BatchConstants.MTD_IS_EPA_REQ, BatchConstants.EXE_IS_EPA_REQ);*/
		logger.info(this.getClass()+
				BatchConstants.MTD_IS_EPA_REQ + BatchConstants.EXE_IS_EPA_REQ);
		boolean epaRequired = false;
		EpaHtsConfgr epaHtsConfgr = null;

		epaHtsConfgr = getEpaHtsCnfgr(epaShpmntDto.getHtsCode());

		if (null == epaHtsConfgr) {
			//logger.informationalEvent(this.getClass(), "isEpaRequired", "EPA not required for "+getHTSKey(epaShpmntDto)+getHTSDetails(epaShpmntDto));
			logger.info(this.getClass()+ "isEpaRequired"+ "EPA not required for "+getHTSKey(epaShpmntDto)+getHTSDetails(epaShpmntDto));
			//errorMessageCreator.logHTSNotFoundError(epaShpmntDto);
			return epaRequired;
		}

		if (BatchConstants.YES_LITERAL.equals(epaHtsConfgr
				.getExceptionIndicator())) {
			epaRequired = isExceptionPart(epaShpmntDto);
			return epaRequired;
		} else {
			epaRequired = true;
		}

		setEpaPartType(epaShpmntDto, epaHtsConfgr.getHtsConfiguration(), false);

		return epaRequired;
	}

	public String getHTSDetails(EpaShipmentDTO epaShipmentDTO){
		
		StringBuilder htsDet = new StringBuilder();
		htsDet.append(epaShipmentDTO.getInvoiceNum());
		htsDet.append(BatchConstants.HYPHEN);
		htsDet.append(epaShipmentDTO.getPartNum());
		htsDet.append(BatchConstants.HYPHEN);
		htsDet.append(epaShipmentDTO.getHtsCode());
		htsDet.append(BatchConstants.HYPHEN);
		htsDet.append(epaShipmentDTO.getItmSeqNo());
		htsDet.append(BatchConstants.HYPHEN);
		htsDet.append(epaShipmentDTO.getLoadNum());
		
		return htsDet.toString();
		
	}
	
public String getHTSKey(EpaShipmentDTO epaShipmentDTO){
		
		StringBuilder htsDet = new StringBuilder();
		htsDet.append(BatchConstants.INVOICE_NUM_HOLDER);
		htsDet.append(BatchConstants.HYPHEN);
		htsDet.append(BatchConstants.PART_NUM_HOLDER);
		htsDet.append(BatchConstants.HYPHEN);
		htsDet.append(BatchConstants.HTS_CD_HOLDER);
		htsDet.append(BatchConstants.HYPHEN);
		htsDet.append(BatchConstants.ORDER_NUM_VAR);
		htsDet.append(BatchConstants.HYPHEN);
		htsDet.append(BatchConstants.SEQ_NUM_VAR);
		htsDet.append(BatchConstants.HYPHEN);
		
		return htsDet.toString();
		
	}

	
	
	
	/**
	 * @param shpmntDto
	 * @return EpaHtsConfgr hts configure obj
	 * @throws ServiceException
	 */
	@SuppressWarnings( { "rawtypes", "unchecked" })
	public EpaHtsConfgr getEpaHtsCnfgr(String htsCode)
			throws ServiceException {
		/*logger.informationalEvent(this.getClass(),
				BatchConstants.MTD_IS_EPA_REQ, BatchConstants.EXE_IS_EPA_REQ);*/
		logger.info(this.getClass()+
				BatchConstants.MTD_IS_EPA_REQ+ BatchConstants.EXE_IS_EPA_REQ);
		EpaHtsConfgr epaHtsConfgr = null;
		String htsCodeFourVar = null;
		String htsCodeSix = null;
		List<EpaHtsConfgr> epaHtsCnfgList = null;
		
		if (htsCode != null) {
			try {
				if (htsCode.length() >= BatchConstants.NUM_SIX) {
						htsCodeSix = htsCode.substring(0,
								BatchConstants.NUM_SEVEN);
					}
					htsCodeFourVar = htsCode.substring(0,
							BatchConstants.NUM_FOUR);
					//logger.informationalEvent(this.getClass(), "getEpaHtsCnfgr"," htsCode : "+htsCode+","+htsCodeSix+","+htsCodeFourVar );
					logger.info(this.getClass() + "getEpaHtsCnfgr"+" htsCode : "+htsCode+","+htsCodeSix+","+htsCodeFourVar );
					List codesList = new ArrayList<String>(Arrays.asList(
							htsCodeFourVar, htsCodeSix, htsCode));

					epaHtsConfgr = epaHtsConfgrDAO
							.getHtsConfgrByCode(codesList);

			} catch (DaoException daoException) {
				/*logger.fatalEvent(this.getClass(),
						BatchConstants.MTD_GET_EPA_HTS_CNFGR,
						BatchConstants.FETCHING_EPA_HTSCNFG_FAILED,
						daoException);*/
				
				logger.error(this.getClass()+
						BatchConstants.MTD_GET_EPA_HTS_CNFGR+
						BatchConstants.FETCHING_EPA_HTSCNFG_FAILED+
						daoException.getMessage());
				throw new ServiceException(daoException.getLocalizedMessage(),
						daoException);
			} catch (Exception daoExc) {
				/*logger.fatalEvent(this.getClass(),
						BatchConstants.MTD_GET_EPA_HTS_CNFGR,
						BatchConstants.FETCHING_EPA_HTSCNFG_FAILED, daoExc);
				throw new ServiceException(daoExc.getLocalizedMessage(), daoExc);*/
				logger.error(this.getClass()+
						BatchConstants.MTD_GET_EPA_HTS_CNFGR+
						BatchConstants.FETCHING_EPA_HTSCNFG_FAILED+ daoExc.getMessage());
				throw new ServiceException(daoExc.getLocalizedMessage(), daoExc);
			}
		}
		return epaHtsConfgr;
	}

	/**
	 * 
	 * @return
	 */
	public List<EpaHtsConfgr> getEpaHtsCds(){
		List<EpaHtsConfgr> epaHtsCnfgList = null;
		try{
			epaHtsCnfgList = epaHtsConfgrDAO.getEpaHtsCds();
		}catch(Exception ex){
			/*logger.fatalEvent(this.getClass(),
					BatchConstants.MTD_GET_EPA_HTS_CDS,
					BatchConstants.FETCHING_EPA_HTSCDS_FAILED, ex);*/
			logger.error(this.getClass()+
					BatchConstants.MTD_GET_EPA_HTS_CDS+
					BatchConstants.FETCHING_EPA_HTSCDS_FAILED+ ex.getMessage());
		}
		return epaHtsCnfgList;
	}
	
	/**
	 * 
	 * @param htsCode
	 * @return
	 * @throws Exception
	 */
	public List<String> splitHtsCd(String htsCode) throws Exception{
		String htsCodeFourVar = null;
		String htsCodeSix = null;
		List codesList = null;
		if (htsCode != null) {
			try {
				if (htsCode.length() >= BatchConstants.NUM_SIX) {
						htsCodeSix = htsCode.substring(0,
								BatchConstants.NUM_SEVEN);
					}
					htsCodeFourVar = htsCode.substring(0,
							BatchConstants.NUM_FOUR);
					//logger.informationalEvent(this.getClass(), "getEpaHtsCnfgr"," htsCode : "+htsCode+","+htsCodeSix+","+htsCodeFourVar );
					logger.info(this.getClass() + "getEpaHtsCnfgr"+" htsCode : "+htsCode+","+htsCodeSix+","+htsCodeFourVar );
					 codesList = new ArrayList<String>(Arrays.asList(
							htsCodeFourVar, htsCodeSix, htsCode));
			}catch(Exception ex){
				throw ex;
			}
		}
		return codesList;
	}
	/**
	 * 
	 * @param htsCode
	 * @param partNum
	 * @return
	 * @throws ServiceException
	 */
	@SuppressWarnings("unchecked")
	public boolean validEpaHtsCd(HTSCodes htsCode,List<EpaHtsConfgr> epaHtsCnfgList) throws ServiceException{
		EpaHtsExcpConfgr excptCnfgr = null;
		List<String> codesList = null;
		Map<String,String> partTyps =(Map<String,String>)BatchContext.getValue(BatchConstants.PART_PARTTYPE);
		
		try{
			codesList = splitHtsCd(htsCode.getHtsCode());
			if(epaHtsCnfgList != null){
				
				for(EpaHtsConfgr htsCd : epaHtsCnfgList){
					if(codesList != null && codesList.contains(htsCd.getHtsCode())){
						
							if (BatchConstants.YES_LITERAL.equals(htsCd
									.getExceptionIndicator())) {
								excptCnfgr =	getEpHtsExcpConfgr(htsCode.getPartId(), htsCd.getHtsCode());
								if(null != excptCnfgr){
									partTyps.put(htsCode.getPartId(), htsCd.getHtsConfiguration());
									//BatchContext.put(BatchConstants.PART_PARTTYPE, partTyps);
									return true;
								}
					  }else{
						 // BatchContext.put(BatchConstants.PART_PARTTYPE, partTyps);
						  partTyps.put(htsCode.getPartId(), htsCd.getHtsConfiguration());
						  return true;
					  }
					}
				}
				
			}
			
			
		}catch(Exception ex){
			throw new ServiceException(ex);
		}
		
		return false;
	}
	
	
	/**
	 * @param epaShpmntDto
	 * @return boolean value
	 * @throws ServiceException
	 */
	@SuppressWarnings("unused")
	public boolean isExceptionPart(EpaShipmentDTO epaShpmntDto)
			throws ServiceException {
		/*logger.informationalEvent(this.getClass(),
				BatchConstants.MTD_IS_EXCEN_PART,
				BatchConstants.EXE_IS_EXCEN_PART);*/
		logger.info(this.getClass()+
				BatchConstants.MTD_IS_EXCEN_PART+
				BatchConstants.EXE_IS_EXCEN_PART);
		boolean epaRequired = false;
		List<EpaHtsExcpConfgr> excpConfgr = null;
		EpaHtsExcpConfgr excptCnfgr = null;

		try {
			excptCnfgr = getEpHtsExcpConfgr(epaShpmntDto.getPartNum(),epaShpmntDto.getHtsCode());
			if (excptCnfgr != null) {
				setEpaPartType(epaShpmntDto, excptCnfgr.getHtsConfiguration(),
						true);
				epaShpmntDto.setEpaProdTypeCode(excptCnfgr.getHtsConfiguration());
				epaRequired = true;
			} else {
				epaRequired = false;
			//	errorMessageCreator.logNoExcptnHTSError(epaShpmntDto);
				//logger.informationalEvent(this.getClass(), "isEpaRequired", "EPA not required for exception htscodes,  "+getHTSKey(epaShpmntDto)+getHTSDetails(epaShpmntDto));
				logger.info(this.getClass()+ "isEpaRequired"+ "EPA not required for exception htscodes,  "+getHTSKey(epaShpmntDto)+getHTSDetails(epaShpmntDto));
			}

		} catch (Exception daoException) {
			/*logger.fatalEvent(getClass(), BatchConstants.MTD_IS_EXCEN_PART,
					BatchConstants.DETERMIN_EXCEN_HTS_FAILED, daoException);*/
			logger.info(getClass()+ BatchConstants.MTD_IS_EXCEN_PART+
					BatchConstants.DETERMIN_EXCEN_HTS_FAILED+ daoException.getMessage());
			throw new ServiceException(
					BatchConstants.COULD_NT_RD_HTSCNFG_DETAILS, daoException);
		}

		return epaRequired;
	}
	/**
	 * 
	 * @param partNum
	 * @param htsCode
	 * @return
	 * @throws DaoException
	 */
	public EpaHtsExcpConfgr getEpHtsExcpConfgr(String partNum,String htsCode) throws ServiceException{
		EpaHtsExcpConfgr excptCnfgr = new EpaHtsExcpConfgr();
		try {
			excptCnfgr.setPartNumber(partNum);
			excptCnfgr.setExcpHtsCode(htsCode);
			excptCnfgr = excptCfngrDao.getEpHtsExcpConfgr(excptCnfgr);
		}catch(DaoException daoEx){
			throw new ServiceException(daoEx);
		}
		return excptCnfgr;
	}

	/**
	 * @param epaShpmntDto
	 * @param partType
	 *            product type
	 * @param exception
	 */
	@SuppressWarnings("unchecked")
	public void setEpaPartType(EpaShipmentDTO epaShpmntDto, String partType,
			boolean exception) {
		/*logger.informationalEvent(this.getClass(),
				BatchConstants.MTD_SET_EPA_PART_TYPE,
				BatchConstants.EXE_SET_EPA_PART_TYPE);*/
		logger.info(this.getClass()+
				BatchConstants.MTD_SET_EPA_PART_TYPE+
				BatchConstants.EXE_SET_EPA_PART_TYPE);
		List<String> serialNumList = null;
		List<String> partsList = null;

		if (partType != null
				&& (partType.equalsIgnoreCase(BatchConstants.ENGINE_LITERAL) || partType
						.equalsIgnoreCase(BatchConstants.MACHINE_LITERAL))) {
			epaShpmntDto.setEpaProdTypeCode(partType);
			
			/*logger.informationalEvent(this.getClass(),
					BatchConstants.MTD_SET_EPA_PART_TYPE,
					BatchConstants.EXE_SET_EPA_PART_TYPE+":: PartType: "+partType+",ItmSeqNo: " +epaShpmntDto.getItmSeqNo()+
					",InvoiceNum: "+epaShpmntDto.getInvoiceNum()+ ", PartNum: "+epaShpmntDto.getPartNum());*/
			logger.info(this.getClass()+
					BatchConstants.MTD_SET_EPA_PART_TYPE+
					BatchConstants.EXE_SET_EPA_PART_TYPE+":: PartType: "+partType+",ItmSeqNo: " +epaShpmntDto.getItmSeqNo()+
					",InvoiceNum: "+epaShpmntDto.getInvoiceNum()+ ", PartNum: "+epaShpmntDto.getPartNum());
			
			serialNumList = (List<String>) BatchContext.getValue(partType);
			if (epaShpmntDto.getProductSerialNum() != null) {
				serialNumList.add(epaShpmntDto.getProductSerialNum());
			}
			partsList = (List<String>) BatchContext.getValue(partType
					+ BatchConstants.PARTS_VAR);
			partsList.add(epaShpmntDto.getPartNum());

		} else if (exception) {
			/*logger.informationalEvent(this.getClass(),
					BatchConstants.MTD_SET_EPA_PART_TYPE,
					BatchConstants.EXC_SET_EPA_PART_TYPE);*/
			logger.info(this.getClass()+
					BatchConstants.MTD_SET_EPA_PART_TYPE+
					BatchConstants.EXC_SET_EPA_PART_TYPE);
			
		}

	}

	/**
	 * @param mchConfgr
	 * @return boolean value
	 * @throws ValidatorException
	 */
	public boolean isPartMachineNum(String mchConfgr) throws ValidatorException {
		/*logger.informationalEvent(this.getClass(),
				BatchConstants.MTD_IS_PART_MCH_NUM,
				BatchConstants.EXE_IS_PART_MCH_NUM);*/
		logger.info(this.getClass()+
				BatchConstants.MTD_IS_PART_MCH_NUM+
				BatchConstants.EXE_IS_PART_MCH_NUM);
		boolean isMachinePart = false;

		if (BatchConstants.MACHINE_LITERAL.equalsIgnoreCase(mchConfgr)) {
			isMachinePart = true;
		} else {
			List<String> errMsgLst = new ArrayList<String>();
			throw new ValidatorException(errMsgLst);
		}
		return isMachinePart;
	}
	
	public List<EpaEngine> getMchShpmnt(String mchNum){
		List<EpaShipment> epaShpmnts = null;
		EpaShipment epaShipment = null;
		List<EpaEngine> engines = new ArrayList<EpaEngine>();
		EpaEngine epaEng = null;
		
		try {
			epaShpmnts = epaShipmentDAO.getEpaShipmentbyMachOrEngNum(mchNum,null);
		} catch (DaoException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		for(EpaShipment epaShipment2 : epaShpmnts){
			epaEng = epaShipment2.getEpaEngines();
			engines.add(epaEng);
		}
		
		
		return engines;
	}
	

	/**
	 * This method is to create Machine Shipment details
	 * 
	 * @see com.cat.logistics.epa.job.service.IEPAService#crteMachShp(com.cat.logistics.epa.dto.EpaShipmentDTO,
	 *      com.cat.logistics.shared.dto.EngineDTO,
	 *      com.cat.logistics.shared.dto.MachineDTO)
	 */
	public void crteMachShp(EpaShipmentDTO engShpDTO,
			EngineDTO engDTO, MachineDTO machDTO) throws ServiceException {
		/*logger.informationalEvent(this.getClass(),
				BatchConstants.MTD_CRT_MCH_SHP,
				BatchConstants.CRET_MCH_INFO);*/
		logger.info(this.getClass()+
				BatchConstants.MTD_CRT_MCH_SHP+
				BatchConstants.CRET_MCH_INFO);
		mchCreateService.createMachineShipment(engShpDTO, engDTO, machDTO);

	}



	public String getEngLogs(EpaEngine epaEng) throws ServiceException {
		StringBuilder engShp = new StringBuilder();
		engShp.append(epaEng.getEngPk().getEngineSerialNum());
		engShp.append(BatchConstants.HYPHEN);
		engShp.append(epaEng.getEpaShipment().getEpaSeqNum());
		engShp.append(BatchConstants.HYPHEN);
		engShp.append(epaEng.getEpaShipment().getPartNum());
		engShp.append(BatchConstants.HYPHEN);
		engShp.append(epaEng.getEpaShipment().getInvoiceNum());
		engShp.append(BatchConstants.HYPHEN);
		engShp.append(epaEng.getEpaShipment().getOrderNum());
		
		return null;
	}
	
	/**
	 * (non-Javadoc)
	 * 
	 * @see com.cat.logistics.epa.job.service.IEPAService#readMailConfigData()
	 */
	@Override
	public void readMailConfigData() throws ServiceException {
		/*logger.informationalEvent(this.getClass(),
				BatchConstants.MTD_RD_MAIL_CNFG_DATA,
				BatchConstants.EXE_LITERAL
						+ BatchConstants.MTD_RD_MAIL_CNFG_DATA);*/
		logger.info(this.getClass()+
				BatchConstants.MTD_RD_MAIL_CNFG_DATA+
				BatchConstants.EXE_LITERAL
						+ BatchConstants.MTD_RD_MAIL_CNFG_DATA);
		EpaConfig epaConfig;
		MailDTO mailDto = new MailDTO();
		String emailFrom;
		String emailTo;
		try {
			epaConfig = epaConfigDAO.getSupportMails();
		} catch (DaoException e) {
			/*logger.fatalEvent(getClass(), BatchConstants.MTD_RD_MAIL_CNFG_DATA,
					BatchConstants.MAIL_CNFG_CUD_NT_FETCH_FRM_EPA, e);*/
			logger.info(this.getClass()+
					BatchConstants.MTD_RD_MAIL_CNFG_DATA+
					BatchConstants.EXE_LITERAL
							+ BatchConstants.MTD_RD_MAIL_CNFG_DATA);
			throw new ServiceException();
		}
		if (epaConfig != null) {
			emailFrom = epaConfig.getId().getValueType1();
			emailTo = epaConfig.getValueType2();
			mailDto.setMailFrom(emailFrom);
			mailDto.setMailTo(emailTo);
		}

		BatchContext.put(BatchConstants.MAIL_DTO, mailDto);

	}

	/**
	 * (non-Javadoc)
	 * 
	 * @see com.cat.logistics.epa.job.service.IEPAService#logEndTime()
	 */
	@Override
	public void logEndTime(String jobName) throws ServiceException {
		try {
			epaConfigDAO.logEndTime(startTime,jobName);
		} catch (DaoException e) {
			/*logger.fatalEvent(getClass(), BatchConstants.MTD_LOG_END_TM,
					BatchConstants.LOG_ENG_TM_FAIL, e);*/
			logger.info(getClass()+ BatchConstants.MTD_LOG_END_TM+
					BatchConstants.LOG_ENG_TM_FAIL+ e.getMessage());
			throw new ServiceException(e);
		}
	}

	/**
	 * (non-Javadoc)
	 * 
	 * @see com.cat.logistics.epa.job.service.IEPAService#logStartTime()
	 */
	/*@Override
	public void logStartTime() throws ServiceException {

		try {
			startTime = getTimestamp();
			epaConfigDAO.logStartTime(startTime);
		} catch (DaoException e) {
			logger.fatalEvent(getClass(), BatchConstants.MTD_LOG_STRT_TM,
					BatchConstants.LOG_STRT_TM_FAIL, e);
			throw new ServiceException(e);
		}
	}*/

	/**
	 * @return String time stamp
	 */
	public String getTimestamp() {
		Calendar cal = Calendar.getInstance();
		java.sql.Timestamp timeStamp = new java.sql.Timestamp(cal
				.getTimeInMillis());
		return timeStamp.toString();
	}

	
	public void saveLstSccsTm(String jobName) throws ServiceException{
		
		try{
			EpaConfig epaConfig = new EpaConfig();
			EpaConfigPK configPk = new EpaConfigPK();
			configPk.setConfigType(jobName);
			configPk.setKeyType(PersistenceConstants.LST_SUCCS_TM);
			 epaConfig.setValueType2(startTime);
			configPk.setValueType1(PersistenceConstants.SUCCESS);
			epaConfig.setId(configPk);
			epaConfig.setKeyDesc(BatchConstants.YES_LITERAL);
			
			epaConfigDAO.saveLstSccsTm(epaConfig);
		}catch(DaoException daoEx){
			/*logger.fatalEvent(getClass(), BatchConstants.MTD_SAVE_SUCCS_TM,
					BatchConstants.LOG_SAV_SUCCS_TM, daoEx);*/
			logger.info(getClass()+ BatchConstants.MTD_SAVE_SUCCS_TM+
					BatchConstants.LOG_SAV_SUCCS_TM+ daoEx.getMessage());
			throw new ServiceException(daoEx);
		}
		
	}

	/**
	 * 
	 * @param crteloginId
	 * @param cretDate
	 * @return
	 */
	public RcrdUpdtLog getRcdUpLg(String crteloginId, Date cretDate) {
		RcrdUpdtLog updtLog = Utils.getRcrdLg(BatchConstants.EPA_SOURCE_SYSTEM,
				new java.util.Date(), null, null);
		return updtLog;
	}

	/**
	 * This method is used to prepare the EPA Shipment object with facility
	 * validations
	 * 
	 * @param epaShpmntDto
	 *            epa shipment object
	 * @throws ServiceException
	 *             Service Exception
	 */
	private void prepareEPAShipmentDTO(EpaShipmentDTO epaShpmntDto)
			throws ServiceException {

		if (Utils.checkForNullAndNoLength(epaShpmntDto.getOrigFacCd())
				&& Utils.checkForNullAndNoLength(epaShpmntDto.getSuppCd())) {

			setOrigFac(epaShpmntDto);
		} else if (Utils.checkForNullAndNoLength(epaShpmntDto.getOrigFacCd())
				&& !Utils.checkForNullAndNoLength(epaShpmntDto.getSuppCd())) {
			try {
				EpaFac fac = epaFacilityDAO.getFacBySuppCd(epaShpmntDto
						.getSuppCd());

				if (fac == null) {
					setOrigFac(epaShpmntDto);
					return;
				}
				epaShpmntDto.setOrigFacCd(fac.getFacCd());
				//epaShpmntDto.setMachineManufactureName(getMachMfrName(fac));
			} catch (DaoException e) {
				/*logger.fatalEvent(this.getClass(),
						BatchConstants.MTD_FAC_VALIDATIONS,
						BatchConstants.FAILED_TO_READ_FAC_BY_SUPPID, e);*/
				logger.error(this.getClass()+
						BatchConstants.MTD_FAC_VALIDATIONS+
						BatchConstants.FAILED_TO_READ_FAC_BY_SUPPID+ e.getMessage());
				throw new ServiceException(e);

			}
		}

	}

	/**
	 * 
	 */
	@Override
	public void createEngineShipment(EpaShipmentDTO engineShpmntDTO,
			EngineDTO engineDTO) throws ServiceException {
		engineCreateService.createEngineShipment(engineShpmntDTO, engineDTO);
		
	}


	@Override
	public void logStartTime(String jobName) throws ServiceException {
		try {
			startTime = getTimestamp();
			epaConfigDAO.logStartTime(startTime,jobName);
		} catch (DaoException e) {
			/*logger.fatalEvent(getClass(), BatchConstants.MTD_LOG_STRT_TM,
					BatchConstants.LOG_STRT_TM_FAIL, e);*/
			logger.error(getClass()+ BatchConstants.MTD_LOG_STRT_TM+
					BatchConstants.LOG_STRT_TM_FAIL+ e.getMessage());
			throw new ServiceException(e);
		}
	}
	
	
	 /**
	  * This method return engine list by using engine status code
		 * @param epaStatCd
		 * @return
		 * @throws DaoException
		 */
	@Override
	public List<EpaShipment> getEngineByStatus(String epaStatCd)
			throws ServiceException {
		List<EpaShipment> epaShipments = null;
		List<String> statusCdList = new ArrayList<String>();
		statusCdList.add(epaStatCd);
		
		int freq = 0;
		
		try {
			freq = epaConfigDAO.getEpaDataRefFreq("EPA_DATA_REFR_JOB");
		} catch (DaoException e) {
			throw new ServiceException("FREQENCEY NOT FETCHED");
		}
		
		
		try {
			epaShipments = epaShipmentDAO.getShipmentListByStatusList(statusCdList,freq);
		} catch (Exception e) {
			/*logger.fatalEvent(getClass(), BatchConstants.MTD_ENG_STATUS,
					BatchConstants.LOG_ENG_STATUS_FAIL, e);*/
			logger.error(getClass() + BatchConstants.MTD_ENG_STATUS+
					BatchConstants.LOG_ENG_STATUS_FAIL+ e.getMessage());
			throw new ServiceException(e);
		}
		
		
		return epaShipments;
	}
	
	/**
	 * this method updates existing engine details
	 * @param exisEpaEngine
	 * @param updatedEpaEng
	 * @throws ServiceException
	 */
	@Override
	public void updateExisEngine(EpaEngine exisEpaEngine,EngineDTO updatedEpaEngDto) throws ServiceException {
		engineCreateService.updateExisEngine(exisEpaEngine, updatedEpaEngDto);
		
	}

}
