package com.cat.logistics.epa.service;

import java.util.Locale;
import java.util.Set;

import com.cat.logistics.shared.dto.MachineDTO;
import com.cat.logistics.shared.exception.ServiceException;



/**
 * Interface of EPA Machine service
 * 
 * @author singhr9
 *
 */

public interface IEpaMachineFormService {

	/**
	 * @param machineSerialNum
	 * @param partType
	 * @param epaSeq
	 * @param locale
	 * @return the machine dto
	 * @throws ServiceException
	 */
	public MachineDTO checkEpaSerialNum(String machineSerialNum,String oldSerilNum, String partType,String epaSeq, Locale locale) throws ServiceException;
	
	/**
	 * @param machineDto
	 * @param locale
	 * @throws ServiceException
	 */
	public void getEngineInfo(MachineDTO machineDto, Locale locale) throws ServiceException;


	/**
	 * @param machineSerialNum
	 * @return Machine DTO
	 * @throws ServiceException
	 */
	public MachineDTO getOdsMachineInfo(String machineSerialNum) throws ServiceException;


	/**
	 * @param engineSerialNumber
	 * @param seqNum
	 * @return the message
	 * @throws ServiceException
	 */
	public String getNonEpaEngineNumbers(Set<String> engineSerialNumber,String mchSerilNum, String seqNum) throws ServiceException;

	/**
	 * @param machineDTO
	 * @param locale
	 * @return Machine DTO
	 * @throws Exception
	 */
	MachineDTO fetchOdsMachineDetl(MachineDTO machineDTO, Locale locale) throws Exception;

	/**
	 * @param mchView
	 * @param locale
	 * @return boolean value
	 * @throws ServiceException
	 */
	public boolean saveSubmitApproveNewForm(MachineDTO mchView, Locale locale) throws ServiceException;

	/**
	 * @param epaSeqNum
	 * @return Machine dto
	 * @throws ServiceException
	 */
	public MachineDTO getShipmentInfo(String epaSeqNum) throws ServiceException;

	/**
	 * @param mchView
	 * @param locale
	 * @return boolean value
	 * @throws ServiceException
	 */
	public boolean saveSubmitApproveExistingMachineForm(MachineDTO mchView,
			Locale locale) throws ServiceException;

	/**
	 * @param facCd
	 * @return Manufacturer name
	 * @throws ServiceException
	 */
	String getManufacturerNameByFacility(String facCd) throws ServiceException;

	/**
	 * @param action
	 * @param setStatus
	 * @param locale
	 * @return status of the form
	 */
	String getStatusOrMsgByAction(String action, boolean setStatus,
			Locale locale);

}
