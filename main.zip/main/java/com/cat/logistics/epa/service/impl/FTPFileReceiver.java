/**
 * Copyright (c) Caterpillar Inc. All Rights Reserved.
 * This work contains Caterpillar Inc.'s unpublished proprietary information
 * which may constitute a trade secret and/or be confidential. This work 
 * may be used only for the purposes for which it was provided, and may 
 * not be copied or disclosed to others. Copyright notice is precautionary 
 * only, and does not imply publication.
 *
 * IPaymentAllocationProcess.java
 * Class Description  : 
 * Revision History
 *//*
package com.cat.logistics.epa.service.impl;

import java.util.Arrays;

import org.apache.commons.net.ftp.FTPFile;
import org.apache.commons.net.ftp.FTPFileFilter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cat.logistics.epa.job.dto.ECCNFileDetails;
import com.cat.logistics.epa.job.service.IFTPFileReceiver;
import com.cat.logistics.epa.job.service.IFileFilterFactory;
import com.cat.logistics.epa.job.utils.ApplicationException;
import com.cat.logistics.epa.job.utils.BatchConstants;
import com.cat.logistics.epa.job.utils.FTPHandler;
import com.cat.logistics.epa.job.utils.ILogger;
import com.cat.logistics.epa.job.utils.Logger;
import com.cat.logistics.epa.job.utils.Utils;
import com.cat.logistics.epa.mail.IEmailSender;


*//**
 * This class is used to receive the files( monthly & daily statements)
 *  from Sterling Integrator via FTP process
 *//*
@Component
public class FTPFileReceiver implements IFTPFileReceiver{
	private ILogger logger = Logger.getInstance();
	@Autowired
	private IFileFilterFactory flFltrFctr;
	@Autowired
	private FTPHandler ftpHndlrMbAch;
	@Autowired
	private IEmailSender mailSender;
	
	
	This method copies the statement files from the SI to temporary folder
	 * @see com.cat.ach.helper.IFileReader#recvStmnt(com.cat.ach.dto.AchFileDetails)
	 
	@Override
	public boolean recvStmnt(ECCNFileDetails eccnFlDtls, boolean jobSuccess)
			throws Exception {
		logger.informationalEvent(this.getClass(),BatchConstants.MTD_RCV_STMT, BatchConstants.METHOD_ENTRY);
		FTPFileFilter ftpFlFilter = null; 
		String fileGroupType = null;
		try {
			fileGroupType = eccnFlDtls.getFileGrpType();		
			Logger.getInstance().informationalEvent(this.getClass(), "recvStmnt", "this is the fileGroupType " + fileGroupType);
			Logger.getInstance().informationalEvent(this.getClass(), "recvStmnt", "we have changed the ftpHndlrMbAch");
			ftpFlFilter = (FTPFileFilter) flFltrFctr.getStmntTypeObject(fileGroupType);
			Logger.getInstance().informationalEvent(this.getClass(), "recvStmnt", "this is the ftpFileFilter " + ftpFlFilter);
			ftpHndlrMbAch.connectToFtpServer(eccnFlDtls.getFileType());
			FTPFile[] files = ftpHndlrMbAch.getFileListFrmFtpSrc(ftpFlFilter, eccnFlDtls.getFileType(), eccnFlDtls.getSrcDirctry());	
			if(null != files && files.length>BatchConstants.INT_0){
				for(FTPFile file: files){
					if(null != file && file.isFile()){
						eccnFlDtls.setFileName(file.getName());
						ftpHndlrMbAch.copyFlsFrmFtpToTempFldr(file.getName(),fileGroupType,eccnFlDtls.getFileType());						
           		 	}
				}	
				jobSuccess = true;
			}else{
				
				logger.informationalEvent(this.getClass(),BatchConstants.MTD_RCV_STMT, "Number of files - "+files.length);
				
			}
		} catch (Exception exc) {
			exc.printStackTrace();
			logger.fatalEvent(this.getClass(), BatchConstants.MTD_RCV_STMT, exc.getMessage(), exc);
			jobSuccess = false;
			mailSender.sendEmail(BatchConstants.ECCN_TECH_EXCEPTION);
		}
	logger.informationalEvent(this.getClass(), BatchConstants.MTD_RCV_STMT,BatchConstants.METHOD_EXIT);
	return jobSuccess;
	}
	
	
}
*/