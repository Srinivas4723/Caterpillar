package com.cat.logistics.epa.service.impl;

import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;

import com.cat.logistics.epa.dao.IEpaConfigDAO;
import com.cat.logistics.epa.dao.IEpaImportTypeDAO;
import com.cat.logistics.epa.dao.IEpaProvisionTypeDAO;
import com.cat.logistics.epa.dao.IEpaUserDAO;
import com.cat.logistics.epa.entities.EpaConfig;
import com.cat.logistics.epa.entities.EpaEngine;
import com.cat.logistics.epa.entities.EpaFac;
import com.cat.logistics.epa.entities.EpaMachine;
import com.cat.logistics.epa.entities.EpaShipment;
import com.cat.logistics.epa.entities.EpaUser;
import com.cat.logistics.epa.helper.ServiceUtilHelper;
import com.cat.logistics.epa.job.utils.BatchConstants;
import com.cat.logistics.epa.service.IEngineDataBusiness;
import com.cat.logistics.epa.service.IMachineDataConverter;
import com.cat.logistics.shared.dto.EngineDTO;
import com.cat.logistics.shared.dto.MachineDTO;
import com.cat.logistics.shared.exception.DaoException;
import com.cat.logistics.shared.exception.ServiceException;
import com.cat.logistics.shared.service.IAutoCompleteService;
import com.cat.logistics.shared.utils.MasterData;
import com.cat.logistics.shared.utils.MessageConstants;
import com.cat.logistics.shared.utils.PersistenceConstants;
import com.cat.logistics.shared.utils.ServiceConstants;
import com.cat.logistics.shared.utils.ServiceUtils;

/**
 * This class is to check import and provision code combination is valid or not
 * @author ganamr
 *
 */
public class EngineDataBusiness implements IEngineDataBusiness {
	
	@Autowired
	private IEpaConfigDAO epaConfigDAO;
	
	public static final Logger LOGGER = LogManager.getLogger(EngineDataBusiness.class);
	
	@Autowired
	private IEpaProvisionTypeDAO epaProvisionDAO;
	
	@Autowired
	private IEpaImportTypeDAO epaImportDAO;
	
	@Autowired
	private IMachineDataConverter machineDataConverter;
	
	@Autowired
	private IAutoCompleteService autoCompleteService;
	
	@Autowired
	private ServiceUtilHelper serHelper;
	
	@Autowired  
	private MessageSource messageSource;
	
	@Autowired
	private IEpaUserDAO epaUserDAO;
	
	/**
	 * This method checks if given import and provision code combination is valid or not
	 * @param importCode
	 * @param provisionCode
	 * @return boolean value true or false
	 * @throws ServiceException
	 */
	@Override
	public boolean isImportProvisionCodeValid(String importCode, String provisionCode)  throws ServiceException{
		LOGGER.info("Entry method of isImportProvisionCodeValid {}", ServiceConstants.METHOD_ENTRY);
		boolean isValid = true;
		try{
			Map<String,Set<String>> impProvConfig = MasterData.getConfigMap().get(ServiceConstants.IMPORT_PROV_COMB);
			if(null ==impProvConfig || impProvConfig.size()==0){
				List<EpaConfig> epaImpProvConfig = epaConfigDAO.getEpaConfig(ServiceConstants.IMPORT_PROV_COMB);
				impProvConfig = machineDataConverter.convertEpaConfigToMap(epaImpProvConfig);
			}
			
			if(null != impProvConfig.get(importCode) && impProvConfig.get(importCode).contains(provisionCode)){
				isValid = false;
			}
			LOGGER.info("Exit method of isImportProvisionCodeValid {}", ServiceConstants.METHOD_EXIT);
		}catch(DaoException daoExc){
			LOGGER.error("Error in isImportProvisionCodeValid {}", daoExc.getMessage(), daoExc);
			throw new ServiceException(daoExc);
		}
			
		return isValid;
	}

		/**
		 * @param engineDto
		 * @throws ServiceException
		 */
		@Override
		public void getCodeDescription(EngineDTO engineDto)  throws ServiceException{
			LOGGER.info("Entry method of getCodeDescription {}", ServiceConstants.METHOD_ENTRY);
		try{
			if(!ServiceUtils.isNullOrEmpty(engineDto.getEngineProvisionTypeCode())){
				String provDesc = epaProvisionDAO.getImportProvisionDesc(engineDto.getEngineProvisionTypeCode());
				if(!ServiceUtils.isNullOrEmpty(provDesc)){
					engineDto.setEngineProvisionTypeCode(engineDto.getEngineProvisionTypeCode()+ServiceConstants.DOT +provDesc);
				}							
			}
			if(!ServiceUtils.isNullOrEmpty(engineDto.getEngineImportTypeCode())){
				String importDesc = epaImportDAO.getImportDesc(engineDto.getEngineImportTypeCode());
				if(!ServiceUtils.isNullOrEmpty(importDesc)){
					engineDto.setEngineImportTypeCode(engineDto.getEngineImportTypeCode()+ServiceConstants.DOT +importDesc);	
				}
			}
			LOGGER.info("Exit method of getCodeDescription {}", ServiceConstants.METHOD_EXIT);
		}catch(DaoException daoExc){
			LOGGER.error("Error in getCodeDescription {}", daoExc.getMessage(), daoExc);
			throw new ServiceException(daoExc);
		}	
	
	}
		
		/**
		 * Checks the access for the given facility code
		 * @param epaFac epaFac
		 * @return true or false
		 */
		public boolean isValidAccessFac(EpaFac epaFac) {
			LOGGER.info("Entry method of isValidAccessFac {}", ServiceConstants.METHOD_ENTRY);
			boolean isValid=false;
			String facility= ServiceConstants.EMPTY;
			String userId= serHelper.getLogOnId();
			if(null!=epaFac && null!=epaFac.getFacCd() ){
			 facility= epaFac.getFacCd() + ServiceConstants.HIPHEN + epaFac.getFacilityName();
			}
			List<String> usrFacList = autoCompleteService.getfacilitiesForUser(userId);
			if(serHelper.isPrdGrpAdm()){
				isValid = true;
			}
			if(usrFacList.contains(facility) ){
				isValid = true;
			}
			LOGGER.info("Exit method of isValidAccessFac {}", ServiceConstants.METHOD_EXIT);
			return isValid;
		}
	
		/**
		 * This method concatenates the facility code and facility name
		 * @param facility facility 
		 * @return facility detail
		 */
		public String getFacilityDetails(EpaFac facility){
			LOGGER.info("Entry method of getFacilityDetails {}", ServiceConstants.METHOD_ENTRY);
			String facilityDetail = ServiceConstants.EMPTY;
			if(null != facility){
				facilityDetail = facility.getFacCd() + ServiceConstants.HIPHEN + facility.getFacilityName();
			}
			LOGGER.info("Exit method of getFacilityDetails {}", ServiceConstants.METHOD_EXIT);
			return facilityDetail;
		}
	
		/**
		 * fetches form status from engine 
		 * @param epaEngine engine details
		 * @return form status
		 */
		public String getFormStatus(EpaEngine epaEngine) {
			LOGGER.info("Entry method of getFormStatus {}", ServiceConstants.METHOD_ENTRY);
			String formStatus=null;
			if(null != epaEngine && null != epaEngine.getEpaStatus()){
				 formStatus= epaEngine.getEpaStatus().getEpaStatusDesc();
			}
			LOGGER.info("Exit method of getFormStatus {}", ServiceConstants.METHOD_EXIT);
			return formStatus;
		}
	
		/**
		 * Checks the form status is submitted to the broker or not
		 * @param epaEngine engine details
		 * @return true or false
		 */
		public boolean isFrmSubmittedToBroker(EpaEngine epaEngine) {
			LOGGER.info("Entry method of isFrmSubmittedToBroker {}", ServiceConstants.METHOD_ENTRY);
			boolean isSubmittd=false;
			if (null != epaEngine && null != epaEngine.getEpaStatus()
					&& ServiceConstants.STB.equalsIgnoreCase(epaEngine.getEpaStatus()
							.getEpaStatusCd())) {
				isSubmittd = true;
			}
			LOGGER.info("Exit method of isFrmSubmittedToBroker {}", ServiceConstants.METHOD_EXIT);
			return isSubmittd;
		}
	
		/**
		 * Checks the form status is Completed or not
		 * @param epaEngine holds engine details
		 * @return true if form status is CMP
		 */
		public boolean isFrmCompleated(EpaEngine epaEngine) {
			LOGGER.info("Entry method of isFrmCompleated {}", ServiceConstants.METHOD_ENTRY);
			boolean isCMP=false;
			if (null != epaEngine && null != epaEngine.getEpaStatus()
					&& ServiceConstants.CMP.equalsIgnoreCase(epaEngine.getEpaStatus()
							.getEpaStatusCd())) {
				isCMP = true;
			}
			LOGGER.info("Exit method of isFrmCompleated {}", ServiceConstants.METHOD_EXIT);
			return isCMP;
		}
	
		/**
		 * fetches the form submitted date for the given engine object
		 * @param epaEngine holds engine details
		 * @return Form submitted date
		 */
		public String getSubmtdDate(EpaEngine epaEngine) {
			LOGGER.info("Entry method of getSubmtdDate {}", ServiceConstants.METHOD_ENTRY);
			String submtdDate= ServiceConstants.EMPTY;
			if(null != epaEngine && null != epaEngine.getRcdLog() 
					&&  null !=epaEngine.getRcdLog().getLastUpdtTs()){
				Date date= epaEngine.getRcdLog().getLastUpdtTs();
				 submtdDate=ServiceUtils.convertDateToString(date, ServiceConstants.DD_MMM_YYYY).toUpperCase();
			}
			LOGGER.info("Exit method of getSubmtdDate {}", ServiceConstants.METHOD_EXIT);
			return submtdDate;
		}
	
		/**
		 * fetches the form approved date for the given engine object
		 * @param epaEngine holds engine details
		 * @return form approved date
		 */
		public String getCMPFrmDate(EpaEngine epaEngine) {
			LOGGER.info("Entry method of getCMPFrmDate {}", ServiceConstants.METHOD_ENTRY);
			String cmpDate= ServiceConstants.EMPTY;
			if(null != epaEngine &&  null != epaEngine.getCertDate() ){
				Date date= epaEngine.getCertDate();
				cmpDate=ServiceUtils.convertDateToString(date, ServiceConstants.DD_MMM_YYYY).toUpperCase();
			}
			LOGGER.info("Exit method of getCMPFrmDate {}", ServiceConstants.METHOD_EXIT);
			return cmpDate;
		}
	
		/**
		 * fetches the invoice number from shipment table
		 * @param epaShipment shipment details
		 * @return invoice number
		 */
		public String getInvoiceNum(EpaShipment epaShipment) {
			LOGGER.info("Entry method of getInvoiceNum {}", ServiceConstants.METHOD_ENTRY);
			String invoiceNo=ServiceConstants.EMPTY;
			if(null !=epaShipment && null != epaShipment.getInvoiceNum()){
				invoiceNo= epaShipment.getInvoiceNum();
			}
			LOGGER.info("Exit method of getInvoiceNum {}", ServiceConstants.METHOD_EXIT);
			return invoiceNo;
		}
		/**
		 * It populates the Error messages for engine 
		  * @param epaShpm epaShpm
		  * @param objType engine or machine
		  * @param partType part type
		  * @param locale locale
		 */
		@Override
		public void populateSerilErrMsg(EpaShipment epaShpm,Object objType,
				String partType, Locale locale,String serialNum) {
			LOGGER.info("Entry method of populateSerilErrMsg {}", ServiceConstants.METHOD_ENTRY);
			String	errMsg=null;
			String errPopMsg=null;
			boolean check=false;
			EpaFac fac=epaShpm.getEpaFac();
			EpaEngine epaEngine= epaShpm.getEpaEngines();
			EpaMachine epaMachine=epaShpm.getEpaMachines();
			
			errMsg = getErrMsgFrEngOrMch(partType, epaShpm, locale, fac,serialNum);
			if(null == errMsg && isFrmSubmittedToBroker(epaEngine)){
				errPopMsg=messageSource.getMessage(MessageConstants.LOGISTICS_ERROR_SUBMTD_TO_BRKR,null,locale).replace(ServiceConstants.FAC_DET,getFacilityDetails(fac));
				errPopMsg = errPopMsg.replace(ServiceConstants.INV_NUM, getInvoiceNum(epaShpm));
				errPopMsg = errPopMsg.replace(ServiceConstants.SUBMTD_DATE, getSubmtdDate(epaEngine));
			}else if(null == errMsg && isFrmCompleated(epaEngine)){
				String apprvrName= getApproverDetails(epaEngine);
				errPopMsg=messageSource.getMessage(MessageConstants.LOGISTICS_ERROR_CMP_FRM,null,locale).replace(ServiceConstants.FAC_DET,getFacilityDetails(fac));
				errPopMsg=errPopMsg.replace(ServiceConstants.INV_NUM, getInvoiceNum(epaShpm));
				errPopMsg=errPopMsg.replace(ServiceConstants.APPRVE_NAME, apprvrName);
				errPopMsg=errPopMsg.replace(ServiceConstants.APPRVD_DATE, getCMPFrmDate(epaEngine));
			}
			//added 'or' condition for missing Engine serial number for machine record-addansn
			  else if(null == errMsg &&  (null != epaEngine || null !=epaMachine)){
				 check= true;
			}
			populteErrMsg(epaShpm,objType,check,errMsg,errPopMsg);
			LOGGER.info("Exit method of populateSerilErrMsg {}", ServiceConstants.METHOD_EXIT);
		}
		
		/**
		 * it populates appropriate object with error message
		 * @param epaShpm shipment object
		 * @param obj Type of the obj engine or machine
		 * @param check true or false
		 * @param errMsg error message
		 * @param errPopMsg error popUp message
		 */
		public void populteErrMsg(EpaShipment epaShpm, Object obj, boolean check, String errMsg, String errPopMsg){
			if(obj instanceof EngineDTO){
				if(check){
					populateEngine((EngineDTO) obj, epaShpm);
				}
				((EngineDTO)obj).setErrMessage(errMsg);
				((EngineDTO)obj).setErrPopupMsg(errPopMsg);
			}
			if(obj instanceof MachineDTO){
				EngineDTO mchEngine= new EngineDTO();
				if(check){
					populateEngine(mchEngine, epaShpm);
				}
				mchEngine.setErrMessage(errMsg);
				mchEngine.setErrPopupMsg(errPopMsg);
				((MachineDTO)obj).setMchEngine(mchEngine);
			}
		}
		/**
		 * populates the engine update redirect attribute
		 * @param engDto engine dto
		 * @param epaShpm epa shipment
		 */
		public void populateEngine(EngineDTO engDto, EpaShipment epaShpm){
			engDto.setIsUpdRedirct(ServiceConstants.YES);
			engDto.setEpaSeqNum(epaShpm.getEpaSeqNum());
		}
	/**
	 * validates entered serial number engine or machine
	 * @param partType partType
	 * @param epaShpm epaShpm
	 * @param locale locale
	 * @param fac 
	 * @param serialNum 
	 * @return error message
	 */
	private String getErrMsgFrEngOrMch(String partType, EpaShipment epaShpm,Locale locale, EpaFac fac, String serialNum){ 
		String errMsg=null;
		String formStatus= getFormStatus(epaShpm.getEpaEngines());
		if(ServiceConstants.STRING_M.equalsIgnoreCase(partType) && ServiceConstants.STRING_E.equalsIgnoreCase(epaShpm.getEpaProdTypeCode())){
			errMsg = messageSource.getMessage(MessageConstants.LOGISTICS_ERROR_ISENGINE,null,locale);
		}else if(ServiceConstants.STRING_E.equalsIgnoreCase(partType) && ServiceConstants.STRING_M.equalsIgnoreCase(epaShpm.getEpaProdTypeCode())){
			if(serialNum.equalsIgnoreCase(epaShpm.getEngineSerialNum())){
				errMsg = messageSource.getMessage(MessageConstants.LOGISTICS_ERROR_ENGASMCH,null,locale).replace(ServiceConstants.FAC_DET,getFacilityDetails(fac));
				errMsg= errMsg.replace(ServiceConstants.MCH_SER, epaShpm.getMachineSerialNum());
			}else{
			errMsg = messageSource.getMessage(MessageConstants.LOGISTICS_ERROR_ISMACHINE,null,locale);
			}
		}else if( !isValidAccessFac(fac)){
			errMsg=messageSource.getMessage(MessageConstants.LOGISTICS_ERROR_NO_ACCESS,null,locale).replace(ServiceConstants.FAC_DET,getFacilityDetails(fac));
			errMsg = errMsg.replace(ServiceConstants.FRM_STATUS, formStatus);
		}
		return errMsg;
	}
	
	/**
	 * fetches user details for the given cws id
	 * @param epaEngine
	 * @return approverName
	 */
	private String getApproverDetails(EpaEngine epaEngine) {
		String approvrName=ServiceConstants.EMPTY;
		if(null != epaEngine && null != epaEngine.getCertIndividualSign()){
			EpaUser epaUser= epaUserDAO.getEpaUserByUserName(epaEngine.getCertIndividualSign());
			approvrName= epaUser.getFirstName() +ServiceConstants.EMPTY_SPACE +epaUser.getLastName();
		}
		return approvrName;
	}

}
