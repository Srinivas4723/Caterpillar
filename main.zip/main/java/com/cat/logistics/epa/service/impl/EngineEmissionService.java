package com.cat.logistics.epa.service.impl;

import java.lang.reflect.Field;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.codec.binary.Base64;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.cat.googletink.util.EncryptAndDecryptApplication;

import com.cat.logistics.epa.dto.Element;
import com.cat.logistics.epa.dto.EngineJson;
import com.cat.logistics.epa.dto.FieldName;
import com.cat.logistics.epa.service.IEngineEmissionService;
import com.cat.logistics.shared.dto.EngineDTO;
import com.cat.logistics.shared.exception.ServiceException;
import com.cat.logistics.shared.utils.ServiceConstants;
import com.cat.logistics.shared.utils.ServiceUtils;




/**
 * This class is to fetch Engine information from Engine Emission Database for the given engine serial number
 * @author chanda15
 *
 */
public class EngineEmissionService implements IEngineEmissionService {

	@Autowired
	private RestTemplate engineEmissionClient;

	@Autowired
	private HttpHeaders httpHeaders;

	private String userName;

	private String password;

	private String url;
	
	//private ILogger logger = Logger.getInstance();

	private final static Logger logger = LogManager.getLogger(EngineEmissionService.class);
	
	/**
	 * fetches the engine information for the given list of serial numbers
	 * @param serialNums
	 * @return map key as serialNum and value engine data
	 * @throws ServiceException
	 */
	public Map<String,EngineDTO> getEngineInfo(List<String> serialNums) throws ServiceException{
		//logger.informationalEvent(EngineEmissionService.class, "getEngineInfo",ServiceConstants.METHOD_ENTRY);
		logger.info(EngineEmissionService.class+ "getEngineInfo"+ServiceConstants.METHOD_ENTRY);
		Map<String,EngineDTO> engines = null;
		try {
			
			StringBuilder serialNumVals = getSerialNumber(serialNums);
			createHeaders();
			HttpEntity<String> request = new HttpEntity<String>(httpHeaders);
			
			//url = ServiceUtils.getProperty(ServiceUtils.getCurrentEnvironment()+ServiceConstants.ENG_EMSS_URL);
			
			//logger.informationalEvent(this.getClass(), "getEngineInfo", serialNumVals.toString() + " URLS "+url);
			logger.info(this.getClass()+ "getEngineInfo"+ serialNumVals.toString() + " URLS "+url);
			System.out.println("EMS url : "+url);
			ResponseEntity<EngineJson> response = engineEmissionClient.exchange(url + serialNumVals, HttpMethod.GET, request, EngineJson.class);
			System.out.println("response from ems");
			EngineJson result = response.getBody();
			if(null != result && result.getElements() != null && result.getElements().length > 0){
				engines = createEngines(result);
			}			
			//logger.informationalEvent(EngineEmissionService.class, "getEngineInfo",ServiceConstants.METHOD_EXIT);
			logger.info(EngineEmissionService.class + "getEngineInfo"+ ServiceConstants.METHOD_EXIT);
		} catch (ServiceException ex) {
			System.out.println("error while hitting ems");
			//logger.fatalEvent(EngineEmissionService.class, "getEngineInfo", ex.getMessage(), ex);
			logger.error(EngineEmissionService.class+ "getEngineInfo"+ ex.getMessage());
			throw ex;
		}catch (Exception ex) {
			System.out.println("error while hitting ems");
			//logger.fatalEvent(EngineEmissionService.class, "getEngineInfo", ex.getMessage(), ex);
			logger.error(EngineEmissionService.class+ "getEngineInfo"+ ex.getMessage());
			//throw new ServiceException(ServiceConstants.ERROR_READING_ENGINE_INFO,ex);
		}
		return engines;
	}
	
	/**
	 * 
	 * @param serialNums
	 * @return list of serial numbers appended to string buffer
	 */
	private StringBuilder getSerialNumber(List<String> serialNums) {
		//logger.informationalEvent(EngineEmissionService.class, "getSerialNumber",ServiceConstants.METHOD_ENTRY);
		logger.info(EngineEmissionService.class + "getSerialNumber" +ServiceConstants.METHOD_ENTRY);
		StringBuilder serialNumVals = new StringBuilder();
		if(serialNums != null){
			serialNumVals.append(ServiceConstants.OPEN_BRACE);
			for (String serialNum : serialNums) {
				if(null != serialNum && !ServiceUtils.chkSpclChrs(serialNum)){
				serialNumVals.append(ServiceConstants.SINGLE_QUOTE);
				serialNumVals.append(serialNum.trim());
				serialNumVals.append(ServiceConstants.SINGLE_QUOTE);
				serialNumVals.append(ServiceConstants.COMMA);
			}}
			serialNumVals.append(ServiceConstants.CLOSED_BRACE);
		}
		if(serialNumVals.length()>2){
			serialNumVals.deleteCharAt(serialNumVals
					.lastIndexOf(ServiceConstants.COMMA));
		}
		if (ServiceConstants.OPEN_CLOSE_BRACE.equalsIgnoreCase(serialNumVals
				.toString())) {
			serialNumVals.replace(ServiceConstants.ZERO, ServiceConstants.TWO,
					ServiceConstants.OPEN_CLOSE_BRACE_WITH_QUOTES);
		}
		//logger.informationalEvent(EngineEmissionService.class, "getSerialNumber",ServiceConstants.METHOD_EXIT);
		logger.info(EngineEmissionService.class + "getSerialNumber" + ServiceConstants.METHOD_EXIT);
		return serialNumVals;
	}

	/**
	 * @param result
	 * @return Engine info DTO
	 * @throws ServiceException
	 */
	public Map<String,EngineDTO> createEngines(EngineJson result) throws ServiceException{
		//logger.informationalEvent(EngineEmissionService.class, "createEngines",ServiceConstants.METHOD_ENTRY);
		logger.info(EngineEmissionService.class + "createEngines" +ServiceConstants.METHOD_ENTRY);
		Map<String,EngineDTO> engineMap = new HashMap<String,EngineDTO>();
		EngineDTO engine = null;
		String serialNumber = null;
		String longSerNum = null;
		Map<String,String> dateMap = new HashMap<String,String>();
		try{
		Element[] elements  = result.getElements();
		String engineBuildMonth = null;
		String engineBuildYear = null;
		for(Element element : elements){
			engine = setEngineMap(engineMap,element);
			String fldId = element.getFld_id();
			setDateMap(fldId,engineBuildMonth,dateMap,element,engineBuildYear,engine);
			setEngineBuildDate(engine,engineBuildMonth,engineBuildYear,dateMap);
			setEngineDTO(fldId,engine,element);
			
			if(null == serialNumber){
			serialNumber = element.getEng_ser_no();
			}
			if("ENG_SER_NO".equals(element.getFld_id()) && null == engineMap.get(element.getFld_val())){
				longSerNum  = element.getFld_val();	
			}
			if( !serialNumber.equalsIgnoreCase(element.getEng_ser_no()) ){
				serialNumber = element.getEng_ser_no();
				longSerNum = null;
			}
			if(null != longSerNum){
				engineMap.put(longSerNum, engine);
			} 

		}//logger.informationalEvent(EngineEmissionService.class, "createEngines",ServiceConstants.METHOD_EXIT);
		logger.info(EngineEmissionService.class+ "createEngines"+ServiceConstants.METHOD_EXIT);
		}catch(Exception exception){
			//logger.fatalEvent(EngineEmissionService.class, "createEngines", exception.getMessage(), exception);
			logger.error(EngineEmissionService.class+ "createEngines"+ exception.getMessage(), exception);
			throw new ServiceException("",exception);
		}
		
		return engineMap;
	}
	
	/**
	 * 
	 * @param fldId
	 * @param engine
	 * @param element
	 * @throws IllegalArgumentException
	 * @throws IllegalAccessException
	 */
	private void setEngineDTO(String fldId,EngineDTO engine,Element element) throws IllegalArgumentException, IllegalAccessException {
		//logger.informationalEvent(EngineEmissionService.class, "setEngineDTO",ServiceConstants.METHOD_ENTRY);
		logger.info(EngineEmissionService.class+ "setEngineDTO" + ServiceConstants.METHOD_ENTRY);
		
		if(!ServiceConstants.ENG_EMSN_BLD_MNTH.equalsIgnoreCase(fldId) && !ServiceConstants.ENG_EMSN_BLD_MM.equalsIgnoreCase(fldId) && !ServiceConstants.ENG_EMSN_BLD_YR.equalsIgnoreCase(fldId)){
			Field[] engFields = EngineDTO.class.getDeclaredFields();
			Field[] shpFields = engine.getClass().getSuperclass().getDeclaredFields();
			Field[] fields = new Field[engFields.length+shpFields.length];
			System.arraycopy(engFields,0,fields,0,engFields.length);
			System.arraycopy(shpFields,0,fields,engFields.length,shpFields.length);
			for(Field field : fields){
				field.setAccessible(true);
				if(field.isAnnotationPresent(FieldName.class)){
				FieldName fieldName = field.getAnnotation(FieldName.class);
				if(fieldName.name().equals(fldId)){
					field.set(engine, element.getFld_val());
					break;
				}
				}
			}
		}
		//logger.informationalEvent(EngineEmissionService.class, "setEngineDTO",ServiceConstants.METHOD_EXIT);
		logger.info(EngineEmissionService.class+ "setEngineDTO"+ServiceConstants.METHOD_EXIT);
		
	}

	/**
	 * 
	 * @param engine
	 * @param engineBuildMonth
	 * @param engineBuildYear
	 * @param dateMap
	 * @throws ParseException
	 */
	private void setEngineBuildDate(EngineDTO engine, String engineBuildMonth,
			String engineBuildYear,Map<String, String> dateMap) throws ParseException {
		//logger.informationalEvent(EngineEmissionService.class, "setEngineBuildDate",ServiceConstants.METHOD_ENTRY);
		logger.info(EngineEmissionService.class+ "setEngineBuildDate"+ServiceConstants.METHOD_ENTRY);
		if(dateMap.get(engine.getEngineSerialNumber() + ServiceConstants.HIPHEN+ServiceConstants.YY) != null && dateMap.get(engine.getEngineSerialNumber() + ServiceConstants.HIPHEN+ServiceConstants.MM) != null){
			
			engineBuildMonth = dateMap.get(engine.getEngineSerialNumber() + ServiceConstants.HIPHEN+ServiceConstants.MM);
			engineBuildYear = dateMap.get(engine.getEngineSerialNumber() +ServiceConstants.HIPHEN+ServiceConstants.YY);
			String start_dt = ServiceUtils.concatenate(ServiceConstants.STRING_01,ServiceConstants.HIPHEN,engineBuildMonth,
					ServiceConstants.HIPHEN,engineBuildYear);
			
			if(isNumericString(engineBuildMonth)){
				engine.setEngineBuildDate(ServiceUtils.convertStringTodate(start_dt, ServiceConstants.DD_MM_YYYY));
			}else{
				engine.setEngineBuildDate(ServiceUtils.convertStringTodate(start_dt, ServiceConstants.DD_MMM_YYYY));
			}
		}
		//logger.informationalEvent(EngineEmissionService.class, "setEngineBuildDate",ServiceConstants.METHOD_EXIT);
		logger.info(EngineEmissionService.class+ "setEngineBuildDate"+ServiceConstants.METHOD_EXIT);
	}

	/**
	 * 
	 * @param fldId
	 * @param engineBuildMonth
	 * @param dateMap
	 * @param element
	 * @param engineBuildYear
	 * @param engine
	 */
	private void setDateMap(String fldId, String engineBuildMonth,
			Map<String, String> dateMap,Element element,String engineBuildYear,EngineDTO engine) {
		//logger.informationalEvent(EngineEmissionService.class, "setDateMap",ServiceConstants.METHOD_ENTRY);
		logger.info(EngineEmissionService.class+ "setDateMap"+ServiceConstants.METHOD_ENTRY);
		if(ServiceConstants.ENG_EMSN_BLD_MNTH.equalsIgnoreCase(fldId) ||
				ServiceConstants.ENG_EMSN_BLD_MM.equalsIgnoreCase(fldId)){
			engineBuildMonth = element.getFld_val();
			dateMap.put(engine.getEngineSerialNumber() + ServiceConstants.HIPHEN+ServiceConstants.MM, engineBuildMonth);
		}
		if(ServiceConstants.ENG_EMSN_BLD_YR.equalsIgnoreCase(fldId)){
			engineBuildYear = element.getFld_val();
			dateMap.put(engine.getEngineSerialNumber() + ServiceConstants.HIPHEN+ServiceConstants.YY, engineBuildYear);
		}
		//logger.informationalEvent(EngineEmissionService.class, "setDateMap",ServiceConstants.METHOD_EXIT);
		logger.info(EngineEmissionService.class + "setDateMap"+ServiceConstants.METHOD_EXIT);
	}

	/**
	 * 
	 * @param engineMap
	 * @param element
	 * @return Engine DTO
	 */
	private EngineDTO setEngineMap(Map<String,EngineDTO> engineMap,Element element) {
		//logger.informationalEvent(EngineEmissionService.class, "setEngineMap",ServiceConstants.METHOD_ENTRY);
		logger.info(EngineEmissionService.class + "setEngineMap" + ServiceConstants.METHOD_ENTRY);
		EngineDTO engine = null;
		if(engineMap.get(element.getEng_ser_no()) != null){
			 engine = (EngineDTO)engineMap.get(element.getEng_ser_no());
		}else{
			engine = new EngineDTO(element.getEng_ser_no());
			engineMap.put(element.getEng_ser_no(), engine);
		}
	//logger.informationalEvent(EngineEmissionService.class, "setEngineMap",ServiceConstants.METHOD_EXIT);
		logger.info(EngineEmissionService.class +  "setEngineMap" + ServiceConstants.METHOD_EXIT);
	return engine;
	}

	/**
	 * @param input
	 * @return boolean value as true or false for numeric check
	 */
	private  boolean isNumericString(String input) {
		boolean result = false;

	    if(input != null && input.length() > 0) {
	        char[] charArray = input.toCharArray();

	        for(char c : charArray) {
	            if(c >= '0' && c <= '9') {
	                // it is a digit
	                result = true;
	            } else {
	                result = false;
	                break;
	            }
	        }
	    }
	    return result;
	}

	/**
	 * @return the HttpHeaders
	 */
	public HttpHeaders createHeaders() {
		//logger.informationalEvent(EngineEmissionService.class, "createHeaders",ServiceConstants.METHOD_ENTRY);
		logger.info(EngineEmissionService.class+ "createHeaders"+ServiceConstants.METHOD_ENTRY);
		StringBuilder authorization = new StringBuilder();
		authorization.append(userName).append(ServiceConstants.COLON).append(password);

		byte[] encodedAuth = Base64.encodeBase64(authorization.toString().getBytes());

		String authHeader = ServiceConstants.BASIC + new String(encodedAuth);
		httpHeaders.add(ServiceConstants.AUTHORIZATION, authHeader);
		//logger.informationalEvent(EngineEmissionService.class, "createHeaders",ServiceConstants.METHOD_EXIT);
		logger.info(EngineEmissionService.class+ "createHeaders"+ServiceConstants.METHOD_EXIT);
		return httpHeaders;

	}

	/**
	 * @return the template
	 *//*
	public RestTemplate getTemplate() {
		return engineEmissionClient;
	}

	*//**
	 * @param template
	 *//*
	public void setTemplate(RestTemplate template) {
		this.engineEmissionClient = template;
	}*/

	/**
	 * @return the userName
	 */
	public String getUserName() {
		return userName;
	}

	/**
	 * @param userName
	 */
	public void setUserName(String userName) {
		this.userName = userName;
	}

	
	public String getPassword() {
		return password;
	}

	
	public void setPassword(String password) {
		this.password = EncryptAndDecryptApplication.decrypt(System.getProperty("tink.serverKeyset"),
				System.getProperty("tink.associateKeyset"), password);
	}

	/**
	 * @return the url
	 */
	public String getUrl() {
		return url;
	}

	/**
	 * @param url
	 */
	public void setUrl(String url) {
		this.url = url;
	}

}
