package com.cat.logistics.epa.service;

import java.util.Locale;

import com.cat.logistics.epa.entities.EpaShipment;
import com.cat.logistics.shared.dto.EngineDTO;
import com.cat.logistics.shared.exception.ServiceException;

/**
 * Interface for EngineDataBusiness
 * @author ganamr
 *
 */
public interface IEngineDataBusiness {

	/**
	 * @param importCode
	 * @param provisionCode
	 * @return true or false
	 * @throws ServiceException
	 */
	public boolean isImportProvisionCodeValid(String importCode, String provisionCode)
			throws ServiceException;

	/**
	 * @param epaShpm
	 * @param objType
	 * @param partType
	 * @param locale
	 */
	public void populateSerilErrMsg(EpaShipment epaShpm, Object objType,
			String partType, Locale locale, String serialNum);

	/**
	 * @param engineDto
	 * @throws ServiceException
	 */
	public void getCodeDescription(EngineDTO engineDto) throws ServiceException;

}
