package com.cat.logistics.epa.service.impl;

import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import com.cat.logistics.epa.dao.IEpaShipmentDAO;
import com.cat.logistics.epa.entities.EpaConfig;
import com.cat.logistics.epa.entities.EpaEngine;
import com.cat.logistics.epa.entities.EpaEnginePK;
import com.cat.logistics.epa.entities.EpaFac;
import com.cat.logistics.epa.entities.EpaImportType;
import com.cat.logistics.epa.entities.EpaMachine;
import com.cat.logistics.epa.entities.EpaMachinePK;
import com.cat.logistics.epa.entities.EpaProvisionType;
import com.cat.logistics.epa.entities.EpaShipment;
import com.cat.logistics.epa.entities.EpaStatus;
import com.cat.logistics.epa.entities.RcrdUpdtLog;
import com.cat.logistics.epa.service.IMachineDataConverter;
import com.cat.logistics.shared.dto.EngineDTO;
import com.cat.logistics.shared.dto.MachineDTO;
import com.cat.logistics.shared.exception.DaoException;
import com.cat.logistics.shared.utils.PersistenceConstants;
import com.cat.logistics.shared.utils.ServiceConstants;
import com.cat.logistics.shared.utils.ServiceUtils;

/**
 * This class is to convert Entity to DTO and DTO to Entity for machine related
 * 
 * @author singh9
 * 
 */
public class MachineDataConverterEpaImpl implements IMachineDataConverter {

	public static final Logger LOGGER = LogManager.getLogger(MachineDataConverterEpaImpl.class);
	
	@Autowired
	private IEpaShipmentDAO epaShipmentDao;

	/**
	 * converts Shipment to Machine DTO
	 * 
	 * @param epaMchShpmt
	 * @return Machine DTO
	 */
	public MachineDTO convertEpaShipmentLstToMachineDTO(
			List<EpaShipment> epaMchShpmt) {
		LOGGER.info("Entry method of convertEpaShipmentLstToMachineDTO {}",
				ServiceConstants.METHOD_ENTRY);
		MachineDTO mchDto = new MachineDTO(new EngineDTO());
		StringBuffer engNum = new StringBuffer();
		EpaShipment epaShp = epaMchShpmt.get(0);
		mchDto.setInvoiceNumber(epaShp.getInvoiceNum());
		mchDto.setOrderNumber(epaShp.getOrderNum());
		mchDto.setShipmentDate(epaShp.getOrigShipDate());
		if (null != epaShp.getEpaFac() && null != epaShp.getEpaFac().getFacCd()
				&& null != epaShp.getEpaFac().getFacilityName()) {
			mchDto.setOriginFacility(ServiceUtils.concatenate(epaShp
					.getEpaFac().getFacCd()
					+ ServiceConstants.HIPHEN
					+ epaShp.getEpaFac().getFacilityName()));
		}

		for (EpaShipment epaShpm : epaMchShpmt) {
			if (null != epaShpm.getEngineSerialNum()) {
				engNum.append(epaShpm.getEngineSerialNum());
				engNum.append(ServiceConstants.COMMA);
			}
		}
		if (engNum.length() > 0) {
			engNum = engNum.deleteCharAt(engNum.length() - 1);
			mchDto.getMchEngine().setEngineSerialNumber(engNum.toString());
		}

		EpaMachine epaMachine = epaMchShpmt.get(0).getEpaMachines();
		if (null != epaMachine) {
			convertEpaMachineToMachineDTO(epaMachine, mchDto);
		}
		LOGGER.info("Exit method of convertEpaShipmentLstToMachineDTO {}",
				ServiceConstants.METHOD_EXIT);
		return mchDto;
	}

	/**
	 * converts Machine dto to EpaShipment
	 * 
	 * @param mchDto
	 * @param status
	 * @return Epa shipment
	 * @throws DaoException 
	 */
	public EpaShipment convertMachineDTOtoEpaShipment(MachineDTO mchDto,
			String status) throws DaoException {
		LOGGER.info("Entry method of convertMachineDTOtoEpaShipment {}",
				ServiceConstants.METHOD_ENTRY);
		EpaShipment epaShipment = new EpaShipment();
		EpaEngine epaEngine = null;
		String userId = (String) ServiceUtils.getSession().getAttribute(
				ServiceConstants.LOGON_ID);
		EpaMachine epaMachine = convertMachineDTOtoEpaMachine(mchDto,
				new EpaMachine());
		if(null != mchDto.getEpaSeqNo()){
		mchDto.getMchEngine().setEpaSeqNum(new Long(mchDto.getEpaSeqNo()));
		}
		epaEngine = converEngineDTOtoEpaEngine(mchDto.getMchEngine(),
				new EpaEngine(), status);
		epaEngine.setMachineSerialNum(mchDto.getMachineSerialNum()
				.toUpperCase());
		
		epaShipment.setEpaCmnt(mchDto.getEpaCmnt());
		epaShipment.setMachineSerialNum(mchDto.getMachineSerialNum()
				.toUpperCase());
		epaShipment.setEngineSerialNum(mchDto.getMchEngine()
				.getEngineSerialNumber().toUpperCase());
		if (!ServiceUtils.isNullOrEmpty(mchDto.getOriginFacility())) {
			epaShipment.setEpaFac(new EpaFac(ServiceUtils.splitNgetNthValue(
					mchDto.getOriginFacility(), ServiceConstants.HIPHEN, 0)));
		}
		epaShipment.setEpaMachines(epaMachine);
		epaShipment.setEpaEngines(epaEngine);
		RcrdUpdtLog rcvdLog = new RcrdUpdtLog();
		rcvdLog.setLastUpdtTs(new Date());
		rcvdLog.setLastUpdtLogonId(userId);
		epaShipment.setRcdLog(rcvdLog);
		populateMchShimtInfoFrmExistngToNew(epaShipment);
		if (ServiceConstants.APPROVE_FORM.equalsIgnoreCase(mchDto
				.getMachineFormAction())) {
			epaShipment.getEpaEngines().setCertIndividualSign(userId);
			epaShipment.getEpaEngines().setCertDate(new Date());
		}
		LOGGER.info("Exit method of convertMachineDTOtoEpaShipment {}", ServiceConstants.METHOD_EXIT);
		return epaShipment;
	}
	/**
	 * It fetches existed shipment info for the given serial number and copies to the new Shipment object in case of creating duplicate engine.
	 * @param engineShipmentsDTO EngineDTO
	 * @param shipmentInfo shipment DTO
	 * @throws DaoException 
	 */
	private void populateMchShimtInfoFrmExistngToNew(EpaShipment shipmnt) throws DaoException {
		String mchSerilNum = shipmnt.getEpaMachines().getId().getMachineSerialNum();
		List<EpaShipment> epaShipmentlist=null;
			epaShipmentlist = epaShipmentDao.getEpaShipmentbyMachOrEngNum(mchSerilNum, null);
			if(null != epaShipmentlist && epaShipmentlist.size()>0){
				EpaShipment epaShpm = epaShipmentlist.get(0);
				shipmnt.setPartNum(epaShpm.getPartNum());
				shipmnt.setHtsCode(epaShpm.getHtsCode());
				shipmnt.setSalesModel(epaShpm.getSalesModel());
			}
	}

	/**
	 * converts Engine Dto to EpaEngine
	 * 
	 * @param mchEngine
	 * @param epaEngine
	 * @param status
	 * @return EPA engine
	 */
	private EpaEngine converEngineDTOtoEpaEngine(EngineDTO mchEngine,
			EpaEngine epaEngine, String status) {
		LOGGER.info("Entry method of convertMachineDTOtoEpaShipment {}", ServiceConstants.METHOD_ENTRY);
		if (null != mchEngine && null != epaEngine) {
			String provCd = ServiceUtils.splitNgetNthValue(mchEngine
					.getEngineProvisionTypeCode(), ServiceConstants.SLASH_STOP,
					0);
			String importCd = ServiceUtils.splitNgetNthValue(mchEngine
					.getEngineImportTypeCode(), ServiceConstants.SLASH_STOP, 0);
			EpaEnginePK engPk= new EpaEnginePK();
			engPk.setEngineSerialNum(mchEngine.getEngineSerialNumber().toUpperCase());
			engPk.setEpaSeqNo(mchEngine.getEpaSeqNum());
			epaEngine.setId(engPk);
			epaEngine.setEpaStatus(new EpaStatus(status));

			intializeEPAEngine_1(epaEngine, mchEngine, provCd, importCd);
			intializeEPAEngine_2(epaEngine, mchEngine, provCd);

			if (ServiceConstants.STRING_TWTYTWO.equalsIgnoreCase(provCd)
					|| (ServiceConstants.STRING_ONE.equalsIgnoreCase(provCd) && ServiceConstants.STRING_G
							.equalsIgnoreCase(importCd))) {
				epaEngine.setXmptFrmBond(mchEngine.getIsExemptFromBond());
				if (null != mchEngine.getIsExemptFromBond()
						&& ServiceConstants.NO.equalsIgnoreCase(mchEngine
								.getIsExemptFromBond())) {
					String stateCd = ServiceUtils.splitNgetNthValue(mchEngine
							.getStateOfIssue(), ServiceConstants.HIPHEN, 0);
					epaEngine.setBondNaicNum(mchEngine.getNaicForBondIssuer());
					epaEngine.setBondPlcyNum(mchEngine.getPolicyNumber());
					epaEngine.setBondNaicState(stateCd);
				}
			}
			if(ServiceConstants.NS.equalsIgnoreCase(mchEngine.getEpaStatusCd())){
			populateMchFormDefltValuesFrMassApprvalNS(epaEngine, mchEngine, provCd, importCd);
			}
		}
		LOGGER.info("Exit method of convertMachineDTOtoEpaShipment {}", ServiceConstants.METHOD_EXIT);
		return epaEngine;
	}

	/**
	 * While performing Mass approval Not started form, if Engine mfrDateSource, mfrDateSourceDesc, UnitOfmesure and  mfrDateType fields are empty then setting default values to those fields
	 * @param epaEngine
	 * @param mchEngine
	 * @param provCd
	 * @param importCd
	 */
	private void populateMchFormDefltValuesFrMassApprvalNS(EpaEngine epaEngine,
			EngineDTO mchEngine, String provCd, String importCd) {
		if( null == mchEngine.getBuildDataSource()){
			epaEngine.setMfrDateSource(ServiceConstants.OTH);
			epaEngine.setMfrDateSourceDesc(ServiceConstants.DEFAULT_BLD_SRC_TYP_OTH);
		}
		if( null == mchEngine.getBuildDateType() ){
			epaEngine.setMfrDateType(ServiceConstants.MCH_STR_VAR);
		}
		if( ServiceConstants.STRING_TWTYTWO.equalsIgnoreCase(provCd)){
			if(null == mchEngine.getIsExemptFromBond()){
				epaEngine.setXmptFrmBond(ServiceConstants.YES);
			}
			if(null == mchEngine.getUnitOfMeasure()){
				epaEngine.setEngPowerMeasrmt(ServiceConstants.KW);
			}
		}
		if(ServiceConstants.STRING_ONE.equalsIgnoreCase(provCd)  
				 && ServiceConstants.STRING_G.equalsIgnoreCase(importCd)
				 && null == mchEngine.getIsExemptFromBond()){
			epaEngine.setXmptFrmBond(ServiceConstants.YES);
		}
		
	}

	/**
	 * initialize Epa Engine
	 * 
	 * @param epaEngine
	 * @param mchEngine
	 * @param provCd
	 */
	private void intializeEPAEngine_2(EpaEngine epaEngine, EngineDTO mchEngine,
			String provCd) {
		LOGGER.info("Entry method of intializeEPAEngine_2 {}", ServiceConstants.METHOD_ENTRY);
		if (ServiceConstants.STRING_TWTYFORA.equalsIgnoreCase(provCd)
				|| ServiceConstants.STRING_TWTYFORB.equalsIgnoreCase(provCd)) {
			epaEngine.setStorageLoc(mchEngine.getLocationOfStorage());
		}

		if (ServiceConstants.STRING_TWTYFIVE.equalsIgnoreCase(provCd)) {
			epaEngine.setOthSplCaseXmpt(mchEngine.getOtherExemption());
		}
		if (ServiceConstants.STRING_TEN.equalsIgnoreCase(provCd)
				|| ServiceConstants.STRING_ELVN.equalsIgnoreCase(provCd)
				|| ServiceConstants.STRING_TWLV.equalsIgnoreCase(provCd)
				|| ServiceConstants.STRING_EIGTN.equalsIgnoreCase(provCd)) {
			epaEngine.setExemptNum(mchEngine.getEpaExemptionApprNo());
		}
		if (ServiceConstants.STRING_TWTYTWO.equalsIgnoreCase(provCd)) {
			epaEngine.setEngFamilyname(mchEngine.getEngineFamilyName());
			epaEngine.setEngMaxPower(mchEngine.getEngineMaxPower());
			epaEngine.setEngPowerMeasrmt(mchEngine.getUnitOfMeasure());
		}
		LOGGER.info("Exit method of intializeEPAEngine_2 {}", ServiceConstants.METHOD_EXIT);
	}

	/**
	 * intializeEPAEngine
	 * 
	 * @param epaEngine
	 * @param mchEngine
	 * @param provCd
	 * @param importCd
	 */
	private void intializeEPAEngine_1(EpaEngine epaEngine, EngineDTO mchEngine,
			String provCd, String importCd) {
		LOGGER.info("Entry method of intializeEPAEngine_1 {}", ServiceConstants.METHOD_ENTRY);
		if (null != importCd) {
			epaEngine.setEpaImportType(new EpaImportType(importCd));
		}
		if (null != provCd) {
			epaEngine.setEpaProvisionType(new EpaProvisionType(provCd));
		}
		
		if(ServiceConstants.STRING_ONE.equalsIgnoreCase(provCd)){
			epaEngine.setEngFamilyname(mchEngine.getEngineFamilyName());
		 }else{
			 epaEngine.setEngFamilyname(ServiceConstants.EMPTY);
		 }

		
		epaEngine.setEngMfrName(mchEngine.getEngineManfacturer());
		epaEngine.setEngModelNum(mchEngine.getEngineModelNumber());
		epaEngine.setMfrDateType(mchEngine.getBuildDateType());

		epaEngine.setEpaEngineMnfDate(mchEngine.getEngineBuildDate());
		epaEngine.setMfrDateSource(mchEngine.getBuildDataSource());
		epaEngine.setMfrDateType(mchEngine.getBuildDateType());
		if (null != mchEngine.getBuildDataSource()
				&& ServiceConstants.OTH.equalsIgnoreCase(mchEngine
						.getBuildDataSource())) {
			epaEngine.setMfrDateSourceDesc(mchEngine.getExplBuildDataSrcOthr());
		}

		RcrdUpdtLog rcvdLog = new RcrdUpdtLog();
		rcvdLog.setLastUpdtTs(new Date());
		rcvdLog.setLastUpdtLogonId((String) ServiceUtils.getSession()
				.getAttribute(ServiceConstants.LOGON_ID));
		epaEngine.setRcdLog(rcvdLog);
		LOGGER.info("Exit method of intializeEPAEngine_1 {}", ServiceConstants.METHOD_EXIT);
	}

	/**
	 * @param epaImpProvConfig
	 * @return import provision type map
	 */
	public Map<String, Set<String>> convertEpaConfigToMap(
			List<EpaConfig> epaImpProvConfig) {
		LOGGER.info("Entry method of convertEpaConfigToMap {}", ServiceConstants.METHOD_ENTRY);
		Map<String, Set<String>> importProvMap = new HashMap<String, Set<String>>();

		if (null != epaImpProvConfig) {
			for (EpaConfig epaConfig : epaImpProvConfig) {
				String[] provArray = epaConfig.getId().getValueType1().split(
						ServiceConstants.COMMA);
				importProvMap.put(epaConfig.getId().getKeyType(),
						new HashSet<String>(Arrays.asList(provArray)));
			}
		}
		LOGGER.info("Exit method of convertEpaConfigToMap {}", ServiceConstants.METHOD_EXIT);
		return importProvMap;
	}

	/**
	 * Converts EPA Shipment To Machine DTO
	 * 
	 * @param epaShipment
	 * @return Machine DTO
	 */
	public MachineDTO convertEpaShipmentToMachineDTO(EpaShipment epaShipment) {
		LOGGER.info("Entry method of convertEpaShipmentToMachineDTO {}",
				ServiceConstants.METHOD_ENTRY);
		MachineDTO machineDto = new MachineDTO(new EngineDTO());
		convertEpaMachineToMachineDTO(epaShipment.getEpaMachines(), machineDto);
		EngineDTO engineDto = convertEpaEngineToEngineDto(epaShipment
				.getEpaEngines(), new EngineDTO());
		machineDto.setMchEngine(engineDto);
		machineDto.setEpaCmnt(epaShipment.getEpaCmnt());
		machineDto.setArPartNumber(epaShipment.getPartNum());
		machineDto.setOrderNumber(epaShipment.getOrderNum());
		machineDto.setInvoiceNumber(epaShipment.getInvoiceNum());
		machineDto.setShipmentDate(epaShipment.getOrigShipDate());
		//machineDto.setEpaStatusCdDesc(epaShipment.getEpaEngines().getEpaStatus().getEpaStatusDesc());
		if (null != epaShipment.getEpaFac()) {
			machineDto.setOriginFacility(epaShipment.getEpaFac().getFacCd()
					+ ServiceConstants.HIPHEN
					+ epaShipment.getEpaFac().getFacilityName());
		}
		LOGGER.info("Exit method of convertEpaShipmentToMachineDTO {}",
				ServiceConstants.METHOD_EXIT);
		return machineDto;
	}

	/**
	 * Converts EPA Engine To Engine DTO
	 * 
	 * @param epaEngines
	 * @param engineDTO
	 * @return Engine DTO
	 */
	private EngineDTO convertEpaEngineToEngineDto(EpaEngine epaEngines,
			EngineDTO engineDTO) {
		LOGGER.info("Entry method of convertEpaEngineToEngineDto {}", ServiceConstants.METHOD_ENTRY);
		if (null != epaEngines && null != engineDTO) {
			engineDTO.setEngineSerialNumber(epaEngines.getId().getEngineSerialNum());
			engineDTO.setBuildDataSource(epaEngines.getMfrDateSource());
			engineDTO.setBuildDateType(epaEngines.getMfrDateType());
			engineDTO.setEngineModelNumber(epaEngines.getEngModelNum());
			engineDTO.setEngineBuildDate(epaEngines.getEpaEngineMnfDate());
			engineDTO.setEngineFamilyName(epaEngines.getEngFamilyname());
			if (null != epaEngines.getEpaImportType()) {
				engineDTO.setEngineImportTypeCode(epaEngines.getEpaImportType()
						.getImportTypeCode()
						+ ServiceConstants.DOT
						+ epaEngines.getEpaImportType()
								.getImportTypeDescription());
			}
			engineDTO.setEngineManfacturer(epaEngines.getEngMfrName());
			engineDTO.setEngineMaxPower(epaEngines.getEngMaxPower());
			engineDTO.setUnitOfMeasure(epaEngines.getEngPowerMeasrmt());
			if (null != epaEngines.getEpaProvisionType()) {
				engineDTO.setEngineProvisionTypeCode(epaEngines
						.getEpaProvisionType().getProvisionTypeCode()
						+ ServiceConstants.DOT
						+ epaEngines.getEpaProvisionType()
								.getProvisionTypeDescription());
			}
			engineDTO.setEpaExemptionApprNo(epaEngines.getExemptNum());
			if (ServiceConstants.OTH.equalsIgnoreCase(epaEngines
					.getMfrDateSource())) {
				engineDTO.setExplBuildDataSrcOthr(epaEngines
						.getMfrDateSourceDesc());
			}
			engineDTO.setIsExemptFromBond(epaEngines.getXmptFrmBond());
			engineDTO.setLocationOfStorage(epaEngines.getStorageLoc());
			engineDTO.setNaicForBondIssuer(epaEngines.getBondNaicNum());
			engineDTO.setStateOfIssue(epaEngines.getBondNaicState());
			engineDTO.setPolicyNumber(epaEngines.getBondPlcyNum());
			engineDTO.setOtherExemption(epaEngines.getOthSplCaseXmpt());
			if (null != epaEngines.getEpaStatus())
				engineDTO.setEpaStatusCd(epaEngines.getEpaStatus()
						.getEpaStatusCd());
				engineDTO.setEpaFrmStatusDes(epaEngines.getEpaStatus().getEpaStatusDesc());
		}
		LOGGER.info("Exit method of convertEpaEngineToEngineDto {}", ServiceConstants.METHOD_EXIT);
		return engineDTO;
	}

	/**
	 * Converts EPAMachine to Machine DTO
	 * 
	 * @param epaMach
	 * @param machDto
	 * @return Machine DTO
	 */
	public MachineDTO convertEpaMachineToMachineDTO(EpaMachine epaMach,
			MachineDTO machDto) {
		LOGGER.info("Entry method of convertEpaEngineToEngineDto {}", ServiceConstants.METHOD_ENTRY);
		if (null != epaMach) {
			machDto.setMachineModelNum(epaMach.getMchModelNum());
			machDto.setMachinebuildDt(epaMach.getMchMfrDate());
			machDto.setMachineDescription(epaMach.getMchTypeDesc());
			machDto.setMachineSerialNum(epaMach.getId().getMachineSerialNum());
			machDto.setMachineMfrName(epaMach.getMchMfrName());
			machDto.setMachineSrcFac(epaMach.getMchsrcFacCd());
		}
		LOGGER.info("Exit method of convertEpaEngineToEngineDto {}", ServiceConstants.METHOD_EXIT);
		return machDto;
	}

	/**
	 * Converts MachineDTO to EPA Machine
	 * 
	 * @param machDto
	 * @param epaMach
	 * @return EPA Machine
	 */
	public EpaMachine convertMachineDTOtoEpaMachine(MachineDTO machDto,
			EpaMachine epaMach) {
		LOGGER.info("Entry method of convertMachineDTOtoEpaMachine {}", ServiceConstants.METHOD_ENTRY);
		if (null != machDto && null != epaMach) {
			epaMach.setMchModelNum(machDto.getMachineModelNum());
			epaMach.setMchMfrDate(machDto.getMachinebuildDt());
			epaMach.setMchTypeDesc(machDto.getMachineDescription());
			EpaMachinePK mchPk= new EpaMachinePK();
			mchPk.setMachineSerialNum(machDto.getMachineSerialNum().toUpperCase());
			if(null != machDto.getEpaSeqNo()){
			mchPk.setEpaSeqNo(new Long(machDto.getEpaSeqNo()));
			}
			epaMach.setId(mchPk);
			epaMach.setMchMfrName(machDto.getMachineMfrName());
			String macSrcFac=machDto.getMachineSrcFac();
			if (null!=macSrcFac) {
				macSrcFac= macSrcFac.substring(0,macSrcFac.indexOf(ServiceConstants.HIPHEN));
			}
			epaMach.setMchsrcFacCd(macSrcFac); 
			RcrdUpdtLog rcrdUpdtLog= new RcrdUpdtLog();
			rcrdUpdtLog.setLastUpdtTs(new Date());
			rcrdUpdtLog.setLastUpdtLogonId(
						(String) ServiceUtils.getSession().getAttribute(
								ServiceConstants.LOGON_ID));
			epaMach.setRcdLog(rcrdUpdtLog);
		}
		LOGGER.info("Exit method of convertMachineDTOtoEpaMachine {}", ServiceConstants.METHOD_EXIT);
		return epaMach;
	}

}
