package com.cat.logistics.epa.populators;

import com.cat.logistics.epa.dto.EpaShipmentDTO;
import com.cat.logistics.epa.entities.EpaShipment;
import com.cat.logistics.shared.exception.ServiceException;
/**
 * interface for shpmnt populator
 * @author chanda15
 *
 */
public interface IShpmntPopulator {

	/**
	 * populates EpaShipment entity from shipment dto
	 * @param engineShpmntDTO
	 * @return
	 * @throws ServiceException
	 */
	EpaShipment populateEpaShipment(EpaShipmentDTO engineShpmntDTO)
	throws ServiceException;
	
	/**
	 * validates eng ser in EpaShpmnt entity
	 * @param epaSpmnt
	 * @param engSer
	 */
	void valShpEng(EpaShipment epaSpmnt,String engSer);
}
