package com.cat.logistics.epa.populators.impl;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import com.cat.logistics.epa.entities.EpaEngine;
import com.cat.logistics.epa.entities.EpaImportType;
import com.cat.logistics.epa.entities.EpaProvisionType;
import com.cat.logistics.epa.entities.EpaStatus;
import com.cat.logistics.epa.entities.RcrdUpdtLog;
import com.cat.logistics.epa.helper.EngineServiceValidator;
import com.cat.logistics.epa.job.utils.BatchConstants;
import com.cat.logistics.epa.job.utils.Utils;
import com.cat.logistics.epa.populators.IEnginePopulator;
import com.cat.logistics.shared.dto.EngineDTO;


/**
 * 
 * @author chanda15
 *
 */
public class EnginePopulator  implements IEnginePopulator{

	
	@Autowired
	private EngineServiceValidator engSerValidator;
	//private ILogger logger = Logger.getInstance();
	
	private final static Logger logger = LogManager.getLogger(EnginePopulator.class);

	
	/**
	 * method to populate engine entity
	 */
	public EpaEngine populateEpaEngine(EngineDTO engineDTO,boolean machEng) {
		logger.info(this.getClass()+ BatchConstants.MTD_POPLTE_ENG+ BatchConstants.METHOD_ENTRY);
		EpaEngine epaEngine = new EpaEngine();
		if (engineDTO != null) {
			epaEngine.setBondPlcyNum(engineDTO.getPolicyNumber());
			validateEngSerNum(epaEngine, engineDTO.getEngineSerialNumber().toUpperCase());
			epaEngine.setEngMaxPower(engineDTO.getEngineMaxPower());
			epaEngine.setEngFamilyname(engineDTO.getEngineFamilyName());
			epaEngine.setEngMfrName(engineDTO.getEngineManfacturer());

			String status = engSerValidator.getStatus(engineDTO,machEng);
			epaEngine.setEpaStatus(new EpaStatus(status));
			if (engineDTO.getEngineImportTypeCode() != null) {
				epaEngine.setEpaImportType(new EpaImportType(engineDTO
						.getEngineImportTypeCode()));
			}
			
			setImpProv(epaEngine, engineDTO, machEng);

			if (engineDTO.getEngineBuildDate() != null) {
				epaEngine.setEpaEngineMnfDate(engineDTO.getEngineBuildDate());
			}
			epaEngine.setEngModelNum(engineDTO.getEngineModelNumber());
			epaEngine.setEngPowerMeasrmt(engineDTO.getUnitOfMeasure());
			epaEngine.setExemptNum(engineDTO.getEpaExemptionApprNo());
			RcrdUpdtLog updtLog = Utils.getRcdUpLg();
			epaEngine.setRcdLog(updtLog);
			epaEngine.setOthSplCaseXmpt(engineDTO.getOtherExemption());
			epaEngine.setStorageLoc(engineDTO.getLocationOfStorage());
			epaEngine.setXmptFrmBond(engineDTO.getExemptFromBond());

		}
		
		populateLogFlds(epaEngine);
		logger.info(this.getClass()+ BatchConstants.MTD_POPLTE_ENG+ BatchConstants.METHOD_EXIT);
		return epaEngine;

	}
	
	
	/**
	 * constructing Import provision Type code
	 * @param epaEngine
	 * @param engDto
	 * @param machEng
	 */
	public void setImpProv(EpaEngine epaEngine,EngineDTO engDto,boolean machEng){
		
		if(machEng){
			if (engDto.getEngProvEqu() != null) {
				epaEngine.setEpaProvisionType(new EpaProvisionType(engDto
						.getEngProvEqu()));
			}
		}else{
			if (engDto.getEngImpProv() != null) {
				epaEngine.setEpaProvisionType(new EpaProvisionType(engDto
						.getEngImpProv()));
			}
		}
	}

	/**
	 * @param epaEngine
	 */
	public void populateLogFlds(EpaEngine epaEngine){
		RcrdUpdtLog updtLog = Utils.getRcdUpLg();
		epaEngine.setRcdLog(updtLog);
		
	}
	
	/**
	 * it validates the Engine serial number
	 * @param epaEngine
	 * @param serilaNum
	 */
	public void validateEngSerNum(EpaEngine epaEngine,String serilaNum){
		if(!Utils.chkSpclChrs(serilaNum) && Utils.checkLenth(serilaNum,BatchConstants.SERIAL_LEN) ){
				epaEngine.addEngNum(serilaNum);
			}else{
				epaEngine.addEngNum(BatchConstants.INVALID_INPUT);
			}
	}
	
	
	/**
	 * It validates the machine serial number
	 * @param epaEngine
	 * @param machNum
	 */
	public void valEngMacNum(EpaEngine epaEngine,String machNum){
		if(epaEngine != null){
		if(!Utils.chkSpclChrs(machNum) && Utils.checkLenth(machNum,BatchConstants.SERIAL_LEN) ){
				epaEngine.setMachineSerialNum(machNum.trim());
			}else{
				epaEngine.setMachineSerialNum(BatchConstants.INVALID_INPUT);
			}
		}
	}
}
