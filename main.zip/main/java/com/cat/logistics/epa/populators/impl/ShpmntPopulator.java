package com.cat.logistics.epa.populators.impl;


import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.BeanUtils;

import com.cat.logistics.epa.dto.EpaShipmentDTO;
import com.cat.logistics.epa.entities.EpaFac;
import com.cat.logistics.epa.entities.EpaShipment;
import com.cat.logistics.epa.entities.RcrdUpdtLog;
import com.cat.logistics.epa.job.utils.BatchConstants;
import com.cat.logistics.epa.job.utils.Utils;
import com.cat.logistics.epa.populators.IShpmntPopulator;
import com.cat.logistics.shared.exception.ServiceException;

/**
 * populates shipment entity from shipmentdto object
 * @author chanda15
 *
 */
public class ShpmntPopulator implements IShpmntPopulator{

	private final static Logger logger = LogManager.getLogger(ShpmntPopulator.class);
	
	/**
	 * @param engineShpmntDTO
	 * @return EpaShipment object
	 * @throws ServiceException
	 */
	public EpaShipment populateEpaShipment(EpaShipmentDTO engineShpmntDTO)
			throws ServiceException {
		logger.info(this.getClass()+ BatchConstants.MTD_POPLTE_SHIPMT+ BatchConstants.METHOD_ENTRY);
		EpaShipment epaShipment = new EpaShipment();

		try {
			BeanUtils.copyProperties(engineShpmntDTO, epaShipment);
			EpaFac epaFac = new EpaFac();
			epaFac.setFacCd(engineShpmntDTO.getOrigFacCd());
			epaShipment.setEpaFac(epaFac);
			epaShipment.setEpaProdTypeCode(engineShpmntDTO.getEpaProdTypeCode());
			epaShipment.setOrderNum(engineShpmntDTO.getLoadNum());
			if (engineShpmntDTO.getEpaProdTypeCode().equals(
					BatchConstants.ENGINE_LITERAL)) {
				epaShipment.setEngineSerialNum(engineShpmntDTO
						.getProductSerialNum());
			} else {
				epaShipment.setMachineSerialNum(engineShpmntDTO
						.getProductSerialNum());
			}
			epaShipment.setSuppItemSeqNum(engineShpmntDTO.getItmSeqNo());
			epaShipment.setPartNum(engineShpmntDTO.getPartNum().trim());
			epaShipment.setInvoiceNum(engineShpmntDTO.getInvoiceNum().trim());
			epaShipment.setOrderNum(engineShpmntDTO.getOrderNum().trim());
			epaShipment.setSupplierCode(engineShpmntDTO.getSuppCd());
			if (!Utils.checkForNullAndNoLength(engineShpmntDTO.getDealerCode())) {
				epaShipment.setDlrOrderNo(engineShpmntDTO.getDealerCode()
						.trim());
			}
			if (!Utils.checkForNullAndNoLength(engineShpmntDTO.getSalesMdlNo())) {
				epaShipment.setSalesModel(engineShpmntDTO.getSalesMdlNo()
						.trim());
			}
			RcrdUpdtLog updtlg = Utils.getRcdUpLg();
			epaShipment.setRcdLog(updtlg);
			epaShipment.setSuppLdTs(engineShpmntDTO.getSuppLdTmstmp());
		} catch (Exception exception) {
			/*logger.fatalEvent(this.getClass(),
					BatchConstants.POPULATE_EPA_SHIPMT,
					BatchConstants.EXCPN_WHILE_POPING_SHIP, exception);*/
			logger.error(this.getClass() + BatchConstants.POPULATE_EPA_SHIPMT+
					BatchConstants.EXCPN_WHILE_POPING_SHIP+ exception.getMessage());
			throw new ServiceException(exception);
		}
		logger.info(this.getClass()+ BatchConstants.MTD_POPLTE_SHIPMT+ BatchConstants.METHOD_EXIT);
		return epaShipment;
	}
	
	/**
	 * 
	 * @param epaSpmnt
	 * @param engSer
	 */
	public void valShpEng(EpaShipment epaSpmnt,String engSer){
		if(!Utils.chkSpclChrs(engSer) && Utils.checkLenth(engSer,BatchConstants.SERIAL_LEN) ){
			epaSpmnt.setEngineSerialNum(engSer);
		}else{
			epaSpmnt.setEngineSerialNum(BatchConstants.INVALID_INPUT);
		}
	}
	
	
}
