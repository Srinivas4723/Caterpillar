package com.cat.logistics.epa.populators;

import com.cat.logistics.epa.entities.EpaEngine;
import com.cat.logistics.shared.dto.EngineDTO;

/**
 * interface for engine populator
 * @author chanda15
 *
 */
public interface IEnginePopulator {

	/**
	 * populates Epa engine from engineDTO
	 * 
	 * @param engineDTO
	 * @param machEng
	 * @return
	 */
	EpaEngine populateEpaEngine(EngineDTO engineDTO,boolean machEng);
	
	/**
	 * validates engine sernum for any junk values
	 * @param epaEngine
	 * @param serilaNum
	 */
	public void validateEngSerNum(EpaEngine epaEngine,String serilaNum);
	
	/**
	 * validates engine mac ser num for any junk values
	 * @param epaEngine
	 * @param machNum
	 */
	public void valEngMacNum(EpaEngine epaEngine,String machNum);
	
}
