package com.cat.logistics.epa.populators;

import com.cat.logistics.epa.entities.EpaEngine;
import com.cat.logistics.epa.entities.EpaMachine;
import com.cat.logistics.shared.dto.MachineDTO;

/**
 * interface for machine entity populator
 * @author chanda15
 *
 */
public interface IMachPopulator {

	/**
	 * populates EpaMachine entity  from machineDTO
	 * @param machineDTO
	 * @return
	 */
	public EpaMachine populateEpaMachine(MachineDTO machineDTO);
	
	/**
	 * validates mach sernum for any junk values
	 * @param epaMach
	 * @param machser
	 */
	public void validateMchSerNum(EpaMachine epaMach,String machser);
	
	/**
	 * sets status for machine's engine
	 * @param machineDto
	 * @param engineDto
	 * @return
	 */
	public String setMachStatus(EpaMachine machineDto, EpaEngine engineDto) ;
	
	
}
