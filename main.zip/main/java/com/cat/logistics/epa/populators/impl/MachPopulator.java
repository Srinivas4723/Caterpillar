package com.cat.logistics.epa.populators.impl;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import com.cat.logistics.epa.entities.EpaEngine;
import com.cat.logistics.epa.entities.EpaMachine;
import com.cat.logistics.epa.entities.RcrdUpdtLog;
import com.cat.logistics.epa.helper.EngineServiceValidator;
import com.cat.logistics.epa.job.utils.BatchConstants;
import com.cat.logistics.epa.job.utils.Utils;
import com.cat.logistics.epa.populators.IMachPopulator;
import com.cat.logistics.shared.dto.MachineDTO;
import com.cat.logistics.shared.utils.PersistenceConstants;
/**
 * 
 * populator for machine's info creation
 * @author chanda15
 *
 */
public class MachPopulator  implements IMachPopulator{

	
	@Autowired
	private EngineServiceValidator engSerValidator;
	
	public static final Logger LOGGER = LogManager.getLogger(MachPopulator.class);
	
	/**
	 * method to create machine populator
	 * @param machineDTO
	 * @return EpaMachine object
	 */
	public EpaMachine populateEpaMachine(MachineDTO machineDTO) {
		LOGGER.info("Entry method of populateEpaMachine {}", BatchConstants.METHOD_ENTRY);
		EpaMachine epaMachine = new EpaMachine();
		validateMchSerNum(epaMachine, machineDTO.getMachineSerialNum());
		epaMachine.setMchMfrDate(machineDTO.getMachinebuildDt());
		epaMachine.setMchMfrName(machineDTO.getMachineMfrName());
		epaMachine.setMchModelNum(machineDTO.getMachineModelNum());
		epaMachine.setMchTypeDesc(machineDTO.getMachineDescription());
		epaMachine.setMchsrcFacCd(machineDTO.getMachineSrcFac());
		RcrdUpdtLog updtLog = Utils.getRcdUpLg();
		epaMachine.setRcdLog(updtLog);
		LOGGER.info("Exit method of populateEpaMachine {}", BatchConstants.METHOD_EXIT);
		return epaMachine;
	}
	
	
	/**
	 * @param epaMach
	 * @param machser
	 */
	public void validateMchSerNum(EpaMachine epaMach,String machser){
		if(!Utils.chkSpclChrs(machser) && Utils.checkLenth(machser,BatchConstants.SERIAL_LEN) ){
				epaMach.addMchNum(machser.trim());
			}else{
				epaMach.addMchNum(BatchConstants.INVALID_INPUT);
			}
	}
	
	
	/**
	 * Return the engine status of machine
	 * @param machineDto
	 * @param engineDto
	 * @return String
	 */
	public String setMachStatus(EpaMachine machineDto, EpaEngine engineDto) {
		
	    return engSerValidator.getMachStatus(machineDto, engineDto);
	}
}
