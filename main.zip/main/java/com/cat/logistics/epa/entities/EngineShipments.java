package com.cat.logistics.epa.entities;

import java.io.Serializable;

/**
 * 
 * @author dullas
 *
 */
//@Entity
//@Table(name = "EPA_ENG_IMPORT")
public class EngineShipments implements Serializable{

	
	private static final long serialVersionUID = 3168241970171714864L;
	
	private String engineSerialNumber;
	private String engineManfacturer;
	private String engineModelNumber;
	private String engineBuildDate;
	private String buildDataSource;
	private String highwayType;
	private String provisionIndicator;
	
	
	public EngineShipments(){}
	
	/**
	 * @return the engineSerialNumber
	 */
	public String getEngineSerialNumber() {
		return engineSerialNumber;
	}
	/**
	 * @param engineSerialNumber the engineSerialNumber to set
	 */
	public void setEngineSerialNumber(String engineSerialNumber) {
		this.engineSerialNumber = engineSerialNumber;
	}
	/**
	 * @return the engineManfacturer
	 */
	public String getEngineManfacturer() {
		return engineManfacturer;
	}
	/**
	 * @param engineManfacturer the engineManfacturer to set
	 */
	public void setEngineManfacturer(String engineManfacturer) {
		this.engineManfacturer = engineManfacturer;
	}
	/**
	 * @return the engineModelNumber
	 */
	public String getEngineModelNumber() {
		return engineModelNumber;
	}
	/**
	 * @param engineModelNumber the engineModelNumber to set
	 */
	public void setEngineModelNumber(String engineModelNumber) {
		this.engineModelNumber = engineModelNumber;
	}
	/**
	 * @return the engineBuildDate
	 */
	public String getEngineBuildDate() {
		return engineBuildDate;
	}
	/**
	 * @param engineBuildDate the engineBuildDate to set
	 */
	public void setEngineBuildDate(String engineBuildDate) {
		this.engineBuildDate = engineBuildDate;
	}
	/**
	 * @return the buildDataSource
	 */
	public String getBuildDataSource() {
		return buildDataSource;
	}
	/**
	 * @param buildDataSource the buildDataSource to set
	 */
	public void setBuildDataSource(String buildDataSource) {
		this.buildDataSource = buildDataSource;
	}
	/**
	 * @return the highwayType
	 */
	public String getHighwayType() {
		return highwayType;
	}
	/**
	 * @param highwayType the highwayType to set
	 */
	public void setHighwayType(String highwayType) {
		this.highwayType = highwayType;
	}
	/**
	 * @return the provisionIndicator
	 */
	public String getProvisionIndicator() {
		return provisionIndicator;
	}
	/**
	 * @param provisionIndicator the provisionIndicator to set
	 */
	public void setProvisionIndicator(String provisionIndicator) {
		this.provisionIndicator = provisionIndicator;
	}
	
}
