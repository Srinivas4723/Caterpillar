package com.cat.logistics.epa.entities;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the EPA_CNFGR database table.
 * @singhr9
 * 
 */
@Embeddable
public class EpaConfigPK implements Serializable {

	private static final long serialVersionUID = -2933232357627748506L;

	@Column(name="CNFGR_TYPE")
	private String configType;

	@Column(name="TYP_KEY")
	private String keyType;
	
	@Column(name="TYP_VAL1")
	private String valueType1;

	public EpaConfigPK() {
	}

	/**
	 * @return the configType
	 */
	public String getConfigType() {
		return configType;
	}

	/**
	 * @param configType the configType to set
	 */
	public void setConfigType(String configType) {
		this.configType = configType;
	}

	/**
	 * @return the keyType
	 */
	public String getKeyType() {
		return keyType;
	}

	/**
	 * @param keyType the keyType to set
	 */
	public void setKeyType(String keyType) {
		this.keyType = keyType;
	}

	/**
	 * @return the valueType
	 */
	public String getValueType1() {
		return valueType1;
	}

	/**
	 * @param valueType the valueType to set
	 */
	public void setValueType1(String valueType1) {
		this.valueType1 = valueType1;
	}
	
	
	
}