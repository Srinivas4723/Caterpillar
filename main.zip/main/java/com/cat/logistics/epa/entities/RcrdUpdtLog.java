package com.cat.logistics.epa.entities;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Embeddable
public  class RcrdUpdtLog implements Serializable{

	@Column(name="CRTE_LOGON_ID",updatable=false)
	private String crteLogin;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="CRETE_TS", updatable=false)
	private Date crteTm;

	@Column(name="LAST_UPDT_LOGON_ID")
	private String lastUpdtLogonId;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="LAST_UPDT_TS")
	private Date lastUpdtTs;
	
	/**
	 * Default constructor
	 */
	public RcrdUpdtLog(){
		
	}
	
	
	/**
	 * constructor to create RcrdUpdtLog 
	 * @param crteLogin
	 * @param crteTm
	 * @param lastUpdtLogonId
	 * @param lastUpdtTs
	 */
	public RcrdUpdtLog(String crteLogin,Date crteTm,String lastUpdtLogonId,Date lastUpdtTs){
		this.crteLogin = crteLogin;
		this.crteTm = crteTm;
		this.lastUpdtLogonId = lastUpdtLogonId;
		this.lastUpdtTs = lastUpdtTs;
		
	}
	
	/**
	 * @param crteLogin
	 * @param crteTm
	 */
	public RcrdUpdtLog(String crteLogin,Date crteTm){
		this.crteLogin = crteLogin;
		this.crteTm = crteTm;
	}
	
	
	/**
	 * @return create Login id
	 */
	public String getCrteLogin() {
		return crteLogin;
	}

	/**
	 * @param crteLogin
	 */
	public void setCrteLogin(String crteLogin) {
		this.crteLogin = crteLogin;
	}

	/**
	 * @return Create time stamp
	 */
	public Date getCrteTm() {
		return crteTm;
	}

	/**
	 * @param crteTm
	 */
	public void setCrteTm(Date crteTm) {
		this.crteTm = crteTm;
	}

	/**
	 * @return the lastUpdtLogonId
	 */
	public String getLastUpdtLogonId() {
		return lastUpdtLogonId;
	}

	/**
	 * @param lastUpdtLogonId
	 */
	public void setLastUpdtLogonId(String lastUpdtLogonId) {
		this.lastUpdtLogonId = lastUpdtLogonId;
	}

	/**
	 * @return the lastUpdtTs
	 */
	public Date getLastUpdtTs() {
		return lastUpdtTs;
	}

	/**
	 * @param lastUpdtTs
	 */
	public void setLastUpdtTs(Date lastUpdtTs) {
		this.lastUpdtTs = lastUpdtTs;
	}
}
