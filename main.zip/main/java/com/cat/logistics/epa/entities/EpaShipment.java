
package com.cat.logistics.epa.entities;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.Cascade;
import org.hibernate.annotations.CascadeType;

/**
 * The persistent class for the Shipment database table.
 * @author singhr9
 *
 */

@Entity
@Table(name="EPA_SHIPMENT",schema="US_EPA_IMP")
public class EpaShipment implements Serializable{
	private static final long serialVersionUID = 1L;
	
	@Id
    @GeneratedValue(generator = "EPA_SEQUENCE",strategy=GenerationType.SEQUENCE)
    @SequenceGenerator(name = "EPA_SEQUENCE", sequenceName="EPA_SEQ", allocationSize=1)
	@Column(name="EPA_SEQ_NO")
	private long epaSeqNum;

	@Column(name="PART_NO",updatable=false)
	private String partNum;
	
	@Column(name="HTS_Code",updatable=false)
	private String htsCode;

	@Column(name="INVC_NO",updatable=false)
	private String invoiceNum;
	
	@Column(name="ORDER_NO",updatable=false)
	private String orderNum;
	
	@Column(name="FWDR_REF_NO",updatable=false)
	private String fwdrRefNo;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="ORIG_SHP_DT",updatable=false)
	private Date origShipDate;
	
	@Column(name="ENG_SER_NO")
	private String engineSerialNum;
	
	@Column(name="MCH_SER_NO")
	private String machineSerialNum;
	
	@Column(name="SUPP_CD",updatable=false)
	private String supplierCode;
	
	@Column(name="SUPP_ITM_SEQ_NO",updatable=false)
	private String suppItemSeqNum;
	
	@Column(name="SUPP_LD_TS",updatable=false)
	private Timestamp suppLdTs;
	
	@Column(name="EPA_PROD_TYPE_CD")
	private String epaProdTypeCode;
	
	@Embedded
	private RcrdUpdtLog rcdLog;
			
	@OneToOne(mappedBy="epaShipment")
	@Cascade({CascadeType.ALL})
	private EpaEngine epaEngines;
	
	@OneToOne(mappedBy="epaShipment")
	@Cascade({CascadeType.ALL})
	private EpaMachine epaMachines;
	
	@Column(name="SL_MDL_NME",updatable=false)
	private String salesModel;
	
	@Column(name="DLR_ORD_NO")
	private String dlrOrderNo;
	
	@Column(name="EPA_CMNT")
	private String epaCmnt;
	
	@OneToOne
	@JoinColumn(name="ORIG_FAC_CD", insertable=true, updatable=true)
	private EpaFac epaFac;

	/**
	 * @return the epaSeqNum
	 */
	public long getEpaSeqNum() {
		return epaSeqNum;
	}
	

	/**
	 * @param epaSeqNum the epaSeqNum to set
	 */
	public void setEpaSeqNum(int epaSeqNum) {
		this.epaSeqNum = epaSeqNum;
	}

	/**
	 * @return the partNum
	 */
	public String getPartNum() {
		return partNum;
	}

	/**
	 * @param partNum the partNum to set
	 */
	public void setPartNum(String partNum) {
		this.partNum = partNum;
	}

	/**
	 * @return the htsCode
	 */
	public String getHtsCode() {
		return htsCode;
	}

	/**
	 * @param htsCode the htsCode to set
	 */
	public void setHtsCode(String htsCode) {
		this.htsCode = htsCode;
	}

	/**
	 * @return the invoiceNum
	 */
	public String getInvoiceNum() {
		return invoiceNum;
	}

	/**
	 * @param invoiceNum the invoiceNum to set
	 */
	public void setInvoiceNum(String invoiceNum) {
		this.invoiceNum = invoiceNum;
	}

	/**
	 * @return the orderNum
	 */
	public String getOrderNum() {
		return orderNum;
	}

	/**
	 * @param orderNum the orderNum to set
	 */
	public void setOrderNum(String orderNum) {
		this.orderNum = orderNum;
	}

	/**
	 * @return the origShipDate
	 */
	public Date getOrigShipDate() {
		return origShipDate;
	}

	/**
	 * @param origShipDate the origShipDate to set
	 */
	public void setOrigShipDate(Date origShipDate) {
		this.origShipDate = origShipDate;
	}

	/**
	 * @return the engineSerialNum
	 */
	public String getEngineSerialNum() {
		return engineSerialNum;
	}

	/**
	 * @return the machineSerialNum
	 */
	public String getMachineSerialNum() {
		return machineSerialNum;
	}

	/**
	 * @param engineSerialNum the engineSerialNum to set
	 */
	public void setEngineSerialNum(String engineSerialNum) {
		this.engineSerialNum = engineSerialNum;
	}

	/**
	 * @param machineSerialNum the machineSerialNum to set
	 */
	public void setMachineSerialNum(String machineSerialNum) {
		this.machineSerialNum = machineSerialNum;
	}


	/**
	 * @return the supplierCode
	 */
	public String getSupplierCode() {
		return supplierCode;
	}


	/**
	 * @return the suppItemSeqNum
	 */
	public String getSuppItemSeqNum() {
		return suppItemSeqNum;
	}


	


	/**
	 * @return the epaProdTypeCode
	 */
	public String getEpaProdTypeCode() {
		return epaProdTypeCode;
	}


	/**
	 * @param epaSeqNum the epaSeqNum to set
	 */
	public void setEpaSeqNum(long epaSeqNum) {
		this.epaSeqNum = epaSeqNum;
	}


	/**
	 * @param supplierCode the supplierCode to set
	 */
	public void setSupplierCode(String supplierCode) {
		this.supplierCode = supplierCode;
	}


	/**
	 * @param suppItemSeqNum the suppItemSeqNum to set
	 */
	public void setSuppItemSeqNum(String suppItemSeqNum) {
		this.suppItemSeqNum = suppItemSeqNum;
	}


	/**
	 * @param epaProdTypeCode the epaProdTypeCode to set
	 */
	public void setEpaProdTypeCode(String epaProdTypeCode) {
		this.epaProdTypeCode = epaProdTypeCode;
	}


	/**
	 * @return
	 */
	public EpaEngine getEpaEngines() {
		return epaEngines;
	}


	public void setEpaEngines(EpaEngine epaEngines) {
		this.epaEngines = epaEngines;
	}


	/**
	 * @return the epaMachines
	 */
	public EpaMachine getEpaMachines() {
		return epaMachines;
	}


	/**
	 * @param epaMachines the epaMachines to set
	 */
	public void setEpaMachines(EpaMachine epaMachines) {
		this.epaMachines = epaMachines;
	}


	/**
	 * @return the epaFac
	 */
	public EpaFac getEpaFac() {
		return epaFac;
	}


	/**
	 * @param epaFac the epaFac to set
	 */
	public void setEpaFac(EpaFac epaFac) {
		this.epaFac = epaFac;
	}


	/**
	 * @return the salesModel
	 */
	public String getSalesModel() {
		return salesModel;
	}


	/**
	 * @param salesModel the salesModel to set
	 */
	public void setSalesModel(String salesModel) {
		this.salesModel = salesModel;
	}


	/**
	 * @return the dlrOrderNo
	 */
	public String getDlrOrderNo() {
		return dlrOrderNo;
	}


	/**
	 * @param dlrOrderNo the dlrOrderNo to set
	 */
	public void setDlrOrderNo(String dlrOrderNo) {
		this.dlrOrderNo = dlrOrderNo;
	}


	/**
	 * @return
	 */
	public Timestamp getSuppLdTs() {
		return suppLdTs;
	}


	/**
	 * @param suppLdTs
	 */
	public void setSuppLdTs(Timestamp suppLdTs) {
		this.suppLdTs = suppLdTs;
	}


	public RcrdUpdtLog getRcdLog() {
		return rcdLog;
	}


	public void setRcdLog(RcrdUpdtLog rcdLog) {
		this.rcdLog = rcdLog;
	}


	/**
	 * 
	 * @return String epaCmnt
	 */
	public String getEpaCmnt() {
		return epaCmnt;
	}


	/**
	 * 
	 * @param epaCmnt epaCmnt
	 */
	public void setEpaCmnt(String epaCmnt) {
		this.epaCmnt = epaCmnt;
	}


	/**
	 * @return the fwdrRefNo
	 */
	public String getFwdrRefNo() {
		return fwdrRefNo;
	}


	/**
	 * @param fwdrRefNo the fwdrRefNo to set
	 */
	public void setFwdrRefNo(String fwdrRefNo) {
		this.fwdrRefNo = fwdrRefNo;
	}
	
	

}
