
package com.cat.logistics.epa.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;


/**
 * The persistent class for the ImportProvisionType database table.
 * @author singhr9
 *
 */

@Entity
@Table(name="EPA_IMP_CD",schema="US_EPA_IMP")
@NamedQueries({
@NamedQuery(name="EpaImp.findAll", query="SELECT e FROM EpaProvisionType e")})
public class EpaProvisionType implements Serializable{
	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name="ENG_IMP_PROV_TYP_CD")
	private String provisionTypeCode;
		
	@Column(name="ENG_IMP_PROV_TYP_DESC")
	private String provisionTypeDescription;

	@Embedded
	private RcrdUpdtLog rcdLog; 	

	/**
	 * 
	 */
	public EpaProvisionType() {
		super();
	}
		

	/**
	 * @param provisionTypeCode
	 */
	public EpaProvisionType(String provisionTypeCode) {
		super();
		this.provisionTypeCode = provisionTypeCode;
	}


	/**
	 * @return the provisionTypeCode
	 */
	public String getProvisionTypeCode() {
		return provisionTypeCode;
	}

	/**
	 * @return the provisionTypeDescription
	 */
	public String getProvisionTypeDescription() {
		return provisionTypeDescription;
	}



	/**
	 * @param provisionTypeCode the provisionTypeCode to set
	 */
	public void setProvisionTypeCode(String provisionTypeCode) {
		this.provisionTypeCode = provisionTypeCode;
	}

	/**
	 * @param provisionTypeDescription the provisionTypeDescription to set
	 */
	public void setProvisionTypeDescription(String provisionTypeDescription) {
		this.provisionTypeDescription = provisionTypeDescription;
	}


	public RcrdUpdtLog getRcdLog() {
		return rcdLog;
	}


	public void setRcdLog(RcrdUpdtLog rcdLog) {
		this.rcdLog = rcdLog;
	}

}
