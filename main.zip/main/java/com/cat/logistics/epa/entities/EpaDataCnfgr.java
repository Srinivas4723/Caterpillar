package com.cat.logistics.epa.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;


/**
 * The persistent class for the EPA_DATA_CNFGR database table.
 * 
 */
@Entity
@Table(name="EPA_DATA_CNFGR",schema="US_EPA_IMP")
public class EpaDataCnfgr implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private EpaDataCnfgrPK id;

	@Column(name="CNFGR_VAL")
	private String cnfgrVal;

	@Column(name="CRETE_TS")
	private Timestamp creteTs;

	@Column(name="CRTE_LOGON_ID")
	private String crteLogonId;

	@Column(name="LAST_UPDT_LOGON_ID")
	private String lastUpdtLogonId;

	@Column(name="LAST_UPDT_TS")
	private Timestamp lastUpdtTs;

	/**
	 * EpaDataCnfgr
	 */
	public EpaDataCnfgr() {
	}

	/**
	 * @return the EpaDataCnfgrPK object
	 */
	public EpaDataCnfgrPK getId() {
		return this.id;
	}

	/**
	 * @param id id
	 */
	public void setId(EpaDataCnfgrPK id) {
		this.id = id;
	}

	/**
	 * @return the configure value
	 */
	public String getCnfgrVal() {
		return this.cnfgrVal;
	}

	/**
	 * @param cnfgrVal
	 */
	public void setCnfgrVal(String cnfgrVal) {
		this.cnfgrVal = cnfgrVal;
	}

	/**
	 * @return the Time stamp
	 */
	public Timestamp getCreteTs() {
		return this.creteTs;
	}

	/**
	 * @param creteTs creteTs
	 */
	public void setCreteTs(Timestamp creteTs) {
		this.creteTs = creteTs;
	}

	/**
	 * @return create Logon Id
	 */
	public String getCrteLogonId() {
		return this.crteLogonId;
	}

	/**
	 * @param crteLogonId
	 */
	public void setCrteLogonId(String crteLogonId) {
		this.crteLogonId = crteLogonId;
	}

	/**
	 * @return Last update Logon Id
	 */
	public String getLastUpdtLogonId() {
		return this.lastUpdtLogonId;
	}

	/**
	 * @param lastUpdtLogonId
	 */
	public void setLastUpdtLogonId(String lastUpdtLogonId) {
		this.lastUpdtLogonId = lastUpdtLogonId;
	}

	/**
	 * @return Last updated time stamp
	 */
	public Timestamp getLastUpdtTs() {
		return this.lastUpdtTs;
	}

	/**
	 * @param lastUpdtTs lastUpdtTs
	 */
	public void setLastUpdtTs(Timestamp lastUpdtTs) {
		this.lastUpdtTs = lastUpdtTs;
	}

}