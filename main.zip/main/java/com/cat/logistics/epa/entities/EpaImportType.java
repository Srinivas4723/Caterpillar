
package com.cat.logistics.epa.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;


/**
 * The persistent class for the ImportTypeCode database table.
 * @author singhr9
 *
 */

@Entity
@Table(name="EPA_IND_CD",schema="US_EPA_IMP")
@NamedQueries({
@NamedQuery(name="EpaInd.findAll", query="SELECT e FROM EpaImportType e")})
public class EpaImportType implements Serializable{
	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name="ENG_IMP_TYP_CD")
	private String importTypeCode;
		
	@Column(name="ENG_IMP_TYP_DESC")
	private String importTypeDescription;
	
	@Embedded
	private RcrdUpdtLog rcdLog; 
	
	/**
	 * 
	 */
	public EpaImportType() {
		super();
	}

	
	/**
	 * @param importTypeCode
	 */
	public EpaImportType(String importTypeCode) {
		super();
		this.importTypeCode = importTypeCode;
	}


	/**
	 * @return the importTypeCode
	 */
	public String getImportTypeCode() {
		return importTypeCode;
	}

	/**
	 * @return the importTypeDescription
	 */
	public String getImportTypeDescription() {
		return importTypeDescription;
	}

	/**
	 * @param importTypeCode the importTypeCode to set
	 */
	public void setImportTypeCode(String importTypeCode) {
		this.importTypeCode = importTypeCode;
	}

	/**
	 * @param importTypeDescription the importTypeDescription to set
	 */
	public void setImportTypeDescription(String importTypeDescription) {
		this.importTypeDescription = importTypeDescription;
	}


	public RcrdUpdtLog getRcdLog() {
		return rcdLog;
	}


	public void setRcdLog(RcrdUpdtLog rcdLog) {
		this.rcdLog = rcdLog;
	}

}
