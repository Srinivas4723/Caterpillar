package com.cat.logistics.epa.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;



/**
 * The persistent class for the EPA_HTS_CNFGR database table.
 * 
 */
@Entity
@Table(name="EPA_HTS_CNFGR",schema="US_EPA_IMP")
public class EpaHtsConfgr implements Serializable {
	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name="EPA_HTS_CD")
	private String htsCode;
	
	@Column(name="CTRY_CD")
	private String countryCode;
	
	@Column(name="EPA_HTS_DESC")
	private String htsDescription;
	
	@Column(name="EPA_HTS_CNFGR")
	private String htsConfiguration;
	
	@Column(name="XCPT_IND")
	private String exceptionIndicator;
	
	
	@Embedded
	private RcrdUpdtLog rcdLog;
	
	/**
	 * @return the htsCode
	 */
	public String getHtsCode() {
		return htsCode;
	}

	/**
	 * @return the countryCode
	 */
	public String getCountryCode() {
		return countryCode;
	}

	/**
	 * @return the htsDescription
	 */
	public String getHtsDescription() {
		return htsDescription;
	}

	/**
	 * @return the htsConfiguration
	 */
	public String getHtsConfiguration() {
		return htsConfiguration;
	}

	/**
	 * @return the exceptionIndicator
	 */
	public String getExceptionIndicator() {
		return exceptionIndicator;
	}

	/**
	 * @param htsCode the htsCode to set
	 */
	public void setHtsCode(String htsCode) {
		this.htsCode = htsCode;
	}

	/**
	 * @param countryCode the countryCode to set
	 */
	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}

	/**
	 * @param htsDescription the htsDescription to set
	 */
	public void setHtsDescription(String htsDescription) {
		this.htsDescription = htsDescription;
	}

	/**
	 * @param htsConfiguration the htsConfiguration to set
	 */
	public void setHtsConfiguration(String htsConfiguration) {
		this.htsConfiguration = htsConfiguration;
	}

	/**
	 * @param exceptionIndicator the exceptionIndicator to set
	 */
	public void setExceptionIndicator(String exceptionIndicator) {
		this.exceptionIndicator = exceptionIndicator;
	}

	public RcrdUpdtLog getRcdLog() {
		return rcdLog;
	}

	public void setRcdLog(RcrdUpdtLog rcdLog) {
		this.rcdLog = rcdLog;
	}

	

}