package com.cat.logistics.epa.entities;

import java.io.Serializable;

import javax.persistence.Embedded;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;


/**
 * The persistent class for the EPA_ATH_ACCESS database table.
 * 
 */
@Entity
@Table(name="EPA_ATH_ACCESS",schema="US_EPA_IMP")

@NamedQueries({
	@NamedQuery(name="EpaAthAccess.findAll", query="SELECT e FROM EpaAthAccess e"),
@NamedQuery(name="EpaAthAccess.getMap", query="SELECT new map(epaAthLvl.epaAthLvlDesc, epaAccess.epaAccessCd )FROM EpaAthAccess e")
	})
public class EpaAthAccess implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private EpaAthAccessPK id;

	@Embedded
	private RcrdUpdtLog rcdLog;
	

	//bi-directional many-to-one association to EpaAccess
	@ManyToOne
	@JoinColumn(name="EPA_ACCESS_CD", insertable=false, updatable=false)
	private EpaAccess epaAccess;

	//bi-directional many-to-one association to EpaAthLvl
	@ManyToOne
	@JoinColumn(name="EPA_ATH_LVL_CD", insertable=false, updatable=false)
	private EpaAthLvl epaAthLvl;
/**
 * 
 */
	public EpaAthAccess() {
	}
	/**
	 * 
	 * @return
	 */
	public EpaAthAccessPK getId() {
		return this.id;
	}
	/**
	 * 
	 * @param id
	 */
	public void setId(EpaAthAccessPK id) {
		this.id = id;
	}
	
	/**
	 * 
	 * @return
	 */
	public EpaAccess getEpaAccess() {
		return this.epaAccess;
	}
	/**
	 * 
	 * @param epaAccess
	 */
	public void setEpaAccess(EpaAccess epaAccess) {
		this.epaAccess = epaAccess;
	}
	/**
	 * 
	 * @return
	 */
	public EpaAthLvl getEpaAthLvl() {
		return this.epaAthLvl;
	}
	/**
	 * 
	 * @param epaAthLvl
	 */
	public void setEpaAthLvl(EpaAthLvl epaAthLvl) {
		this.epaAthLvl = epaAthLvl;
	}
	public RcrdUpdtLog getRcdLog() {
		return rcdLog;
	}
	public void setRcdLog(RcrdUpdtLog rcdLog) {
		this.rcdLog = rcdLog;
	}

}