package com.cat.logistics.epa.entities;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.LazyCollection;
import org.hibernate.annotations.LazyCollectionOption;


/**
 * The persistent class for the EPA_ATH_LVL database table.
 * 
 */
/**
 * @author addansn
 *
 */
@Entity
@Table(name="EPA_ATH_LVL",schema="US_EPA_IMP")
@NamedQuery(name="EpaAthLvl.findAll", query="SELECT e FROM EpaAthLvl e")
public class EpaAthLvl implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="EPA_ATH_LVL_CD")
	private String epaAthLvlCd;

	@Embedded
	private RcrdUpdtLog rcdLog;

	@Column(name="EPA_ATH_LVL_DESC")
	private String epaAthLvlDesc;

	//bi-directional many-to-one association to EpaAthAccess
	@LazyCollection(LazyCollectionOption.FALSE)
	@OneToMany(mappedBy="epaAthLvl")
	private List<EpaAthAccess> epaAthAccs;

	//bi-directional many-to-one association to EpaUserAth
	@OneToMany(mappedBy="epaAthLvl")
	private List<EpaUserAth> epaUserAths;

	public EpaAthLvl() {
	}

	/**
	 * @return
	 */
	public String getEpaAthLvlCd() {
		return this.epaAthLvlCd;
	}

	/**
	 * @param epaAthLvlCd
	 */
	public void setEpaAthLvlCd(String epaAthLvlCd) {
		this.epaAthLvlCd = epaAthLvlCd;
	}


	/**
	 * @return
	 */
	public String getEpaAthLvlDesc() {
		return this.epaAthLvlDesc;
	}

	/**
	 * @param epaAthLvlDesc
	 */
	public void setEpaAthLvlDesc(String epaAthLvlDesc) {
		this.epaAthLvlDesc = epaAthLvlDesc;
	}

	/**
	 * @return
	 */
	public List<EpaAthAccess> getEpaAthAccs() {
		return this.epaAthAccs;
	}

	/**
	 * @param epaAthAccs
	 */
	public void setEpaAthAccs(List<EpaAthAccess> epaAthAccesses) {
		this.epaAthAccs = epaAthAccesses;
	}

	/**
	 * @param epaAthAccess
	 * @return
	 */
	public EpaAthAccess addEpaAthAccs(EpaAthAccess epaAthAccess) {
		getEpaAthAccs().add(epaAthAccess);
		epaAthAccess.setEpaAthLvl(this);

		return epaAthAccess;
	}

	/**
	 * @param epaAthAccess
	 * @return
	 */
	public EpaAthAccess removeEpaAthAccess(EpaAthAccess epaAthAccess) {
		getEpaAthAccs().remove(epaAthAccess);
		epaAthAccess.setEpaAthLvl(null);

		return epaAthAccess;
	}

	/**
	 * @return
	 */
	public List<EpaUserAth> getEpaUserAths() {
		return this.epaUserAths;
	}

	/**
	 * @param epaUserAths
	 */
	public void setEpaUserAths(List<EpaUserAth> epaUserAths) {
		this.epaUserAths = epaUserAths;
	}

	/**
	 * @param epaUserAth
	 * @return
	 */
	public EpaUserAth addEpaUserAth(EpaUserAth epaUserAth) {
		getEpaUserAths().add(epaUserAth);
		epaUserAth.setEpaAthLvl(this);

		return epaUserAth;
	}

	/**
	 * @param epaUserAth
	 * @return
	 */
	public EpaUserAth removeEpaUserAth(EpaUserAth epaUserAth) {
		getEpaUserAths().remove(epaUserAth);
		epaUserAth.setEpaAthLvl(null);

		return epaUserAth;
	}

	public RcrdUpdtLog getRcdLog() {
		return rcdLog;
	}

	public void setRcdLog(RcrdUpdtLog rcdLog) {
		this.rcdLog = rcdLog;
	}

}