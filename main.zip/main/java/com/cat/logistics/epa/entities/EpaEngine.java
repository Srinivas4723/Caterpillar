
package com.cat.logistics.epa.entities;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.MapsId;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.Cascade;
import org.hibernate.annotations.CascadeType;


/**
 * The persistent class for the Engine database table.
 * @author singhr9
 *
 */

@Entity
@Table(name="EPA_ENG_IMPORT",schema="US_EPA_IMP")
@NamedQuery(name="EpaEngine.updateEngineNum", query="UPDATE EpaEngine e SET e.id.engineSerialNum = :engineNumber where e.epaShipment.epaSeqNum = :epaSeqNo")
public class EpaEngine implements Serializable{
	private static final long serialVersionUID = 1L;
	
	@EmbeddedId
	private EpaEnginePK id;
		
	@Column(name="EPA_MCH_SER_NO")
	private String machineSerialNum;
	
	@Column(name="EPA_XMPT_FROM_BOND")
	private String xmptFrmBond;
	
	@Column(name="EPA_BOND_NAIC_NO")
	private String bondNaicNum;
	
	@Column(name="EPA_BOND_NAIC_STATE")
	private String bondNaicState;
	
	@Column(name="EPA_BOND_PLCY_NO")
	private String bondPlcyNum;
	
	@Column(name="EPA_ENG_MAX_PWR")
	private String engMaxPower;
	
	@Column(name="EPA_ENG_PWR_UM")
	private String engPowerMeasrmt;
	
	@Column(name="EPA_ENG_FAM_NM")
	private String engFamilyname;
	
	@Column(name="EPA_TPEM_STR_LOC")
	private String storageLoc;
	
	@Column(name="EPA_OTH_SPL_CASE_XMPT")
	private String othSplCaseXmpt;
	
	@Column(name="EPA_ENG_MFR_NME")
	private String engMfrName;
	
	@Column(name="EPA_ENG_MDL_NO")
	private String engModelNum;
	
	@Column(name="EPA_XMPT_NO")
	private String exemptNum;
	
	@Column(name="EPA_MFR_DT_TYP")
	private String mfrDateType;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="EPA_ENG_MFR_DT")
	private Date epaEngineMnfDate;
		
	@Column(name="EPA_MFR_DT_SRC")
	private String mfrDateSource;
	
	@Column(name="EPA_MFR_DT_SRC_DESC")
	private String mfrDateSourceDesc;
	
	@Column(name="EPA_CERT_INDIV_SGNTR")
	private String certIndividualSign;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="EPA_CERT_DT")
	private Date certDate;
	
	@Embedded
	private RcrdUpdtLog rcdLog;
	
	@Column(name="CASE_NO")
	private String caseNo;
	
	@Column(name="CCR_NO")
	private String ccrNo;
	
	@Column(name="ADTL_ENG_SER_NO")
	private String adtlEngSerNo;
	
	public String getAdtlEngSerNo() {
		return adtlEngSerNo;
	}


	public void setAdtlEngSerNo(String adtlEngSerNo) {
		this.adtlEngSerNo = adtlEngSerNo;
	}


	@OneToOne
	@JoinColumn(name="EPA_STAT_CD", insertable=true, updatable=true)
	private EpaStatus epaStatus;
	//bi-directional many-to-one association to EpaShipment
	@OneToOne
	@Cascade({CascadeType.ALL})
	@MapsId("epaSeqNo")
	@JoinColumn(name="EPA_SEQ_NO", referencedColumnName="EPA_SEQ_NO")
	private EpaShipment epaShipment;
	
	@OneToOne
	@JoinColumn(name="EPA_ENG_IMP_TYP_CD", insertable=true, updatable=true)
	private EpaImportType epaImportType;
	
	@OneToOne
	@JoinColumn(name="EPA_ENG_IMP_PROV_TYP_CD", insertable=true, updatable=true)
	private EpaProvisionType epaProvisionType;
	
	
	public EpaEnginePK getEngPk(){
		
		return new EpaEnginePK();
	}
	
	
	public void addEngNum(String engNum){
		
		EpaEnginePK enginePk = new EpaEnginePK(engNum);
		this.id = enginePk;
	}
	
	/**
	 * @return the machineSerialNum
	 */
	public String getMachineSerialNum() {
		return machineSerialNum;
	}

	/**
	 * @param machineSerialNum the machineSerialNum to set
	 */
	public void setMachineSerialNum(String machineSerialNum) {
		this.machineSerialNum = machineSerialNum;
	}

	/**
	 * @return the xmptFrmBond
	 */
	public String getXmptFrmBond() {
		return xmptFrmBond;
	}

	/**
	 * @param xmptFrmBond the xmptFrmBond to set
	 */
	public void setXmptFrmBond(String xmptFrmBond) {
		this.xmptFrmBond = xmptFrmBond;
	}

	/**
	 * @return the bondNaicNum
	 */
	public String getBondNaicNum() {
		return bondNaicNum;
	}

	/**
	 * @param bondNaicNum the bondNaicNum to set
	 */
	public void setBondNaicNum(String bondNaicNum) {
		this.bondNaicNum = bondNaicNum;
	}

	/**
	 * @return the bondNaicState
	 */
	public String getBondNaicState() {
		return bondNaicState;
	}

	/**
	 * @param bondNaicState the bondNaicState to set
	 */
	public void setBondNaicState(String bondNaicState) {
		this.bondNaicState = bondNaicState;
	}

	/**
	 * @return the bondPlcyNum
	 */
	public String getBondPlcyNum() {
		return bondPlcyNum;
	}

	/**
	 * @param bondPlcyNum the bondPlcyNum to set
	 */
	public void setBondPlcyNum(String bondPlcyNum) {
		this.bondPlcyNum = bondPlcyNum;
	}

	/**
	 * @return the engMaxPower
	 */
	public String getEngMaxPower() {
		return engMaxPower;
	}

	/**
	 * @param engMaxPower the engMaxPower to set
	 */
	public void setEngMaxPower(String engMaxPower) {
		this.engMaxPower = engMaxPower;
	}

	/**
	 * @return the engPowerMeasrmt
	 */
	public String getEngPowerMeasrmt() {
		return engPowerMeasrmt;
	}

	/**
	 * @param engPowerMeasrmt the engPowerMeasrmt to set
	 */
	public void setEngPowerMeasrmt(String engPowerMeasrmt) {
		this.engPowerMeasrmt = engPowerMeasrmt;
	}

	/**
	 * @return the engFamilyname
	 */
	public String getEngFamilyname() {
		return engFamilyname;
	}

	/**
	 * @param engFamilyname the engFamilyname to set
	 */
	public void setEngFamilyname(String engFamilyname) {
		this.engFamilyname = engFamilyname;
	}

	/**
	 * @return the storageLoc
	 */
	public String getStorageLoc() {
		return storageLoc;
	}

	/**
	 * @param storageLoc the storageLoc to set
	 */
	public void setStorageLoc(String storageLoc) {
		this.storageLoc = storageLoc;
	}

	/**
	 * @return the othSplCaseXmpt
	 */
	public String getOthSplCaseXmpt() {
		return othSplCaseXmpt;
	}

	/**
	 * @param othSplCaseXmpt the othSplCaseXmpt to set
	 */
	public void setOthSplCaseXmpt(String othSplCaseXmpt) {
		this.othSplCaseXmpt = othSplCaseXmpt;
	}

	/**
	 * @return the engMfrName
	 */
	public String getEngMfrName() {
		return engMfrName;
	}

	/**
	 * @param engMfrName the engMfrName to set
	 */
	public void setEngMfrName(String engMfrName) {
		this.engMfrName = engMfrName;
	}

	/**
	 * @return the engModelNum
	 */
	public String getEngModelNum() {
		return engModelNum;
	}

	/**
	 * @param engModelNum the engModelNum to set
	 */
	public void setEngModelNum(String engModelNum) {
		this.engModelNum = engModelNum;
	}

	/**
	 * @return the exemptNum
	 */
	public String getExemptNum() {
		return exemptNum;
	}

	/**
	 * @param exemptNum the exemptNum to set
	 */
	public void setExemptNum(String exemptNum) {
		this.exemptNum = exemptNum;
	}

	/**
	 * @return the mfrDateType
	 */
	public String getMfrDateType() {
		return mfrDateType;
	}

	/**
	 * @param mfrDateType the mfrDateType to set
	 */
	public void setMfrDateType(String mfrDateType) {
		this.mfrDateType = mfrDateType;
	}

	/**
	 * @return the mfrDateSource
	 */
	public String getMfrDateSource() {
		return mfrDateSource;
	}

	/**
	 * @param mfrDateSource the mfrDateSource to set
	 */
	public void setMfrDateSource(String mfrDateSource) {
		this.mfrDateSource = mfrDateSource;
	}

	/**
	 * @return the mfrDateSourceDesc
	 */
	public String getMfrDateSourceDesc() {
		return mfrDateSourceDesc;
	}

	/**
	 * @param mfrDateSourceDesc the mfrDateSourceDesc to set
	 */
	public void setMfrDateSourceDesc(String mfrDateSourceDesc) {
		this.mfrDateSourceDesc = mfrDateSourceDesc;
	}

	/**
	 * @return the certIndividualSign
	 */
	public String getCertIndividualSign() {
		return certIndividualSign;
	}

	/**
	 * @param certIndividualSign the certIndividualSign to set
	 */
	public void setCertIndividualSign(String certIndividualSign) {
		this.certIndividualSign = certIndividualSign;
	}

	/**
	 * @return the certDate
	 */
	public Date getCertDate() {
		return certDate;
	}

	/**
	 * @param certDate the certDate to set
	 */
	public void setCertDate(Date certDate) {
		this.certDate = certDate;
	}

	/**
	 * @return the epaShipment
	 */
	public EpaShipment getEpaShipment() {
		return epaShipment;
	}

	/**
	 * @param epaShipments the epaShipment to set
	 */
	public void setEpaShipment(EpaShipment epaShipment) {
		this.epaShipment = epaShipment;
	}

	/**
	 * @return the epaEngineMnfDate
	 */
	public Date getEpaEngineMnfDate() {
		return epaEngineMnfDate;
	}

	/**
	 * @param epaEngineMnfDate the epaEngineMnfDate to set
	 */
	public void setEpaEngineMnfDate(Date epaEngineMnfDate) {
		this.epaEngineMnfDate = epaEngineMnfDate;
	}
	
	/**
	 * @return epaStatus
	 */
	public EpaStatus getEpaStatus() {
		return epaStatus;
	}

	/**
	 * @param epaStatus
	 */
	public void setEpaStatus(EpaStatus epaStatus) {
		this.epaStatus = epaStatus;
	}

	/**
	 * @return the epaImportType
	 */
	public EpaImportType getEpaImportType() {
		return epaImportType;
	}

	/**
	 * @param epaImportType the epaImportType to set
	 */
	public void setEpaImportType(EpaImportType epaImportType) {
		this.epaImportType = epaImportType;
	}

	/**
	 * @return the epaProvisionType
	 */
	public EpaProvisionType getEpaProvisionType() {
		return epaProvisionType;
	}

	/**
	 * @param epaProvisionType the epaProvisionType to set
	 */
	public void setEpaProvisionType(EpaProvisionType epaProvisionType) {
		this.epaProvisionType = epaProvisionType;
	}

	public RcrdUpdtLog getRcdLog() {
		return rcdLog;
	}

	public void setRcdLog(RcrdUpdtLog rcdLog) {
		this.rcdLog = rcdLog;
	}

	/**
	 * @return the id
	 */
	public EpaEnginePK getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(EpaEnginePK id) {
		this.id = id;
	}


	/**
	 * @return the caseNo
	 */
	public String getCaseNo() {
		return caseNo;
	}


	/**
	 * @param caseNo the caseNo to set
	 */
	public void setCaseNo(String caseNo) {
		this.caseNo = caseNo;
	}


	/**
	 * @return the ccrNo
	 */
	public String getCcrNo() {
		return ccrNo;
	}


	/**
	 * @param ccrNo the ccrNo to set
	 */
	public void setCcrNo(String ccrNo) {
		this.ccrNo = ccrNo;
	}
	
	

}
