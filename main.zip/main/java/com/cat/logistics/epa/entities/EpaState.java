package com.cat.logistics.epa.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;


/**
 * The persistent class for the EPA_STATES database table.
 * 
 */
@Entity
@Table(name="EPA_STATES",schema="US_EPA_IMP")
@NamedQueries({
@NamedQuery(name="EpaState.findAll", query="SELECT  e FROM EpaState e")})
public class EpaState implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private EpaStatePK id;

	@Column(name="EPA_STATE_NME")
	private String epaStateNme;

	@Embedded
	private RcrdUpdtLog rcdLog;

	/**
	 * 
	 */
	public EpaState() {
	}

	/**
	 * @return
	 */
	public EpaStatePK getId() {
		return this.id;
	}

	/**
	 * @param id
	 */
	public void setId(EpaStatePK id) {
		this.id = id;
	}

	/**
	 * @return
	 */
	public String getEpaStateNme() {
		return this.epaStateNme;
	}

	/**
	 * @param epaStateNme
	 */
	public void setEpaStateNme(String epaStateNme) {
		this.epaStateNme = epaStateNme;
	}


	public RcrdUpdtLog getRcdLog() {
		return rcdLog;
	}

	public void setRcdLog(RcrdUpdtLog rcdLog) {
		this.rcdLog = rcdLog;
	}

}