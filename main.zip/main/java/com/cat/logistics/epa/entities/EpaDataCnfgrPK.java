package com.cat.logistics.epa.entities;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the EPA_DATA_CNFGR database table.
 * 
 */
@Embeddable
public class EpaDataCnfgrPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="CNFGR_CNSTRNT")
	private String cnfgrCnstrnt;

	@Column(name="CNFGR_TYP")
	private String cnfgrTyp;

	/**
	 * constructor EpaDataCnfgrPK
	 */
	public EpaDataCnfgrPK() {
	}
	/**
	 * @return the Configure constraint
	 */
	public String getCnfgrCnstrnt() {
		return this.cnfgrCnstrnt;
	}
	/**
	 * @param cnfgrCnstrnt
	 */
	public void setCnfgrCnstrnt(String cnfgrCnstrnt) {
		this.cnfgrCnstrnt = cnfgrCnstrnt;
	}
	/**
	 * @return Configure Type
	 */
	public String getCnfgrTyp() {
		return this.cnfgrTyp;
	}
	/**
	 * @param cnfgrTyp
	 */
	public void setCnfgrTyp(String cnfgrTyp) {
		this.cnfgrTyp = cnfgrTyp;
	}

	/**
	 * equals
	 */
	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof EpaDataCnfgrPK)) {
			return false;
		}
		EpaDataCnfgrPK castOther = (EpaDataCnfgrPK)other;
		return 
			this.cnfgrCnstrnt.equals(castOther.cnfgrCnstrnt)
			&& this.cnfgrTyp.equals(castOther.cnfgrTyp);
	}

	/**
	 * @return hash code
	 */
	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.cnfgrCnstrnt.hashCode();
		hash = hash * prime + this.cnfgrTyp.hashCode();
		
		return hash;
	}
}