/**
 * 
 */
package com.cat.logistics.epa.entities;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.MapsId;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.Cascade;
import org.hibernate.annotations.CascadeType;

/**
 * The persistent class for the  database table.
 * @author singhr9
 *
 */

@Entity
@Table(name="EPA_MCH_IMPORT",schema="US_EPA_IMP")
@NamedQuery(name="EpaMachine.updateMachineNum", query="UPDATE EpaMachine m SET m.id.machineSerialNum = :machineNumber where m.epaShipment.epaSeqNum = :epaSeqNo")
public class EpaMachine implements Serializable{
	
private static final long serialVersionUID = 1L;
	
	@EmbeddedId
	private EpaMachinePK id;
		
	@Column(name="EPA_MCH_MFR_NME")
	private String mchMfrName;
	
	@Column(name="EPA_MCH_MDL_NO")
	private String mchModelNum;
	
	@Column(name="EPA_MCH_TYP_DESC")
	private String mchTypeDesc;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="EPA_MCH_MFR_DT")
	private Date mchMfrDate;
	
	@Column(name="MCH_SRC_FAC_CD")
	private String mchsrcFacCd;
	
	@Embedded
	private RcrdUpdtLog rcdLog;
		
	@OneToOne
	@Cascade({CascadeType.ALL})
	@MapsId("epaSeqNo")
	@JoinColumn(name="EPA_SEQ_NO", referencedColumnName="EPA_SEQ_NO")
	private EpaShipment epaShipment;

	public void addMchNum(String mchNum){
		EpaMachinePK mchPk = new EpaMachinePK(mchNum);
		this.id = mchPk;
	}
	

	/**
	 * @return the mchMfrName
	 */
	public String getMchMfrName() {
		return mchMfrName;
	}

	/**
	 * @return the mchModelNum
	 */
	public String getMchModelNum() {
		return mchModelNum;
	}

	/**
	 * @return the mchTypeDesc
	 */
	public String getMchTypeDesc() {
		return mchTypeDesc;
	}

	/**
	 * @return the mchMfrDate
	 */
	public Date getMchMfrDate() {
		return mchMfrDate;
	}


	/**
	 * @return the epaShipment
	 */
	public EpaShipment getEpaShipment() {
		return epaShipment;
	}


	/**
	 * @param mchMfrName the mchMfrName to set
	 */
	public void setMchMfrName(String mchMfrName) {
		this.mchMfrName = mchMfrName;
	}

	/**
	 * @param mchModelNum the mchModelNum to set
	 */
	public void setMchModelNum(String mchModelNum) {
		this.mchModelNum = mchModelNum;
	}

	/**
	 * @param mchTypeDesc the mchTypeDesc to set
	 */
	public void setMchTypeDesc(String mchTypeDesc) {
		this.mchTypeDesc = mchTypeDesc;
	}

	/**
	 * @param mchMfrDate the mchMfrDate to set
	 */
	public void setMchMfrDate(Date mchMfrDate) {
		this.mchMfrDate = mchMfrDate;
	}


	/**
	 * @param epaShipments the epaShipments to set
	 */
	public void setEpaShipment(EpaShipment epaShipment) {
		this.epaShipment = epaShipment;
	}


	public RcrdUpdtLog getRcdLog() {
		return rcdLog;
	}


	public void setRcdLog(RcrdUpdtLog rcdLog) {
		this.rcdLog = rcdLog;
	}

	/**
	 * @return the id
	 */
	public EpaMachinePK getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(EpaMachinePK id) {
		this.id = id;
	}


	/**
	 * This method is used to get the machine source facility code
	 * @return the mchsrcFacCd
	 */
	public String getMchsrcFacCd() {
		return mchsrcFacCd;
	}


	/**
	 * This method is used to set the machine source facility code
	 * @param mchsrcFacCd the mchsrcFacCd to set
	 */
	public void setMchsrcFacCd(String mchsrcFacCd) {
		this.mchsrcFacCd = mchsrcFacCd;
	}

}
