package com.cat.logistics.epa.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

/**
 * The primary key class for the EPA_ENG_IMPORT database table.
 * 
 */
@Embeddable
public class EpaEnginePK implements Serializable {
	private static final long serialVersionUID = 1L;

	@Column(name="EPA_ENG_SER_NO")
	private String engineSerialNum;

	@Column(name="EPA_SEQ_NO")
	private long epaSeqNo;

	/**
	 * Constructor of EpaEnginePK
	 */
	public EpaEnginePK() {
	}
	/**
	 * @param engineSerialNum
	 */
	public EpaEnginePK(String engineSerialNum) {
		super();
		this.engineSerialNum = engineSerialNum;
	}

	

	/** 
	 * @param other
	 * @return true or false
	 */
	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof EpaEnginePK)) {
			return false;
		}
		EpaEnginePK castOther = (EpaEnginePK)other;
		return 
			this.engineSerialNum.equals(castOther.engineSerialNum)
			&& (this.epaSeqNo == castOther.epaSeqNo);
	}
	/** 
	 *@return hash code
	 */
	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.engineSerialNum.hashCode();
		hash = hash * prime + ((int) (this.epaSeqNo ^ (this.epaSeqNo >>> 32)));
		
		return hash;
	}

	/**
	 * @return the engineSerialNum
	 */
	public String getEngineSerialNum() {
		return engineSerialNum;
	}

	/**
	 * @param engineSerialNum the engineSerialNum to set
	 */
	public void setEngineSerialNum(String engineSerialNum) {
		this.engineSerialNum = engineSerialNum;
	}
	
	/**
	 * @return Seq number
	 */
	public long getEpaSeqNo() {
		return this.epaSeqNo;
	}
	/**
	 * @param epaSeqNo
	 */
	public void setEpaSeqNo(long epaSeqNo) {
		this.epaSeqNo = epaSeqNo;
	}
}