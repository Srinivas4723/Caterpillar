package com.cat.logistics.epa.entities;

import java.io.Serializable;

import javax.persistence.Embedded;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 * The persistent class for the EPA_USER_ATH database table.
 * 
 */
@Entity
@Table(name = "EPA_USER_ATH", schema = "US_EPA_IMP")
@NamedQueries( {
		@NamedQuery(name = "EpaUserAth.findAll", query = "SELECT e FROM EpaUserAth e"),
		@NamedQuery(name = "EpaFac.findFac", query = "SELECT epaFac FROM EpaUserAth e") })
public class EpaUserAth implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private EpaUserAthPK id;

	// bi-directional many-to-one association to EpaAthLvl
	@ManyToOne
	@JoinColumn(name = "EPA_ATH_LVL_CD", insertable = false, updatable = false)
	private EpaAthLvl epaAthLvl;

	// bi-directional many-to-one association to EpaFac
	@ManyToOne
	@JoinColumn(name = "ORIG_FAC_CD", insertable = false, updatable = false)
	private EpaFac epaFac;

	// bi-directional many-to-one association to EpaUser
	@ManyToOne
	@JoinColumn(name = "EPA_USER_CWS_ID", insertable = false, updatable = false)
	private EpaUser epaUser;

	@Embedded
	private RcrdUpdtLog rcdLog;

	/**
	 * 
	 */
	public EpaUserAth() {
	}

	/**
	 * @return
	 */
	public EpaUserAthPK getId() {
		return this.id;
	}

	/**
	 * @param id
	 */
	public void setId(EpaUserAthPK id) {
		this.id = id;
	}

	/**
	 * @return
	 */
	public EpaAthLvl getEpaAthLvl() {
		return this.epaAthLvl;
	}

	/**
	 * @param epaAthLvl
	 */
	public void setEpaAthLvl(EpaAthLvl epaAthLvl) {
		this.epaAthLvl = epaAthLvl;
	}

	/**
	 * @return
	 */
	public EpaFac getEpaFac() {
		return this.epaFac;
	}

	/**
	 * @param epaFac
	 */
	public void setEpaFac(EpaFac epaFac) {
		this.epaFac = epaFac;
	}

	/**
	 * @return
	 */
	public EpaUser getEpaUser() {
		return this.epaUser;
	}

	/**
	 * @param epaUser
	 */
	public void setEpaUser(EpaUser epaUser) {
		this.epaUser = epaUser;
	}

	/**
	 * @return hash value
	 * @see java.lang.Object#hashCode()
	 * @since 1.0 Jun 14, 2015 7:46:35 PM badamrr
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}

	/**
	 * 
	 * @param obj
	 * @return true or false
	 */
	@Override
	public boolean equals(Object obj) {
		boolean results = true;
		if (this == obj)
			results = true;
		if (obj == null || !(obj instanceof EpaUserAth))
			results = false;
		EpaUserAth other = (EpaUserAth) obj;
		if (id == null) {
			if (other.id != null)
				results = false;
		} else if (!id.equals(other.id))
			results = false;
		return results;
	}

	public RcrdUpdtLog getRcdLog() {
		return rcdLog;
	}

	public void setRcdLog(RcrdUpdtLog rcdLog) {
		this.rcdLog = rcdLog;
	}

}