package com.cat.logistics.epa.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;


/**
 * The persistent class for the EPA_FAC database table.
 * 
 */
@Entity
@Table(name="EPA_STATUS",schema="US_EPA_IMP")
@NamedQueries({
@NamedQuery(name="EpaStatus.findStatDet", query="SELECT concat(epaStatusCd,'-',epaStatusDesc) FROM EpaStatus e")})
public class EpaStatus implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="EPA_STAT_CD")
	private String epaStatusCd;
	
	@Column(name="EPA_STAT_DESC")
	private String epaStatusDesc;
	
	@Embedded
	private RcrdUpdtLog rcdLog;
	

	/**
	 * @param epaStatusCd
	 */
	public EpaStatus(String epaStatusCd) {
		super();
		this.epaStatusCd = epaStatusCd;
	}

	/**
	 * 
	 */
	public EpaStatus() {
		super();
	}

	/**
	 * @return
	 */
	public String getEpaStatusCd() {
		return epaStatusCd;
	}

	/**
	 * @param epaStatusCd
	 */
	public void setEpaStatusCd(String epaStatusCd) {
		this.epaStatusCd = epaStatusCd;
	}

	/**
	 * @return
	 */
	public String getEpaStatusDesc() {
		return epaStatusDesc;
	}

	/**
	 * @param epaStatusDesc
	 */
	public void setEpaStatusDesc(String epaStatusDesc) {
		this.epaStatusDesc = epaStatusDesc;
	}

	public RcrdUpdtLog getRcdLog() {
		return rcdLog;
	}

	public void setRcdLog(RcrdUpdtLog rcdLog) {
		this.rcdLog = rcdLog;
	}
			
}