package com.cat.logistics.epa.entities;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;


/**
 * The persistent class for the EPA_ACCESS database table.
 * 
 */
@Entity
@Table(name="EPA_ACCESS",schema="US_EPA_IMP")
@NamedQuery(name="EpaAccess.findAll", query="SELECT e FROM EpaAccess e")
public class EpaAccess implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="EPA_ACCESS_CD")
	private String epaAccessCd;

	@Embedded
	RcrdUpdtLog rcrdLog;

	@Column(name="EPA_ACCESS_DESC")
	private String epaAccessDesc;


	//bi-directional many-to-one association to EpaAthAccess
	@OneToMany(mappedBy="epaAccess")
	private List<EpaAthAccess> epaAthAccesses;
/**
 * 
 */
	public EpaAccess() {
	}
/**
 * 
 * @return
 */
	public String getEpaAccessCd() {
		return this.epaAccessCd;
	}
/**
 * 
 * @param epaAccessCd
 */
	public void setEpaAccessCd(String epaAccessCd) {
		this.epaAccessCd = epaAccessCd;
	}
	
	/**
	 * 
	 * @return
	 */
	public String getEpaAccessDesc() {
		return this.epaAccessDesc;
	}
	/**
	 * 
	 * @param epaAccessDesc
	 */
	public void setEpaAccessDesc(String epaAccessDesc) {
		this.epaAccessDesc = epaAccessDesc;
	}
	/**
	 * 
	 * @return
	 */
	public List<EpaAthAccess> getEpaAthAccesses() {
		return this.epaAthAccesses;
	}
	/**
	 * 
	 * @param epaAthAccesses
	 */
	public void setEpaAthAccesses(List<EpaAthAccess> epaAthAccesses) {
		this.epaAthAccesses = epaAthAccesses;
	}
	/**
	 * 
	 * @param epaAthAccess
	 * @return
	 */
	public EpaAthAccess addEpaAthAccess(EpaAthAccess epaAthAccess) {
		getEpaAthAccesses().add(epaAthAccess);
		epaAthAccess.setEpaAccess(this);

		return epaAthAccess;
	}
	/**
	 * 
	 * @param epaAthAccess
	 * @return
	 */
	public EpaAthAccess removeEpaAthAccess(EpaAthAccess epaAthAccess) {
		getEpaAthAccesses().remove(epaAthAccess);
		epaAthAccess.setEpaAccess(null);

		return epaAthAccess;
	}
	public RcrdUpdtLog getRcrdLog() {
		return rcrdLog;
	}
	public void setRcrdLog(RcrdUpdtLog rcrdLog) {
		this.rcrdLog = rcrdLog;
	}

}