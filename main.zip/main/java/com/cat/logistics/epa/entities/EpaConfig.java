package com.cat.logistics.epa.entities;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


/**
 * The persistent class for the EPA_STATES database table.
 * 
 */
@Entity
@Table(name="EPA_CNFGR",schema="US_EPA_IMP")
public class EpaConfig implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private EpaConfigPK id;
	
	@Column(name="TYP_VAL2")
	private String valueType2;
	
	@Column(name="TYP_KEY_DESC")
	private String keyDesc;

	@Temporal(TemporalType.DATE)
	@Column(name="CRETE_TS")
	private Date createTs;

	@Column(name="CRTE_LOGON_ID")
	private String crteLogonId;

	@Column(name="LAST_UPDT_LOGON_ID")
	private String lastUpdtLogonId;

	@Temporal(TemporalType.DATE)
	@Column(name="LAST_UPDT_TS")
	private Date lastUpdtTs;

	public EpaConfig() {
	}

	/**
	 * @return the id
	 */
	public EpaConfigPK getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(EpaConfigPK id) {
		this.id = id;
	}


	/**
	 * @return the crteLogonId
	 */
	public String getCrteLogonId() {
		return crteLogonId;
	}

	/**
	 * @param crteLogonId the crteLogonId to set
	 */
	public void setCrteLogonId(String crteLogonId) {
		this.crteLogonId = crteLogonId;
	}

	/**
	 * @return the lastUpdtLogonId
	 */
	public String getLastUpdtLogonId() {
		return lastUpdtLogonId;
	}

	/**
	 * @param lastUpdtLogonId the lastUpdtLogonId to set
	 */
	public void setLastUpdtLogonId(String lastUpdtLogonId) {
		this.lastUpdtLogonId = lastUpdtLogonId;
	}

	

	/**
	 * @return
	 */
	public String getValueType2() {
		return valueType2;
	}

	/**
	 * @param valueType2
	 */
	public void setValueType2(String valueType2) {
		this.valueType2 = valueType2;
	}

	/**
	 * @return
	 */
	public String getKeyDesc() {
		return keyDesc;
	}

	/**
	 * @param keyDesc
	 */
	public void setKeyDesc(String keyDesc) {
		this.keyDesc = keyDesc;
	}

	/**
	 * @return
	 */
	public Date getCreateTs() {
		return createTs;
	}

	/**
	 * @param createTs
	 */
	public void setCreateTs(Date createTs) {
		this.createTs = createTs;
	}

	/**
	 * @return
	 */
	public Date getLastUpdtTs() {
		return lastUpdtTs;
	}

	/**
	 * @param lastUpdtTs
	 */
	public void setLastUpdtTs(Date lastUpdtTs) {
		this.lastUpdtTs = lastUpdtTs;
	}


}