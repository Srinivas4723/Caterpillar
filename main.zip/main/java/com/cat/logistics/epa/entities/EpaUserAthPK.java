package com.cat.logistics.epa.entities;

import java.io.Serializable;
import javax.persistence.*;

import com.cat.logistics.shared.utils.PersistenceConstants;

/**
 * The primary key class for the EPA_USER_ATH database table.
 * 
 */
@Embeddable
public class EpaUserAthPK implements Serializable {

	private static final long serialVersionUID = -5851424385758409418L;

	@Column(name="EPA_USER_CWS_ID", insertable=true, updatable=false)
	private String epaUserCwsId;

	@Column(name="EPA_ATH_LVL_CD", insertable=false, updatable=false)
	private String epaAthLvlCd;

	@Column(name="ORIG_FAC_CD", insertable=false, updatable=false)
	private String facCd;

	/**
	 * 
	 */
	public EpaUserAthPK() {
	}
	
	/**
	 * @param epaUserCwsId
	 * @param epaAthLvlCd
	 * @param facCd
	 */
	public EpaUserAthPK(String epaUserCwsId,String epaAthLvlCd, String facCd) {
		this.epaUserCwsId = epaUserCwsId;
		this.epaAthLvlCd  = epaAthLvlCd;
		this.facCd   	  = facCd;
	}
	
	/**
	 * @return
	 */
	public String getEpaUserCwsId() {
		return this.epaUserCwsId;
	}
	/**
	 * @param epaUserCwsId
	 */
	public void setEpaUserCwsId(String epaUserCwsId) {
		this.epaUserCwsId = epaUserCwsId;
	}
	/**
	 * @return
	 */
	public String getEpaAthLvlCd() {
		return this.epaAthLvlCd;
	}
	/**
	 * @param epaAthLvlCd
	 */
	public void setEpaAthLvlCd(String epaAthLvlCd) {
		this.epaAthLvlCd = epaAthLvlCd;
	}
	/**
	 * @return
	 */
	public String getFacCd() {
		return this.facCd;
	}
	/**
	 * @param facCd
	 */
	public void setFacCd(String facCd) {
		this.facCd = facCd;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof EpaUserAthPK)) {
			return false;
		}
		EpaUserAthPK castOther = (EpaUserAthPK)other;
		return 
			this.epaUserCwsId.equals(castOther.epaUserCwsId)
			&& this.epaAthLvlCd.equals(castOther.epaAthLvlCd)
			&& this.facCd.equals(castOther.facCd);
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	public int hashCode() {
		final int prime = 31;
		int hash = PersistenceConstants.SEVENTEEN;
		hash = hash * prime + this.epaUserCwsId.hashCode();
		hash = hash * prime + this.epaAthLvlCd.hashCode();
		hash = hash * prime + this.facCd.hashCode();
		
		return hash;
	}
	
}