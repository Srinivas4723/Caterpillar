package com.cat.logistics.epa.entities;

import java.io.Serializable;
import javax.persistence.*;

import com.cat.logistics.shared.utils.PersistenceConstants;

/**
 * The primary key class for the EPA_ATH_ACCESS database table.
 * 
 */
/**
 * @author addansn
 *
 */
@Embeddable
public class EpaAthAccessPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="EPA_ATH_LVL_CD", insertable=false, updatable=false)
	private String epaAthLvlCd;

	@Column(name="EPA_ACCESS_CD", insertable=false, updatable=false)
	private String epaAccessCd;

	public EpaAthAccessPK() {
	}
	/**
	 * 
	 * @return
	 */
	public String getEpaAthLvlCd() {
		return this.epaAthLvlCd;
	}
	/**
	 * 
	 * @param epaAthLvlCd
	 */
	public void setEpaAthLvlCd(String epaAthLvlCd) {
		this.epaAthLvlCd = epaAthLvlCd;
	}
	/**
	 * 
	 * @return
	 */
	public String getEpaAccessCd() {
		return this.epaAccessCd;
	}
	/**
	 * @param epaAccessCd
	 */
	public void setEpaAccessCd(String epaAccessCd) {
		this.epaAccessCd = epaAccessCd;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof EpaAthAccessPK)) {
			return false;
		}
		EpaAthAccessPK castOther = (EpaAthAccessPK)other;
		return 
			this.epaAthLvlCd.equals(castOther.epaAthLvlCd)
			&& this.epaAccessCd.equals(castOther.epaAccessCd);
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	public int hashCode() {
		final int prime = 31;
		int hash = PersistenceConstants.SEVENTEEN;
		hash = hash * prime + this.epaAthLvlCd.hashCode();
		hash = hash * prime + this.epaAccessCd.hashCode();
		
		return hash;
	}
}