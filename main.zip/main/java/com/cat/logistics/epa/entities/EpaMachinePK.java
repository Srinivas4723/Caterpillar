package com.cat.logistics.epa.entities;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the EPA_MCH_IMPORT database table.
 * @author ganamr
 */
@Embeddable
public class EpaMachinePK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="EPA_MCH_SER_NO")
	private String machineSerialNum;

	@Column(name="EPA_SEQ_NO")
	private long epaSeqNo;

	/**
	 * constructor
	 */
	public EpaMachinePK() {
	}
	
	/**
	 * @param machineSerialNum
	 */
	public EpaMachinePK(String machineSerialNum) {
		super();
		this.machineSerialNum = machineSerialNum;
	}

	/**
	 * @return seq No
	 */
	public long getEpaSeqNo() {
		return this.epaSeqNo;
	}
	/**
	 * @param epaSeqNo
	 */
	public void setEpaSeqNo(long epaSeqNo) {
		this.epaSeqNo = epaSeqNo;
	}
	/** 
	 * @param oth
	 * @return true or false
	 */
	public boolean equals(Object oth) {
		if (this == oth) {
			return true;
		}
		if (!(oth instanceof EpaMachinePK)) {
			return false;
		}
		EpaMachinePK castOther = (EpaMachinePK)oth;
		return 
			this.machineSerialNum.equals(castOther.machineSerialNum)
			&& (this.epaSeqNo == castOther.epaSeqNo);
	}

	/** 
	 * @return HASH code
	 */
	public int hashCode() {
		final int prime = 31;
		int hcd = 17;
		hcd = hcd * prime + this.machineSerialNum.hashCode();
		hcd = hcd * prime + ((int) (this.epaSeqNo ^ (this.epaSeqNo >>> 32)));
		return hcd;
	}

	/**
	 * @return the machineSerialNum
	 */
	public String getMachineSerialNum() {
		return machineSerialNum;
	}

	/**
	 * @param machineSerialNum the machineSerialNum to set
	 */
	public void setMachineSerialNum(String machineSerialNum) {
		this.machineSerialNum = machineSerialNum;
	}
}