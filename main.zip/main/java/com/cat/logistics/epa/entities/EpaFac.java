package com.cat.logistics.epa.entities;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;


/**
 * The persistent class for the EPA_FAC database table.
 * 
 */
@Entity
@Table(name="EPA_FAC",schema="US_EPA_IMP")
@NamedQueries({
@NamedQuery(name="EpaFac.findAll", query="SELECT e FROM EpaFac e"),
@NamedQuery(name="EpaFac.findFacDet", query="SELECT concat(facCd,'-',facilityName) FROM EpaFac e")})
public class EpaFac  implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="FAC_CD")
	private String facCd;
	
	@Column(name="FAC_NM")
	private String facilityName;
	
	@Column(name="SUPP_CD")
	private String suppCd;
	
	@Embedded
	private RcrdUpdtLog rcdLog;
	
	//bi-directional many-to-one association to EpaUserAth
	@OneToMany(mappedBy="epaFac")
	private List<EpaUserAth> epaUsrAths;
	
	@Column(name="MCH_FAC_NM")
	private String machineMfrName;
	

	public EpaFac() {
	}

	/**
	 * @param facCd
	 */
	public EpaFac(String facCd) {
		super();
		this.facCd = facCd;
	}

	/**
	 * @return
	 */
	public String getFacCd() {
		return this.facCd;
	}

	/**
	 * @param facCd
	 */
	public void setFacCd(String facCd) {
		this.facCd = facCd;
	}

	/**
	 * @return
	 */
	public List<EpaUserAth> getEpaUsrAth() {
		return this.epaUsrAths;
	}

	/**
	 * @param epaUsrAths
	 */
	public void setEpaUsrAths(List<EpaUserAth> epaUserAths) {
		this.epaUsrAths = epaUserAths;
	}

	/**
	 * @param epaUserAth
	 * @return
	 */
	public EpaUserAth addFacUserAth(EpaUserAth epaUserAth) {
		getEpaUsrAth().add(epaUserAth);
		epaUserAth.setEpaFac(this);

		return epaUserAth;
	}

	/**
	 * @param epaUserAth
	 * @return
	 */
	public EpaUserAth removeEpaUserAth(EpaUserAth epaUserAth) {
		getEpaUsrAth().remove(epaUserAth);
		epaUserAth.setEpaFac(null);

		return epaUserAth;
	}

	/**
	 * @return the facilityName
	 */
	public String getFacilityName() {
		return facilityName;
	}

	/**
	 * @param facilityName the facilityName to set
	 */
	public void setFacilityName(String facilityName) {
		this.facilityName = facilityName;
	}

	/**
	 * @return the machineMfrName
	 */
	public String getMachineMfrName() {
		return machineMfrName;
	}

	/**
	 * @param machineMfrName the machineMfrName to set
	 */
	public void setMachineMfrName(String machineMfrName) {
		this.machineMfrName = machineMfrName;
	}
/**
 * 
 * @return
 */
	public String getSuppCd() {
		return suppCd;
	}

	/**
	 * @param suppCd
	 */
	public void setSuppCd(String suppCd) {
		this.suppCd = suppCd;
	}

	public RcrdUpdtLog getRcdLog() {
		return rcdLog;
	}

	public void setRcdLog(RcrdUpdtLog rcdLog) {
		this.rcdLog = rcdLog;
	}

	
}