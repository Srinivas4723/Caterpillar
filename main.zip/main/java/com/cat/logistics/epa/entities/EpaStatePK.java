package com.cat.logistics.epa.entities;

import java.io.Serializable;
import javax.persistence.*;

import com.cat.logistics.shared.utils.PersistenceConstants;

/**
 * The primary key class for the EPA_STATES database table.
 * 
 */
@Embeddable
public class EpaStatePK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="EPA_CTRY_CD")
	private String epaCtryCd;

	@Column(name="EPA_STATE_CD")
	private String epaStateCd;

	/**
	 * 
	 */
	public EpaStatePK() {
	}
	/**
	 * @return
	 */
	public String getEpaCtryCd() {
		return this.epaCtryCd;
	}
	/**
	 * @param epaCtryCd
	 */
	public void setEpaCtryCd(String epaCtryCd) {
		this.epaCtryCd = epaCtryCd;
	}
	/**
	 * @return
	 */
	public String getEpaStateCd() {
		return this.epaStateCd;
	}
	/**
	 * @param epaStateCd
	 */
	public void setEpaStateCd(String epaStateCd) {
		this.epaStateCd = epaStateCd;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof EpaStatePK)) {
			return false;
		}
		EpaStatePK castOther = (EpaStatePK)other;
		return 
			this.epaCtryCd.equals(castOther.epaCtryCd)
			&& this.epaStateCd.equals(castOther.epaStateCd);
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	public int hashCode() {
		final int prime = 31;
		int hash = PersistenceConstants.SEVENTEEN;
		hash = hash * prime + this.epaCtryCd.hashCode();
		hash = hash * prime + this.epaStateCd.hashCode();
		
		return hash;
	}
}