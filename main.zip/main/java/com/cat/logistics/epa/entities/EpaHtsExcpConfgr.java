package com.cat.logistics.epa.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


/**
 * The persistent class for the EPA_XCPT_HTS_CNFGR database table.
 * 
 */
@Entity
@Table(name="EPA_XCPT_HTS_CNFGR",schema="US_EPA_IMP")
public class EpaHtsExcpConfgr implements Serializable {
	private static final long serialVersionUID = 1L; 
	
	@Id	
	@Column(name="EPA_XCPT_HTS_CD")
	private String excpHtsCode;
	
	@Column(name="PART_NO")
	private String partNumber;
	
	@Column(name="EPA_HTS_CNFGR")
	private String htsConfiguration;
	
	@Embedded
	private RcrdUpdtLog rcdLog;
	
	
	/**
	 * @return the excpHtsCode
	 */
	public String getExcpHtsCode() {
		return excpHtsCode;
	}

	/**
	 * @return the partNumber
	 */
	public String getPartNumber() {
		return partNumber;
	}

	/**
	 * @return the htsConfiguration
	 */
	public String getHtsConfiguration() {
		return htsConfiguration;
	}


	/**
	 * @param excpHtsCode the excpHtsCode to set
	 */
	public void setExcpHtsCode(String excpHtsCode) {
		this.excpHtsCode = excpHtsCode;
	}

	/**
	 * @param partNumber the partNumber to set
	 */
	public void setPartNumber(String partNumber) {
		this.partNumber = partNumber;
	}

	/**
	 * @param htsConfiguration the htsConfiguration to set
	 */
	public void setHtsConfiguration(String htsConfiguration) {
		this.htsConfiguration = htsConfiguration;
	}

	public RcrdUpdtLog getRcdLog() {
		return rcdLog;
	}

	public void setRcdLog(RcrdUpdtLog rcdLog) {
		this.rcdLog = rcdLog;
	}

}