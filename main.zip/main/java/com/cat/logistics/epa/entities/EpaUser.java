package com.cat.logistics.epa.entities;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.LazyCollection;
import org.hibernate.annotations.LazyCollectionOption;

import com.cat.logistics.shared.utils.PersistenceConstants;


/**
 * The persistent class for the EPA_USER database table.
 * 
 */
@Entity
@Table(name="EPA_USER",schema="US_EPA_IMP")
@NamedQuery(name="EpaUser.findAll", query="SELECT e FROM EpaUser e")
public class EpaUser implements Serializable {
	private final static long serialVersionUID = 1L;

	@Id
	@Column(name="EPA_USER_CWS_ID")
	private String epaUserCwsId;
	
	@Column(name="EPA_USER_FST_NM")
	private String firstName;
	
	@Column(name="EPA_USER_LAST_NM")
	private String lastName;
	
	@Column(name="EPA_USER_MID_NM")
	private String middleName;
	
	@Column(name="EPA_CERT_INDIV_EMAIL")
	private String officeEmail;
	
	@Column(name="EPA_CERT_INDIV_PH")
	private String phoneNumber;
	
	@Column(name="EPA_ACTV_IND")
	private String activeIndicator = PersistenceConstants.ALPHA_Y;
	
	@Column(name="ORG_NM")
	private String orgNm;
	
	@Embedded
	private RcrdUpdtLog rcdLog;

	//bi-directional many-to-one association to EpaUserAth
	@LazyCollection(LazyCollectionOption.FALSE)
	@OneToMany(mappedBy="epaUser")
	private List<EpaUserAth> userAths;

	/**
	 * 
	 */
	public EpaUser() {
	}

	/**
	 * @return
	 */
	public String getEpaUserCwsId() {
		return this.epaUserCwsId;
	}

	/**
	 * @param epaUserCwsId
	 */
	public void setEpaUserCwsId(String epaUserCwsId) {
		this.epaUserCwsId = epaUserCwsId;
	}

	/**
	 * @return
	 */
	public List<EpaUserAth> getUserAths() {
		return this.userAths;
	}

	/**
	 * @param userAths
	 */
	public void setUserAths(List<EpaUserAth> epaUserAths) {
		this.userAths = epaUserAths;
	}

	/**
	 * @param epaUserAth
	 * @return
	 */
	public EpaUserAth addUserAth(EpaUserAth epaUserAth) {
		getUserAths().add(epaUserAth);
		epaUserAth.setEpaUser(this);

		return epaUserAth;
	}

	/**
	 * @param epaUserAth
	 * @return
	 */
	public EpaUserAth removeEpaUserAth(EpaUserAth epaUserAth) {
		getUserAths().remove(epaUserAth);
		epaUserAth.setEpaUser(null);

		return epaUserAth;
	}

	/**
	 * @return Returns the serialVersionUID
	 */
	public static long getSerialVersionUID() {
		return serialVersionUID;
	}

	/**
	 *
	 * @return Returns the firstName
	 * @since 1.0 Jun 14, 2015 4:14:16 PM badamrr
	 */
	public String getFirstName() {
		return firstName;
	}

	/**
	 * @param firstName the firstName to set
	 * @since 1.0 Jun 14, 2015 4:14:16 PM badamrr
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	/**
	 * @return Returns the lastName
	 * @since 1.0 Jun 14, 2015 4:14:16 PM badamrr
	 */
	public String getLastName() {
		return lastName;
	}

	/**
	 * @param lastName the lastName to set
	 * @since 1.0 Jun 14, 2015 4:14:16 PM badamrr
	 */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	/**
	 * @return Returns the middleName
	 * @since 1.0 Jun 14, 2015 4:14:16 PM badamrr
	 */
	public String getMiddleName() {
		return middleName;
	}

	/**
	 * @param middleName the middleName to set
	 * @since 1.0 Jun 14, 2015 4:14:16 PM badamrr
	 */
	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	/**
	 * @return Returns the officeEmail
	 * @since 1.0 Jun 14, 2015 4:14:16 PM badamrr
	 */
	public String getOfficeEmail() {
		return officeEmail;
	}

	/**
	 *
	 * @param officeEmail the officeEmail to set
	 * @since 1.0 Jun 14, 2015 4:14:16 PM badamrr
	 */
	public void setOfficeEmail(String officeEmail) {
		this.officeEmail = officeEmail;
	}

	/**
	 * @return Returns the phoneNumber
	 * @since 1.0 Jun 14, 2015 4:14:16 PM badamrr
	 */
	public String getPhoneNumber() {
		return phoneNumber;
	}

	/**
	 * @param phoneNumber the phoneNumber to set
	 * @since 1.0 Jun 14, 2015 4:14:16 PM badamrr
	 */
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	/**
	 * @return Returns the activeIndicator
	 * @since 1.0 Jun 14, 2015 4:14:16 PM badamrr
	 */
	public String getActiveIndicator() {
		return activeIndicator;
	}

	/**
	 * @param activeIndicator the activeIndicator to set
	 * @since 1.0 Jun 14, 2015 4:14:16 PM badamrr
	 */
	public void setActiveIndicator(String activeIndicator) {
		this.activeIndicator = activeIndicator;
	}

	/**
	 * @return received Log
	 */
	public RcrdUpdtLog getRcdLog() {
		return rcdLog;
	}

	/**
	 * @param rcdLog
	 */
	public void setRcdLog(RcrdUpdtLog rcdLog) {
		this.rcdLog = rcdLog;
	}

	public String getOrgNm() {
		return orgNm;
	}

	public void setOrgNm(String orgNm) {
		this.orgNm = orgNm;
	}

}