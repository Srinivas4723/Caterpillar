package com.cat.logistics.epa.mail.service.encrypt;

import org.springframework.mail.javamail.JavaMailSenderImpl;

import com.cat.googletink.util.EncryptAndDecryptApplication;

public class EpaBatchJavaMailSenderImpl extends JavaMailSenderImpl{
@Override
public void setPassword(String key) {
	super.setPassword(EncryptAndDecryptApplication.decrypt(System.getProperty("tink.serverKeyset"),
			System.getProperty("tink.associateKeyset"), key));
}
}
