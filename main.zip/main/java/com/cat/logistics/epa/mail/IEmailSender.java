package com.cat.logistics.epa.mail;

public interface IEmailSender {


	/**
	 * @param message
	 */
	 void sendEmail(String message);
}
