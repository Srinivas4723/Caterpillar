package com.cat.logistics.epa.mail.service;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.MailSender;
import org.springframework.mail.SimpleMailMessage;

import com.cat.logistics.epa.job.dto.MailDTO;
import com.cat.logistics.epa.job.utils.BatchConstants;
import com.cat.logistics.epa.job.utils.BatchContext;
import com.cat.logistics.epa.job.utils.Utils;
import com.cat.logistics.epa.mail.IEmailSender;




/**
 * This class takes the responsibility of sending email when technical
 * exceptions occurs in the batch job to the configred email addresses.
 * @author chanda15
 *
 */
public class EmailSender implements IEmailSender{
	
	@Autowired
	private MailSender javaMailSender;
	
	//private ILogger logger = Logger.getInstance();
	
	private final static Logger logger = LogManager.getLogger(EmailSender.class);
	
	/** 
	 * sends email notification
	 * @see com.cat.logistics.epa.mail.IEmailSender#sendEmail(java.lang.String)
	 */
	public void sendEmail(String message){
		//logger.informationalEvent(this.getClass(), BatchConstants.MTD_SEND_EMAIL, BatchConstants.MTD_SEND_EMAIL);
		logger.info(this.getClass()+ BatchConstants.MTD_SEND_EMAIL+ BatchConstants.MTD_SEND_EMAIL);
		MailDTO mailDto = null;
		try{
		SimpleMailMessage simpleMailMessage = new SimpleMailMessage();
		mailDto = (MailDTO)BatchContext.getValue(BatchConstants.MAIL_DTO);
		if(mailDto.getMailFrom() != null){
		simpleMailMessage.setFrom(mailDto.getMailFrom());
		}else{
			simpleMailMessage.setFrom(Utils.getProperty("MAIL_FROM"));
		}
		if(mailDto.getMailTo() != null){
		simpleMailMessage.setTo(mailDto.getMailTo());
		}else{
			simpleMailMessage.setFrom(Utils.getProperty("MAIL_TO"));
		}
		if(message.contains("Auto ECCN")){
			simpleMailMessage.setSubject(getEnvironment()+" : FATAL Error occured in Auto ECCN Utility Batch Job");
		}else{
			simpleMailMessage.setSubject(getEnvironment()+" : FATAL Error occured in EPA BATCH JOB");
		}
		simpleMailMessage.setText(message);
		javaMailSender.send(simpleMailMessage);
		}catch(Exception exception){
			//logger.fatalEvent(this.getClass(), BatchConstants.MTD_SEND_EMAIL, BatchConstants.EXCE_WHILE_SENDING_EMAIL, exception);
			logger.error(this.getClass()+ BatchConstants.MTD_SEND_EMAIL+ BatchConstants.EXCE_WHILE_SENDING_EMAIL+ exception.getMessage());
		}
	}
	
	
	/**
	 * the method determines the environment where the job is running
	 * @return
	 */
	public String getEnvironment(){
		//logger.informationalEvent(this.getClass(), BatchConstants.MTD_GET_ENVIRMNT, BatchConstants.METHOD_ENTRY);
		logger.info(this.getClass()+ BatchConstants.MTD_GET_ENVIRMNT+ BatchConstants.METHOD_ENTRY);
		String currentEnvironment = null;
		
		try{
			String currentEnv = System.getProperty("ENVIRONMENT");
			if(currentEnv.equalsIgnoreCase("PROD")){
				currentEnvironment = "PR";
			}else if(currentEnv.equalsIgnoreCase("QA")){ 
				currentEnvironment = "QA";
			}else if(currentEnv.equalsIgnoreCase("TEST")){
				currentEnvironment = "Test";
			}else{
				currentEnvironment = "UT";
			}
		}catch(Exception e){
			currentEnvironment = "UT";
			//logger.fatalEvent(this.getClass(), "getEnvironment()", "exception while getting environment ", e);
			logger.error(this.getClass()+ "getEnvironment()"+ "exception while getting environment "+ e.getMessage());
		}
		//logger.informationalEvent(this.getClass(), BatchConstants.MTD_GET_ENVIRMNT, BatchConstants.METHOD_EXIT);
		logger.info(this.getClass()+ BatchConstants.MTD_GET_ENVIRMNT+ BatchConstants.METHOD_EXIT);
		return currentEnvironment;
	}
}
