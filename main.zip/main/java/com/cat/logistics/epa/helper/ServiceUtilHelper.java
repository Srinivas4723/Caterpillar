package com.cat.logistics.epa.helper;

import java.text.ParseException;
import java.util.Date;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.cat.logistics.epa.job.utils.BatchConstants;
import com.cat.logistics.shared.dto.MassUploadExcelRowDTO;
import com.cat.logistics.shared.utils.ServiceConstants;
import com.cat.logistics.shared.utils.ServiceUtils;

/**
 * 
 * @author kakars2
 *
 */
public class ServiceUtilHelper {
	
	public static final Logger LOGGER = LogManager.getLogger(ServiceUtilHelper.class);

	/**
	 * 
	 * @return logId
	 */
	public String getLogOnId(){
		LOGGER.info("Entry method of getLogOnId {}", ServiceConstants.METHOD_ENTRY);
		String logId = (String) ServiceUtils.getSession().getAttribute(ServiceConstants.LOGON_ID);
		LOGGER.info("Exit method of getLogOnId {}", ServiceConstants.METHOD_EXIT);
		return logId;
	}
	
	/**
	 * 
	 * @param massObj
	 * @param format
	 * @return date
	 * @throws ParseException
	 */
	public Date getDateOfStrDate(MassUploadExcelRowDTO massObj, String format) throws ParseException{
		LOGGER.info("Entry method of getDateOfStrDate {}", ServiceConstants.METHOD_ENTRY);
		Date date = ServiceUtils.convertStringTodate(massObj.getShippingDt(), format);
		LOGGER.info("Exit method of getDateOfStrDate {}", ServiceConstants.METHOD_EXIT);
		return date;
	}
	
	/**
	 * @return true or false
	 */
	public boolean isPrdGrpAdm(){
		boolean check=false;
		if(ServiceUtils.isProductGrpAdm()){
			check=true;
		}
		return check;
		
	}
}
