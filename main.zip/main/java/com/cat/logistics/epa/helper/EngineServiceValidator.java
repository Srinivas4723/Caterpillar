package com.cat.logistics.epa.helper;

import java.lang.reflect.Field;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.cat.logistics.epa.dto.StatusField;
import com.cat.logistics.epa.entities.EpaEngine;
import com.cat.logistics.epa.entities.EpaMachine;
import com.cat.logistics.epa.entities.EpaStatus;
import com.cat.logistics.epa.job.utils.BatchConstants;
import com.cat.logistics.shared.dto.EngineDTO;
import com.cat.logistics.shared.utils.EPAUtils;
import com.cat.logistics.shared.utils.PersistenceConstants;
import com.cat.logistics.shared.utils.ServiceConstants;
import com.cat.logistics.shared.utils.ServiceUtils;

/**
 * it validates the engine business logic
 * @author kakars2
 *
 */
public class EngineServiceValidator {
	
	public static final Logger LOGGER = LogManager.getLogger(EngineServiceValidator.class);
	
	public EngineServiceValidator() {
		super();
	}
	
	/**
	 * returns the status
	 * @param engineDTO
	 * @param machEng
	 * @return the status
	 */
	public String getStatus(EngineDTO engineDTO,boolean machEng) {
		LOGGER.info("Entry method of getStatus {}",ServiceConstants.METHOD_ENTRY);
		String status = ServiceConstants.NOT_STARTED_CD;
		Field[] engFields =engineDTO.getClass().getDeclaredFields();
		String statusByFld=null;
		for (Field field : engFields) {
			field.setAccessible(true);
			statusByFld = getEngMchStatusByField(field, engineDTO, machEng);
			if(!EPAUtils.isNullOrEmpty(statusByFld)){
				status=statusByFld;
				break;
			}
		}
	     
		if ((ServiceConstants.NS).equals(status)){
		      status = checkStatusCondition(engineDTO,machEng);
		}
		LOGGER.info("Exit method of getStatus {}",ServiceConstants.METHOD_EXIT);
		return status;
	} 

	/**
	 * Return the engine status
	 * @param engineDTO
	 * @param machEng
	 * @return String status
	 */
	public String checkStatusCondition(EngineDTO engineDTO,boolean machEng) {
	    String status = ServiceConstants.NOT_STARTED_CD;
	    String provType = null;
	    if(machEng){
	    	provType = engineDTO.getEngProvEqu();
	    }else{
	    	provType = engineDTO.getEngImpProv();
	    }
	    
	    if (provType != null) {
	      return checkProvEngFam( engineDTO, provType);
	    }

	    return status;
	  }

	  /**
	 * @param engineDTO
	 * @param importPrvType
	 * @return the engine status
	 */
	public String checkProvEngFam(EngineDTO engineDTO,String importPrvType)
	  {
		  String engStatus = ServiceConstants.NOT_STARTED_CD;
	    if ((importPrvType.equals(ServiceConstants.IMP_PROV_CD_ONE)) && (ServiceUtils.checkForNullAndNoLength(engineDTO.getEngineFamilyName()))){
	    	engStatus = ServiceConstants.MISSING_DATA_CD;
	    }
	    
	    if(!statusCheck(engStatus)){
	    	return checkProvExm(importPrvType, engineDTO);
	    }
	    return engStatus;
	    
	  }

	  /**
	 * @param importPrvType
	 * @param engineDTO
	 * @return the engine status
	 */ 
	public String checkProvExm(String importPrvType,EngineDTO engineDTO)
	  {
		  String engStatus = ServiceConstants.NOT_STARTED_CD;
	    if ((ServiceConstants.PROV_EXM_APPR.contains(importPrvType)) && (ServiceUtils.checkForNullAndNoLength(engineDTO.getEpaExemptionApprNo()))){
	    	engStatus = ServiceConstants.MISSING_DATA_CD;
	    }
	    
	    if(!statusCheck(engStatus)){
	    	return checkProvPower(importPrvType,engineDTO);
	    }
	    return engStatus;
	  }

	  /**
	 * @param importPrvType
	 * @param engineDTO
	 * @return the engine status
	 */
	public String checkProvPower(String importPrvType, EngineDTO engineDTO)
	  {
		  String engStatus = ServiceConstants.NOT_STARTED_CD;
	    if ((importPrvType.equals(ServiceConstants.IMP_PROV_CD_22)) && (ServiceUtils.checkForNullAndNoLength(engineDTO.getUnitOfMeasure()))){
	    	engStatus = ServiceConstants.MISSING_DATA_CD;
	    }
	    
	    if(!statusCheck(engStatus)){
	    	
	    	return checkProvStrg(importPrvType , engineDTO);
	    }
	    
	    return engStatus;
	  }

	  /**
	 * @param importPrvType
	 * @param engineDTO
	 * @return the engine status
	 */
	public String checkProvStrg(String importPrvType, EngineDTO engineDTO)
	  {
		  String engStatus = ServiceConstants.NOT_STARTED_CD;
	    if ((ServiceConstants.PROV_STRG_LOC.contains(importPrvType)) && (ServiceUtils.checkForNullAndNoLength(engineDTO.getLocationOfStorage()))){
	    	engStatus = ServiceConstants.MISSING_DATA_CD;
	    }
	    
	    if(!statusCheck(engStatus)){
	    	return checkProvSplExm(importPrvType, engineDTO);
	    }
	    return engStatus;
	  }

	  /**
	 * @param importPrvType
	 * @param engineDTO
	 * @return the engine status
	 */
	public String checkProvSplExm(String importPrvType, EngineDTO engineDTO)
	  {
		  String engStatus = ServiceConstants.NOT_STARTED_CD;
	      if ((importPrvType.equals(ServiceConstants.IMP_PROV_CD_25)) && (ServiceUtils.checkForNullAndNoLength(engineDTO.getOtherExemption()))){
	    	 engStatus = ServiceConstants.MISSING_DATA_CD;
	      }
	    
	    return engStatus;
	  }
	  
	  /**
	 * @param status
	 * @return the status
	 */
	public boolean statusCheck(String status){
		  
		  return status.equals(ServiceConstants.MISSING_DATA_CD);
	  }
	  
	
	/**
	 * Return the engine status
	 * @param machineDto
	 * @param engineDto
	 * @return the status
	 */
	public String getMachStatusMsg(EpaMachine machineDto, EpaEngine engineDto){
		LOGGER.info("Entry method of getMachStatusMsg {}",ServiceConstants.METHOD_ENTRY);
		String status = ServiceConstants.NS;
		if (null == machineDto.getMchModelNum()
	    		  || null == machineDto.getMchMfrDate()
	    		  || null == machineDto.getMchTypeDesc()) {
	        status = ServiceConstants.MD;
	        if (engineDto != null) {
	          EpaStatus epastatus = new EpaStatus(ServiceConstants.MD);
	          engineDto.setEpaStatus(epastatus);
	        }
	     }
		LOGGER.info("Exit method of getMachStatusMsg {}",ServiceConstants.METHOD_EXIT);
		return status;
	}

	/**
	 * Return the engine status
	 * @param machEng
	 * @param obj
	 * @param fieldName
	 * @return status
	 */
	private String getEngMchStatus(boolean machEng, Object obj, String fieldName){
		LOGGER.info("Enter method of getEngMchStatus {}",ServiceConstants.METHOD_ENTRY);
		String status = null;
		if ((machEng && !ServiceConstants.ENG_IMP_PROV
				.equals(fieldName))
				|| (!machEng && !ServiceConstants.ENG_PROV_EQU
						.equals(fieldName))) {
			status = EngMchStatusInfo(obj);
		}
		LOGGER.info("Exit method of getEngMchStatus {}",ServiceConstants.METHOD_EXIT);
		return status;
	}
	
	/**
	 * Return the engine status
	 * @param obj
	 * @return the status
	 */
	private String EngMchStatusInfo(Object obj){
		LOGGER.info("Entry method of EngMchStatusInfo {}",ServiceConstants.METHOD_ENTRY);
		String status = null;
		if (null == obj
				|| (obj instanceof String && ServiceUtils
						.checkForNullAndNoLength((String) obj))){
			status = ServiceConstants.MD;
		}
		LOGGER.info("Exit method of EngMchStatusInfo {}",ServiceConstants.METHOD_EXIT);
		return 	status;
	}
	
	/**
	 * Return the engine status
	 * @param field
	 * @param engineDTO
	 * @param machEng
	 * @return the status
	 */
	public String getEngMchStatusByField(Field field, EngineDTO engineDTO, boolean machEng){
		LOGGER.info("Entry method of getEngMchStatusByField {}",ServiceConstants.METHOD_ENTRY);
		String status = null;
		if (field.isAnnotationPresent(StatusField.class)) {
			String fieldName = field.getName();
			try {
				Object obj = field.get(engineDTO);
				status = getEngMchStatus(machEng, obj, fieldName);
			} catch (IllegalArgumentException e) {
				LOGGER.error("Error in getEngMchStatusByField {}", fieldName, e);
			} catch (IllegalAccessException e) {
				LOGGER.error("Error in getEngMchStatusByField {}", fieldName, e);
			}
		}
		LOGGER.info("Exit method of getEngMchStatusByField {}",ServiceConstants.METHOD_EXIT);
		return status;
	}
	
	/**
	 * Return the engine status of machine
	 * @param machineDto
	 * @param engineDto
	 * @return the String
	 */
	public String getMachStatus(EpaMachine machineDto, EpaEngine engineDto) {
		LOGGER.info("Entry method of getMachStatus {}",ServiceConstants.METHOD_ENTRY);
		String status = ServiceConstants.NS;
	    if ((null!=engineDto) && (!ServiceConstants.MD.equals(engineDto.getEpaStatus().getEpaStatusCd())))
	    {
	    	status = getMachStatusMsg(machineDto, engineDto);
	    }
	    LOGGER.info("Exit method of getMachStatus {}",ServiceConstants.METHOD_EXIT);
	    return status;
	}
}
