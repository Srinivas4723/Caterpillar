package com.cat.logistics.epa.helper;

import java.util.Date;
import java.util.List;
import java.util.Map;

public class FacilityWorkQueueHelper {

	/**
	 * 
	 * Property for List of Facility Code Description
	 *
	 */
	private List<String> facCdList;
	
	/**
	 * Property for List of Invoice No
	 */
	private List<String> invoiceNoList;
	/**
	 * Property for List of MSOS
	 */
	private List<String> msosList;
	/**
	 * Property for List of ESO
	 */
	private List<String> esoList;
	/**
	 * Property for List of Engine Serial No
	 */
	private List<String> engSerList;
	/**
	 * Property for List of Machine Serial No
	 */
	private List<String> machineSerNo;
	/**
	 * Property for fromShippedDate
	 */
	private Date fromShippedDate;
	/**
	 * Property for toShippedDate
	 */
	private Date toShippedDate;
	/**
	 * Property for fromBuildDate
	 */
	private Date fromBuildDate;
	/**
	 *  Property for toBuildDate
	 */
	private Date toBuildDate;
	
	private List<Map<String, String>> wrkQueSFormStatus;
	/**
	 * Property for List of Invoice No
	 */
	private List<String> frwdrRefNoList;
	/**
	 * @return the facCdList
	 */
	public List<String> getFacCdList() {
		return facCdList;
	}
	/**
	 * @param facCdList the facCdList to set
	 */
	public void setFacCdList(List<String> facCdList) {
		this.facCdList = facCdList;
	}
	/**
	 * @return the statusCdList
	 *//*
	public List<String> getStatusCdList() {
		return statusCdList;
	}*/

	/**
	 * @return the invoiceNoList
	 */
	public List<String> getInvoiceNoList() {
		return invoiceNoList;
	}
	/**
	 * @param invoiceNoList the invoiceNoList to set
	 */
	public void setInvoiceNoList(List<String> invoiceNoList) {
		this.invoiceNoList = invoiceNoList;
	}
	/**
	 * @return the msosList
	 */
	public List<String> getMsosList() {
		return msosList;
	}
	/**
	 * @param msosList the msosList to set
	 */
	public void setMsosList(List<String> msosList) {
		this.msosList = msosList;
	}
	/**
	 * @return the esoList
	 */
	public List<String> getEsoList() {
		return esoList;
	}
	/**
	 * @param esoList the esoList to set
	 */
	public void setEsoList(List<String> esoList) {
		this.esoList = esoList;
	}
	/**
	 * @return the engSerList
	 */
	public List<String> getEngSerList() {
		return engSerList;
	}
	/**
	 * @param engSerList the engSerList to set
	 */
	public void setEngSerList(List<String> engSerList) {
		this.engSerList = engSerList;
	}
	/**
	 * @return the machineSerNo
	 */
	public List<String> getMachineSerNo() {
		return machineSerNo;
	}
	/**
	 * @param machineSerNo the machineSerNo to set
	 */
	public void setMachineSerNo(List<String> machineSerNo) {
		this.machineSerNo = machineSerNo;
	}
	/**
	 * @return the fromShippedDate
	 */
	public Date getFromShippedDate() {
		return fromShippedDate;
	}
	/**
	 * @param fromShippedDate the fromShippedDate to set
	 */
	public void setFromShippedDate(Date fromShippedDate) {
		this.fromShippedDate = fromShippedDate;
	}
	/**
	 * @return the toShippedDate
	 */
	public Date getToShippedDate() {
		return toShippedDate;
	}
	/**
	 * @param toShippedDate the toShippedDate to set
	 */
	public void setToShippedDate(Date toShippedDate) { 
		this.toShippedDate = toShippedDate;
	}
	/**
	 * @return the fromBuildDate
	 */
	public Date getFromBuildDate() {
		return fromBuildDate;
	}
	/**
	 * @param fromBuildDate the fromBuildDate to set
	 */
	public void setFromBuildDate(Date fromBuildDate) {
		this.fromBuildDate = fromBuildDate;
	}
	/**
	 * @return the toBuildDate
	 */
	public Date getToBuildDate() {
		return toBuildDate;
	}
	/**
	 * @param toBuildDate the toBuildDate to set
	 */
	public void setToBuildDate(Date toBuildDate) {
		this.toBuildDate = toBuildDate;
	}
	/**
	 * @return the wrkQueSFormStatus
	 */
	public List<Map<String, String>> getWrkQueSFormStatus() {
		return wrkQueSFormStatus;
	}
	/**
	 * @param wrkQueSFormStatus the wrkQueSFormStatus to set
	 */
	public void setWrkQueSFormStatus(List<Map<String, String>> wrkQueSFormStatus) {
		this.wrkQueSFormStatus = wrkQueSFormStatus;
	}
	/**
	 * @return the frwdrRefNoList
	 */
	public List<String> getFrwdrRefNoList() {
		return frwdrRefNoList;
	}
	/**
	 * @param frwdrRefNoList the frwdrRefNoList to set
	 */
	public void setFrwdrRefNoList(List<String> frwdrRefNoList) {
		this.frwdrRefNoList = frwdrRefNoList;
	}
	
}
