package com.cat.logistics.epa.helper;

import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Disjunction;
import org.hibernate.criterion.Restrictions;

import com.cat.logistics.epa.job.utils.BatchConstants;
import com.cat.logistics.shared.utils.PersistenceConstants;

/**
 * This class has common reusable methods for criteria
 * @author chanda15
 *
 */
public class CriteriaHelper {
	public static final Logger LOGGER = LogManager.getLogger(CriteriaHelper.class);

	/**
	 * It determines this criteria should execute or not based upon status selection conditions
	 * @param status
	 * @param criteria
	 * @return boolean value
	 */
	public boolean statusCriteria(List<Map<String, String>> status,
			Criteria criteria) {
		LOGGER.info("Entry method of statusCriteria {}",
				PersistenceConstants.METHOD_ENTRY);
		boolean fetchStat = false;
		if (status != null && status.size() != 0) {
			criteria.createAlias("epaEngines.epaStatus", "epaStat");
			Disjunction multplOr = Restrictions.disjunction();
			for (Map<String, String> formStatus : status) {
				Criterion cdNclr = null;
				
				cdNclr = Restrictions.conjunction()
						.add(Restrictions.eq("epaStat.epaStatusCd", formStatus.get(PersistenceConstants.STATUS_CD)))
						.add(Restrictions.le("origShipDate", new Date()));
				multplOr.add(cdNclr);
				
				cdNclr = Restrictions.conjunction()
						.add(Restrictions.eq("epaStat.epaStatusCd", formStatus.get(PersistenceConstants.STATUS_CD)))
						.add(Restrictions.ge("origShipDate", new Date()));
				multplOr.add(cdNclr);
				
				cdNclr = Restrictions.conjunction()
						.add(Restrictions.eq("epaStat.epaStatusCd", formStatus.get(PersistenceConstants.STATUS_CD)))
						.add(Restrictions.isNull("origShipDate"));
				multplOr.add(cdNclr);
				
				cdNclr = Restrictions.conjunction()
						.add(Restrictions.eq("epaStat.epaStatusCd", formStatus.get(PersistenceConstants.STATUS_CD)));				
				multplOr.add(cdNclr);
			}
			criteria.add(multplOr);
			fetchStat = true;
		}
		LOGGER.info("Exit method of statusCriteria {}",
				PersistenceConstants.METHOD_EXIT);
		return fetchStat;
	}

	/**
	 * It determines Missing information has to be fetch or not based on selection status color  
	 * @param facWrkQueHelper
	 * @param critFrMisData
	 * @param prodType
	 * @return boolean value
	 */
	public boolean fetchMsngInfo(FacilityWorkQueueHelper facWrkQueHelper,
			Criteria critFrMisData, String prodType) {
		LOGGER.info("Entry method of fetchMsngInfo {}",
				PersistenceConstants.METHOD_ENTRY);
		boolean fetMD = false;
		Disjunction multplOR = Restrictions.disjunction();
		Criterion cdNclr = null;

		for (Map<String, String> formStatus : facWrkQueHelper.getWrkQueSFormStatus()) {
			if (PersistenceConstants.MISSING_INFO.equalsIgnoreCase(formStatus.get(PersistenceConstants.STATUS_CD))) {
				Criterion critrnNull= Restrictions.isNull(PersistenceConstants.ENG_SER_NUM_VAR);
				Criterion critrnInvld= Restrictions.eq(PersistenceConstants.ENG_SER_NUM_VAR, PersistenceConstants.INVLD_VALUE);
				cdNclr = Restrictions.conjunction().add(
						Restrictions.in("epaFac.facCd", facWrkQueHelper
								.getFacCdList())).add(
						Restrictions.le("origShipDate", new Date())).add(
						Restrictions.eq("epaProdTypeCode", prodType)).add(Restrictions.or(critrnNull,critrnInvld));
				fetMD = true;
				multplOR.add(cdNclr);
				
				Criterion critrinNull= Restrictions.isNull(PersistenceConstants.ENG_SER_NUM_VAR); 
				Criterion critrnInvlid= Restrictions.eq(PersistenceConstants.ENG_SER_NUM_VAR, PersistenceConstants.INVLD_VALUE);
				multplOR.add(Restrictions.conjunction().add(
						Restrictions.or(critrinNull,critrnInvlid)).add(
						Restrictions.in("epaFac.facCd", facWrkQueHelper
								.getFacCdList())).add(
						Restrictions.isNull("origShipDate")).add(
						Restrictions.eq("epaProdTypeCode", prodType))).add(Restrictions.ge("origShipDate", new Date()));
				fetMD = true;
			}

		}
		critFrMisData.add(multplOR);
		LOGGER.info("Exit method of fetchMsngInfo {}",
				PersistenceConstants.METHOD_EXIT);
		return fetMD;
	}

	/**
	 * Based on conditions it will add to criteria object
	 * @param facWrkQueHelper
	 * @param criteria
	 * @param serNum
	 * @return boolean value
	 */
	public boolean addShmntCrit(FacilityWorkQueueHelper facWrkQueHelper,
			Criteria criteria, String serNum, boolean engineshmt) {
		LOGGER.info("Entry method of addShmntCrit {}",
				PersistenceConstants.METHOD_ENTRY);
		
		boolean fetch = false;
		fetch = addListCrit(facWrkQueHelper.getFacCdList(), criteria,
				PersistenceConstants.FAC_CD_VAR,fetch);
		fetch = addListCrit(facWrkQueHelper.getInvoiceNoList(), criteria,
				PersistenceConstants.PRT_NUM_INVC_NUM_VAR,fetch);
		fetch = addListCrit(facWrkQueHelper.getFrwdrRefNoList(), criteria,
				PersistenceConstants.FORWARDER_REF_NUM_VAR,fetch);
		if(engineshmt){
			fetch = addListCrit(facWrkQueHelper.getEsoList(), criteria,
					PersistenceConstants.ORD_NUM_VAR,fetch);
		}else{
			fetch = addListCrit(facWrkQueHelper.getMsosList(), criteria,
					PersistenceConstants.ORD_NUM_VAR,fetch);
		}
		
		fetch = addListCrit(facWrkQueHelper.getEngSerList(), criteria, serNum,fetch);
		fetch = addListCrit(facWrkQueHelper.getMachineSerNo(), criteria, serNum,fetch);
		fetch = addDtCrit(facWrkQueHelper.getFromShippedDate(), facWrkQueHelper
				.getToShippedDate(), criteria, PersistenceConstants.ORG_SHP_DT,fetch);
		LOGGER.info("Exit method of addShmntCrit {}",
				PersistenceConstants.METHOD_EXIT);
		return fetch;
	}

	/**
	 * it determines criteria has to be appended or not 
	 * @param values
	 * @param criteria
	 * @param columnAttr
	 * @param fetchCrit
	 * @return boolean value
	 */
	public boolean addListCrit(List<String> values, Criteria criteria,
			String columnAttr,boolean fetchCrit) {
		LOGGER.info("Entry method of addListCrit {}",
				PersistenceConstants.METHOD_ENTRY);
		if (values != null && values.size() != 0) {
			criteria.add(Restrictions.in(columnAttr, values));
			fetchCrit = true;
		}
		LOGGER.info("Exit method of addListCrit {}",
				PersistenceConstants.METHOD_EXIT);
		return fetchCrit;
	}

	/**
	 * @param from
	 * @param to
	 * @param criteria
	 * @param columnAttr
	 * @param dtfetch
	 * @return boolean value
	 */
	public boolean addDtCrit(Date from, Date to, Criteria criteria,
			String columnAttr,boolean dtfetch) {
		LOGGER.info("Enter method of addDtCrit {}",
				PersistenceConstants.METHOD_ENTRY);
		if (from != null && to != null) {
			criteria.add(Restrictions.ge(columnAttr, from));
			criteria.add(Restrictions.le(columnAttr, to));
			dtfetch = true;
		}
		LOGGER.info("Exit method of addDtCrit {}",
				PersistenceConstants.METHOD_EXIT);
		return dtfetch;
	}
}
