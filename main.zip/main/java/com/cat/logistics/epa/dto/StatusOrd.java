package com.cat.logistics.epa.dto;

import com.cat.logistics.shared.utils.ServiceConstants;


/**
 * This class holds status information
 * @author chanda15
 *
 */
public class StatusOrd {

	private String color;
	
	private String statusCd;

	/**
	 * @return status color
	 */
	public String getColor() {
		return color;
	}

	/**
	 * @param color
	 */
	public void setColor(String color) {
		this.color = color;
	}

	/**
	 * @return status code
	 */
	public String getStatusCd() {
		return statusCd;
	}

	/**
	 * @param statusCd
	 */
	public void setStatusCd(String statusCd) {
		this.statusCd = statusCd;
	}
	
	/**
	 * @param color
	 * @param statusCd
	 */
	public StatusOrd(String color,String statusCd){
		this.color = color;
		this.statusCd = statusCd;
	}

	/** 
	 * default hash code mechanism
	 */
	  @Override
	    public int hashCode() {
	        int hash = ServiceConstants.INT_7;
	        hash = ServiceConstants.INT_97 * hash + (this.color != null ? this.color.hashCode() : 0);
	        hash = ServiceConstants.INT_97 * hash + (this.statusCd != null ? this.statusCd.hashCode() : 0);
	        return hash;
	    }
	  /** 
		 * default equals mechanism
		 */
	  @Override
	    public boolean equals(Object obj) {
	        if (obj == null) {
	            return false;
	        }
	        if (getClass() != obj.getClass()) {
	            return false;
	        }
	        StatusOrd other = (StatusOrd) obj;
		    return color == other.color && 
	        		(statusCd == other.statusCd || (statusCd != null && statusCd.equals(other.getStatusCd()))); 
	        		


	    }
	
	
}
