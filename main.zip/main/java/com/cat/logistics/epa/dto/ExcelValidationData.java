package com.cat.logistics.epa.dto;

/**
 * ExcelValidationData object
 * @author kakars2
 *
 * @param <T>
 */
public class ExcelValidationData<T> {
	
	private String errorMessage;
	private T response;
	/**
	 * 
	 * @return T
	 */
	public T getResponse() {
		return response;
	}
	
	/**
	 * 
	 * @param response
	 */
	public void setResponse(T response) {
		this.response = response;
	}

	/**
	 * 
	 * @return errorMessage
	 */
	public String getErrorMessage() {
		return errorMessage;
	}

	/**
	 * 
	 * @param errorMessage
	 */
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
	
	
}
