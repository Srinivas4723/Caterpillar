package com.cat.logistics.epa.dto;

import java.sql.Date;
import java.sql.Timestamp;

/**
 * This class holds Shipment related information
 * @author ganamr
 *
 */
public class EpaShipmentDTO {

	String itmSeqNo;
	
	String invoiceNum;	
	
	String partNum;
	
	String epaProdTypeCode;
	
	String machineManufactureName;
	
	Timestamp suppLdTmstmp;
	
	private String productSerialNum ; 

	private String origFacCd;
	
	private String rcvgFacCd;
	
	private Timestamp suppLoadTmstmp;
	
	private Date origShipDate;
	
	private String suppCd;
	
	private String originCtry;
	
	private String destCtry;
	
	private String orderNum;
	
	private String htsCode;
	
	private String dealerCode;
	
	private String salesMdlNo;
	
	private boolean newEngShmt;
	
	private boolean validHtsCd;
	
	private String partType;
	

	/**
	 * @return the itmSeqNo
	 */
	public String getItmSeqNo() {
		return itmSeqNo;
	}

	/**
	 * @param itmSeqNo
	 */
	public void setItmSeqNo(String itmSeqNo) {
		this.itmSeqNo = itmSeqNo;
	}

	/**
	 * @return the invoiceNum
	 *//*
	public String getInvoiceNumber() {
		return invoiceNum;
	}*/

	/**
	 * @param invoiceNumber
	 */
	public void setInvoiceNumber(String invoiceNumber) {
		this.invoiceNum = invoiceNumber;
	}

	/**
	 * @return the partNum
	 */
	public String getPartNum() {
		return partNum;
	}

	/**
	 * @param partNum
	 */
	public void setPartNum(String partNum) {
		this.partNum = partNum;
	}

	/**
	 * @return the suppLdTmstmp
	 */
	public Timestamp getSuppLdTmstmp() {
		return suppLdTmstmp;
	}

	/**
	 * @param suppLdTmstmp
	 */
	public void setSuppLdTmstmp(Timestamp suppLdTmstmp) {
		this.suppLdTmstmp = suppLdTmstmp;
	}

	/**
	 * @return the origFacCd
	 */
	public String getOrigFacCd() {
		return origFacCd;
	}

	/**
	 * @param origFacCd
	 */
	public void setOrigFacCd(String origFacCd) {
		this.origFacCd = origFacCd;
	}

	/**
	 * @return the suppLoadTmstmp
	 */
	public Timestamp getSuppLoadTmstmp() {
		return suppLoadTmstmp;
	}

	/**
	 * @param suppLoadTmstmp
	 */
	public void setSuppLoadTmstmp(Timestamp suppLoadTmstmp) {
		this.suppLoadTmstmp = suppLoadTmstmp;
	}

	/**
	 * @return the origShipDate
	 */
	public Date getOriginshpDate() {
		return origShipDate;
	}

	/**
	 * @param originshpDate
	 */
	public void setOriginshpDate(Date originshpDate) {
		this.origShipDate = originshpDate;
	}

	/**
	 * @return the suppCd
	 */
	public String getSuppCd() {
		return suppCd;
	}

	/**
	 * @param suppCd
	 */
	public void setSuppCd(String suppCd) {
		this.suppCd = suppCd;
	}

	/**
	 * @return the originCtry
	 */
	public String getOriginCtry() {
		return originCtry;
	}

	/**
	 * @param originCtry
	 */
	public void setOriginCtry(String originCtry) {
		this.originCtry = originCtry;
	}

	/**
	 * @return the destCtry
	 */
	public String getDestCtry() {
		return destCtry;
	}

	/**
	 * @param destCtry
	 */
	public void setDestCtry(String destCtry) {
		this.destCtry = destCtry;
	}

	/**
	 * @return the orderNum
	 */
	public String getLoadNum() {
		return orderNum;
	}

	/**
	 * @param loadNum
	 */
	public void setLoadNum(String loadNum) {
		this.orderNum = loadNum;
	}

	
	/**
	 * @return the productSerialNum
	 */
	public String getProductSerialNum() {
		return productSerialNum;
	}

	/**
	 * @param productSerialNum
	 */
	public void setProductSerialNum(String productSerialNum) {
		if(productSerialNum != null)
		this.productSerialNum = productSerialNum.trim();
	}

	/**
	 * @return the htsCode
	 */
	public String getHtsCode() {
		return htsCode;
	}

	/**
	 * @param htsCode
	 */
	public void setHtsCode(String htsCode) {
		this.htsCode = htsCode;
	}

	/**
	 * @return the epaProdTypeCode
	 */
	public String getEpaProdTypeCode() {
		return epaProdTypeCode;
	}

	/**
	 * @param partType
	 */
	public void setEpaProdTypeCode(String partType) {
		this.epaProdTypeCode = partType;
	}

	/**
	 * @return the invoiceNum
	 */
	public String getInvoiceNum() {
		return invoiceNum;
	}

	/**
	 * @param invoiceNum
	 */
	public void setInvoiceNum(String invoiceNum) {
		this.invoiceNum = invoiceNum;
	}

	/**
	 * @return the epaProdTypeCode
	 *//*
	public String getEpaProdTypeCode() {
		return epaProdTypeCode;
	}*/

	/**
	 * @param epaProdTypeCode
	 *//*
	public void setEpaProdTypeCode(String epaProdTypeCode) {
		this.epaProdTypeCode = epaProdTypeCode;
	}*/

	/**
	 * @return the origShipDate
	 */
	public Date getOrigShipDate() {
		return origShipDate;
	}

	/**
	 * @param origShipDate
	 */
	public void setOrigShipDate(Date origShipDate) {
		this.origShipDate = origShipDate;
	}

	/**
	 * @return the orderNum
	 */
	public String getOrderNum() {
		return orderNum;
	}

	/**
	 * @param orderNum
	 */
	public void setOrderNum(String orderNum) {
		this.orderNum = orderNum;
	}

	/**
	 * @return the dealerCode
	 */
	public String getDealerCode() {
		return dealerCode;
	}

	/**
	 * @param dealerCode
	 */
	public void setDealerCode(String dealerCode) {
		this.dealerCode = dealerCode;
	}

	/**
	 * @return the salesMdlNo
	 */
	public String getSalesMdlNo() {
		return salesMdlNo;
	}

	/**
	 * @param salesMdlNo
	 */
	public void setSalesMdlNo(String salesMdlNo) {
		this.salesMdlNo = salesMdlNo;
	}

	/**
	 * @return the rcvgFacCd
	 */
	public String getRcvgFacCd() {
		return rcvgFacCd;
	}

	/**
	 * @param rcvgFacCd
	 */
	public void setRcvgFacCd(String rcvgFacCd) {
		this.rcvgFacCd = rcvgFacCd;
	}

	/**
	 * @return the machineManufactureName
	 */
	public String getMachineManufactureName() {
		return machineManufactureName;
	}

	/**
	 * @param machineManufactureName
	 */
	public void setMachineManufactureName(String machineManufactureName) {
		this.machineManufactureName = machineManufactureName;
	}

	/**
	 * @return true or false
	 */
	public boolean isNewEngShmt() {
		return newEngShmt;
	}

	/**
	 * @param newEngShmt
	 */
	public void setNewEngShmt(boolean newEngShmt) {
		this.newEngShmt = newEngShmt;
	}

	public boolean isValidHtsCd() {
		return validHtsCd;
	}

	public void setValidHtsCd(boolean validHtsCd) {
		this.validHtsCd = validHtsCd;
	}

	public String getPartType() {
		return partType;
	}

	public void setPartType(String partType) {
		this.partType = partType;
	}

	
	
}
