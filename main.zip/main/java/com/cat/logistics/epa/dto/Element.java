package com.cat.logistics.epa.dto;


/**
 * This class holds engine data for reflection purpose 
 * @author chanda15
 *
 */
public class Element {

	
	String eng_ser_no;
	String fld_id;
	String fld_val;
	String dta_src;
	
	/**
	 * @return the engine serial number
	 */
	public String getEng_ser_no() {
		return eng_ser_no;
	}
	/**
	 * @param eng_ser_no
	 */
	public void setEng_ser_no(String eng_ser_no) {
		this.eng_ser_no = eng_ser_no;
	}
	/**
	 * @return the field id
	 */
	public String getFld_id() {
		return fld_id;
	}
	/**
	 * @param fld_id
	 */
	public void setFld_id(String fld_id) {
		this.fld_id = fld_id;
	}
	/**
	 * @return the field value
	 */
	public String getFld_val() {
		return fld_val;
	}
	/**
	 * @param fld_val
	 */
	public void setFld_val(String fld_val) {
		this.fld_val = fld_val;
	}
	/**
	 * @return the data source
	 */
	public String getDta_src() {
		return dta_src;
	}
	/**
	 * @param dta_src
	 */
	public void setDta_src(String dta_src) {
		this.dta_src = dta_src;
	}
	/**
	 * @return last updated time stamp
	 */
	public String getLd_ts() {
		return ld_ts;
	}
	/**
	 * @param ld_ts
	 */
	public void setLd_ts(String ld_ts) {
		this.ld_ts = ld_ts;
	}
	String ld_ts;
}
