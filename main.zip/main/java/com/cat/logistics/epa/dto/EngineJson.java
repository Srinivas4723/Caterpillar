package com.cat.logistics.epa.dto;


import java.util.Arrays;


/**
 * This class holds Engine related information 
 * @author chanda15
 *
 */
public class EngineJson {

String name;
	
	Element[] elements;
	
	Errors[] errors;

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the elements
	 */
	public Element[] getElements() {
		return  elements == null ? null : Arrays.copyOf(elements,elements.length) ;
	}

	/**
	 * @param elements
	 */
	public void setElements(Element[] elements) {
		this.elements =  elements == null ? null :  (Element[]) elements.clone();
	}

	/**
	 * @return the errors
	 */
	public Errors[] getErrors() {
		return  errors == null ? null : Arrays.copyOf(errors,errors.length) ;
	}

	/**
	 * @param errors
	 */
	public void setErrors(Errors[] errors) {
		this.errors =  errors == null ? null :  (Errors[]) errors.clone();
	}
}
