package com.cat.logistics.epa.dto;

/**
 * This class holds Error details
 * @author ganamr
 *
 */
public class Errors {

	String code;
	
	String message;

	/**
	 * @return error code
	 */
	public String getCode() {
		return code;
	}

	/**
	 * @param code
	 */
	public void setCode(String code) {
		this.code = code;
	}

	/**
	 * @return error message
	 */
	public String getMessage() {
		return message;
	}

	/**
	 * @param message
	 */
	public void setMessage(String message) {
		this.message = message;
	}
}
