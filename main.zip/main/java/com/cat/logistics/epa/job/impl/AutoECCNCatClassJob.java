/**
 * 
 *//*
package com.cat.logistics.epa.job.impl;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cat.logistics.epa.job.IAutoECCNCatClassProcess;
import com.cat.logistics.epa.job.utils.ApplicationException;

*//**
 * @author addansn
 *
 *//*
@Component
public class AutoECCNCatClassJob implements Runnable {

	@Autowired
	IAutoECCNCatClassProcess autoECCNCatClassProcess;
	
	public void run() {
		
		try {
			autoECCNCatClassProcess.processFilesToMQ();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ApplicationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
*/