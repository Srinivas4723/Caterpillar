package com.cat.logistics.epa.job.dto;

/**
 * This class Stores information about a mail form Type data
 * @author chanda15
 *
 */
public class MailDTO {

	private String mailFrom;
	
	private String mailTo;

	/**
	 * @return the mailFrom
	 */
	public String getMailFrom() {
		return mailFrom;
	}

	/**
	 * @param mailFrom
	 */
	public void setMailFrom(String mailFrom) {
		this.mailFrom = mailFrom;
	}

	/**
	 * @return the mailTo
	 */
	public String getMailTo() {
		return mailTo;
	}

	/**
	 * @param mailTo
	 */
	public void setMailTo(String mailTo) {
		this.mailTo = mailTo;
	}
}
