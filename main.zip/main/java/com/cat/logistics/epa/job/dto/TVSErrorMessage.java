package com.cat.logistics.epa.job.dto;

import java.util.Date;

/**
 * This class Stores information about a TVS Error logging data
 * @author chanda15
 *
 */
public class TVSErrorMessage {

	private String sourceSystem;

	private String keyValue;

	private String errorCode;

	private String errorDetails;

	private int maxErrorLevel;

	private String incmgMsgFileNm;
	
	private String invoiceNumber;
	
	private String orderNumber;
	
	private String suppCode;
	
	private String origFacility;
	
	private String partnumber;
	
	private Date msgRcvdTmstmp;

	/**
	 * @param keyValue
	 * @param sourceSystem
	 * @param errorCode
	 * @param errorDetails
	 * @param incomingMessageFileName
	 */
	public TVSErrorMessage(String keyValue,String sourceSystem,String errorCode,String errorDetails,String incmgMsgFileNm) {
		this.keyValue = keyValue;
		this.sourceSystem = sourceSystem;
		this.errorCode = errorCode;
		this.errorDetails = errorDetails;
		this.incmgMsgFileNm = incmgMsgFileNm;
		
	}
	
	/**
	 * @return sourceSystem
	 */
	public String getSourceSystem() {
		return sourceSystem;
	}

	/**
	 * @param sourceSystem
	 */
	public void setSourceSystem(String sourceSystem) {
		this.sourceSystem = sourceSystem;
	}

	/**
	 * @return keyValue
	 */
	public String getKeyValue() {
		return keyValue;
	}

	/**
	 * @param keyValue
	 */
	public void setKeyValue(String keyValue) {
		this.keyValue = keyValue;
	}

	/**
	 * @return errorCode
	 */
	public String getErrorCode() {
		return errorCode;
	}

	/**
	 * @param errorCode
	 */
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	/**
	 * @return errorDetails
	 */
	public String getErrorDetails() {
		return errorDetails;
	}

	/**
	 * @param errorDetails
	 */
	public void setErrorDetails(String errorDetails) {
		this.errorDetails = errorDetails;
	}

	/**
	 * @return maxErrorLevel
	 */
	public int getMaxErrorLevel() {
		return maxErrorLevel;
	}

	/**
	 * @param maxErrorLevel
	 */
	public void setMaxErrorLevel(int maxErrorLevel) {
		this.maxErrorLevel = maxErrorLevel;
	}

	/**
	 * @return invoiceNumber
	 */
	public String getInvoiceNumber() {
		return invoiceNumber;
	}

	/**
	 * @param invoiceNumber
	 */
	public void setInvoiceNumber(String invoiceNumber) {
		this.invoiceNumber = invoiceNumber;
	}

	/**
	 * @return orderNumber
	 */
	public String getOrderNumber() {
		return orderNumber;
	}

	/**
	 * @param orderNumber
	 */
	public void setOrderNumber(String orderNumber) {
		this.orderNumber = orderNumber;
	}

	/**
	 * @return suppCode
	 */
	public String getSuppCode() {
		return suppCode;
	}

	/**
	 * @param suppCode
	 */
	public void setSuppCode(String suppCode) {
		this.suppCode = suppCode;
	}

	/**
	 * @return origFacility
	 */
	public String getOrigFacility() {
		return origFacility;
	}

	/**
	 * @param origFacility
	 */
	public void setOrigFacility(String origFacility) {
		this.origFacility = origFacility;
	}

	/**
	 * @return partnumber
	 */
	public String getPartnumber() {
		return partnumber;
	}

	/**
	 * @param partnumber
	 */
	public void setPartnumber(String partnumber) {
		this.partnumber = partnumber;
	}

	/**
	 * @return msgRcvdTmstmp
	 */
	public Date getMsgRcvdTmstmp() {
		return msgRcvdTmstmp;
	}

	/**
	 * @param msgRcvdTmstmp
	 */
	public void setMsgRcvdTmstmp(Date msgRcvdTmstmp) {
		this.msgRcvdTmstmp = msgRcvdTmstmp;
	}

	/**
	 * @return the incmgMsgFileNm
	 */
	public String getIncmgMsgFileNm() {
		return incmgMsgFileNm;
	}

	/**
	 * @param incmgMsgFileNm the incmgMsgFileNm to set
	 */
	public void setIncmgMsgFileNm(String incmgMsgFileNm) {
		this.incmgMsgFileNm = incmgMsgFileNm;
	}
}
