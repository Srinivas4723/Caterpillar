package com.cat.logistics.epa.job.service;

import java.util.List;
import java.util.Map;

import com.cat.logistics.epa.dto.EpaShipmentDTO;
import com.cat.logistics.epa.entities.EpaEngine;
import com.cat.logistics.epa.entities.EpaHtsConfgr;
import com.cat.logistics.epa.entities.EpaHtsExcpConfgr;
import com.cat.logistics.epa.entities.EpaShipment;
import com.cat.logistics.shared.dto.EngineDTO;
import com.cat.logistics.shared.dto.MachineDTO;
import com.cat.logistics.shared.exception.DaoException;
import com.cat.logistics.shared.exception.ServiceException;
import com.cat.logistics.tis.entities.HTSCodes;

/**
 * @author ganamr
 *
 */
 public interface IEPAService {

	
	/**
	 * @param partShpmnts
	 * @throws Exception
	 */
	 void partDetermination(Map<String,EpaShipmentDTO> partShpmnts,boolean checkEpaRqurd) throws Exception;
	
	/**
	 * @param engineShpmntDTO
	 * @param engineDTO
	 * @throws ServiceException
	 */
	 void createEngineShipment(EpaShipmentDTO engineShpmntDTO,EngineDTO engineDTO) throws ServiceException;
	
	/**
	 * @param engineShpmntDTO
	 * @param engineDTO
	 * @param machineDTO
	 * @throws ServiceException
	 */
	 void crteMachShp(EpaShipmentDTO engineShpmntDTO,
			EngineDTO engineDTO,MachineDTO machineDTO) throws ServiceException;
	
	/**
	 * @param engineShpmnt
	 * @throws ServiceException
	 */
	// void saveShipment(EpaShipment engineShpmnt) throws ServiceException;
	
	/**
	 * @throws ServiceException
	 */
	 void readMailConfigData() throws ServiceException;
	
	/**
	 * @throws ServiceException
	 */
	/* void logStartTime() throws ServiceException;*/
	 
	 /**
	 * @throws ServiceException
	 */
	 void logStartTime(String jobName) throws ServiceException;
	
	/**
	 * @throws ServiceException
	 */
	 void logEndTime(String jobName) throws ServiceException;
	
	/**
	 * 
	 */
	 void saveLstSccsTm(String jobName) throws ServiceException;
	 /**
	  * 
	  * @param shpmntDto
	  * @return
	  * @throws ServiceException
	  */
	 EpaHtsConfgr getEpaHtsCnfgr(String htsCode)
		throws ServiceException;
	 /**
	  * 
	  * @param partNum
	  * @param htsCode
	  * @return
	  * @throws DaoException
	  */
	 EpaHtsExcpConfgr getEpHtsExcpConfgr(String partNum,String htsCode) throws ServiceException;
	 
	 /**
	  * 
	  * @param htsCode
	  * @param partNum
	  * @return
	  * @throws ServiceException
	  */
	 public boolean validEpaHtsCd(HTSCodes htsCode,List<EpaHtsConfgr> epaHtsCnfgList) throws ServiceException;
	 
	 /**
	  * 
	  * @return
	  */
	 public List<EpaHtsConfgr> getEpaHtsCds();
	 /**
	  * 
	  * @param epaShpmntDto
	  * @param partType
	  * @param exception
	  */
	 public void setEpaPartType(EpaShipmentDTO epaShpmntDto, String partType,
				boolean exception);
	 
	 /**
	  * This method return engine list by using engine status code
		 * @param epaStatCd
		 * @return
		 * @throws DaoException
		 */
		public List<EpaShipment> getEngineByStatus(String epaStatCd) throws ServiceException;
		
		/**
		 * this method updates existing engine details
		 * @param exisEpaEngine
		 * @param updatedEpaEng
		 * @throws ServiceException
		 */
		public void updateExisEngine(EpaEngine exisEpaEngine,EngineDTO updatedEpaEngDto) throws ServiceException;
	
	
	 
}
