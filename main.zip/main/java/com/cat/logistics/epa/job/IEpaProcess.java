package com.cat.logistics.epa.job;


/**
 * @author chanda15
 *
 */
public interface IEpaProcess {

	/**
	 * epaProcess
	 */
	void epaProcess();
	

	/**
	 * epadatarefresherProcess
	 */
	void epaDataRefresherProcess();
	
}
