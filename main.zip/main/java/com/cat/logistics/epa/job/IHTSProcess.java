package com.cat.logistics.epa.job;

import com.cat.logistics.shared.exception.ServiceException;

public interface IHTSProcess {
	/**
	 * process to check for hts classification
	 * changes for part numbers which need EPA certification
	 */
	void htsCdMonitor() throws Exception;
}
