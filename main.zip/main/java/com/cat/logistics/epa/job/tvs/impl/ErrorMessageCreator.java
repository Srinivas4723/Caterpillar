package com.cat.logistics.epa.job.tvs.impl;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import com.cat.logistics.epa.dto.EpaShipmentDTO;
import com.cat.logistics.epa.job.dto.TVSErrorMessage;
import com.cat.logistics.epa.job.tvs.IErrorMessageCreator;
import com.cat.logistics.epa.job.tvs.ITVSErrorLogger;
import com.cat.logistics.epa.job.utils.BatchConstants;
import com.cat.logistics.epa.job.utils.BatchConstants.ERR_CODES;
import com.cat.logistics.shared.utils.PersistenceConstants;
import com.cat.logistics.shared.utils.ServiceUtils;
import com.cat.tvsgrief.service.ITVSGriefUtilityService;
import com.cat.logistics.epa.job.utils.Utils;

/**
 * This class is for to create Error message and Error code
 * @author chanda15
 *
 */
public class ErrorMessageCreator implements IErrorMessageCreator{
	
	@Autowired
	private ITVSErrorLogger tvsErrorLogger;
	
	@Autowired
	private ITVSGriefUtilityService tVSGriefUtilityService;
	
	public static final Logger LOGGER = LogManager.getLogger(ErrorMessageCreator.class);
	
	/** 
	 * creates Error msg if HTS configuration not found
	 * @see com.cat.logistics.epa.job.tvs.IErrorMessageCreator#logHTSNotFoundError(com.cat.logistics.epa.dto.EpaShipmentDTO)
	 */
	public void logHTSNotFoundError(EpaShipmentDTO epaShipmentDTO){
		LOGGER.info("Entry method of logHTSNotFoundError {}", BatchConstants.LOGGING_ERR_CD_TO_TVS);
		String errorDetails = populateErrDet(BatchConstants.ERR_040,epaShipmentDTO);
		createTVSError(
				getKeyValue(epaShipmentDTO), ERR_CODES.ERR_040.toString(), errorDetails);
	}
	
	/** 
	 * 	creates error message if database connection fails  
	 * * @see com.cat.logistics.epa.job.tvs.IErrorMessageCreator#databaseConnErr(com.cat.logistics.epa.dto.EpaShipmentDTO)
	 */
	@Override
	public void databaseConnErr(EpaShipmentDTO epaShipmentDTO) {
		LOGGER.info("Entry method of databaseConnErr {}", BatchConstants.LOGGING_ERR_CD_TO_TVS);
		String errorDetails = populateErrDet(BatchConstants.ERR_995,epaShipmentDTO);
		 createTVSError(
				getKeyValue(epaShipmentDTO), ERR_CODES.ERR_995.toString(),errorDetails);
		
	}

	/** 
	 * Error message if Engine Info not found
	 * @see com.cat.logistics.epa.job.tvs.IErrorMessageCreator#engineInfoNotFound(com.cat.logistics.epa.dto.EpaShipmentDTO)
	 */
	@Override
	public void engineInfoNotFound(EpaShipmentDTO epaShipmentDTO) {
		LOGGER.info("Entry method of engineInfoNotFound {}", BatchConstants.LOGGING_ERR_CD_TO_TVS);
		String errorDetail = populateErrDet(BatchConstants.ERR_224_1,epaShipmentDTO);
		
		 createTVSError(
				getKeyValue(epaShipmentDTO), ERR_CODES.ERR_224.toString(), errorDetail);
		
	}

	/** 
	 * @see com.cat.logistics.epa.job.tvs.IErrorMessageCreator#engineSerialNumMissing(com.cat.logistics.epa.dto.EpaShipmentDTO)
	 */
	@Override
	public void engineSerialNumMissing(EpaShipmentDTO epaShipmentDTO) {
		LOGGER.info("Entry method of engineSerialNumMissing {}", BatchConstants.LOGGING_ERR_CD_TO_TVS);
		String errorDetail = populateErrDet(BatchConstants.ERR_023_1,epaShipmentDTO);
		
		createTVSError(
				getKeyValue(epaShipmentDTO), ERR_CODES.ERR_023.toString(), errorDetail);
		
	}

	/** 
	 * creates Error msg for if origfacsuppcode is invalid
	 * @see com.cat.logistics.epa.job.tvs.IErrorMessageCreator#invalidOrigFacSuppCode(com.cat.logistics.epa.dto.EpaShipmentDTO)
	 */
	@Override
	public void invalidOrigFacSuppCode(EpaShipmentDTO epaShipmentDTO) {
		LOGGER.info("Entry method of invalidOrigFacSuppCode {}", BatchConstants.LOGGING_ERR_CD_TO_TVS);
		String errorDetails = populateErrDet(BatchConstants.ERR_223,epaShipmentDTO);
		
		 createTVSError(
				getKeyValue(epaShipmentDTO).toString(), ERR_CODES.ERR_223.toString(), errorDetails);
		
	}

	/** creates error msg if no exception hts err
	 * @see com.cat.logistics.epa.job.tvs.IErrorMessageCreator#logNoExcptnHTSError(com.cat.logistics.epa.dto.EpaShipmentDTO)
	 */
	@Override
	public void logNoExcptnHTSError(EpaShipmentDTO epaShipmentDTO) {
		LOGGER.info("Entry method of logNoExcptnHTSError {}", BatchConstants.LOGGING_ERR_CD_TO_TVS);
		String htsErrDet = populateErrDet(BatchConstants.ERR_040_1,epaShipmentDTO);
		 createTVSError(
				getKeyValue(epaShipmentDTO), ERR_CODES.ERR_040.toString(),htsErrDet );
		
	}

	/** (non-Javadoc)
	 * @see com.cat.logistics.epa.job.tvs.IErrorMessageCreator#machEngInfoNotFound(com.cat.logistics.epa.dto.EpaShipmentDTO)
	 */
	@Override
	public void machEngInfoNotFound(EpaShipmentDTO epaShipmentDTO) {
		LOGGER.info("Entry method of machEngInfoNotFound {}", BatchConstants.LOGGING_ERR_CD_TO_TVS);
		String errDetails = populateErrDet(BatchConstants.ERR_224_3,epaShipmentDTO);
		createTVSError(
				getKeyValue(epaShipmentDTO), ERR_CODES.ERR_224.toString(), errDetails);
		
	}

	/** create the error msg for if machine info not found
	 * @see com.cat.logistics.epa.job.tvs.IErrorMessageCreator#machineInfoNotFound(com.cat.logistics.epa.dto.EpaShipmentDTO)
	 */
	@Override
	public void machineInfoNotFound(EpaShipmentDTO epaShipmentDTO) {
		LOGGER.info("Entry method of machineInfoNotFound {}", BatchConstants.LOGGING_ERR_CD_TO_TVS);
		String errorDetails = populateErrDet(BatchConstants.ERR_224_2,epaShipmentDTO);
		createTVSError(
				getKeyValue(epaShipmentDTO), ERR_CODES.ERR_224.toString(), errorDetails);
		
	}

	/**create error msg for if machine serial number missing
	 * @see com.cat.logistics.epa.job.tvs.IErrorMessageCreator#machineSerialNumMissing(com.cat.logistics.epa.dto.EpaShipmentDTO)
	 */
	@Override
	public void machineSerialNumMissing(EpaShipmentDTO epaShipmentDTO) {
		LOGGER.info("Entry method of machineSerialNumMissing {}", BatchConstants.LOGGING_ERR_CD_TO_TVS);
		String errDetails = populateErrDet(BatchConstants.ERR_023_2,epaShipmentDTO);
		createTVSError(
				getKeyValue(epaShipmentDTO), ERR_CODES.ERR_023.toString(), errDetails);
		
	}

	/** creates error message for origin facility not configured in epa
	 * @see com.cat.logistics.epa.job.tvs.IErrorMessageCreator#originFacNotCnfgrEPA(com.cat.logistics.epa.dto.EpaShipmentDTO)
	 */
	@Override
	public void originFacNotCnfgrEPA(EpaShipmentDTO epaShipmentDTO) {
		LOGGER.info("Entry method of originFacNotCnfgrEPA {}", BatchConstants.LOGGING_ERR_CD_TO_TVS);
		String errorDetails = populateErrDet(BatchConstants.ERR_308,epaShipmentDTO);
		 createTVSError(
				getKeyValue(epaShipmentDTO).toString(), ERR_CODES.ERR_308.toString(), errorDetails);
		
		
	}
	
	/** 
	 * @see com.cat.logistics.epa.job.tvs.IErrorMessageCreator#userNotAssgndFac(com.cat.logistics.epa.dto.EpaShipmentDTO)
	 */
	@Override
	public void userNotAssgndFac(EpaShipmentDTO epaShipmentDTO) {
		LOGGER.info("Entry method of userNotAssgndFac {}", BatchConstants.LOGGING_ERR_CD_TO_TVS);
		String errorDetails = populateErrDet(BatchConstants.ERR_219,epaShipmentDTO);
		 createTVSError(
				getKeyValue(epaShipmentDTO).toString(), ERR_CODES.ERR_219.toString(), errorDetails);
		
		
	}

	/** 
	 * @see com.cat.logistics.epa.job.tvs.IErrorMessageCreator#webServiceConnErr(com.cat.logistics.epa.dto.EpaShipmentDTO)
	 * @param epaShipmentDTO
	 */
	@Override
	public void webServiceConnErr(EpaShipmentDTO epaShipmentDTO) {
		LOGGER.info("Entry method of webServiceConnErr {}", BatchConstants.LOGGING_ERR_CD_TO_TVS);
		String errorDetails = populateErrDet(BatchConstants.ERR_998,epaShipmentDTO);
		 createTVSError(
				getKeyValue(epaShipmentDTO), ERR_CODES.ERR_998.toString(),errorDetails );
		
	}
	
	/**
	 * @param epaShipmentDTO
	 * @return key value
	 */
	public String getKeyValue(EpaShipmentDTO epaShipmentDTO){
		StringBuilder keyVal = new StringBuilder();
		keyVal.append(epaShipmentDTO.getLoadNum()).append(BatchConstants.HYPHEN).append(
				epaShipmentDTO.getInvoiceNum());
		return keyVal.toString();
	}
	
	/**
	 * @param keyVal
	 * @param errorCode
	 * @param errorDetail
	 */
	public void createTVSError(String keyVal,String errorCode,String errorDetail){
		
		try {
			tVSGriefUtilityService.storeErrorMessage(BatchConstants.EPA_SOURCE_SYSTEM, ServiceUtils.getTimeStamp(),
					keyVal, errorCode, errorDetail, BatchConstants.EPA_INPUT_FILE);
		} catch (com.cat.tvsgrief.shared.dao.TvsDaoException e) {
			e.printStackTrace();
		}
		 
		
	}
	
	/**
	 * @param errorCode
	 * @param epaShipmentDTO
	 * @return Error details
	 */
	public String populateErrDet(String errorCode,EpaShipmentDTO epaShipmentDTO){
		LOGGER.info("Entry method of populateErrDet {}", BatchConstants.METHOD_ENTRY);
	String errorDetails = Utils.getProperty(errorCode);
	StringBuilder error = new StringBuilder(errorDetails);
	
		replaceString(BatchConstants.ORDER_NUM_VAR,epaShipmentDTO.getLoadNum(),error);
		replaceString(BatchConstants.INVOICE_NUM_HOLDER,epaShipmentDTO.getInvoiceNum(),error);
		replaceString(BatchConstants.SUPP_CD_HOLDER,epaShipmentDTO.getSuppCd(),error);
		replaceString(BatchConstants.ORIG_FAC_CD_HOLDER,epaShipmentDTO.getOrigFacCd(),error);
		replaceString(BatchConstants.PART_NUM_HOLDER,epaShipmentDTO.getPartNum(),error);
		if(errorDetails.contains(BatchConstants.HTS_CD_HOLDER)){
			replaceString(BatchConstants.HTS_CD_HOLDER,epaShipmentDTO.getHtsCode(),error);
		}
		if(errorDetails.contains(BatchConstants.ENG_SER_HOLDER)){
			replaceString(BatchConstants.ENG_SER_HOLDER,epaShipmentDTO.getProductSerialNum(),error);
		}
		if(errorDetails.contains(BatchConstants.MCH_SER_HOLDER)){
			replaceString(BatchConstants.MCH_SER_HOLDER,epaShipmentDTO.getProductSerialNum(),error);
		}
		LOGGER.info("Exit method of populateErrDet {}", BatchConstants.METHOD_EXIT);
		return error.toString();
	}
	
	/**
	 * @param from
	 * @param with
	 * @param builder
	 */
	public void replaceString(String from , String strTo,StringBuilder builder){
		String	replace=strTo;
		if(strTo == null){
			replace = BatchConstants.NA;}
		
		int index = builder.indexOf(from);
		if(index != -1){
		builder.replace(index, index+from.length(),replace );
		}
	}
}
