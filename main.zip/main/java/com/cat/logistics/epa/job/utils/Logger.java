/**
 * Copyright (c) Caterpillar Inc. All Rights Reserved. This work contains
 * Caterpillar Inc.'s unpublished proprietary information which may constitute a
 * trade secret and/or be confidential. This work may be used only for the
 * purposes for which it was provided, and may not be copied or disclosed to
 * others. Copyright notice is precautionary only, and does not imply
 * publication.
 *
 * Logger.java Class Description : Revision History Version Date Changed By
 * Comments 1.0 09-02-2014 singhr9 Initial Creation
 */
/*
 * 
 * package com.cat.logistics.epa.job.utils;
 * 
 * import cat.cis.tuf.common.directory.Person; import
 * cat.cis.tuf.common.logging.EventDispatcher; import
 * cat.cis.tuf.common.logging.FatalEvent; import
 * cat.cis.tuf.common.logging.InformationalEvent; import
 * cat.cis.tuf.common.logging.LoggerConfiguration; import
 * cat.cis.tuf.common.logging.TraceEvent; import
 * cat.cis.tuf.common.logging.UsageEvent; import
 * cat.cis.tuf.common.logging.WarningEvent; import
 * cat.cis.tuf.common.util.Counter; import cat.cis.tuf.common.util.TUFUtils;
 * import cat.cis.tuf.server.util.TUFServerUtil;
 * 
 *//**
	 * This class implements the different level of logging
	 */
/*
 * public class Logger implements ILogger {
 * 
 * public static final String THE_APPLICATION = BatchConstants.APPLICATION;
 * 
 * private static ILogger instance = null;
 * 
 *//**
	 * Logger()
	 */
/*
 * private Logger() { super(); init(); }
 * 
 *//**
	 * init()
	 */
/*
 * protected void init() {
 * 
 * LoggerConfiguration lc = new LoggerConfiguration(THE_APPLICATION,
 * TUFServerUtil.getInstance().getProperties(
 * BatchConstants.LOG_PROPERTIES_FILE)); EventDispatcher.register(lc);
 * 
 * }
 * 
 *//**
	 * Method Description : getInstance
	 * 
	 * @return ILogger
	 */
/*
 * public static ILogger getInstance() { if (instance == null) { instance = new
 * Logger(); } return instance; }
 * 
 *//**
	 * @param classReference
	 * @param methodName
	 * @exception e
	 */
/*
 * @SuppressWarnings("rawtypes") public void fatalEvent(Class classReference,
 * String methodName, String message, Exception e) { try { new
 * FatalEvent(THE_APPLICATION, Counter.getNext(), classReference .getName(),
 * methodName, message, getDetails(e)); } catch (Exception ee) {
 * ee.getMessage(); } }
 *//**
	 * @param classReference
	 * @param methodName
	 */
/*
 * @SuppressWarnings("rawtypes") public void informationalEvent(Class classRef,
 * String methodName, String message) { try { new
 * InformationalEvent(THE_APPLICATION, Counter.getNext(), classRef.getName(),
 * methodName, message); } catch (Exception ex) { ex.getMessage(); } }
 * 
 *//**
	 * java.lang.String, boolean)
	 */
/*
 * @SuppressWarnings("rawtypes") public void traceEvent(int requestId, Class
 * classReference, String methodName, boolean begin) {
 * 
 * try { new TraceEvent(THE_APPLICATION, requestId, classReference.getName(),
 * methodName, begin);
 * 
 * } catch (Exception e) { e.getMessage(); } }
 * 
 *//**
	* 
	*/
/*
 * @SuppressWarnings("rawtypes") public void usageEvent(Class classReference,
 * Person person, long elapsed) { try { new UsageEvent(THE_APPLICATION,
 * Counter.getNext(), classReference .getName(), person, elapsed); } catch
 * (Exception e) { e.getMessage(); } }
 * 
 *//**
	 * Implements the logging of Warning event
	 */
/*
 * @SuppressWarnings("rawtypes") public void warningEvent(Class classReference,
 * String methodName, String message) { try { new WarningEvent(THE_APPLICATION,
 * Counter.getNext(), classReference .getName(), methodName, message); } catch
 * (Exception e) { e.getMessage(); } }
 * 
 *//**
	 * @param e
	 * @return exception details
	 */
/*
 * private String getDetails(Exception e) { String details = "Details: " +
 * TUFUtils.getInstance().generateExceptionDetails(e); return details; }
 * 
 *//**
	 * Method Description : setMockLogger
	 * 
	 * @param log void
	 *//*
		 * public static void setMockLogger(ILogger log) { instance = log; }
		 * 
		 * }
		 */