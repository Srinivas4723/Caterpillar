/**
 * Copyright (c) 2011 Caterpillar Inc. All Rights Reserved.
 * This work contains Caterpillar Inc.'s unpublished
 * proprietary information which may constitute a trade secret
 * and/or be confidential. This work may be used only for the
 * purposes for which it was provided, and may not be copied
 * or disclosed to others. Copyright notice is precautionary
 * only, and does not imply publication.
 */
package com.cat.logistics.epa.job.utils;
/**
 * This class handles exceptions generated while FTPing.
 */

public class FTPException extends Exception {
	private static final long serialVersionUID = 9999L;
	
	private Exception targetException = null;

	/**
	 * 
	 * Update constructor documentation for FTPException
	 * Description of the constructor.
	 *
	 * @param ftpException FTPException run time
	 * @since 1.0 Mar 3, 2015 3:00:09 PM badamrr
	 */
	public FTPException(final Exception ftpException) {
		super();
		setTargetException(ftpException);
	}

	/**
	 * 
	 * Update constructor documentation for FTPException
	 * Description of the constructor.
	 *
	 * @param message message
	 * @since 1.0 Mar 3, 2015 3:00:42 PM badamrr
	 */
	public FTPException(final String message) {
		super(message);
	}


	/**
	 * 
	 * Update constructor documentation for FTPException
	 * Description of the constructor.
	 *
	 * @param str String 
	 * @param tE technical error
	 * @since 1.0 Mar 3, 2015 3:01:07 PM badamrr
	 */
	public FTPException(final String str, final Exception techErr) {
		super(str);
		setTargetException(techErr);
	}


	/**
	 * @return Exception
	 */
	public Exception getTargetException() {
		return targetException;
	}

	/**
	 * @param Exception targetException
	 */
	private void setTargetException(final Exception targetException) {
		this.targetException = targetException;
	}
}
