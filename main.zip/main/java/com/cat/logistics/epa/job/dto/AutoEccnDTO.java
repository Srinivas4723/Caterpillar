package com.cat.logistics.epa.job.dto;
import org.springframework.beans.factory.annotation.Value;

public class AutoEccnDTO {

	private String fileTyp;
	private String rjn;
	private String facCd;
	private String partNo;
	private String vers;
	private String chgLvl;
	private String partTyp;
	private String ntceTyp;
	private String partNm;
	private String dsgnCtlCd;
	private String eMdl;
	private String engrMdlNm;
	private String prodFamDesc;
	private String slsMdl;
	private String dccDesc;
	private String dccEmail;
	private String dccDeptNm;
	private String dccSectNm;
	private String prdctEccn;
	private String drftTnl;
	private String clsBy;
	private String rvwBy;
	private String lastRvwDt;
	@Value( "${dburl}" )
	private String dburl;
	@Value( "${eccnuser}" )
	private String eccnuser;
	@Value( "${eccnkey}" )
	private String eccnkey;
	@Value( "${driver}" )
	private String driver;
	@Value( "${mqmanager}" )
	private String mqmanager;
	@Value( "${mqchannel}" )
	private String mqchannel;
	@Value( "${mqhost}" )
	private String mqhost;
	@Value( "${mqport}" )
	private String mqport;

	/**
	 * @return the fileTyp
	 */
	public String getFileTyp() {
		return fileTyp;
	}

	/**
	 * @param fileTyp
	 *            the fileTyp to set
	 */
	public void setFileTyp(String fileTyp) {
		this.fileTyp = fileTyp;
	}

	/**
	 * @return the rjn
	 */
	public String getRjn() {
		return rjn;
	}

	/**
	 * @param rjn
	 *            the rjn to set
	 */
	public void setRjn(String rjn) {
		this.rjn = rjn;
	}

	/**
	 * @return the facCd
	 */
	public String getFacCd() {
		return facCd;
	}

	/**
	 * @param facCd
	 *            the facCd to set
	 */
	public void setFacCd(String facCd) {
		this.facCd = facCd;
	}

	/**
	 * @return the partNo
	 */
	public String getPartNo() {
		return partNo;
	}

	/**
	 * @param partNo
	 *            the partNo to set
	 */
	public void setPartNo(String partNo) {
		this.partNo = partNo;
	}

	/**
	 * @return the vers
	 */
	public String getVers() {
		return vers;
	}

	/**
	 * @param vers
	 *            the vers to set
	 */
	public void setVers(String vers) {
		this.vers = vers;
	}

	/**
	 * @return the chgLvl
	 */
	public String getChgLvl() {
		return chgLvl;
	}

	/**
	 * @param chgLvl
	 *            the chgLvl to set
	 */
	public void setChgLvl(String chgLvl) {
		this.chgLvl = chgLvl;
	}

	/**
	 * @return the partTyp
	 */
	public String getPartTyp() {
		return partTyp;
	}

	/**
	 * @param partTyp
	 *            the partTyp to set
	 */
	public void setPartTyp(String partTyp) {
		this.partTyp = partTyp;
	}

	/**
	 * @return the ntceTyp
	 */
	public String getNtceTyp() {
		return ntceTyp;
	}

	/**
	 * @param ntceTyp
	 *            the ntceTyp to set
	 */
	public void setNtceTyp(String ntceTyp) {
		this.ntceTyp = ntceTyp;
	}

	/**
	 * @return the partNm
	 */
	public String getPartNm() {
		return partNm;
	}

	/**
	 * @param partNm
	 *            the partNm to set
	 */
	public void setPartNm(String partNm) {
		this.partNm = partNm;
	}

	/**
	 * @return the dsgnCtlCd
	 */
	public String getDsgnCtlCd() {
		return dsgnCtlCd;
	}

	/**
	 * @param dsgnCtlCd
	 *            the dsgnCtlCd to set
	 */
	public void setDsgnCtlCd(String dsgnCtlCd) {
		this.dsgnCtlCd = dsgnCtlCd;
	}

	/**
	 * @return the eMdl
	 */
	public String geteMdl() {
		return eMdl;
	}

	/**
	 * @param eMdl
	 *            the eMdl to set
	 */
	public void seteMdl(String eMdl) {
		this.eMdl = eMdl;
	}

	/**
	 * @return the engrMdlNm
	 */
	public String getEngrMdlNm() {
		return engrMdlNm;
	}

	/**
	 * @param engrMdlNm
	 *            the engrMdlNm to set
	 */
	public void setEngrMdlNm(String engrMdlNm) {
		this.engrMdlNm = engrMdlNm;
	}

	/**
	 * @return the prodFamDesc
	 */
	public String getProdFamDesc() {
		return prodFamDesc;
	}

	/**
	 * @param prodFamDesc
	 *            the prodFamDesc to set
	 */
	public void setProdFamDesc(String prodFamDesc) {
		this.prodFamDesc = prodFamDesc;
	}

	/**
	 * @return the slsMdl
	 */
	public String getSlsMdl() {
		return slsMdl;
	}

	/**
	 * @param slsMdl
	 *            the slsMdl to set
	 */
	public void setSlsMdl(String slsMdl) {
		this.slsMdl = slsMdl;
	}

	/**
	 * @return the dccDesc
	 */
	public String getDccDesc() {
		return dccDesc;
	}

	/**
	 * @param dccDesc
	 *            the dccDesc to set
	 */
	public void setDccDesc(String dccDesc) {
		this.dccDesc = dccDesc;
	}

	/**
	 * @return the dccEmail
	 */
	public String getDccEmail() {
		return dccEmail;
	}

	/**
	 * @param dccEmail
	 *            the dccEmail to set
	 */
	public void setDccEmail(String dccEmail) {
		this.dccEmail = dccEmail;
	}

	/**
	 * @return the dccDeptNm
	 */
	public String getDccDeptNm() {
		return dccDeptNm;
	}

	/**
	 * @param dccDeptNm
	 *            the dccDeptNm to set
	 */
	public void setDccDeptNm(String dccDeptNm) {
		this.dccDeptNm = dccDeptNm;
	}

	/**
	 * @return the dccSectNm
	 */
	public String getDccSectNm() {
		return dccSectNm;
	}

	/**
	 * @param dccSectNm
	 *            the dccSectNm to set
	 */
	public void setDccSectNm(String dccSectNm) {
		this.dccSectNm = dccSectNm;
	}

	/**
	 * @return the prdctEccn
	 */
	public String getPrdctEccn() {
		return prdctEccn;
	}

	/**
	 * @param prdctEccn
	 *            the prdctEccn to set
	 */
	public void setPrdctEccn(String prdctEccn) {
		this.prdctEccn = prdctEccn;
	}

	/**
	 * @return the drftTnl
	 */
	public String getDrftTnl() {
		return drftTnl;
	}

	/**
	 * @param drftTnl
	 *            the drftTnl to set
	 */
	public void setDrftTnl(String drftTnl) {
		this.drftTnl = drftTnl;
	}

	/**
	 * @return the clsBy
	 */
	public String getClsBy() {
		return clsBy;
	}

	/**
	 * @param clsBy
	 *            the clsBy to set
	 */
	public void setClsBy(String clsBy) {
		this.clsBy = clsBy;
	}

	/**
	 * @return the rvwBy
	 */
	public String getRvwBy() {
		return rvwBy;
	}

	/**
	 * @param rvwBy
	 *            the rvwBy to set
	 */
	public void setRvwBy(String rvwBy) {
		this.rvwBy = rvwBy;
	}

	/**
	 * @return the lastRvwDt
	 */
	public String getLastRvwDt() {
		return lastRvwDt;
	}

	/**
	 * @param lastRvwDt
	 *            the lastRvwDt to set
	 */
	public void setLastRvwDt(String lastRvwDt) {
		this.lastRvwDt = lastRvwDt;
	}

	/**
	 * @return
	 */
	@Override
	public boolean equals(Object obj) {
		if (obj instanceof AutoEccnDTO) {
            return ((AutoEccnDTO) obj).partNo == partNo;
        }
        return false;
    }

	/**
	 * @return the dburl
	 */
	public String getDburl() {
		return dburl;
	}

	/**
	 * @param dburl the dburl to set
	 */
	public void setDburl(String dburl) {
		this.dburl = dburl;
	}

	/**
	 * @return the eccnuser
	 */
	public String getEccnuser() {
		return eccnuser;
	}

	/**
	 * @param eccnuser the eccnuser to set
	 */
	public void setEccnuser(String eccnuser) {
		this.eccnuser = eccnuser;
	}

	/**
	 * @return the eccnkey
	 */
	public String getEccnkey() {
		return eccnkey;
	}

	/**
	 * @param eccnkey the eccnkey to set
	 */
	public void setEccnkey(String eccnkey) {
		this.eccnkey = eccnkey;
	}

	/**
	 * @return the driver
	 */
	public String getDriver() {
		return driver;
	}

	/**
	 * @param driver the driver to set
	 */
	public void setDriver(String driver) {
		this.driver = driver;
	}

	/**
	 * @return the mqmanager
	 */
	public String getMqmanager() {
		return mqmanager;
	}

	/**
	 * @param mqmanager the mqmanager to set
	 */
	public void setMqmanager(String mqmanager) {
		this.mqmanager = mqmanager;
	}

	/**
	 * @return the mqchannel
	 */
	public String getMqchannel() {
		return mqchannel;
	}

	/**
	 * @param mqchannel the mqchannel to set
	 */
	public void setMqchannel(String mqchannel) {
		this.mqchannel = mqchannel;
	}

	/**
	 * @return the mqhost
	 */
	public String getMqhost() {
		return mqhost;
	}

	/**
	 * @param mqhost the mqhost to set
	 */
	public void setMqhost(String mqhost) {
		this.mqhost = mqhost;
	}

	/**
	 * @return the mqport
	 */
	public String getMqport() {
		return mqport;
	}

	/**
	 * @param mqport the mqport to set
	 */
	public void setMqport(String mqport) {
		this.mqport = mqport;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "AutoEccnDTO [dburl=" + dburl + ", eccnuser=" + eccnuser
				+ ", eccnkey=" + eccnkey + ", driver=" + driver
				+ ", mqmanager=" + mqmanager + ", mqchannel=" + mqchannel
				+ ", mqhost=" + mqhost + ", mqport=" + mqport + "]";
	}
	
	
}
