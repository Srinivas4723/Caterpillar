package com.cat.logistics.epa.job.tvs;

import com.cat.logistics.epa.job.dto.TVSErrorMessage;

/**
 * @author ganamr
 *
 */
public interface ITVSErrorLogger {

	/**
	 * @param tvsErrorMessage
	 */
	public void logErrorMessage(TVSErrorMessage tvsErrorMessage);
}
