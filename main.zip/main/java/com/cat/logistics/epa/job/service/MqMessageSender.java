/**
 * Copyright (c) Caterpillar Inc. All Rights Reserved.
 * This work contains Caterpillar Inc.'s unpublished proprietary information
 * which may constitute a trade secret and/or be confidential. This work 
 * may be used only for the purposes for which it was provided, and may 
 * not be copied or disclosed to others. Copyright notice is precautionary 
 * only, and does not imply publication.
 *
 * Logger.java
 * Class Description  : 
 * Revision History
 * Version        Date         Changed By        Comments
 *  1.0           Dec 22, 2015      kk3           Initial Creation
 */
package com.cat.logistics.epa.job.service;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import com.cat.logistics.epa.job.dto.AutoEccnDTO;
import com.cat.logistics.epa.job.utils.ApplicationException;
import com.cat.logistics.epa.job.utils.BatchConstants;
import com.ibm.mq.MQEnvironment;
import com.ibm.mq.MQException;
import com.ibm.mq.MQMessage;
import com.ibm.mq.MQPutMessageOptions;
import com.ibm.mq.MQQueue;
import com.ibm.mq.MQQueueManager;
import com.ibm.mq.constants.MQConstants;

public class MqMessageSender implements IMqMessageSender {

	private static Logger logger = LogManager.getLogger(MqMessageSender.class);
	
	/**
	 * This method used to send message to the source queue
	 * 
	 * @param mqDetails
	 * @param msgString
	 * @param fileName
	 * @param fileType
	 * @throws ApplicationException
	 */
	@Override
	public void sendMQMsgToSrcQueue(String msgString, String fileName, String fileType, AutoEccnDTO autoEccnDTO) throws ApplicationException {
		logger.info("Entry method of sendMQMsgToSrcQueue{}",BatchConstants.METHOD_ENTRY);
		String mqQManager = null;
		String mqQName = null;
		MQMessage message = null;
		MQQueue queue = null;
		MQQueueManager qMgr = null;

		try {
			connectMqEnvironment(autoEccnDTO);
			mqQManager = autoEccnDTO.getMqmanager();
			qMgr = new MQQueueManager(mqQManager);
			int openOptions = MQConstants.MQOO_OUTPUT | MQConstants.MQOO_FAIL_IF_QUIESCING;
			mqQName = BatchConstants.MQ_NAME;
			logger.info("sendMQMsgToSrcQueue{}", mqQName); 
			queue = qMgr.accessQueue(mqQName, openOptions, null, null, null);
			MQPutMessageOptions pmo = new MQPutMessageOptions();

			if (null != msgString) {

				StringBuffer headrInfo = new StringBuffer();
				headrInfo.append(BatchConstants.MQ_HDR_FL_NAME);
				headrInfo.append(fileName);
				headrInfo.append(BatchConstants.MQ_HDR_FL_TYP);
				headrInfo.append(fileType);
				headrInfo.append(BatchConstants.MQ_HDR_END);

				message = new MQMessage();
				message.writeString(msgString);

				queue.put(message, pmo);
				qMgr.commit();
				System.out.println("MQ msg placed successfully");
			} else {
				logger.warn("Exit method of sendMQMsgToSrcQueue {}",BatchConstants.NULL_PSD);
			}

		} catch (MQException ex) {
			ex.printStackTrace();

		} catch (Exception e) {
			e.printStackTrace();
			logger.error("Error in MqMessageSender {}",e.getMessage(), e);
			throw new ApplicationException(this.getClass(), BatchConstants.SND_MQ_MSG_TO_SRC_QUEUE, BatchConstants.SEVERITY_FATAL,
					e.getMessage());
		} finally {
			closeConnection(queue, qMgr);
		}
		logger.info(BatchConstants.SND_MQ_MSG_TO_SRC_QUEUE, BatchConstants.METHOD_EXIT);
	}

	/**
	 * Method used to set MQ Details.
	 * 
	 * @param mqDetails
	 */
	private void connectMqEnvironment(AutoEccnDTO autoEccnDTO) {
		try{
		logger.info("Entry method {} {}",BatchConstants.CONN_MQ_ENV+"-"+autoEccnDTO.getMqhost()+"-"+autoEccnDTO.getMqchannel()+"-"+autoEccnDTO.getMqport(), BatchConstants.METHOD_ENTRY);
		MQEnvironment.hostname = autoEccnDTO.getMqhost();
		MQEnvironment.channel = autoEccnDTO.getMqchannel();
		MQEnvironment.port = Integer.parseInt(autoEccnDTO.getMqport());
		}catch(Exception e){
			e.printStackTrace();
			logger.error("Error in connectMqEnvironment {}",e.getMessage(), e);
		}
		logger.info("Exit method {} {}",BatchConstants.CONN_MQ_ENV, BatchConstants.METHOD_EXIT);

	}

	private void closeConnection(MQQueue queue, MQQueueManager qMgr) {
		logger.info("Entry method {} {}",BatchConstants.CLOSE_CONN, BatchConstants.METHOD_ENTRY);
		if (null != queue && null != qMgr) {
			try {
				queue.close();
				qMgr.disconnect();
			} catch (MQException e) {
				logger.error("Error in closeConnection {}",e.getMessage(), e);
			}
			logger.info("Exit method {} {}",BatchConstants.CLOSE_CONN, BatchConstants.METHOD_EXIT);
		}

	}

}
