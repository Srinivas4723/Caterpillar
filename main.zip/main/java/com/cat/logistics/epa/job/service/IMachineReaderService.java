package com.cat.logistics.epa.job.service;

import java.util.List;
import java.util.Map;

import com.cat.logistics.shared.dto.MachineDTO;
import com.cat.logistics.shared.exception.ServiceException;

/**
 * @author chanda15
 *
 */
public interface IMachineReaderService {

	/**
	 * @param machineSerialNum
	 * @return Machine DTO
	 * @throws ServiceException
	 */
	public  Map<String,MachineDTO> getMachineDetails(List<String> machineSerialNum) throws ServiceException;
}
