package com.cat.logistics.epa.job.service;

import com.cat.logistics.epa.dto.EpaShipmentDTO;
import com.cat.logistics.epa.entities.EpaEngine;
import com.cat.logistics.shared.dto.EngineDTO;
import com.cat.logistics.shared.exception.ServiceException;

/**
 * 
 * interface for creating engine shipments
 * @author chanda15
 *
 */
public interface IEngineCreateService {

	/**
	 * @param engineShpmntDTO
	 * @param engineDTO
	 * @throws ServiceException
	 */
	public void createEngineShipment(EpaShipmentDTO engineShpmntDTO,
			EngineDTO engineDTO) throws ServiceException;
	
	/**
	 * This method updates the engine information
	 * @param exisEpaEngine
	 * @param updatedEpaEng
	 * @throws ServiceException
	 */
	public void updateExisEngine(EpaEngine exisEpaEngine,EngineDTO updatedEpaEngDto) throws ServiceException;
}
