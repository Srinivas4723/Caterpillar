package com.cat.logistics.epa.job.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Properties;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFDateUtil;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.springframework.util.ResourceUtils;

import com.cat.autoeccn.dao.impl.GetSeqNumberDAOImpl;
import com.cat.logistics.epa.entities.RcrdUpdtLog;



/**
 * It contains commonly used utility methods
 * @author badamrr
 *
 */
public final class Utils {

	private static String currentEnvironment = null;
	
	public static final Logger LOGGER = LogManager.getLogger(Utils.class);

	/**
	 * Private constructor to prevent creating object of this class.
	 */
	private Utils() {

	}

	
	/**
	 * 
	 * returns the current environment
	 *
	 * @return CurrentEnvironment
	 * @since 1.0 Nov 10, 2014 6:57:21 PM badamrr
	 */
	public static String getCurrentEnvironment() {
		if (currentEnvironment == null) {
			setCurrentEnvironment();
		}
		return currentEnvironment;
	}

	/**
	 * 
	 * This method takes the input and searched for it in
	 * *application.properties file
	 * 
	 * @param propName
	 * @return property value
	 * @since 1.0 Oct 30, 2014 11:18:45 AM badamrr
	 */
	public static final String getProperty(String propName) {
		String propValue = null;
		if (propName != null) {
			propValue = getEPAProperty(propName);
		}
		
		return propValue;
	}

	public static String getEPAProperty(String propName) {
		String propValue = null;
		Properties prop = new Properties();
		InputStream iStream = null;
		if (propName != null) {
			try {
				iStream = Utils.class.getClassLoader().getResourceAsStream(BatchConstants.PROPERTIES_EPA_BATCH);
				prop.load(iStream);
				propValue = prop.getProperty(propName);
			} catch (IOException e) {
				LOGGER.error("Exit getProperty", e);
			}
		}
		return propValue;
	}

	public static final String getPropertyECCN(String propName) {
		String propValue = null;
		if (propName != null) {
			propValue = getECCNProperty(propName);
		}
		
		return propValue;
	}
	
	public static String getECCNProperty(String propName) {
		String propValue = null;
		Properties prop = new Properties();
		InputStream iStream = null;
		if (propName != null) {
			try {
				iStream = Utils.class.getClassLoader().getResourceAsStream(BatchConstants.PROPERTIES_ECCN_BATCH);
				prop.load(iStream);
				propValue = prop.getProperty(propName);
			} catch (IOException e) {
				LOGGER.error("Exit getProperty", e);
			}
		}
		return propValue;
	}
	/**
	 * 
	 * Performs null check and length check on input
	 *
	 * @param theString
	 * @return boolean value
	 * @since 1.0 Nov 10, 2014 6:57:54 PM badamrr
	 */
	public static boolean checkForNullAndNoLength(String theString) {
		return (theString == null) || (theString.trim().length() == 0);
	}

	/**
	 * 
	 * Sets the current environment where application is running
	 *
	 * @since 1.0 Nov 10, 2014 6:58:26 PM badamrr
	 */
	public static void setCurrentEnvironment() {
		try {
			String currentEnv = System.getProperty("ENVIRONMENT");
			if (currentEnv.equalsIgnoreCase("PROD")) {
				currentEnvironment = BatchConstants.PR_ENV;
			} else if (currentEnv.equalsIgnoreCase("QA")) {
				currentEnvironment = BatchConstants.QA_ENV;
			} else if (currentEnv.equalsIgnoreCase("TEST")) {
				currentEnvironment = BatchConstants.TEST_ENV;
			} else {
				currentEnvironment = BatchConstants.UI_ENV;
			}
		} catch (Exception e) {
			currentEnvironment = BatchConstants.UI_ENV;
			e = null;
		}
	}
	
	/**
	 * 
	 * Concatenates all the input arguments and returns a String as output
	 *
	 * @param values pass values to concatenate
	 * @return concatenated value
	 * @since 1.0 Nov 11, 2014 2:43:51 PM badamrr
	 */
	public static String concatenate(String... values) {
		StringBuilder strBuilder = new StringBuilder();
		for (String stringVar : values) {
			strBuilder.append(stringVar);
		}
		return strBuilder.toString();
	}
	
	/**
	 * @param key
	 * @return part info
	 */
	public static String getPartNum(String key){
		String[] arr = key.split(BatchConstants.HYPHEN);
		
		return arr[0];
		
	}
	
	
	/**
	 * @param minutes
	 * @return the Time stamp
	 */
	public static Timestamp getTmStmp(int minutes){
		
		Calendar calendar = Calendar.getInstance();
		if(minutes != 0){
		calendar.add(Calendar.MINUTE, Integer.parseInt(Utils.getProperty(BatchConstants.READ_TIME)));
		}
		java.util.Date now = calendar.getTime();
		Timestamp tmStmp = new Timestamp(now.getTime());
		return tmStmp;
	}
	
	public static String getTmStmpinString(int minutes){
		
		Calendar calendar = Calendar.getInstance();
		if(minutes != 0){
		calendar.add(Calendar.MINUTE, Integer.parseInt(Utils.getProperty(BatchConstants.READ_TIME)));
		}
		java.util.Date now = calendar.getTime();
		String timeStamp = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS").format(now);

		return timeStamp;
	}	
	

	/**
	 * 
	 * @param minutes
	 * @return
	 */
	public static Timestamp getHtsTmStmp(){
		
		Calendar calendar = Calendar.getInstance();
		calendar.add(Calendar.DATE, -1);
		java.util.Date now = calendar.getTime();
		Timestamp tmStmp = new Timestamp(now.getTime());
		return tmStmp;
	}
	
	/**
	 * @param crteLogin
	 * @param crteTm
	 * @param lastUpdtLogonId
	 * @param lastUpdtTs
	 * @return the RcrdUpdtLog
	 */
	public static RcrdUpdtLog getRcrdLg(String crteLogin,Date crteTm,String lastUpdtLogonId,Date lastUpdtTs){
	
		RcrdUpdtLog rcrdUpdLog = new RcrdUpdtLog(crteLogin,crteTm,lastUpdtLogonId,lastUpdtTs);
		
		return rcrdUpdLog;
	}
	/**
	 * validates if a string contains special chars
	 * @param engSer
	 * @return
	 */
	public static boolean chkSpclChrs(String engSer){
		Pattern p = Pattern.compile("[^a-z0-9 ]", Pattern.CASE_INSENSITIVE);
		Matcher m = p.matcher(engSer);
		boolean b = m.find();
		return b;
	}
	
	/**
	 * @param value
	 * @param length
	 * @return true or false
	 */
	public static boolean checkLenth(String value,int length){
		boolean flag = true;
		if(value != null && value.length() > length){
			flag = false;
		}
		return flag;
		
	}
	
	/**
	 * @param value
	 * @param length
	 * @return fit collen value
	 */
	public static String fitColLen(String value,int length){
		String inputVal = null;
		if(value != null && value.length() > length){
			inputVal = value.substring(0,length);
		}
		
		return inputVal;
	}
	
	/**
	 * @param val
	 * @return the string value after trim
	 */
	public static String trim(String val){
	String value = null;
		if(val != null ){
			value = val.trim();
		}
		return value;
	}
	
	/**
	 * @param tmstmp
	 * @return the time stamp
	 */
	public static Timestamp getFrmTmstmp(Timestamp tmstmp){
		
		   Timestamp original = tmstmp;
	        Calendar cal = Calendar.getInstance();
	        cal.setTimeInMillis(original.getTime());
	        Timestamp frmTm = new Timestamp(cal.getTime().getTime());
		
		return frmTm;
	}

	/**
	 * @param minutes
	 * @return the Time stamp
	 */
	public static Timestamp getTmStmp() {

		Calendar calendar = Calendar.getInstance();
		java.util.Date now = calendar.getTime();
		Timestamp tmStmp = new Timestamp(now.getTime());
		return tmStmp;
	}
	
	
	/**
	 * 
	 * @return Received Update log
	 */
	public static RcrdUpdtLog getRcdUpLg() {
		RcrdUpdtLog updtLog = Utils.getRcrdLg("EPA_GTI",
				new java.util.Date(), "EPA_GTI",
				new java.util.Date());
		return updtLog;
	}
	
	/**
	 * @author vak
	 * @return NAS path based on tuf.appFiles.rootDirectory runtime configuration in server
	 */
	public static String getNASpath(){
		return System.getProperty("tuf.nasFilesStore.rootDirectory");
	}
	
	/**
	 * Method used to get cell value
	 * 
	 * @param cell
	 * @return String of the cell value
	 */
	public static String getCellValue(Cell inputCell) {
		String result = null;

		if (null == inputCell) {
			result = BatchConstants.EMPTY_SPACE;
			return result;
		}

		switch (inputCell.getCellType()) {
		case Cell.CELL_TYPE_BLANK:
			result = BatchConstants.EMPTY_SPACE;
			break;
		case Cell.CELL_TYPE_BOOLEAN:
			result = String.valueOf(inputCell.getBooleanCellValue());
			break;
		case Cell.CELL_TYPE_NUMERIC:
			if (HSSFDateUtil.isCellDateFormatted(inputCell)) {
				result = dateToStringConversion(inputCell.getDateCellValue(), "yyyy-MM-dd");
				break;
			}
			result = new DataFormatter().formatCellValue(inputCell);
			break;
		case Cell.CELL_TYPE_STRING:
			result = inputCell.getStringCellValue();
			break;
		default:
			break;
		}
		return result;
	}
	
	/**
	 * @param stringDate
	 * @param stringPattern
	 * @return the date
	 */
	public static String dateToStringConversion(Date date, String stringPattern) {
		DateFormat formatter;
		formatter = new SimpleDateFormat(stringPattern);
		String dateStr = null;
		dateStr = formatter.format(date);
		return dateStr;
	}
	
	/**
	 */
	public static String trimString(String inputStr) {
		return null != inputStr ? inputStr.trim() : inputStr;
	}
	
	
	public static String getEnvironmentFromProperty() {
		String environment = "";
		try {
			environment = System.getProperty("ENVIRONMENT");
		} catch (Exception e) {
			LOGGER.error("Exception: ", e);
		}
		return environment;
	}

	public static String getEnvironment() {
		String enviroment = Utils.getEnvironmentFromProperty();
		if (enviroment.equalsIgnoreCase("test")) {
			enviroment = "DEV";
		}
		return enviroment;
	}

	public static Properties loadPropertiesFile() {
		Properties properties = new Properties();
		InputStream iStream = null;
		try {
			iStream = Utils.class.getClassLoader().getResourceAsStream("properties/" + getEnvironment() + "_autoECCN_config.properties");
			properties.load(iStream);
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				if (iStream != null) {
					iStream.close();
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return properties;
	}

}
