/**
 * 
 *//*
package com.cat.logistics.epa.job.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cat.logistics.epa.job.IAutoECCNUtiliyProcess;
import com.cat.logistics.epa.job.IHTSProcess;
import com.cat.logistics.epa.job.dto.ECCNFileDetails;
import com.cat.logistics.epa.job.dto.ECCNFileDetails.FileType;
import com.cat.logistics.epa.job.service.IFileReader;
import com.cat.logistics.epa.job.utils.BatchConstants;
import com.cat.logistics.epa.job.utils.ILogger;
import com.cat.logistics.epa.job.utils.Logger;

*//**
 * @author addansn
 *
 *//*
@Component
public class AutoECCNUtiliyProcess extends AbstractProcess implements IAutoECCNUtiliyProcess {

	private ILogger logger = Logger.getInstance();
	
	@Autowired
	private IFileReader fileReader;

	@Override
	public void getECCNfiles() throws Exception {
		logger.informationalEvent(this.getClass(), BatchConstants.MTD_AUTO_ECCN_UTIL_PROCESS, BatchConstants.AUTO_ECCN_UTIL_STARTED);
		boolean jobSuccs = true;
		jobStartTime(BatchConstants.AUTO_ECCN_UTIL_JOB);
		readMailConfigurations();
		ECCNFileDetails flDtls = new ECCNFileDetails(BatchConstants.ECCN_OUT, null,FileType.BINARY);
	    try {
	    	jobSuccs = fileReader.recvStmnt(flDtls, jobSuccs);
		} catch (Exception e) {
			e.printStackTrace();
			logger.fatalEvent(AutoECCNUtiliyProcess.class, BatchConstants.MTD_GET_ECCN_FILES, e.getMessage(), e);
			throw e;
		}
	    jobShutDown(BatchConstants.AUTO_ECCN_UTIL_JOB, jobSuccs);
	}
	
}
*/