/**
 * Copyright (c) Caterpillar Inc. All Rights Reserved.
 * This work contains Caterpillar Inc.'s unpublished proprietary information
 * which may constitute a trade secret and/or be confidential. This work 
 * may be used only for the purposes for which it was provided, and may 
 * not be copied or disclosed to others. Copyright notice is precautionary 
 * only, and does not imply publication.
 *
 * Revision History
 * Version        Date         Changed By        Comments
 *  1.0        20-01-2016      singhr9           Initial Creation
 **/
package com.cat.logistics.epa.job.utils;
import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import org.apache.commons.net.ftp.FTP;
import org.apache.commons.net.ftp.FTPClient;
import org.apache.commons.net.ftp.FTPFile;
import org.apache.commons.net.ftp.FTPFileFilter;
import org.apache.commons.net.ftp.FTPReply;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import com.cat.googletink.util.EncryptAndDecryptApplication;
import com.cat.logistics.epa.job.dto.ECCNDetails;
import com.cat.logistics.epa.job.dto.ECCNFileDetails.FileType;
import com.cat.logistics.shared.utils.PersistenceConstants;



/**
 * This class contains FTPUtility methods
 *
 */
public class FTPHandler {

	public static final Logger LOGGER = LogManager.getLogger(FTPHandler.class);
	@Autowired
	private FTPClient ftpClient;
	@Autowired
	private ECCNDetails achDtls;
	
	private String ftpHostName;
	private String ftpDirectory;
	private String ftpUserName;
	private String ftpPassword;
	/**
	 * Constructor
	 * 
	 * @param config
	 */
	public FTPHandler(String ftpHostName,String ftpDirectory, String ftpUserName,String ftpPassword) {
		this.ftpHostName = ftpHostName;
		this.ftpDirectory = ftpDirectory;
		this.ftpUserName  = ftpUserName;
		this.ftpPassword = EncryptAndDecryptApplication.decrypt(System.getProperty("tink.serverKeyset"),
				System.getProperty("tink.associateKeyset"),ftpPassword);
	}

	/**
	 * This method connects to the Sterling Integrator and reads ECCN output files
	 *
	 * 
	 * @param fileName
	 * @param fileGrpTyp
	 * @param ftpFlTyp
	 * @return
	 * @throws FTPException
	 * @throws IOException
	 */
	public void copyFlsFrmFtpToTempFldr(String fileName, String fileGrpTyp,FileType ftpFlTyp) throws FTPException, IOException {
		//logger.informationalEvent(this.getClass(),Constants.MTD_CPY_FLS, Constants.METHOD_ENTRY);
		OutputStream outputStream = null;
		String filePath = null;
		String tmpLocation = null;
		boolean isSuccess = false;
		String currentEnv = System.getProperty("ENVIRONMENT");
		String fileNameArr[] = fileName.split(BatchConstants.UNDER_SCORE, BatchConstants.NUM_FOUR);
		String seqNo = fileNameArr[BatchConstants.NUM_TWO].toString();
		String formattedFileName =  fileNameArr[BatchConstants.NUM_THREE].toString();
		try {
			if(fileGrpTyp.equals(BatchConstants.ECCN_OUT)){
				tmpLocation = achDtls.getTmpFldrLocDly();
			}
			if(tmpLocation!=null){
			if(!currentEnv.equalsIgnoreCase("DEV")){
				tmpLocation=Utils.getNASpath()+tmpLocation;
			}
			connectIfDisconnected(ftpFlTyp);
			LOGGER.info("Entry method of copyFlsFrmFtpToTempFldr {}",tmpLocation);
			File seqDir = new File(tmpLocation + BatchConstants.BACK_SLASH + seqNo + BatchConstants.BACK_SLASH);
			if(!seqDir.exists()){
				isSuccess = seqDir.mkdirs();
			}
			filePath = seqDir.getPath();
			LOGGER.info("Entry method of copyFlsFrmFtpToTempFldr {}",seqDir.getAbsolutePath());
			outputStream = new BufferedOutputStream(new FileOutputStream(filePath + BatchConstants.BACK_SLASH +formattedFileName));
			
			ftpClient.retrieveFile(fileName, outputStream);
			int reply = ftpClient.getReplyCode();
			if (!FTPReply.isPositiveCompletion(reply)&& !String.valueOf(reply).startsWith(BatchConstants.STRING_1)) {
				String copyFtpMessage = ftpClient.getReplyString();

				disconnect();
				throw new FTPException(copyFtpMessage); 
			}
			LOGGER.info("Entry method of copyFlsFrmFtpToTempFldr {} {}",BatchConstants.DIR_DEL,isSuccess);
		}
		}catch (IOException ioex) { 
			ioex.printStackTrace();
			LOGGER.error("Error in copyFlsFrmFtpToTempFldr {}",
					(BatchConstants.IO_EXC_OCRD + ioex.getMessage()), (Exception) ioex);
			throw new FTPException(ioex.getMessage()
					+ BatchConstants.IO_EXC_MSG, ioex);
		} catch (Exception exc) {
			exc.printStackTrace();
			LOGGER.error("Error in copyFlsFrmFtpToTempFldr {}",
					(BatchConstants.IO_EXC_OCRD + exc.getMessage()), (Exception) exc);
			throw new FTPException(exc.getMessage()
					+ BatchConstants.IO_EXC_MSG, exc);
		} finally {			
			if (null != outputStream) {
				outputStream.close();
			} 
		}	

	}

	/**
	 * 
	 * @param fileGroupType
	 * @return
	 * @throws FTPException
	 */
	public FTPFile[] getFileListFrmFtpSrc(FTPFileFilter ftpFlFilter,
			FileType ftpFlTyp, String srcDir) throws FTPException {

		FTPFile[] files = null;
		try {
			connectIfDisconnected(ftpFlTyp);
			LOGGER.info("Entry method of getFileListFrmFtpSrc {}",srcDir);
			files = ftpClient.listFiles(srcDir, ftpFlFilter);

			if (!FTPReply.isPositiveCompletion(ftpClient.getReplyCode())) {
				String ftpMessage = ftpClient.getReplyString();
				disconnect();
				throw new FTPException(ftpMessage);
			}
		} catch (IOException exception) {
			exception.printStackTrace();
			LOGGER.error("Error in getFileListFrmFtpSrc {}",
					(BatchConstants.IO_EXC_OCRD + exception.getMessage()), (Exception) exception);
			throw new FTPException(exception.getMessage()
					+ BatchConstants.IO_EXC_MSG, exception);
		} catch (Exception e) {
			e.printStackTrace();
			LOGGER.error("Error in getFileListFrmFtpSrc {}",
					(BatchConstants.IO_EXC_OCRD  + e.getMessage()), (Exception) e);
			throw new FTPException(e.getMessage()
					+ BatchConstants.IO_EXC_MSG, e);
		}
		LOGGER.info("Exit method of getFileListFrmFtpSrc{} {}",BatchConstants.SI_FL_CNT, null==files ? BatchConstants.STR_0 :String.valueOf(files.length));
		return files;

	}

	/**
	 * If connected to an FTP server it disconnects from it
	 * 
	 * @return 0 - If able to successfully disconnect from the server -1 - If
	 *         there is an error disconnecting
	 * @return
	 * @throws FTPException
	 */
	public int disconnect() throws FTPException {
		int error = -1;
		if (ftpClient != null && ftpClient.isConnected()) {
			try {
				ftpClient.disconnect();
				error = isPositiveComp();
			} catch (IOException ioexe) {
				ioexe.printStackTrace();
				LOGGER.error("Error in disconnect {}",
						(BatchConstants.IO_EXC_OCRD + ioexe.getMessage()), (Exception) ioexe);
				throw new FTPException(ioexe.getMessage()
						+ BatchConstants.IO_EXC_MSG, ioexe);
			} catch (Exception exce) {
				exce.printStackTrace();
				LOGGER.error("Error in disconnect {}",
						(BatchConstants.IO_EXC_OCRD + exce.getMessage()), (Exception) exce);
				throw new FTPException(exce.getMessage()
						+ BatchConstants.IO_EXC_MSG, exce);


			}
		} else {
			error = BatchConstants.INT_0;
		}
		return error;
	}

	/**
	 * Performs all setup functions. Connect to the FTP server, go to the passed
	 * directory, and set passive move
	 * 
	 * - directory where files will be put
	 * 
	 * @return 0 if successful -1 if there was an error and error will be logged
	 * @throws FTPException
	 * @throws IOException
	 * @throws FTPException
	 */
	public int connectToFtpServer(FileType ftpFlTyp) throws FTPException {
		int error = -1;
		error = connect();
		if (error == BatchConstants.INT_0) {
			error = tryLogin();
			if (error == BatchConstants.INT_0 && changeFileTransferMode(ftpFlTyp) == BatchConstants.INT_0) {
				ftpClient.enterLocalPassiveMode();
				if (!FTPReply.isPositiveCompletion(ftpClient
						.getReplyCode())) {
					String ftpMessage = ftpClient.getReplyString();
					throw new FTPException(ftpMessage);
				} else {
					error = BatchConstants.INT_0;
				}
			}
		} else {
			LOGGER.warn(BatchConstants.CNCT_TO_FTP_SRVR, BatchConstants.FTP_CON_FLR);
		}
		LOGGER.info("Entry method of connectToFtpServer{}{} {}","connectToFtpServer", "this is the connectToFtpServer " ,error);
		return error;
	}

	/**
	 * Confirms still connected to FTP server, if not connected it attempts to
	 * reconnect
	 * 
	 * @return - 0 if either already connected or was able to connect
	 * @throws FTPException
	 * @throws IOException
	 * @throws ApplicationException
	 *             Runtime exception in the form of ApplicationException
	 */
	private int connectIfDisconnected(FileType ftpFlTyp) throws FTPException,
			IOException, ApplicationException {
		int error = -1;
		if (ftpClient != null && ftpClient.isConnected()) {
			error = BatchConstants.INT_0;
		} else {
			error = connectToFtpServer(ftpFlTyp);
		}
		return error;
	}

	/**
	 * Change the file transfer mode between ASCII and Binary
	 * 
	 * @return int - 0 if successful -1 if unsuccessful
	 * @throws FTPException
	 * @throws ApplicationException
	 *             Runtime exception in the form of ApplicationException
	 * @throws FTPException
	 */
	private int changeFileTransferMode(FileType ftpFileType)
			throws FTPException {
		int error = -1;
		try {
			if (BatchConstants.BINARY.equalsIgnoreCase(ftpFileType.toString())) {
				ftpClient.setFileType(FTP.BINARY_FILE_TYPE);
			} else {
				ftpClient.setFileType(FTP.ASCII_FILE_TYPE);
			}
			error = isPositiveComp();
		} catch (IOException ioe) {
			ioe.printStackTrace();
			LOGGER.error("Error in changeFileTransferMode {}",
					(BatchConstants.EXC_OCCRD + ioe.getMessage()), (Exception) ioe);
			throw new FTPException(ioe.getMessage()
					+ BatchConstants.EXC_MSG, ioe);
		}
		LOGGER.info("Exit method of changeFileTransferMode {}" ,error);
		return error;
	}

	/**
	 * 
	 * Connects to the FTP server
	 * 
	 * @return
	 * @throws FTPException
	 * @throws ApplicationException
	 *             Runtime exception in the form of ApplicationException
	 * 
	 */
	private int connect() throws FTPException {
		int error = -1;
		error = disconnect();
		LOGGER.info("Entry method of connect{}" ,error);
		if (error == BatchConstants.INT_0) {
			try {
				String hostName = ftpHostName;
				ftpClient.connect(hostName);
				ftpClient.enterLocalPassiveMode();
				LOGGER.info("Entered the local passive mode {} {} {}",ftpHostName ,ftpUserName,ftpPassword);
				if (!FTPReply.isPositiveCompletion(ftpClient
						.getReplyCode())) {
					String ftpMessageC = ftpClient.getReplyString();
					ftpClient.disconnect();
					throw new FTPException(ftpMessageC);
				} else {
					error = BatchConstants.INT_0;
				}
			} catch (IOException ioex) {
				ioex.printStackTrace();
				LOGGER.info(" Exception While connecting to server {}",ioex.getMessage());
				throw new FTPException(ioex.getMessage()
						+ BatchConstants.CON_FTP_ST, ioex); 
			}
		} else {
			LOGGER.warn(BatchConstants.CONNECT,
					BatchConstants.CON_MSG);
		}
		LOGGER.info(" This is the error Status {} ",error);
		return error;
	}

	/**
	 * 
	 * Attempts to log into the server
	 * 
	 * @return
	 * @throws FTPException
	 * @throws ApplicationException
	 *             Runtime exception in the form of ApplicationException
	 * 
	 */
	private int tryLogin() throws FTPException {
		int error = -1;
		String username = ftpUserName;
		String password = ftpPassword;
		try {
			boolean loggedIn = ftpClient.login(username, password);
			LOGGER.info("Entry method this is the login status {} " , loggedIn);
			if (!FTPReply.isPositiveCompletion(ftpClient.getReplyCode())) {
				String ftpMessage =ftpClient.getReplyString();
				LOGGER.info("Inside not positive completion of login method {}", ftpMessage);
				ftpClient.logout();
				disconnect();
				throw new FTPException(ftpMessage);
			} else {
				error = BatchConstants.INT_0;
			}
		} catch (IOException ioe) {
			LOGGER.info("Exception while {}" , ioe.getMessage());
			throw new FTPException(ioe.getMessage()
					+ BatchConstants.LOG_MSG, ioe);
		}
		LOGGER.info("Exit method this is the error {} " , error);
		return error;
	}
	
	
	/**
	 * @return the ftpHostName
	 */
	public String getFtpHostName() {
		return ftpHostName;
	}

	/**
	 * @param ftpHostName the ftpHostName to set
	 */
	public void setFtpHostName(String ftpHostName) {
		this.ftpHostName = ftpHostName;
	}

	/**
	 * @return the ftpDirectory
	 */
	public String getFtpDirectory() {
		return ftpDirectory;
	}

	/**
	 * @param ftpDirectory the ftpDirectory to set
	 */
	public void setFtpDirectory(String ftpDirectory) {
		this.ftpDirectory = ftpDirectory;
	}

	/**
	 * @return the ftpUserName
	 */
	public String getFtpUserName() {
		return ftpUserName;
	}

	/**
	 * @param ftpUserName the ftpUserName to set
	 */
	public void setFtpUserName(String ftpUserName) {
		this.ftpUserName = ftpUserName;
	}

	
	public String getFtpPassword() {
		return ftpPassword;
	}

	
	public void setFtpPassword(String ftpPassword) {
		this.ftpPassword = EncryptAndDecryptApplication.decrypt(System.getProperty("tink.serverKeyset"),
				System.getProperty("tink.associateKeyset"),ftpPassword);
	}
	
	
	private int isPositiveComp() throws FTPException{
		int error = -1;
		if (!FTPReply.isPositiveCompletion(ftpClient.getReplyCode())) {
			String ftpMsg = ftpClient.getReplyString();
			throw new FTPException(ftpMsg);
		} else {
			error = BatchConstants.INT_0;
		}
		return error;
	}

}
