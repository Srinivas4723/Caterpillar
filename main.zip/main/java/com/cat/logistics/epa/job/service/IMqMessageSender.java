/*
 * Copyright (c) 2015 Caterpillar Inc. All Rights Reserved.
 *
 * This work contains Caterpillar Inc.'s unpublished
 * proprietary information which may constitute a trade secret
 * and/or be confidential. This work may be used only for the
 * purposes for which it was provided, and may not be copied
 * or disclosed to others. Copyright notice is precautionary
 * only, and does not imply publication.
 */
package com.cat.logistics.epa.job.service;

import com.cat.logistics.epa.job.dto.AutoEccnDTO;
import com.cat.logistics.epa.job.utils.ApplicationException;


/**
 * This class used to send message to the specific MQ
 * 
 * @author kk3
 *
 */
public interface IMqMessageSender {

	/**
	 * This method used to send message to the source queue
	 * 
	 * @param mqDetails
	 * @param msgString
	 * @param fileName
	 * @param fileType
	 * @throws ApplicationException
	 */
	void sendMQMsgToSrcQueue(String msgString, String fileName, String fileType, AutoEccnDTO autoEccnDTO) throws ApplicationException;
}
