/**
 * 
 *//*
package com.cat.logistics.epa.job.impl;

import java.io.IOException;
import java.sql.Timestamp;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.cat.autoeccn.dao.impl.GetSeqNumberDAO;
import com.cat.logistics.epa.job.IAutoECCNCatClassProcess;
import com.cat.logistics.epa.job.service.IAutoEccnService;
import com.cat.logistics.epa.job.utils.ApplicationException;
import com.cat.logistics.epa.job.utils.BatchConstants;
import com.cat.logistics.epa.job.utils.ILogger;
import com.cat.logistics.epa.job.utils.Logger;
import com.cat.logistics.epa.job.utils.Utils;

*//**
 * @author addansn
 *
 *//*
public class AutoECCNCatClassProcess extends AbstractProcess implements IAutoECCNCatClassProcess {

	private ILogger logger = Logger.getInstance();
	
	@Autowired
	private IAutoEccnService eccnService;
	
	@Autowired
	private GetSeqNumberDAO getSeqNumberDAO;
	
	public void processFilesToMQ() throws IOException, ApplicationException {
		
		logger.informationalEvent(this.getClass(), BatchConstants.MTD_AUTO_ECCN_CAT_CLASS_PROCESS, BatchConstants.AUTO_ECCN_CAT_CLASS_STARTED);
		try{
		Timestamp currTm = null;
		currTm = Utils.getTmStmp();
		Timestamp lstSccsTm = getSeqNumberDAO.getLstSuccTS();
		List<String> seqNoList = getSeqNumberDAO.getSeqNo(lstSccsTm, currTm);
		eccnService.readExcel(seqNoList, BatchConstants.OUTPUT);
		eccnService.readExcel(seqNoList, BatchConstants.REVIEWED);
		getSeqNumberDAO.updateLstSuccTS(currTm);
		}catch(Exception e){
			logger.fatalEvent(this.getClass(), "processFilesToMQ", e.getMessage(), e);
		}
		logger.informationalEvent(this.getClass(), BatchConstants.MTD_AUTO_ECCN_CAT_CLASS_PROCESS, BatchConstants.METHOD_EXIT);
		
	}
	
}
*/