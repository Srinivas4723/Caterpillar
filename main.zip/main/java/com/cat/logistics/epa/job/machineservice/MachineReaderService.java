package com.cat.logistics.epa.job.machineservice;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import com.cat.logistics.epa.job.service.IMachineReaderService;
import com.cat.logistics.epa.job.utils.BatchConstants;
import com.cat.logistics.epa.service.IEpaMachineFormService;
import com.cat.logistics.shared.dto.MachineDTO;
import com.cat.logistics.shared.exception.ServiceException;

/**
 * Fetches the Machine Details
 * @author chanda15
 *
 */
public class MachineReaderService implements IMachineReaderService {

	@Autowired
	private IEpaMachineFormService machineFormService;
	
	//private ILogger logger = Logger.getInstance();
	
	private final static Logger logger = LogManager.getLogger(MachineReaderService.class);
	
	/**
	 * fetches the machine details from ODS
	 * @param machineSerialNums
	 * @return Machine DTO object as map
	 */
	@Override
	public Map<String, MachineDTO> getMachineDetails(
			List<String> machineSerialNums) throws ServiceException {
		//logger.informationalEvent(this.getClass(), "getMachineDetails", BatchConstants.EPA_BATCH_STARTED);
		logger.info(this.getClass()+ "getMachineDetails"+ BatchConstants.EPA_BATCH_STARTED);
		 Map<String,MachineDTO> machineDetailsMap = new HashMap<String,MachineDTO>();
		 MachineDTO machineDTO = null;
		try {
			for(String machSerNum : machineSerialNums){
				if (machSerNum !=null) {
					final String trimmedMachSerNum = machSerNum.trim();
					machineDTO = machineFormService.getOdsMachineInfo(trimmedMachSerNum);
					machineDetailsMap.put(trimmedMachSerNum, machineDTO);
				}			
			}
		} catch (ServiceException e) {
			//logger.informationalEvent(this.getClass(), "getMachineDetails", BatchConstants.METHOD_EXIT);
			logger.info(this.getClass() + "getMachineDetails" + BatchConstants.METHOD_EXIT);
			throw e;
		}
		
		return machineDetailsMap;
	}

}
