package com.cat.logistics.epa.job.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import com.cat.logistics.epa.dto.EpaShipmentDTO;
import com.cat.logistics.epa.entities.EpaShipment;
import com.cat.logistics.epa.job.service.IEPAService;
import com.cat.logistics.epa.job.service.IMachineReaderService;
import com.cat.logistics.epa.job.tvs.IErrorMessageCreator;
import com.cat.logistics.epa.job.utils.BatchConstants;
import com.cat.logistics.epa.job.utils.BatchContext;
import com.cat.logistics.epa.mail.IEmailSender;
import com.cat.logistics.epa.service.IEngineEmissionService;
import com.cat.logistics.shared.dto.EngineDTO;
import com.cat.logistics.shared.dto.MachineDTO;
import com.cat.logistics.shared.exception.ServiceException;

public class AbstractProcess {

	@Autowired
	IEPAService epaService;
	
	@Autowired
	private IEmailSender mailSender;
	
	@Autowired
	private IErrorMessageCreator errorMessageCreator;
	
	@Autowired
	private IEngineEmissionService engineEmissionService;
	
	@Autowired
	private IMachineReaderService machineReaderService;
	
	//private ILogger logger = Logger.getInstance();
	
	private final static Logger logger = LogManager.getLogger(AbstractProcess.class);
	
	public void jobInitialization(String jobName) throws Exception{
		
		try{
			jobStartTime(jobName);
			readMailConfigurations();
			initializeBatchContext();
		}catch(Exception excp){
			throw excp;
		}
	}
	
	public void jobShutDown(String jobName,boolean jobSuccs) throws Exception{
		jobEndTime(jobName);
		if(jobSuccs){
			saveSuccTm(jobName);
		}
	}
	
	public void initializeBatchContext(){
		List<String> engineList = new ArrayList<String>();
		List<String> engineParts = new ArrayList<String>();
		List<String> machineParts = new ArrayList<String>();
		List<String> machineList = new ArrayList<String>();
		Map<String,String> partTyps = new HashMap<String,String>();
		BatchContext.put(BatchConstants.ENGINE_LITERAL, engineList);
		BatchContext.put(BatchConstants.MACHINE_LITERAL, machineList);
		BatchContext.put(BatchConstants.E_PARTS, engineParts);
		BatchContext.put(BatchConstants.M_PARTS, machineParts);
		BatchContext.put(BatchConstants.PART_PARTTYPE, partTyps);
	}
	
	/**
	 * This method is to find batch jobStartTime
	 * @throws ServiceException
	 */
	public void jobStartTime(String jobName) throws ServiceException{
		
		try {
			epaService.logStartTime(jobName);
		} catch (ServiceException e) {
			//logger.fatalEvent(this.getClass(), BatchConstants.JOB_STRT_TIME, BatchConstants.LOG_JB_STRT_TIME_FAILED, e);
			logger.error(this.getClass() + BatchConstants.JOB_STRT_TIME + BatchConstants.LOG_JB_STRT_TIME_FAILED + e.getMessage());
			throw e;
		}
	}
	
	/**
	 * This method is to find batch jobEndTime
	 * @throws ServiceException
	 */
	public void jobEndTime(String jobName) throws ServiceException{
		//logger.informationalEvent(this.getClass(), BatchConstants.JB_END_TIME, BatchConstants.EXE_JB_END_TIME);
		logger.info(this.getClass() + BatchConstants.JB_END_TIME + BatchConstants.EXE_JB_END_TIME);
		try {
			epaService.logEndTime(jobName);
		} catch (ServiceException e) {
			//logger.fatalEvent(this.getClass(), BatchConstants.JB_END_TIME, BatchConstants.LOG_JB_END_TIME_FAILED, e);
			logger.error(this.getClass() + BatchConstants.JB_END_TIME + BatchConstants.LOG_JB_END_TIME_FAILED + e.getMessage());
			throw e;
		}
	}
	
	public void saveSuccTm(String jobName) throws ServiceException{
		//logger.informationalEvent(this.getClass(), BatchConstants.MTD_SAVE_SUCCS_TM, BatchConstants.EXE_SAV_SUCCS_TM);
		logger.info(this.getClass() + BatchConstants.MTD_SAVE_SUCCS_TM + BatchConstants.EXE_SAV_SUCCS_TM);

		epaService.saveLstSccsTm(jobName);
		
		//logger.informationalEvent(this.getClass(), BatchConstants.MTD_SAVE_SUCCS_TM, BatchConstants.EXE_SAV_SUCCS_TM);
		logger.info(this.getClass() + BatchConstants.MTD_SAVE_SUCCS_TM + BatchConstants.EXE_SAV_SUCCS_TM);
	}
	
	
	/**
	 * reads mail configuration details
	 * @throws ServiceException
	 */
	public void readMailConfigurations() throws ServiceException{
		try{
			epaService.readMailConfigData();
		}catch(ServiceException servExcp){
			//logger.fatalEvent(this.getClass(), BatchConstants.JOB_STRT_TIME, BatchConstants.LOG_JB_STRT_TIME_FAILED, servExcp);
			logger.error(this.getClass()+ BatchConstants.JOB_STRT_TIME+ BatchConstants.LOG_JB_STRT_TIME_FAILED+ servExcp.getMessage());
		}
	}
	/**
	 * 
	 * @param partShpmnts
	 */
	public boolean processEPAParts(Map<String,EpaShipmentDTO> partShpmnts) throws Exception{
		boolean succs = true;
		try{
			saveEngineInfoToEpa(partShpmnts);
		}catch(ServiceException engineServiceExc){
			mailSender.sendEmail("Technical Exception occured while saving engine info. Please check EPA Batch logs");
			//logger.fatalEvent(this.getClass(), BatchConstants.MTD_EPA_PROCESS, BatchConstants.ENG_DATA_COULDNT_SAVE, engineServiceExc);
			logger.error(this.getClass()+ BatchConstants.MTD_EPA_PROCESS+ BatchConstants.ENG_DATA_COULDNT_SAVE+ engineServiceExc.getMessage(),engineServiceExc);
			succs = false;
		}
		try{
		saveMachineInfoToEpa(partShpmnts);
		}catch(Exception machineException){
			mailSender.sendEmail("Technical Exception occured while saving machine info. Please check EPA Batch logs");
			succs = false;
			//logger.fatalEvent(this.getClass(), BatchConstants.MTD_EPA_PROCESS, BatchConstants.MCH_DATA_COULDNT_SAVE, machineException);
			logger.error(this.getClass() + BatchConstants.MTD_EPA_PROCESS + BatchConstants.MCH_DATA_COULDNT_SAVE + machineException.getMessage());
		}
		return succs;
	}
	
	
	 /**
	  * Populates the Engine data to EPA database
	 * @param partShpmnts
	 * @throws Exception
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public void saveEngineInfoToEpa(Map<String,EpaShipmentDTO> partShpmnts) throws Exception {
		 //logger.informationalEvent(this.getClass(), BatchConstants.MTD_SAVE_ENG_TO_EPA, BatchConstants.EXE_SAVE_ENG_TO_EPA);
		logger.info(this.getClass() +  BatchConstants.MTD_SAVE_ENG_TO_EPA + BatchConstants.EXE_SAVE_ENG_TO_EPA);
		 Map<String,EngineDTO> serialEngineMap = null;
		 EngineDTO engineDTO = null;
		 EpaShipmentDTO engineShpmntDTO = null;

			 try{
				 List<String> engines = (List<String>) BatchContext.getValue(BatchConstants.ENGINE_LITERAL);
				 serialEngineMap = getEngineDetails(engines);
			 }catch(ServiceException exception){
				 //logger.fatalEvent(this.getClass(), BatchConstants.MTD_SAVE_ENG_TO_EPA, BatchConstants.ENG_COULD_NOT_RETRIVE_FRM_EED, exception); 
				 logger.error(this.getClass() + BatchConstants.MTD_SAVE_ENG_TO_EPA + BatchConstants.ENG_COULD_NOT_RETRIVE_FRM_EED + exception.getMessage(),exception); 
				 mailSender.sendEmail("Technical Exception occured while reading engine info from EngineEmission web service. Please check EPA Batch logs");
			 }
			 
		 Set<Entry<String,EpaShipmentDTO>>  epaEntrySet = partShpmnts.entrySet();
		 
		 Iterator iterator = epaEntrySet.iterator();
		
		 while(iterator.hasNext()){
			 try{
			 engineDTO = null;
			 Entry<String,EpaShipmentDTO> entry = (Entry<String,EpaShipmentDTO>) iterator.next();
			 engineShpmntDTO = (EpaShipmentDTO) entry.getValue();
			
			 if(engineShpmntDTO.getEpaProdTypeCode().equals(BatchConstants.ENGINE_LITERAL)){
			if(engineShpmntDTO.getProductSerialNum() != null && serialEngineMap != null){
				 engineDTO = serialEngineMap.get(engineShpmntDTO.getProductSerialNum());
			}
			try{
			epaService.createEngineShipment(engineShpmntDTO,engineDTO);
			}catch(Exception exception){
				//logger.fatalEvent(this.getClass(), BatchConstants.MTD_SAVE_ENG_TO_EPA, BatchConstants.SAVE_ENG_NT_SUCCESS + engineShpmntDTO.getProductSerialNum() + BatchConstants.HYPHEN+engineShpmntDTO.getPartNum(), exception);
				logger.error(this.getClass() + BatchConstants.MTD_SAVE_ENG_TO_EPA + BatchConstants.SAVE_ENG_NT_SUCCESS + engineShpmntDTO.getProductSerialNum() + BatchConstants.HYPHEN+engineShpmntDTO.getPartNum() + exception.getMessage(),exception);
				mailSender.sendEmail("Technical Exception occured while saving engine info. Please check EPA Batch logs");
			}
			 if(engineDTO == null){
			 	 errorMessageCreator.engineInfoNotFound(engineShpmntDTO);
			 }
			 }
		 
		 }catch(Exception ex){
			 //logger.fatalEvent(this.getClass(), BatchConstants.MTD_SAVE_ENG_TO_EPA, BatchConstants.SAVE_ENG_NT_SUCCESS, ex);
			 logger.error(this.getClass() + BatchConstants.MTD_SAVE_ENG_TO_EPA + BatchConstants.SAVE_ENG_NT_SUCCESS + ex.getMessage());
			 mailSender.sendEmail("Technical Exception occured while saving engine info. Please check EPA Batch logs");
		 }
		 }
	 }
	
	
	/**
	 * Populates the Machine info to EPA database 
	 * @param partShpmnts
	 * @throws ServiceException
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public void saveMachineInfoToEpa(Map<String,EpaShipmentDTO> partShpmnts) throws ServiceException{
		// logger.informationalEvent(this.getClass(), BatchConstants.MTD_SAVE_MCH_TO_EPA, BatchConstants.EXE_SAVE_MCH_TO_EPA);
		logger.info(this.getClass() + BatchConstants.MTD_SAVE_MCH_TO_EPA + BatchConstants.EXE_SAVE_MCH_TO_EPA);
		 EpaShipmentDTO engineShpmntDTO = null;
		 MachineDTO machineDTO = null;
		 EngineDTO engineDTO = null;
		 Map<String,MachineDTO> machineDTOMap = null;
		 
		machineDTOMap = getMachineDetails();
		 
		 Set<Entry<String,EpaShipmentDTO>>  entrySet = partShpmnts.entrySet();
		 
		 Iterator iterator = entrySet.iterator();
		
		 while(iterator.hasNext()){
			 engineDTO = null;
			 machineDTO = null;
			 Entry<String,EpaShipmentDTO> epaEntry = (Entry<String,EpaShipmentDTO>) iterator.next();
			 engineShpmntDTO = (EpaShipmentDTO) epaEntry.getValue();
			 if(null != engineShpmntDTO && engineShpmntDTO.getEpaProdTypeCode().equals(BatchConstants.MACHINE_LITERAL)){
				if(engineShpmntDTO.getProductSerialNum() != null){
				 machineDTO = machineDTOMap.get(engineShpmntDTO.getProductSerialNum().trim());
				}
				 if(machineDTO != null){
					 createMachineShipment ( engineShpmntDTO, machineDTO,  engineDTO );
				 }else{
					 try{
					 epaService.crteMachShp(engineShpmntDTO, null, null);
					 errorMessageCreator.machineInfoNotFound(engineShpmntDTO);
					 }catch(Exception exc){
						// logger.fatalEvent(this.getClass(), BatchConstants.MTD_SAVE_MCH_TO_EPA, BatchConstants.SAVE_MCH_NT_SUCCESS + "Invoice : "+engineShpmntDTO.getInvoiceNum()+"_"+engineShpmntDTO.getProductSerialNum(), exc);
						 logger.error(this.getClass() + BatchConstants.MTD_SAVE_MCH_TO_EPA+ BatchConstants.SAVE_MCH_NT_SUCCESS + "Invoice : "+engineShpmntDTO.getInvoiceNum()+"_"+engineShpmntDTO.getProductSerialNum()+ exc.getMessage());
						 mailSender.sendEmail("Technical Exception occured while saving engine info. Please check EPA Batch logs");
					 }

				 }
			 }
			
		 }
	 }
	
	
	/**
	 * fetches Engine info from Engine Emission database
	 * @return Engine map
	 * @throws ServiceException
	 */
	@SuppressWarnings("unchecked")
	public Map<String,EngineDTO> getEngineDetails(List<String> engines) throws ServiceException{
		//logger.informationalEvent(this.getClass(), BatchConstants.MTD_GET_ENG_DETAILS, BatchConstants.METHOD_ENTRY);
		logger.info(this.getClass()+ BatchConstants.MTD_GET_ENG_DETAILS + BatchConstants.METHOD_ENTRY);
		 Map<String,EngineDTO> serialEngineMainMap = new HashMap<String,EngineDTO>();
		 Map<String,EngineDTO> serialEngineMap = null;
		 int partitionSize = 15;
		 try {
			 
			 for(int j=0; j<engines.size(); j+=partitionSize){
					serialEngineMap = engineEmissionService
							.getEngineInfo(engines.subList(j, Math.min(j + partitionSize, engines.size())));
				 if(null !=serialEngineMap){
				 serialEngineMainMap.putAll(serialEngineMap);
				 }
				}
		} catch (ServiceException e) {
			//logger.fatalEvent(this.getClass(), BatchConstants.MTD_GET_ENG_DETAILS, BatchConstants.ENG_COULD_NOT_RETRIVE_FRM_EED, e);
			logger.error(this.getClass() +  BatchConstants.MTD_GET_ENG_DETAILS+ BatchConstants.ENG_COULD_NOT_RETRIVE_FRM_EED+ e.getMessage());
			throw e;
		}
		// logger.informationalEvent(this.getClass(), BatchConstants.MTD_GET_ENG_DETAILS, BatchConstants.METHOD_EXIT);
		 logger.info(this.getClass()+ BatchConstants.MTD_GET_ENG_DETAILS+ BatchConstants.METHOD_EXIT);
		return serialEngineMainMap;
	 }
	
	
	/**
	 * fetches Machine details
	 *  @return Machine details map
	 * @throws ServiceException
	 */
	@SuppressWarnings("unchecked")
	public Map<String,MachineDTO> getMachineDetails() throws ServiceException{
		//logger.informationalEvent(this.getClass(), BatchConstants.MTD_GET_MCH_DETAILS, BatchConstants.METHOD_ENTRY);
		logger.info(this.getClass()+ BatchConstants.MTD_GET_MCH_DETAILS + BatchConstants.METHOD_ENTRY);
		 Map<String,MachineDTO> machineDetailsMap = null;
		 List<String> machines = (List<String>) BatchContext.getValue(BatchConstants.MACHINE_LITERAL);
		 try{
			 machineDetailsMap =  machineReaderService.getMachineDetails(machines);
		 } catch (ServiceException e) {
				//logger.fatalEvent(this.getClass(), BatchConstants.MTD_GET_MCH_DETAILS, BatchConstants.MCH_INFO_COULD_NT_RETRIVE, e);
			 logger.error(this.getClass() + BatchConstants.MTD_GET_MCH_DETAILS + BatchConstants.MCH_INFO_COULD_NT_RETRIVE + e.getMessage());
				throw e;
		}
		 //logger.informationalEvent(this.getClass(), BatchConstants.MTD_GET_MCH_DETAILS, BatchConstants.METHOD_EXIT); 
		 logger.info(this.getClass() + BatchConstants.MTD_GET_MCH_DETAILS + BatchConstants.METHOD_EXIT); 
		 return machineDetailsMap;
	 }
	
	
	/**
	 * This method is used to create the machine shipment
	 * @param engineShpmntDTO engineShipment
	 * @param machineDTO machineDTO
	 * @param engineDTO	engineDTO
	 */
	private void createMachineShipment (EpaShipmentDTO engineShpmntDTO,MachineDTO machineDTO, EngineDTO engineDTO ) {
		EngineDTO machEng = null;
		 if(null!=engineShpmntDTO.getProductSerialNum()){
			 Set<String> engines = machineDTO.getEngineNumbers();
			 List<String> engineList =  new ArrayList<String>();
			if( engines!= null && !engines.isEmpty())	{
			 engineList.addAll(engines);
			}
			try{
				 Map<String,EngineDTO> serialEngineMap =	engineEmissionService.getEngineInfo(engineList);
				if(serialEngineMap != null && serialEngineMap.size() > 0){
					machEng = serialEngineMap.get(engineList.get(0).trim());
				}
				}catch(Exception exception){
					//logger.fatalEvent(this.getClass(),  BatchConstants.MTD_SAVE_MCH_TO_EPA, BatchConstants.RETRIVG_MCH_NT_SUCCESS, exception);
					logger.error(this.getClass() +  BatchConstants.MTD_SAVE_MCH_TO_EPA +BatchConstants.RETRIVG_MCH_NT_SUCCESS+ exception.getMessage());
				}
			 
			 try{
			 epaService.crteMachShp(engineShpmntDTO, machEng, machineDTO);
			 }catch(Exception ex){
				 //logger.fatalEvent(this.getClass(), BatchConstants.MTD_SAVE_MCH_TO_EPA, BatchConstants.SAVE_MCH_NT_SUCCESS, ex);
				 logger.error(this.getClass() + BatchConstants.MTD_SAVE_MCH_TO_EPA + BatchConstants.SAVE_MCH_NT_SUCCESS + ex.getMessage());
				 mailSender.sendEmail("Technical Exception occured while saving engine info. Please check EPA Batch logs");
			 }
		 }
	 
	}
	
	
	/**
	 * This method returns list of engine serial number from list of engines
	 * @param epaEngines
	 * @return
	 */
	public List<String> getEpaListEngSerNo(List<EpaShipment> epaShipmentLst){
		List<String> listEpaEngSerNo = new ArrayList<String>();
		

		for(EpaShipment epaShipment : epaShipmentLst){
			listEpaEngSerNo.add(epaShipment.getEpaEngines().getId().getEngineSerialNum());
		}
		
		return listEpaEngSerNo;
	}
	
	/**
	 * This method updates engine info to EPa
	 * @param existEpaEngines
	 * @param serialEngineMap
	 * @throws ServiceException
	 */
	public void updateEngineInfoToEpa(List<EpaShipment> existEpaShipment, Map<String,EngineDTO> serialEngineMap){
		for(EpaShipment epaShipment : existEpaShipment){
			
			EngineDTO updatedEpaEngDTO = serialEngineMap.get(epaShipment.getEpaEngines().getId().getEngineSerialNum());
			if(null != updatedEpaEngDTO){
				try{
					epaService.updateExisEngine(epaShipment.getEpaEngines(), updatedEpaEngDTO);
				} catch (Exception e) {}
				
			}
		}
		
	}
}
