/**
 * Copyright (c) Caterpillar Inc. All Rights Reserved.
 * This work contains Caterpillar Inc.'s unpublished proprietary information
 * which may constitute a trade secret and/or be confidential. This work 
 * may be used only for the purposes for which it was provided, and may 
 * not be copied or disclosed to others. Copyright notice is precautionary 
 * only, and does not imply publication.
 *
 * Revision History
 * Version        Date         Changed By        Comments
 *  1.0        20-01-2016                 Initial Creation
 **/
package com.cat.logistics.epa.job.utils;

import java.util.ArrayList;
import java.util.List;
import java.util.Properties;



/**
 * @author 
 *
 */
public final class FTPCodes {

	private static List<String> ftpErrorCodeKeys = new ArrayList<String>();
	private static String ftpErrorMessage = null;
	private static Properties ftpErrorProps;

	/**
	 * Default constructor
	 */
	private FTPCodes(){
	}

	
	/**
	 * Returns the FTP error message using the code Key.
	 * @param code FTPErrorCode
	 * @return FTP error code for the passed code
	 */
	public static String getFtpErrorCode(int code) {
		ftpErrorMessage = getFtpErrorCodeProperty(code);
		return ftpErrorMessage;
	}
	/**
	 * Returns the property label from the ftp error code property file
	 * @return value for passed property
	 * @param propertyName - name of error property code
	 */
	public static String getFtpErrorCodeProperty(int propertyName) {
		final String codeProperty = String.valueOf(propertyName);
		final String errCdProperty = ftpErrorProps.getProperty(codeProperty);
		return errCdProperty.trim();
	}
	/**
	 * Returns the filename keys.
	 * @param theCode FTPErrorCode
	 * @return true if passed code is an ftp error code key
	 */
	public static boolean getFtpErrorCodeKey(final int theCode) {
		final String codeKey = String.valueOf(theCode);
		boolean found = false;
		String akey = null;
		for(int m=0; m<=ftpErrorCodeKeys.size(); m++){
			akey = (String)ftpErrorCodeKeys.get(m);
			if(codeKey.trim().equals(akey.trim())) {
				found = true;
				break;
			}
		}
		return found;
	}


	/**
	 * 
	 * Sets the ftp error code keys.
	 *
	 * @param errorCodesPropertyFile Error Codes Properties file
	 * @throws FTPException RuntimeFTPException
	 */
	public static void setFtpErrorCodeKeys(String errorCodesPropertyFile) throws FTPException {
		//Get ftp_error_code's properties
		try {
			if(ftpErrorProps == null) {
				//ftpErrorProps = TUFServerUtil.getInstance().getProperties(errorCodesPropertyFile);
			}
		} catch (Exception ioe) {
			throw new FTPException(ioe);
		}		
	}

}

