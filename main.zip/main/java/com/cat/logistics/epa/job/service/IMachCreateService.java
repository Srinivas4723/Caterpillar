package com.cat.logistics.epa.job.service;

import com.cat.logistics.epa.dto.EpaShipmentDTO;
import com.cat.logistics.shared.dto.EngineDTO;
import com.cat.logistics.shared.dto.MachineDTO;
import com.cat.logistics.shared.exception.ServiceException;

/**
 * interface for creating machine , eng and shipment
 * @author chanda15
 *
 */
public interface IMachCreateService {

	/**
	 * This is abstract method to create machine , machine's engine and shipment information
	 * @param engineShpmntDTO
	 * @param engineDTO
	 * @param machineDTO
	 * @throws ServiceException
	 */
	public void createMachineShipment(EpaShipmentDTO engineShpmntDTO,
			EngineDTO engineDTO, MachineDTO machineDTO) throws ServiceException ;
}
