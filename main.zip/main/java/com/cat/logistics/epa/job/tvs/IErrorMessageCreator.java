package com.cat.logistics.epa.job.tvs;

import com.cat.logistics.epa.dto.EpaShipmentDTO;

/**
 * @author chanda15
 *
 */
 public interface IErrorMessageCreator {

	/**
	 * @param epaShipmentDTO
	 */
	 void logHTSNotFoundError(EpaShipmentDTO epaShipmentDTO);
	
	/**
	 * @param epaShipmentDTO
	 */
	 void logNoExcptnHTSError(EpaShipmentDTO epaShipmentDTO);
	
	/**
	 * @param epaShipmentDTO
	 */
	 void originFacNotCnfgrEPA(EpaShipmentDTO epaShipmentDTO);
	
	/**
	 * @param epaShipmentDTO
	 */
	 void userNotAssgndFac(EpaShipmentDTO epaShipmentDTO);
	
	/**
	 * @param epaShipmentDTO
	 */
	 void invalidOrigFacSuppCode(EpaShipmentDTO epaShipmentDTO);
	
	/**
	 * @param epaShipmentDTO
	 */
	 void engineSerialNumMissing(EpaShipmentDTO epaShipmentDTO);
	
	/**
	 * @param epaShipmentDTO
	 */
	 void machineSerialNumMissing(EpaShipmentDTO epaShipmentDTO);
	
	/**
	 * @param epaShipmentDTO
	 */
	 void engineInfoNotFound(EpaShipmentDTO epaShipmentDTO);
	
	/**
	 * @param epaShipmentDTO
	 */
	 void machineInfoNotFound(EpaShipmentDTO epaShipmentDTO);
	
	/**
	 * @param epaShipmentDTO
	 */
	 void machEngInfoNotFound(EpaShipmentDTO epaShipmentDTO);
	
	/**
	 * @param epaShipmentDTO
	 */
	 void databaseConnErr(EpaShipmentDTO epaShipmentDTO);
	
	/**
	 * @param epaShipmentDTO
	 */
	 void webServiceConnErr(EpaShipmentDTO epaShipmentDTO);
	
	
	
	
}
