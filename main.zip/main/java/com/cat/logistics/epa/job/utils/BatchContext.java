package com.cat.logistics.epa.job.utils;

import java.util.HashMap;
import java.util.Map;

/**
 * @author chanda15
 *
 */
public class BatchContext {

	@SuppressWarnings({ "rawtypes" })
	public static ThreadLocal contextMap = new ThreadLocal() {

		/** 
		 * initialValue()
		 */
		protected Map initialValue() {

			return new HashMap<String,Object>();
		}
	};
	
	/**
	 * @return Part shipments
	 */
	@SuppressWarnings("rawtypes")
	public static Map getPartShpmnts() {
		Map partShpmnts = (Map) contextMap.get();
		return (Map)partShpmnts.get(BatchConstants.EMPTY_STRING);
	}
	
	/**
	 * @param key
	 * @param value
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public static void put(String key , Object value){
		Map  list = (Map)contextMap.get();
		list.put(key, value);
		
	}
	
	/**
	 * @param key
	 * @return
	 */
	@SuppressWarnings("rawtypes")
	public static Object getValue(String key){
		Map  ctxMap = (Map)contextMap.get();
		
		return ctxMap.get(key);
	}
	
	
	
}
