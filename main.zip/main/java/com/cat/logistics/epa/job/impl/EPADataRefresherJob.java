package com.cat.logistics.epa.job.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cat.logistics.epa.job.IEpaProcess;

/**
 * This class act as initial step to run epa data refresher batch process
 * @author neelask
 *
 */
@Component
public class EPADataRefresherJob implements Runnable{

	@Autowired
	private IEpaProcess epaProcess;
	
	/**
	 * run()
	 */
	public void run(){
		
		epaProcess.epaDataRefresherProcess();
	}
	
}
