/*package com.cat.logistics.epa.job.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cat.logistics.epa.dto.EpaShipmentDTO;
import com.cat.logistics.epa.entities.EpaHtsConfgr;
import com.cat.logistics.epa.entities.EpaHtsExcpConfgr;
import com.cat.logistics.epa.job.IHTSProcess;
import com.cat.logistics.epa.job.service.IEPAService;
import com.cat.logistics.epa.job.tis.ITISService;
import com.cat.logistics.epa.job.utils.BatchConstants;
import com.cat.logistics.epa.job.utils.BatchContext;
import com.cat.logistics.epa.job.utils.ILogger;
import com.cat.logistics.epa.job.utils.Logger;
import com.cat.logistics.shared.exception.ServiceException;
import com.cat.logistics.tis.entities.HTSCodes;
*//**
 * This is a process class to monitor if
 * there are any parts which are eligible for EPA certification
 * based on the latest HTS code change
 * @author chanda15
 *
 *//*
@Component
public class HTSProcess extends AbstractProcess implements IHTSProcess{

	private ILogger logger = Logger.getInstance();
	
	@Autowired
	ITISService tisService;
	
	@Autowired
	IEPAService epaService;
	
	*//**
	 * process to check for hts classification
	 * changes for part numbers which need EPA certification
	 * @throws ServiceException 
	 *//*
	@Override
	public void htsCdMonitor() throws Exception {
		logger.informationalEvent(HTSProcess.class, BatchConstants.MTD_HTS_CD_MNTR, BatchConstants.EXE_HTS_CD_MNTR);
		List<HTSCodes> htsCdsList = null;
		boolean jobSuccs = true;
		try{
		jobInitialization(BatchConstants.HTS_JOB_NAME);
		// Read records which were modified in last 24 hours in CAT_ID_XREF table
		 htsCdsList = tisService.getHtsCdChngs();
		if(htsCdsList != null){
		 Map<String, String> partDetMap = getEpaParts(htsCdsList);
		 htsCdsList= null;
		 if(!partDetMap.isEmpty()){
		 Map<String,EpaShipmentDTO> partShpmnts = tisService.getPartsFrmTIS(partDetMap);
		 getPartSerialNum(partShpmnts);
		 setEpaPartType(partShpmnts);
		 jobSuccs = processEPAParts(partShpmnts);
		 }
		 jobShutDown(BatchConstants.HTS_JOB_NAME, jobSuccs);
			
		}
		 
		}catch(Exception ex){
			ex.printStackTrace();
			logger.fatalEvent(HTSProcess.class, BatchConstants.MTD_HTS_CD_MNTR, ex.getMessage(), ex);
			throw ex;
		}
		
		
	}
	
	*//**
	 * 
	 * @param htsCdsList
	 * @return
	 * @throws Exception
	 *//*
	public Map<String,String> getEpaParts(List<HTSCodes> htsCdsList) throws Exception{
		logger.informationalEvent(HTSProcess.class, BatchConstants.MTD_GET_EPA_PARTS, BatchConstants.EXE_GET_EPA_PARTS);
		Map<String,String> partHtsCd = new HashMap<String,String>();
		Map<String,String> partDetMap = new HashMap<String,String>();
		boolean valid = false;
		 List<EpaHtsConfgr> epaHtsCnfgList = null;
		
		try{
			epaHtsCnfgList = epaService.getEpaHtsCds();
			for(HTSCodes htsCode : htsCdsList){
				valid = epaService.validEpaHtsCd(htsCode, epaHtsCnfgList);
				if(valid){
					partDetMap.put(htsCode.getPartId(), htsCode.getPartTyp());
					partHtsCd.put(htsCode.getPartId(), htsCode.getHtsCode());
				}
			}
			
			BatchContext.put(BatchConstants.PART_HTSCD, partHtsCd);
			
		}catch(ServiceException svcExcp){
			logger.fatalEvent(HTSProcess.class, BatchConstants.MTD_HTS_CD_MNTR, svcExcp.getMessage(), svcExcp);
			throw svcExcp;
		}
		return partDetMap;
	}
	
	*//**
	 * 
	 * @param partShpmnts
	 * @throws Exception
	 *//*
	@SuppressWarnings("unchecked")
	public void getPartSerialNum(Map<String,EpaShipmentDTO> partShpmnts) throws Exception{
		
		String[] entryKey = null;
		Map<String,String> partTyps = (Map<String,String>)	BatchContext.getValue(BatchConstants.PART_PARTTYPE);
		Map<String,String> partHts = (Map<String,String>) BatchContext.getValue(BatchConstants.PART_HTSCD);
		Set<Entry<String,EpaShipmentDTO>> entries = partShpmnts.entrySet();
		
		for(Entry entry : entries){
			EpaShipmentDTO shpmntDto = (EpaShipmentDTO) entry.getValue();
			entryKey = ((String)entry.getKey()).split(BatchConstants.HYPHEN);
			String part = entryKey[0];
			shpmntDto.setEpaProdTypeCode(partTyps.get(part));
			shpmntDto.setHtsCode(partHts.get(part));
		}
		
		tisService.getPartSerialNumbers(partShpmnts);
	}
	
	*//**
	 * 
	 * @param partShpmnts
	 * @throws Exception
	 *//*
	public void setEpaPartType(Map<String,EpaShipmentDTO> partShpmnts) throws Exception{
		
		try{
			epaService.partDetermination(partShpmnts, false);
			}catch(Exception ex){
				logger.fatalEvent(HTSProcess.class, BatchConstants.MTD_HTS_CD_MNTR, ex.getMessage(), ex);
				throw ex;
		}
	}
	
	*//**
	 * 
	 * @param htsCode
	 * @return
	 * @throws ServiceException
	 *//*
	public EpaHtsExcpConfgr checkForExcptnPart(HTSCodes htsCode) throws ServiceException{
		logger.informationalEvent(HTSProcess.class, BatchConstants.MTD_CHECK_EXCP_PARTS, BatchConstants.EXE_CHECK_EXCP_PARTS);
		EpaHtsExcpConfgr excptCnfgr = null;
		excptCnfgr = epaService.getEpHtsExcpConfgr(htsCode.getPartId(), htsCode.getHtsCode());
		return excptCnfgr;
	}

	
	
}
*/