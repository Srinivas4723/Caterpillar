package com.cat.logistics.epa.job;

/**
 * 
 * @author addansn
 *
 */
public interface IAutoECCNUtiliyProcess {

	/**
	 * 
	 * @getECCNfiles
	 */
	void getECCNfiles() throws Exception;
	
}
