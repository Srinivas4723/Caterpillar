/*package com.cat.logistics.epa.job.impl;

import org.springframework.beans.factory.annotation.Autowired;

import com.cat.logistics.epa.job.IHTSProcess;

public class HTSJob implements Runnable {

	@Autowired
	IHTSProcess htsProcess;
	
	@Override
	public void run() {
		try{
			htsProcess.htsCdMonitor();
		}catch(Exception exception){
			exception.printStackTrace();
		}
	}

}
*/