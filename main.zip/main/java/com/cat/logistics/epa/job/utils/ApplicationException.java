package com.cat.logistics.epa.job.utils;



/*
 * Copyright (c) 2014 Caterpillar Inc. All Rights Reserved.
 *
 * This work contains Caterpillar Inc.'s unpublished
 * proprietary information which may constitute a trade secret
 * and/or be confidential. This work may be used only for the
 * purposes for which it was provided, and may not be copied
 * or disclosed to others. Copyright notice is precautionary
 * only, and does not imply publication.
 */

/**
 * Custom Exception
 */


public class ApplicationException extends Exception {

	public static final int SEVERITY_FATAL = BatchConstants.SEVERITY_FATAL;
	public static final int SEVERITY_WARNING = BatchConstants.SEVERITY_WARNING;
	public static final int SEVERITY_INFORMATIONAL = BatchConstants.SEVERITY_INFORMATIONAL;
	public static final int SEVERITY_SUCCESSFUL = BatchConstants.INT_0;

	/** Update comment for serialVersionUID. */
	private static final long serialVersionUID = 1L;
	private Class<?> classReference;
	private String methodReference;
	private int severityLevel;
	private String errorCode;
	private String technicalMessage;
	private Exception nestedException;

	

	/**
	 * 
	 * Update constructor documentation for ApplicationException
	 * Description of the constructor.
	 *
	 * @param newClassReference Class name
	 * @param newMethodReference method name
	 * @param newSeverityLevel severity level
	 * @param newTechnicalMessage technical message
	 *
	 */
	public ApplicationException(Class<?> newClassReference,
			String newMethodReference, int newSeverityLevel,
			String newTechnicalMessage) {

		classReference = newClassReference;
		methodReference = newMethodReference;
		severityLevel = newSeverityLevel;
		technicalMessage = newTechnicalMessage;
	}

		/**
	 * 
	 * Update constructor documentation for ApplicationException
	 * Description of the constructor.
	 *
	 * @param newClassReference Class name
	 * @param newMethodReference method name
	 * @param newSeverityLevel severity level
	 * @param newTechnicalMessage technical message
	 * @param newNestedException Nested exception
	 * @param newErrorCode Error Code
	 
	 */
	public ApplicationException(Class<?> newClassReference,
			String newMethodReference, int newSeverityLevel,
			String newErrorCode, String newTechnicalMessage,
			Exception newNestedException) {
		severityLevel = newSeverityLevel;
		errorCode = newErrorCode;
		classReference = newClassReference;
		methodReference = newMethodReference;
		technicalMessage = newTechnicalMessage;
		nestedException = newNestedException;
	}

	/**
	 * getClassReference() - Returns the String to identify the Class name where
	 * the error occurred. This is used for logging.
	 * 
	 * @return java.lang.String class reference
	 */
	public Class<?> getClassReference() {
		return classReference;
	}

	/**
	 * Insert method description
	 */
	/**
	 * Returns the error code.
	 *
	 * @return java.lang.String
	 */
	public String getErrorCode() {
		return errorCode;
	}

	/**
	 * Returns the String to identify the method name where the error occurred.
	 * 
	 * @return java.lang.String method reference
	 */
	public String getMethodReference() {
		return methodReference;
	}

	/**
	 * Gets the Exception nested inside this ApplicationException Creation date:
	 *
	 * @return java.lang.Exception
	 */
	public Exception getNestedException() {
		return nestedException;
	}

	/**
	 * Returns the severity level of this Application Exception. This is used to
	 * determine what level of logging must occur. 
	 * 
	 * @param errorCode Error Code
	 * 
	 *@return String (error status)
	 *@exception MissingResourceException
	 */
	public int getSeverityLevel() {
		return severityLevel;
	}

	/**
	 * Returns a technically informative error message.
	 * 
	 *@return String (TechnicalMessage)
	 */
	public String getTechnicalMessage() {
		return technicalMessage;
	}

	
	/**
	 * 
	 * Sets the technical message
	 *
	 * @param newTechnicalMessage Technical message
	 
	 */
	public void setTechnicalMessage(String newTechnicalMessage) {
		technicalMessage = newTechnicalMessage;
	}


}
