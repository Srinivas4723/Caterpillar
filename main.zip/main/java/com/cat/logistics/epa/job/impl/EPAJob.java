package com.cat.logistics.epa.job.impl;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cat.logistics.epa.job.IAutoECCNCatClassProcess;
import com.cat.logistics.epa.job.IAutoECCNUtiliyProcess;
import com.cat.logistics.epa.job.IEpaProcess;
import com.cat.logistics.epa.job.utils.ApplicationException;

/**
 * This class act as initial step to run epa batch process
 * @author ganamr
 *
 */
@Component
public class EPAJob implements Runnable{

	@Autowired
	private IEpaProcess epaProcess;
	
	/**
	 * run()
	 */
	public void run(){
		
			epaProcess.epaProcess();
	}
	
}
