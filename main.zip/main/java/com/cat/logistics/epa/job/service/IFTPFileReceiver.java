/*
 * Copyright (c) 2015 Caterpillar Inc. All Rights Reserved.
 *
 * This work contains Caterpillar Inc.'s unpublished
 * proprietary information which may constitute a trade secret
 * and/or be confidential. This work may be used only for the
 * purposes for which it was provided, and may not be copied
 * or disclosed to others. Copyright notice is precautionary
 * only, and does not imply publication.
 */

package com.cat.logistics.epa.job.service;




/** This class return FTP file type receiver 
 * @author singhr9 2015 3:08:19 PM
 * 
 */
public interface IFTPFileReceiver extends IFileReader {

}
