package com.cat.logistics.epa.job.tvs.impl;

import java.util.Date;
import java.util.GregorianCalendar;
import java.util.TimeZone;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ws.client.core.WebServiceTemplate;

import com.cat.logistics.epa.job.dto.TVSErrorMessage;
import com.cat.logistics.epa.job.tvs.ITVSErrorLogger;
import com.cat.logistics.epa.job.utils.BatchConstants;
import com.cat.logistics.epa.job.utils.Utils;
import com.cat.logistics.shared.utils.PersistenceConstants;
import com.cat.transp.vws.oxm.errorhandling.WebServiceReturn;
import com.cat.transp.vws.oxm.websvc3.InsertIncomingFileData;
import com.cat.transp.vws.oxm.websvc3.InsertIncomingFileDataResponse;
import com.cat.transp.vws.oxm.websvc4.InsertErrorMessages;
import com.cat.transp.vws.oxm.websvc4.InsertErrorMessagesResponse;

/**
 * @author chanda15
 *
 */
public class TVSErrorLogger implements ITVSErrorLogger{

	@Autowired
	private WebServiceTemplate storeErrMsgWSTemp ;
	
	public static final Logger LOGGER = LogManager.getLogger(TVSErrorLogger.class);
	
	@Autowired
	private WebServiceTemplate insrtIncmgWSTemp;
	
	/**
	 * TVSErrorLogger
	 */
	public void tvsErrorLogger(){
		setDefaultUri();
	}
	
	/**
	 * setDefaultUri
	 */
	private void setDefaultUri() {
		String vwsUrl = Utils.getProperty(Utils.getCurrentEnvironment() + BatchConstants.VWS_URL);
		insrtIncmgWSTemp.setDefaultUri(Utils.concatenate(vwsUrl, BatchConstants.STORE_INCOMING_FILE_DATA));
		storeErrMsgWSTemp.setDefaultUri(Utils.concatenate(vwsUrl, BatchConstants.STORE_ERROR_MESSAGES));
		
	}
	
	
	/** 
	 * logging Error message to TVS
	 * @see com.cat.logistics.epa.job.tvs.ITVSErrorLogger#logErrorMessage(com.cat.logistics.epa.job.dto.TVSErrorMessage)
	 */
	public void logErrorMessage(TVSErrorMessage tvsErrorMessage){
		storeIncomingFileData(tvsErrorMessage);
		storeErrorMessages(tvsErrorMessage);
		
	}
	
	
	/**
	 * Passing Error details as input  to TVS(VWS) web service and getting response object
	 * @param tvsErrorMessage
	 */
	public void storeIncomingFileData(TVSErrorMessage tvsErrorMessage)  {
		LOGGER.info("Entry method of storeIncomingFileData {}", BatchConstants.METHOD_ENTRY);
		InsertIncomingFileData requestObj = null;
		InsertIncomingFileDataResponse responseObj = null;
		WebServiceReturn returnVal = null;
		try {
			setDefaultUri();
			requestObj = new InsertIncomingFileData();

			requestObj.setIncmgMsgFileNm(tvsErrorMessage.getIncmgMsgFileNm());
			tvsErrorMessage.setMsgRcvdTmstmp(new Date());
			requestObj.setMsgRcvdTS(convertToXmlDate(tvsErrorMessage.getMsgRcvdTmstmp()));
			requestObj.setSrcSysId(tvsErrorMessage.getSourceSystem());
			requestObj.setSrcSysKeyVal(tvsErrorMessage.getKeyValue());

			responseObj = (InsertIncomingFileDataResponse) insrtIncmgWSTemp
					.marshalSendAndReceive(requestObj);

			returnVal = responseObj == null ? null : responseObj
					.getInsertIncomingFileDataReturn();
			if (returnVal == null) {
				LOGGER.info("Entry method of storeIncomingFileData {}",
						BatchConstants.NO_RSPNS_FRM_VWS_SERVICE);
			} else {
				LOGGER.info("Entry method of storeIncomingFileData {} {}",
						returnVal.getReturnCode(),returnVal.getDetailedMessage());
			}
		} catch (Exception excep) {
			LOGGER.error("Error in storeIncomingFileData {} {}",
					BatchConstants.MTD_STORE_INCMG_FILE_DATA,
					(BatchConstants.EXC_OCCURRED),(Exception) excep);		

		}
	}
	
	/**
	 * Passes error message as input to the vws service and gets the response object
	 * @param tvsErrorMessage
	 */
	@SuppressWarnings("unused")
	private void storeErrorMessages(TVSErrorMessage tvsErrorMessage) {
		InsertErrorMessages requestObj = null;
		InsertErrorMessagesResponse responseObj = null;
		WebServiceReturn returnVal = null;
		try {
			setDefaultUri();
			requestObj = new InsertErrorMessages();

			requestObj.setMsgRcvdTS(convertToXmlDate(tvsErrorMessage.getMsgRcvdTmstmp()));
			requestObj.setErrCd(tvsErrorMessage.getErrorCode());
			requestObj.setSrcSysId(tvsErrorMessage.getSourceSystem());
			requestObj.setErrDet(tvsErrorMessage.getErrorDetails());
			requestObj.setSrcSysKeyVal(tvsErrorMessage.getKeyValue());

			responseObj = (InsertErrorMessagesResponse) storeErrMsgWSTemp
					.marshalSendAndReceive(requestObj);

			returnVal = responseObj == null ? null : responseObj
					.getInsertErrorMessagesReturn();
			if (returnVal == null) {
				LOGGER.info("Entry method of storeErrorMessages {} {}",
						BatchConstants.NO_RSPNS_FRM_VWS_SERVICE,
						new Exception());
			} else {
				LOGGER.info("Entry method of storeErrorMessages {}{}{}{}{}{}",
						BatchConstants.ERR_REPRT_SENT_FOR , BatchConstants.KEY_VALUE_VAR ,BatchConstants.AND_RETRN_WITH_CD
						, returnVal.getReturnCode() , BatchConstants.MSG
						, returnVal.getDetailedMessage());
			}

		} catch (Exception exc) {
			LOGGER.error("Error in storeErrorMessages {} {} ",
					BatchConstants.EXC_OCCURRED, exc.toString(),
					(Exception) exc);
			
			StackTraceElement stackTracEle = exc.getStackTrace()[0];
			

		}

	}
	
	/**
	 * converts Date into xml date
	 * @param utilDate
	 * @return XMLGregorianCalendar object
	 */
	public XMLGregorianCalendar convertToXmlDate(Date utilDate)  {
		LOGGER.info("Entry method of convertToXmlDate {}", BatchConstants.METHOD_ENTRY);
		if (utilDate == null) {
			return null;
		}
		GregorianCalendar gregorianCalendar = new GregorianCalendar();
		gregorianCalendar.setTime(utilDate);

		gregorianCalendar.setTimeZone(TimeZone.getTimeZone(BatchConstants.CST_VAR));
		XMLGregorianCalendar xmlGregorianCalendar = null;
		try {
			xmlGregorianCalendar = DatatypeFactory.newInstance().newXMLGregorianCalendar(gregorianCalendar);
		} catch (DatatypeConfigurationException exceptionConfg) {
			LOGGER.error("Error in convertToXmlDate {}", BatchConstants.CONVERT_TO_XML_FAILED, exceptionConfg);
			
		}
		LOGGER.info("Exit method of convertToXmlDate {}", BatchConstants.METHOD_EXIT);
		return xmlGregorianCalendar;
	}
	
	
}
