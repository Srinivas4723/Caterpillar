/*
 * Copyright (c) 2015 Caterpillar Inc. All Rights Reserved.
 *
 * This work contains Caterpillar Inc.'s unpublished
 * proprietary information which may constitute a trade secret
 * and/or be confidential. This work may be used only for the
 * purposes for which it was provided, and may not be copied
 * or disclosed to others. Copyright notice is precautionary
 * only, and does not imply publication.
 */

package com.cat.logistics.epa.job.service;

import com.cat.logistics.epa.job.dto.ECCNFileDetails;
import com.cat.logistics.epa.job.utils.ApplicationException;

/** This class used to read the files from the SI mail box
 * @author kk3
 *
 */
public interface IFileReader {
	
	/** This method copies files from SI mail box and places into temporary folder
	 * @param fileDtls
	 * @return
	 * @throws ApplicationException
	 * @throws Exception 
	 */
	boolean recvStmnt(ECCNFileDetails fileDtls, boolean jobSuccess) throws ApplicationException, Exception;

}
