/**
 * Copyright (c) Caterpillar Inc. All Rights Reserved. This work contains
 * Caterpillar Inc.'s unpublished proprietary information which may constitute a
 * trade secret and/or be confidential. This work may be used only for the
 * purposes for which it was provided, and may not be copied or disclosed to
 * others. Copyright notice is precautionary only, and does not imply
 * publication.
 *
 * ILogger.java Class Description : Revision History Version Date Changed By
 * Comments 1.0 09-02-2014 singhr9 Initial Creation
 */
/*
 * 
 * package com.cat.logistics.epa.job.utils;
 * 
 * import cat.cis.tuf.common.directory.Person;
 * 
 *//**
	 * Tis class defines the levels of logging used by application
	 */
/*
 * public interface ILogger {
 * 
 *//**
	 * Method Description : fatalEvent
	 * 
	 * @param classReference
	 * @param methodName
	 * @param message
	 * @param e              void
	 */
/*
 * @SuppressWarnings({ "rawtypes" }) void fatalEvent(Class classReference,
 * String methodName, String message, Exception e);
 * 
 *//**
	 * Method Description : traceEvent
	 * 
	 * @param requestId
	 * @param classReference
	 * @param methodName
	 * @param begin          void
	 */
/*
 * @SuppressWarnings("rawtypes") void traceEvent(int requestId, Class
 * classReference, String methodName, boolean begin);
 * 
 *//**
	 * Method Description : informationalEvent
	 * 
	 * @param classReference
	 * @param methodName
	 * @param message        void
	 */
/*
 * @SuppressWarnings("rawtypes") void informationalEvent(Class classReference,
 * String methodName, String message);
 * 
 *//**
	 * Method Description : usageEvent
	 * 
	 * @param classReference
	 * @param person
	 * @param elapsed        void
	 */
/*
 * @SuppressWarnings({ "rawtypes" }) void usageEvent(Class classReference,
 * Person person, long elapsed);
 * 
 *//**
	 * Method Description : warningEvent
	 * 
	 * @param classReference
	 * @param methodName
	 * @param message        void
	 *//*
		 * @SuppressWarnings("rawtypes") void warningEvent(Class classReference, String
		 * methodName, String message);
		 * 
		 * }
		 */