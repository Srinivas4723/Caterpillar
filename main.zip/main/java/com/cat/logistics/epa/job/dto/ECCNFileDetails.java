/**
 * Copyright (c) Caterpillar Inc. All Rights Reserved.
 * This work contains Caterpillar Inc.'s unpublished proprietary information
 * which may constitute a trade secret and/or be confidential. This work 
 * may be used only for the purposes for which it was provided, and may 
 * not be copied or disclosed to others. Copyright notice is precautionary 
 * only, and does not imply publication.
 *
 * Logger.java
 * Class Description  : 
 * Revision History
 * Version        Date         Changed By        Comments
 *  1.0           Oct 9, 2015      singhr9           Initial Creation
 */

package com.cat.logistics.epa.job.dto;


/**
 * This class used to set the file information based on daily or monthly statement
 * @author addansn
 */
public class ECCNFileDetails {
	
	
	public enum FileType {BINARY,ASCII};
	
	//Name of the file
	private String fileName;
	
	//Content of the file
	private String fileContent;
	
	//Group Type of the file like - monthly statement, daily statement
	private String fileGrpType;
	
	//Directory of the file location
	private String srcDirctry;
	
	//Type of the FTP file i.e. Binary of ASCII
	private FileType fileType;
	
	
	
	/**
	 * @param fileGrpType
	 * @param srcDirctry
	 * @param fileType
	 */
	public ECCNFileDetails(String fileGrpType, String srcDirctry,
			FileType fileType) {
		super();
		this.fileGrpType = fileGrpType;
		this.srcDirctry = srcDirctry;
		this.fileType = fileType;
	}

	/**
	 * @return the fileName
	 */
	public String getFileName() {
		return fileName;
	}

	/**
	 * @param fileName
	 */
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	/**
	 * @return the fileContent
	 */
	public String getFileContent() {
		return fileContent;
	}

	/**
	 * @param fileContent
	 */
	public void setFileContent(String fileContent) {
		this.fileContent = fileContent;
	}

	/**
	 * @return the fileGrpType
	 */
	public String getFileGrpType() {
		return fileGrpType;
	}

	/**
	 * @param fileGrpType
	 */
	public void setFileGrpType(String fileGrpType) {
		this.fileGrpType = fileGrpType;
	}

	/**
	 * @return the srcDirctry
	 */
	public String getSrcDirctry() {
		return srcDirctry;
	}

	/**
	 * @param srcDirctry
	 */
	public void setSrcDirctry(String srcDirctry) {
		this.srcDirctry = srcDirctry;
	}

	/**
	 * @return the FileType
	 */
	public FileType getFileType() {
		return fileType;
	}

	/**
	 * @param fileType
	 */
	public void setFileType(FileType fileType) {
		this.fileType = fileType;
	}
	
	

}
