package com.cat.logistics.epa.job.tis;

import java.util.List;
import java.util.Map;

import com.cat.logistics.epa.dto.EpaShipmentDTO;
import com.cat.logistics.shared.exception.ServiceException;
import com.cat.logistics.tis.entities.HTSCodes;
import com.cat.logistics.tis.entities.SupplierInvoiceItem;

/**
 * @author chanda15
 *
 */
public interface ITISService {

	/**
	 * @return Shipment DTO
	 * @throws ServiceException
	 */
	 Map<String,EpaShipmentDTO>  getPartsFrmTIS() throws ServiceException;
	 
	 /**
	 * @return Shipment DTO
	 * @throws ServiceException
	 */
	 Map<String,EpaShipmentDTO>  getPartsFrmTIS(Map<String,String> partDetMap) throws ServiceException;
	 
	 /**
	  * Retrieves product serial numbers of Parts
	  * @param partShipments
	  * @throws ServiceException
	  */
	 void getPartSerialNumbers(Map<String,EpaShipmentDTO>  partShipments) throws ServiceException;
	 
	 /**
	  * 
	  * @param partNumbers
	  * @param shpmntParts
	  * @param partShipments
	  * @throws Exception
	  */
	 public void extractPartNumbers(List<String> partNumbers,List<SupplierInvoiceItem> shpmntParts,Map<String,EpaShipmentDTO>  partShipments) throws Exception;
	 
	 /**
	  * 
	  * @return
	  */
	 List<HTSCodes> getHtsCdChngs() throws Exception ;
	
}
