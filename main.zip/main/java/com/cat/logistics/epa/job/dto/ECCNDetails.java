/**
 * Copyright (c) Caterpillar Inc. All Rights Reserved.
 * This work contains Caterpillar Inc.'s unpublished proprietary information
 * which may constitute a trade secret and/or be confidential. This work 
 * may be used only for the purposes for which it was provided, and may 
 * not be copied or disclosed to others. Copyright notice is precautionary 
 * only, and does not imply publication.
 *
 * Revision History
 * Version        Date         Changed By        Comments
 *  1.0        20-01-2016      kk3           Initial Creation
 **/
package com.cat.logistics.epa.job.dto;

/** This class is used to set Ach related information from properties file
 * @author addansn
 *
 */
public class ECCNDetails {
	

	private String tmpFldrLocDly;
	private String mailSub;
	private String mailCnt;
	
	/**
	 * @return the tmpFldrLoc
	 */
	public String getTmpFldrLocDly() {
		return tmpFldrLocDly;
	}

	/**
	 * @param tmpFldrLoc the tmpFldrLoc to set
	 */
	public void setTmpFldrLocDly(String tmpFldrLocDly) {
		this.tmpFldrLocDly = tmpFldrLocDly;
	}

	/**
	 * @return the mailSub
	 */
	public String getMailSub() {
		return mailSub;
	}

	/**
	 * @param mailSub the mailSub to set
	 */
	public void setMailSub(String mailSub) {
		this.mailSub = mailSub;
	}

	/**
	 * @return the mailTo
	 */
	public String getMailCnt() {
		return mailCnt;
	}

	/**
	 * @param mailTo the mailTo to set
	 */
	public void setMailCnt(String mailCnt) {
		this.mailCnt = mailCnt;
	}

}
