package com.cat.logistics.epa.job.utils;

import java.util.Arrays;
import java.util.List;

/**
 * @author ganamr
 *
 */
 public interface BatchConstants {

	 static final String APPLICATION = "EPA_BATCH_JOB";
	 static final String APPLICATION_WND = "EPA_BATCH_JOB_WNDS";
	 static final String EPA_DATA_REFRESH = "EPA_DATA_REFRESH_JOB";
	 static String ENGINE_LITERAL = "E";
	 static String E_PARTS = "E_PARTS";
	 static String M_PARTS = "M_PARTS";
	 static String PART_PARTTYPE = "PART_PARTTYPE";
	 static String PART_HTSCD = "PART_HTSCD";
	 static String MACHINE_LITERAL = "M";
	 static String YES_LITERAL = "Y";
	 static String NO_LITERAL = "N";
	 static String ENGINE = "ENGINE";
	 static String MACHINE = "MACHINE";
	 static String PART_NUM_LIST = "PART_NUM_LIST";
	 static String ORDER_NUMBER = "OrderNumber";
	 static String REDUCE_MINUTES = "REDUCE_MINS";
	 static String EXCLUSION_SUPP_CD = "EXCLUSION_SUPP_CD";
	 static String EXCLUSION_ORG_FAC_CD = "EXCLUSION_ORG_FAC_CD";
	 
	 String SEMICOLON =";";
	
	//Number Constants
	 static final int NUM_SIX = 6;
	 static final int NUM_FOUR = 4;
	 static final int NUM_SEVEN = 7;
	
	 static final String VWS_URL = "_VWS_URL";
	 static final String LOG_PROPERTIES_FILE = "properties/epa_batch_log";
	 static final String MAIL_DTO = "MAIL_DTO";
	 static String READ_TIME = "READ_TIME";
	
	// ERROR CODES
	 static final String ERR_040 = "ERR_040";
	 static final String ERR_040_1 = "ERR_040_1";
	 static final String ERR_219 = "ERR_219";
	 static final String ERR_308 = "ERR_308";
	 static final String ERR_223 = "ERR_223";
	 static final String ERR_023 = "ERR_023";
	 static final String ERR_023_1 = "ERR_023";
	 static final String ERR_023_2 = "ERR_023";
	 static final String ERR_095 = "ERR_095";
	 static final String ERR_098 = "ERR_098";
	 static final String ERR_007 = "ERR_007";
	 static final String ERR_224_1 = "ERR_224_1";
	 static final String ERR_224_2 = "ERR_224_2";
	 static final String ERR_224_3 = "ERR_224_3";
	 static final String ERR_995 = "ERR_995";
	 static final String ERR_998 = "ERR_998";
	
	 static enum ERR_CODES {ERR_040,ERR_219,ERR_308,ERR_223,ERR_224,ERR_023,ERR_095,ERR_098,ERR_007,ERR_995,ERR_998};
	
	 static final String ORDER_NUM_VAR = "<OrderNumber>";
	 static final String SEQ_NUM_VAR = "<ItemSeqNo>";
	 static final String INVOICE_NUM_HOLDER = "<InvoiceNumber>";
	 static final String SUPP_CD_HOLDER = "<SupplierCode>";
	 static final String ORIG_FAC_CD_HOLDER = "<OriginFacilityCode>";
	 static final String PART_NUM_HOLDER = "<PartNumber>";
	 static final String RECV_FAC_CD_HOLDER = "<ReceivingFacilityCode>";
	 static final String HTS_CD_HOLDER = "<HTSCODE>";
	 static final String ENG_SER_HOLDER = "<EngineSerialNumber>";
	 static final String MCH_SER_HOLDER = "<MachineSerialNumber>";
	 static final String EPA_SOURCE_SYSTEM = "EPA";
	 static final String EPA_INPUT_FILE = "EPA_BATCH_RECORD";
	
	 static final String HYPHEN = "-";
	
	 static final String STORE_INCOMING_FILE_DATA = "StoreIncomingFileData";
	 static final String STORE_ERROR_MESSAGES = "StoreErrorMessages";
	
	 static final String MISSING_DATA = "MD";
	 static final String NOT_STARTED = "NS";
	 static enum STATUS_CDS {
		    NS, MD, WIP, RFA, CMP, STB
		}
	 static final String EMPTY_STRING = "";
	
	 static final String FAC_CD_68 = "68";
	 static final String FAC_CD_47 = "47";
	 static final String FAC_CD_1111 = "1111";
	 static final String FAC_CD_2222 = "2222";
	 static final String FAC_CD_3333 = "3333";
	 static final String UNASG_FAC = "Unassigned Origin Facility";
	 static final String SERV_PARTS_FAC = "Service Parts Facilities";
	 static final String REMAN_FAC = "Reman Facilities";
	 static final String UNKNOWN_FAC = "UNKNOWN FACILITY";
		static final String METHOD_ENTRY = "Entry to Method ";
		static final String METHOD_EXIT	= "Exit from Method ";
	 static final String PR_ENV = "PR";
	 static final String QA_ENV = "QA";
	 static final String TEST_ENV = "TEST";
	 static final String UI_ENV = "UT";
	 static final String PROPERTIES_EPA_BATCH = "properties/epa_batch_job.properties";
	 static final String PROPERTIES_ECCN_BATCH = "properties/eccn_application.properties";
	
	 /*EPA PROCESS CONSTANTS*/
	 static final String MTD_EPA_PROCESS = "epaProcess";
	 static final String MTD_EPA_DATA_REF_PROCESS = "epaDataRefresherProcess";
	 static final String EPA_BATCH_STARTED = "EPA Batch job started";
	 static final String EPA_BATCH_DATA_REFR_STARTED = "EPA Data Refresh job started";
	 static final String ENG_DATA_COULDNT_SAVE = "Engine data could not be saved to EPA";
	 static final String MCH_DATA_COULDNT_SAVE = "Machine data could not be saved to EPA";
	 static final String EPA_PROCESS_FAILED = "EPA Process failed";
	 static final String TECH_EXCEPTION = "Technical Exception occured . Please check EPA Batch logs";
	 static final String MTD_READ_MAIL_CONFIG = "readMailConfigurations";
	 static final String EXCUTING_RD_MAIL_CONFIG = "executing readMailConfigurations";
	 static final String MTD_SAVE_ENG_TO_EPA = "saveEngineInfoToEpa";
	 static final String EXE_SAVE_ENG_TO_EPA = "executing saveEngineInfoToEpa";
	 static final String ENG_COULD_NOT_RETRIVE_FRM_EED = "Engine information could not be retrieved from EngineEmission";
	 static final String SAVE_ENG_NT_SUCCESS = "saving Engine information not successfull";
	 static final String MTD_SAVE_MCH_TO_EPA = "saveMachineInfoToEpa";
	 static final String EXE_SAVE_MCH_TO_EPA = "executing saveMachineInfoToEpa";
	 static final String RETRIVG_MCH_NT_SUCCESS = "Retrieving Machine information for machine not successfull";
	 static final String SAVE_MCH_NT_SUCCESS = "saving machine information not successfull";
	 static final String MTD_GET_ENG_DETAILS = "getEngineDetails";
	 static final String MTD_GET_MCH_DETAILS = "getMachineDetails";
	 static final String MCH_INFO_COULD_NT_RETRIVE = "Machine information could not be retrieved";
	 static final String JOB_STRT_TIME = "jobStartTime";
	 static final String EXE_JB_STRT_TIME = "executing jobStarttime";
	 static final String LOG_JB_STRT_TIME_FAILED = "logging jobstarttime failed";
     static final String JB_END_TIME ="jobEndTime";
     static final String MTD_SAVE_SCCS_TM ="saveSuccTm";
     static final String EXE_JB_END_TIME = "executing jobEndTime";
     static final String EXE_SAV_SUCCS_TM = "executing savesuccstime";
     static final String LOG_JB_END_TIME_FAILED = "logging jobEndTime failed";
     static final String MTD_GET_SHP_PARTS = "getShpmntParts";
     static final String EXCP_GET_SHP_PARTS = "total number of shipments ";
    
    /*ERROR MESSAGE CREATOR CONSTANTS*/
     static final String LOGGING_ERR_CD_TO_TVS = "logging error code into TVS";
     static final String MTD_LOG_HTS_NT_FOUND_ERR = "logHTSNotFoundError";
     static final String MTD_DB_CONN_ERR = "databaseConnErr";
     static final String MTD_ENG_INF_NT_FOUND = "engineInfoNotFound";
     static final String MTD_INVLID_ORG_FAC = "invalidOrigFacSuppCode";
     static final String MTD_ENG_SER_MISSING = "engineSerialNumMissing";
     static final String MTD_NO_EXC_HTS_ERR  = "logNoExcptnHTSError";
     static final String MTD_MAC_ENG_INFO_NT_FOUND = "machEngInfoNotFound";
     static final String MTD_MAC_INFO_NT_FOUND = "machineInfoNotFound";
     static final String MTD_MCH_SER_MISSING = "machineSerialNumMissing";
     static final String MTD_ORIG_FAC_NT_CONFIGUR_EPA = "originFacNotCnfgrEPA";
     static final String MTD_USER_NOT_ASSGNDFAC = "userNotAssgndFac";
     static final String MTD_WEBSERVC_CONN_ERR = "webServiceConnErr";
     static final String NA = "N/A";
    
    /*TVS ERROR LOGGER CONSTANTS*/
     static final String MTD_STORE_INCMG_FILE_DATA = "storeIncomingFileData";
     static final String NO_RSPNS_FRM_VWS_SERVICE = "No response received from VWS webservice call";
     static final String PROCESS_STRT_MSG_HAS_RETRURN_CD = "Process start message sent has returned with code:";
     static final String MSG = ", message:";
     static final String EXC_OCCURRED = "Exception occurred: ";
     static final String MTD_STRE_ERR_MSG = "storeErrorMessages";
     static final String ERR_REPRT_SENT_FOR = "Error report sent for ";
     static final String KEY_VALUE_VAR = "keyvalue";
     static final String AND_RETRN_WITH_CD = " and returned with code: ";
     static final String CST_VAR = "CST";
     static final String CONVRTS_TO_XML_DATE= "convertToXmlDate";
     static final String CONVERT_TO_XML_FAILED = "convertToXmlDate failed";
    
    /*LOGGER CONSTANTS*/
     static final String MTD_FATAL_EVENT = "fatalEvent";
	 static final String FATA_EVENT_FAILED = "fatalEvent failed";
     static final String MTD_INFORL_EVENT = "informationalEvent";
     static final String INFORL_EVENT_FAILED = "informationalEvent failed";
     static final String MTD_TRACE_EVENT = "traceEvent";
     static final String TRACE_EVENT_FAILED = "traceEvent failed";
     static final String MTD_USG_EVENT = "usageEvent";
     static final String USG_EVENT_FAILED = "usageEvent failed";
     static final String MTD_WARNING_EVENT = "warningEvent";
     static final String WARNING_EVENT_FAILED= "warningEvent failed";
     static final String DETAILS_VAR = "Details: ";
    
    /*EMAIL SENDER CONSTANTS*/
     static final String MTD_SEND_EMAIL = "sendEmail";
     static final String EXCE_WHILE_SENDING_EMAIL = "exception while sending mail ";
    
    /*EPA SERVICE CONSTANTS*/
     static final String MTD_PART_DETERMIN = "partDetermination";
     static final String MTD_FILTER_ENGMCH_INVOICE= "filterMchEngs";
     static final String MTD_GET_INVOICE_MAP  = "getInvcMapObj";
     static final String MTD_DEL_INV_ENGS = "delEngEntry";
     static final String EXE_PART_DETERMIN = "executing partDetermination";
     static final String DETERMING_PART_FAILED = "Determining part failed";
     static final String MTD_FAC_VALIDATIONS = "facilityValidations";
     static final String EXE_FAC_VALIDATIONS = "executing facilityValidations";
     static final String READING_FAC_FAILED  = "Reading facilities failed";
     static final String FAC_VALIDATION_FAILED = "facilityValidations failed";
     static final String FAILED_TO_READ_FAC_BY_SUPPID = "Failed to read Fac by SuppCd";
     static final String MTD_PR_SER_NUM_VALIDATIONS = "productSerialNumValidations";
     static final String EXE_PR_SER_NUM_VALIDATIONS = "executing productSerialNumValidations";
     static final String MTD_IS_EPA_REQ = "isEpaRequired";
     static final String EXE_IS_EPA_REQ = "executing isEpaRequired";
     static final String MTD_GET_EPA_HTS_CNFGR = "getEpaHtsCnfgr";
     static final String MTD_GET_EPA_HTS_CDS = "getEpaHtsCds";
     static final String FETCHING_EPA_HTSCNFG_FAILED = "fetching EPA HTS Configuration failed";
     static final String FETCHING_EPA_HTSCDS_FAILED = "fetching EPA HTS Codes failed";
     static final String MTD_IS_EXCEN_PART = "isExceptionPart";
     static final String EXE_IS_EXCEN_PART = "executing isExceptionPart";
     static final String DETERMIN_EXCEN_HTS_FAILED = "Determining exception HTS failed";
     static final String COULD_NT_RD_HTSCNFG_DETAILS = "Could not read HTS Exception Configuraation details";
     static final String MTD_SET_EPA_PART_TYPE = "setEpaPartType";
     static final String EXC_SET_EPA_PART_TYPE = "No Valid part type";
     static final String EXE_SET_EPA_PART_TYPE =  "executing setEpaPartType";
     static final String PARTS_VAR = "_PARTS";
     static final String MTD_IS_PART_MCH_NUM = "isPartMachineNum";
     static final String EXE_IS_PART_MCH_NUM = "executing isPartMachineNum";
     static final String MTD_CREATE_ENG_SHIPMT = "createEngineShipment";
     static final String EXE_CREATE_ENG_SHIPMT = "executing createEngineShipment";
     static final String EXT_CREATE_ENG_SHIPMT = "exit createEngineShipment";
     static final String POPULATE_ENG = "populateEpaEngine";
     static final String WHILE_CHEKING_VALUE_FR = "While checking the value for ";
     static final String MTD_CHECK_SHIP_EXIST = "checkShpExist";
     static final String CHECK_SHIP_EXIST_FAILED = "checkShpExist failed ";
     static final String MTD_CRET_MCH_SHIPMT = "createMachineShipment";
     static final String MTD_CRT_MCH_SHP = "crteMachShp";
     static final String CRET_MCH_INFO = "creating machine info";
     static final String SAVING_ENG_MCH = "saving Eng Mach";
     static final String FAIL_INSERT_SHIP_ENGMCH = "failed inserting shipment with Engine/Machine";
     static final String MTD_SAVE_SHIP = "saveShipment";
     static final String EXE_SAVE_SHIP = "executing saveShipment";
     static final String EXCEPN_WHILE_SAVING_SHIP = "exception while saving shipment";
     static final String POPULATE_EPA_SHIPMT = "populateEpaShipment";
     static final String EXCPN_WHILE_POPING_SHIP = "exception while populating epa shipment  ";
     static final String MTD_SAVE_ENG = "saveEngine";
     static final String EXE_SAVE_ENG = "executing saveEngine";
     static final String ENG_CUD_NT_SAVE = "Engine could not be saved";
     static final String MTD_RD_MAIL_CNFG_DATA = "readMailConfigData";
     static final String EXE_LITERAL = "Executing";
     static final String MAIL_CNFG_CUD_NT_FETCH_FRM_EPA = "MailConfig data from EPA could not be fetched";
     static final String MTD_LOG_END_TM = "logEndTime";
     static final String LOG_ENG_TM_FAIL = "logging end time failed";
     static final String MTD_LOG_STRT_TM = "logStartTime";
     static final String MTD_SAVE_SUCCS_TM = "saveLstSccsTm";
     static final String LOG_STRT_TM_FAIL = "logging start time failed";
     static final String LOG_SAV_SUCCS_TM = "saving last succs tm failed";
     static final String STB = "STB";
     static final int SERIAL_LEN = 17;
     static final String INVALID_INPUT = "INVALID VALUE";
     static final String ENG_IMP_PROV_FNM = "engImpProv";
     static final String ENG_IMP_EQU_FNM = "engProvEqu";
    /*TIS SERVICE CONSTANTS*/
     static final String MTD_GET_PARTS_FRM_TIS = "getPartsFrmTIS";
     static final String NO_INVOCS_TO_PRCS_FR_EPA = "There are no invoices to process for EPA";
     static final String FAIL_TO_FETCH_PARTS_FM_TIS = "Failed to fetch parts from TIS";
     static final String MTD_FILTR_NON_CLASIFD_PARTS = "filterNonClassifiableParts";
     static final String FAIL_TP_FILTR_PARTS = "Failed filtering non classifiable parts";
     static final String MTD_GET_HTS_CODES = "getHTSCodes";
     static final String MTD_GET_HTS_CODES_CHNGS = "getHtsCdChngs";
     static final String MTD_GET_PARTS = "getPartsFrmTIS";
     static final String FAIL_TO_FETCH_HTS_CODES = "Failed to fetch HTS Codes from TIS";
     static final String MTD_GET_PART_SER_NUM = "getPartSerialNumbers";
     static final String FAIL_TO_FETCH_PART_SERNUM = "Failed to fetch PartSerilaNumbers from TIS ";
     static final String TECH_EXCP_FETCH_PART_SERNUM = "Technical exception fetching PartSerilaNumbers from TIS ";
     static final String MTD_POPULATE_PART_SER_NUM = "populatePartSerialNum";
     static final String MTD_POPULATE_EPA_SHIPMNT = "populateEpaShpmnt";
     static final String MTD_EXTRACT_PART_NUMS = "extractPartNumbers";
     String MTD_GET_EXCL_SUPP_FAC_CDS="getExcluSuppCdOrgFacCd";
     static final String INVOICE_PART_UNDRSCR = "Invoice : Part_";
     static final String UNDRSCR_INVOICE_UNDRSCR = "_Invoice_";
     static final String UNDRSCR_SEQNUM_UNDERSCR = "_seqNum_";
     static final String UNDRSCR_LOADNUM_UNDRSCR = "_LoadNum_";
     static final String MTD_GET_SHIP_PARTS = "getShpmntParts";
     static final String MTD_GET_LST_SCCS_TM = "getLstSccsTm";
     static final String MTD_GET_RN_TMS = "getRunTms";
     static final String MTD_GET_FAC_CONSTRAINTS_VALUES = "getFacConstrtVal";
     static final String FAIL_TO_FETCH_SHIP_PARTS = "Failed to shipment parts from TIS";
     String FAIL_TO_EXTRACT_EXCLU_SUPP_CD = "Failed to exatract exclusion SuppCd and OrgFacCds";
     static final String FAIL_LST_SCCS_TM = "Failed to get last succ tmstmp";
     static final String FAIL_GET_RUN_TM = "Failed to get run tmstsmp";
     static final String FAIL_GET_FAC_CONSTRAINTS_VALUES = "Failed to get the facility constraints values";
     static final String FRM_TMSTMP = "FRM_TMSTMP";
     static final String TO_TMSTMP = "TO_TMSTMP";
     
     static final List PROV_EXM_APPR = Arrays.asList("10","11","12","18");
 	 static final List PROV_STRG_LOC = Arrays.asList("24a","24b");
 	 static final String IMP_PROV_CD_ONE = "1";
	 static final String IMP_PROV_CD_22 = "22";
	 static final String IMP_PROV_CD_25 = "25";
	 static final String COMMA=",";
	 
	 static final String MTD_GET_MCHSHIPMNT = "getMchShpmnt";
	 static final String MTD_UPD_EXST_ENG = "updtExstEng";
	static final String MTD_POPLTE_ERR_DETLS = "populateErrDet";
	static final String MTD_STRE_INCMG_FILEDATA = "storeIncomingFileData";
	static final String MTD_CONVRT_TO_XMLDATE = "convertToXmlDate";
	static final String MTD_GET_ENVIRMNT = "getEnvironment";
	static final String MTD_POPLTE_ENG = "populateEpaEngine";
	static final String MTD_POPLTE_MCH = "populateEpaMachine";
	static final String MTD_POPLTE_SHIPMT = "populateEpaShipment";
	static final String MTD_GET_ENG = "getEngine";
	static final String MTD_CHECK_ENG_FR_UPD = "chkEngFrUpdt";
	static final String MTD_VAL_DUP_ENG = "valDupEng";
	static final String MTD_VAL_UPD_ENG = "valUpdtEng";
	static final String MTD_SAVE_LST_TM = "saveLstSccsTm";
	static final String MTD_PREPRE_SHIPMT = "prepareEPAShipmentDTO";
	static final String MTD_UPDT_MCH = "updateMachine";
	static final String MTD_VAL_ENG_NUM = "valEngNum";
	static final String MTD_CRTE_DUP_MCHENG   = "crteDupMchEng";
	static final String MTD_PROCESS_MCH = "processMachine";
	static final String MTD_SET_MFR_NAME = "setMfrName";
	static final String MTD_CRETE_DUP_ENG = "crteDupEng"; 
	
	// HTS JOB CONSTANTS
	static final String HTS_JOB_NAME = "HTS_JOB"; 
	static final String MTD_HTS_CD_MNTR = "htsCdMonitor";
	static final String MTD_GET_ECCN_FILES = "getECCNfiles";
	static final String MTD_SET_EPA_PART_TYP = "setEpaPartType";
	static final String EXE_HTS_CD_MNTR = "executing htsCdMonitor";
	static final String MTD_GET_EPA_PARTS = "getEpaParts";
	static final String EXE_GET_EPA_PARTS = "executing getEpaParts";
	static final String MTD_CHECK_EXCP_PARTS = "checkForExcptnPart";
	static final String EXE_CHECK_EXCP_PARTS = "executing checkForExcptnPart";
	
	static final String MTD_ENG_STATUS = "getEngineByStatus";
	static final String LOG_ENG_STATUS_FAIL = "logEngStatusFail";
	
	static final String Q_LITERAL = "Q";
	
	// AutoECCN JOB CONSTANTS
	static final String AUTO_ECCN_UTIL_JOB = "AUTO_ECCN_UTIL_JOB";
	public static final String TEMP_DIR_KEY = "TEMP_DIR_KEY";
	public static final String STRING_1 = "1";
	public static final String MTD_RCV_STMT = "recvStmnt";
	public static final String BINARY = "BINARY";
	public static final int INT_0 = 0;
	public static final int SEVERITY_FATAL = 16;
	public static final int SEVERITY_WARNING = 8;
	public static final int SEVERITY_INFORMATIONAL = 4;
	public static final String NEW_LINE = ",\n";
	public static final String AT_LN = "() at Line-";
	public static final String MTD_CPY_FLS = "copyFlsFrmFtpToTempFldr";
	public static final String DIR_DEL = "Dir Deleted";
	public static final String IO_EXC_OCRD = "IOException occurred: ";
	public static final String IO_EXC_MSG = "IOException while transferring file to FTP folder";
	static final String ECCN_OUT = "ECCN_OUT";
	static final String BACK_SLASH = "/";
	public static final String GT_FL_LST_FRM_FTP_SRC = "getFileListFrmFtpSrc";
	public static final String SI_FL_CNT = "f";
	public static final String STR_0 = "0";
	public static final String MTD_DISCNCT = "disconnect";
	public static final String CNCT_TO_FTP_SRVR = "connectToFtpServer";
	public static final String FTP_CON_FLR = "Failed to connect to the server";
	public static final String MTD_CHNG_FL_TRSFR_MD = "changeFileTransferMode";
	public static final String EXC_OCCRD = "Exception occurred:";
	public static final String EXC_MSG = "Failed setting the FTP transfer mode.";
	public static final String CON_FTP_ST = "Failed connecting to FTP site.";
	public static final String CONNECT = "connect";
	public static final String CON_MSG = "Failed to disconnect from previous connection";
	public static final String LOG_MSG = "Failed logging to FTP site.";
	static final String MTD_AUTO_ECCN_UTIL_PROCESS = "autoECCNUtiliyProcess";
	static final String MTD_AUTO_ECCN_CAT_CLASS_PROCESS ="AutoECCNCatClassProcess";
	static final String AUTO_ECCN_UTIL_STARTED = "Auto ECCN Util job started";
	static final String AUTO_ECCN_CAT_CLASS_STARTED = "Auto ECCN CAT Class job started";
	static final String UNDER_SCORE = "_";
	static final int NUM_TWO = 2;
	static final int NUM_THREE = 3;
	static final String ECCN_TECH_EXCEPTION = "Technical Exception occured in Auto ECCN Utility Job while connecting to FTP. Please check EPA Batch logs";
 
	// AutoECCN CAT CLASS JOB CONSTANTS
	public static final int CONSTANT_ZERO = 0;
	public static final int CONSTANT_ONE = 1;

	public static final int CONSTANT_TWO = 2;

	public static final int CONSTANT_THREE = 3;

	public static final int CONSTANT_FOUR = 4;

	public static final int CONSTANT_FIVE = 5;

	public static final int CONSTANT_SIX = 6;

	public static final int CONSTANT_SEVEN = 7;

	public static final int CONSTANT_EIGHT = 8;

	public static final int CONSTANT_NINE = 9;

	public static final int CONSTANT_TEN = 10;

	public static final int CONSTANT_ELEVEN = 11;

	public static final int CONSTANT_TWELVE = 12;

	public static final int CONSTANT_THIRTEEN = 13;

	public static final int CONSTANT_FOURTEEN = 14;

	public static final int CONSTANT_FIFTEEN = 15;

	public static final int CONSTANT_SIXTEEN = 16;

	public static final int CONSTANT_SEVENTEEN = 17;

	public static final int CONSTANT_EIGHTEEN = 18;

	public static final int CONSTANT_NINETEEN = 19;

	public static final int CONSTANT_TWENTY = 20;

	public static final int CONSTANT_TWENTYONE = 21;

	public static final int CONSTANT_TWENTYYWO = 22;

	public static final int CONSTANT_TWENTYTHREE = 23;
	/**
	 * Comment for <code>EMPTY_SPACE</code>
	 */
	public static final String EMPTY_SPACE = "";
	
	public static final String MQ_HDR_FL_NAME = "<saveFile><fileName dt=\"string\">";
	public static final String MQ_HDR_FL_TYP = "</fileName><type dt=\"string\">";
	public static final String MQ_HDR_END = "</type></saveFile>";
	public static final String SND_MQ_MSG_TO_SRC_QUEUE = "sendMQMsgToSrcQueue";
	public static final String TWO_THSND_NINE = "2009";
	public static final String NULL_PSD = "Message with null data is passed as input";
	public static final String MQ_EXC_OCRD = "MQException occurred: ";
	public static final String CLOSE_CONN = "closeConnection";	
	
	//public static final String MQ_NAME ="CAT_Z1TRN.CLASSIFICATION.ECCN.IN.POLL";
	public static final String MQ_NAME ="CAT_Z1TRN.CLASSIFICATION.ECCN.IN";
	static final String CONN_MQ_ENV = "connectMqEnvironment";
	public static String OUTPUT1_FILE = "OUTPUT_1.xlsx";
	public static String REVIEWED_FILE = "REVIEWED.xlsx";
	public static String OUTPUT = "OUTPUT";
	public static String REVIEWED = "REVIEWED";
	public static String DELIMITER = "|";
 }
