/**
 * Copyright (c) Caterpillar Inc. All Rights Reserved.
 * This work contains Caterpillar Inc.'s unpublished proprietary information
 * which may constitute a trade secret and/or be confidential. This work 
 * may be used only for the purposes for which it was provided, and may 
 * not be copied or disclosed to others. Copyright notice is precautionary 
 * only, and does not imply publication.
 *
 * Revision History
 * Version        Date         Changed By        Comments
 *  1.0        20-01-2016      kk3           Initial Creation
 **/
package com.cat.logistics.epa.job.service;

/** This class used to create daily or monthly object based on the input 
 * @author kk3
 *
 */
public interface IFileFilterFactory {
 
	/** This returns statement type of object
	 * @param string
	 * @return
	 */
	Object getStmntTypeObject(String string);

}
