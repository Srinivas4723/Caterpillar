package com.cat.logistics.epa.job.impl;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cat.logistics.epa.job.utils.BatchConstants;

public class EpaSnowFlakesBatchJob {

	// private static ILogger logger = Logger.getInstance();
	private final static Logger logger = LogManager.getLogger(EpaSnowFlakesBatchJob.class);

	private static ApplicationContext contextAlert = null;

	/**
	 * @return
	 */
	public static ApplicationContext getContextAlert() {
		return contextAlert;
	}

	/**
	 * @param contextAlert
	 */
	public static void setContextAlert(ApplicationContext contextAlert) {
		EpaSnowFlakesBatchJob.contextAlert = contextAlert;
	}

	/**
	 * Main Method
	 * 
	 * @param args
	 */
	public static void main(String[] args) {

		logger.info(EpaSnowFlakesBatchJob.class + "BATCH MAIN" + BatchConstants.EPA_BATCH_STARTED);
		// logger.informationalEvent(EpaSnowFlakesBatchJob.class, "BATCH MAIN",
		// BatchConstants.EPA_BATCH_STARTED);

		try {

			contextAlert = new ClassPathXmlApplicationContext("classpath:batch-context.xml");

			EPAProcess epaProcess = (EPAProcess) contextAlert.getBean("epaProcess");

			epaProcess.epaProcess();
		} catch (Exception e) {
			logger.error(EpaSnowFlakesBatchJob.class + "Exception" + e.getMessage());
			// logger.fatalEvent(EpaSnowFlakesBatchJob.class, "BATCH MAIN",
			// BatchConstants.EPA_PROCESS_FAILED, e);
		}

		logger.info(EpaSnowFlakesBatchJob.class + "BATCH MAIN" + "EPA Batch job ended");
		// logger.informationalEvent(EpaSnowFlakesBatchJob.class, "BATCH MAIN",
		// BatchConstants.EPA_BATCH_STARTED);
	}

}
