/**
 * Copyright (c) Caterpillar Inc. All Rights Reserved.
 * This work contains Caterpillar Inc.'s unpublished proprietary information
 * which may constitute a trade secret and/or be confidential. This work 
 * may be used only for the purposes for which it was provided, and may 
 * not be copied or disclosed to others. Copyright notice is precautionary 
 * only, and does not imply publication.
 *
 * Revision History
 * Version        Date         Changed By        Comments
 *  1.0        20-01-2016      kk3           Initial Creation
 **/
package com.cat.logistics.epa.job.dto;

import java.util.Map;

import com.cat.logistics.epa.job.service.IFileFilterFactory;


/** This class used to create Eccn object based on the input
 *
 */
public class FileFilterFactory implements IFileFilterFactory{
	
	 private Map<String,Object> filterMap;

    /*  This returns statement type of object
     * @see com.cat.ach.helper.IGenericObjectFactory#getStmntTypeObject(java.lang.String)
     */
    @Override
    public Object getStmntTypeObject(String string) {
        return filterMap.get(string);
    }

	/**
	 * @return the filterMap
	 */
	public Map<String, Object> getFilterMap() {
		return filterMap;
	}

	/**
	 * @param filterMap the filterMap to set
	 */
	public void setFilterMap(Map<String, Object> filterMap) {
		this.filterMap = filterMap;
	}
    
    
}
