package com.cat.logistics.epa.job.impl;

import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import com.cat.logistics.epa.dto.EpaShipmentDTO;
import com.cat.logistics.epa.entities.EpaShipment;
import com.cat.logistics.epa.job.IEpaProcess;
import com.cat.logistics.epa.job.service.IEPAService;
import com.cat.logistics.epa.job.tis.ITISService;
import com.cat.logistics.epa.job.utils.BatchConstants;
import com.cat.logistics.epa.mail.IEmailSender;
import com.cat.logistics.epa.service.impl.EPAService;
import com.cat.logistics.shared.dto.EngineDTO;
import com.cat.logistics.shared.exception.ServiceException;

/**
 * This class invokes all the functionalities of the services to populate Data into EPA
 * @author chanda15
 *
 */
public class EPAProcess extends AbstractProcess implements IEpaProcess {

	@Autowired
	private ITISService tisService;
	
	@Autowired
	private IEPAService epaService;
	
	@Autowired
	private IEmailSender mailSender;
	
	//private ILogger logger = Logger.getInstance();
	private final static Logger logger = LogManager.getLogger(EPAProcess.class);
	
	/** 
	 * Populates EPA Database
	 * @see com.cat.logistics.epa.job.IEpaProcess#epaProcess()
	 */
	public void epaProcess(){
		boolean succs = true;
		try{
		//logger.informationalEvent(this.getClass(), BatchConstants.MTD_EPA_PROCESS, BatchConstants.EPA_BATCH_STARTED);
		logger.info(this.getClass() + BatchConstants.MTD_EPA_PROCESS + BatchConstants.EPA_BATCH_STARTED);
		jobInitialization(BatchConstants.APPLICATION_WND);
		Map<String,EpaShipmentDTO> partShpmnts = tisService.getPartsFrmTIS();
		if(!partShpmnts.isEmpty()){
		isPartType(partShpmnts);
		
		tisService.getPartSerialNumbers(partShpmnts);
		succs =	processEPAParts(partShpmnts);
		
	}	
		jobShutDown(BatchConstants.APPLICATION_WND, succs);
		
		}catch(ServiceException serviceException) {
			//logger.fatalEvent(this.getClass(), BatchConstants.MTD_EPA_PROCESS, BatchConstants.EPA_PROCESS_FAILED, serviceException);
			logger.error(this.getClass()+BatchConstants.MTD_EPA_PROCESS + BatchConstants.EPA_PROCESS_FAILED +serviceException.getMessage(),serviceException);
			mailSender.sendEmail(BatchConstants.TECH_EXCEPTION);
		}catch(Exception exception){
			//logger.fatalEvent(this.getClass(), BatchConstants.MTD_EPA_PROCESS, BatchConstants.EPA_PROCESS_FAILED, exception);
			logger.error(this.getClass()+BatchConstants.MTD_EPA_PROCESS + BatchConstants.EPA_PROCESS_FAILED +exception.getMessage(),exception);
			mailSender.sendEmail(BatchConstants.TECH_EXCEPTION);
		}
	}
	
	/**
	 * reads mail configuration details
	 * @throws ServiceException
	 */
	public void readMailConfigurations() throws ServiceException{
		//logger.informationalEvent(this.getClass(), BatchConstants.MTD_READ_MAIL_CONFIG, BatchConstants.EXCUTING_RD_MAIL_CONFIG);
		logger.info(this.getClass() + BatchConstants.MTD_READ_MAIL_CONFIG + BatchConstants.EXCUTING_RD_MAIL_CONFIG);
		epaService.readMailConfigData();
	}
	
	 /**
	  * checks the part type which belongs to
	 * @param partShpmnts
	 * @throws Exception
	 */
	public void isPartType(Map<String,EpaShipmentDTO> partShpmnts) throws Exception{
		 epaService.partDetermination(partShpmnts,true);
		 
	 }
	
	/**
	 * This method is to find batch jobStartTime
	 * @throws ServiceException
	 */
	public void jobStartTime(String jobName) throws ServiceException{
		
		//logger.informationalEvent(this.getClass(), BatchConstants.JOB_STRT_TIME,BatchConstants.EXE_JB_STRT_TIME);
		logger.info(this.getClass() + BatchConstants.JOB_STRT_TIME + BatchConstants.EXE_JB_STRT_TIME);
		try {
			epaService.logStartTime(jobName);
		} catch (ServiceException e) {
			//logger.fatalEvent(this.getClass(), BatchConstants.JOB_STRT_TIME, BatchConstants.LOG_JB_STRT_TIME_FAILED, e);
			logger.error(this.getClass() + BatchConstants.JOB_STRT_TIME + BatchConstants.LOG_JB_STRT_TIME_FAILED + e.getMessage());
			throw e;
		}
	}
	
	/**
	 * @return
	 */
	public ITISService getTisService() {
		return tisService;
	}

	/**
	 * @param tisService
	 */
	public void setTisService(ITISService tisService) {
		this.tisService = tisService;
	}

	/**
	 * @param epaService
	 */
	public void setEpaService(EPAService epaService) {
		this.epaService = epaService;
	}
	
	
	/** 
	 * 
	 * @see com.cat.logistics.epa.job.IEpaProcess#epaProcess()
	 */
	public void epaDataRefresherProcess(){
		boolean succs = true;
		try{
		//logger.informationalEvent(this.getClass(), BatchConstants.MTD_EPA_DATA_REF_PROCESS, BatchConstants.EPA_BATCH_DATA_REFR_STARTED);
			logger.info(this.getClass()+ BatchConstants.MTD_EPA_DATA_REF_PROCESS + BatchConstants.EPA_BATCH_DATA_REFR_STARTED);
		jobStartTime(BatchConstants.EPA_DATA_REFRESH);
		readMailConfigurations();
		 Map<String,EngineDTO> serialEngineMap = null;
		List<EpaShipment> epaShipmentList = epaService.getEngineByStatus(BatchConstants.MISSING_DATA);
		List<String>  listEpaEngSerNo = getEpaListEngSerNo(epaShipmentList);
			try{
				 serialEngineMap = getEngineDetails(listEpaEngSerNo);
			 }catch(ServiceException exception){
				 //logger.fatalEvent(this.getClass(), BatchConstants.MTD_EPA_DATA_REF_PROCESS, BatchConstants.ENG_COULD_NOT_RETRIVE_FRM_EED, exception); 
				 logger.error(this.getClass() +  BatchConstants.MTD_EPA_DATA_REF_PROCESS + BatchConstants.ENG_COULD_NOT_RETRIVE_FRM_EED + exception.getMessage()); 
				 mailSender.sendEmail(BatchConstants.TECH_EXCEPTION);
				 succs = false;
			 }
		
		if(null != serialEngineMap && !serialEngineMap.isEmpty()){
		
		
		try{
			updateEngineInfoToEpa(epaShipmentList,serialEngineMap);
		}catch(Exception engineServiceExc){
			mailSender.sendEmail(BatchConstants.TECH_EXCEPTION);
			//logger.fatalEvent(this.getClass(), BatchConstants.MTD_EPA_DATA_REF_PROCESS, BatchConstants.ENG_DATA_COULDNT_SAVE, engineServiceExc);
			logger.error(this.getClass() + BatchConstants.MTD_EPA_DATA_REF_PROCESS + BatchConstants.ENG_DATA_COULDNT_SAVE + engineServiceExc.getMessage());
			succs = false;
		}
		
	}	
		jobShutDown(BatchConstants.EPA_DATA_REFRESH, succs);
		}catch(ServiceException serviceException) {
			//logger.fatalEvent(this.getClass(), BatchConstants.MTD_EPA_DATA_REF_PROCESS, BatchConstants.EPA_PROCESS_FAILED, serviceException);
			logger.error(this.getClass() + BatchConstants.MTD_EPA_DATA_REF_PROCESS + BatchConstants.EPA_PROCESS_FAILED + serviceException.getMessage());
			mailSender.sendEmail(BatchConstants.TECH_EXCEPTION);
		}catch(Exception exception){
			//logger.fatalEvent(this.getClass(), BatchConstants.MTD_EPA_DATA_REF_PROCESS, BatchConstants.EPA_PROCESS_FAILED, exception);
			logger.error(this.getClass() + BatchConstants.MTD_EPA_DATA_REF_PROCESS + BatchConstants.EPA_PROCESS_FAILED + exception.getMessage());
			mailSender.sendEmail(BatchConstants.TECH_EXCEPTION);
		}
	}
	
	
	
	
}
