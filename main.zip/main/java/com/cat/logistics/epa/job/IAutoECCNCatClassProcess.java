/**
 * 
 */
package com.cat.logistics.epa.job;

import java.io.IOException;

import com.cat.logistics.epa.job.utils.ApplicationException;

/**
 * @author addansn
 *
 */
public interface IAutoECCNCatClassProcess {

	void processFilesToMQ() throws IOException, ApplicationException;
	
}
