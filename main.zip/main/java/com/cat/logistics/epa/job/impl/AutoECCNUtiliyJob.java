/**
 * 
 *//*
package com.cat.logistics.epa.job.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cat.logistics.epa.job.IAutoECCNUtiliyProcess;

*//**
 * @author addansn
 *
 *//*
@Component
public class AutoECCNUtiliyJob implements Runnable {

	@Autowired
	IAutoECCNUtiliyProcess autoECCNUtiliyProcess;
	
	
	public void run() {
		try{
			autoECCNUtiliyProcess.getECCNfiles();
		}catch(Exception exception){
			exception.printStackTrace();
		}
	}
	
}
*/