package com.cat.logistics.epa.job.service;

import java.io.File;
import java.io.IOException;
import java.util.List;

import com.cat.logistics.epa.job.utils.ApplicationException;


public interface IAutoEccnService {

	public void readExcel(List<String> seqNo, String fileTyp) throws IOException, ApplicationException;

	public File getFileForDownload(String sNo, String fileType);

}
