/**
 * Copyright (c) Caterpillar Inc. All Rights Reserved.
 * This work contains Caterpillar Inc.'s unpublished proprietary information
 * which may constitute a trade secret and/or be confidential. This work 
 * may be used only for the purposes for which it was provided, and may 
 * not be copied or disclosed to others. Copyright notice is precautionary 
 * only, and does not imply publication.
 *
 * Revision History
 * Version        Date         Changed By        Comments
 *  1.0        20-01-2016      kk3           Initial Creation
 **/
package com.cat.logistics.epa.job.dto;

/**
 * This class used to set the mq related information for ACH and TVS system
 * 
 * @author addansn
 *
 */
public class MQDetails {
	// MQ Host Name
	private String mqHostName;
	// MQ Port
	private String mqPort;
	// MQ Channel
	private String mqChannel;
	// MQ QManager
	private String mqQManager;
	// MQ QName
	private String mqQName;
	// Is Header Info Required
	private String isHdrReq;

	/**
	 * @return the mqHostName
	 */
	public String getMqHostName() {
		return mqHostName;
	}

	/**
	 * @param mqHostName
	 *            the mqHostName to set
	 */
	public void setMqHostName(String mqHostName) {
		this.mqHostName = mqHostName;
	}

	/**
	 * @return the mqPort
	 */
	public String getMqPort() {
		return mqPort;
	}

	/**
	 * @param mqPort
	 *            the mqPort to set
	 */
	public void setMqPort(String mqPort) {
		this.mqPort = mqPort;
	}

	/**
	 * @return the mqChannel
	 */
	public String getMqChannel() {
		return mqChannel;
	}

	/**
	 * @param mqChannel
	 *            the mqChannel to set
	 */
	public void setMqChannel(String mqChannel) {
		this.mqChannel = mqChannel;
	}

	/**
	 * @return the mqQManager
	 */
	public String getMqQManager() {
		return mqQManager;
	}

	/**
	 * @param mqQManager
	 *            the mqQManager to set
	 */
	public void setMqQManager(String mqQManager) {
		this.mqQManager = mqQManager;
	}

	/**
	 * @return the mqQName
	 */
	public String getMqQName() {
		return mqQName;
	}

	/**
	 * @param mqQName
	 *            the mqQName to set
	 */
	public void setMqQName(String mqQName) {
		this.mqQName = mqQName;
	}

	/**
	 * @return the isHdrReq
	 */
	public String getIsHdrReq() {
		return isHdrReq;
	}

	/**
	 * @param isHdrReq
	 *            the isHdrReq to set
	 */
	public void setIsHdrReq(String isHdrReq) {
		this.isHdrReq = isHdrReq;
	}

}
