package com.cat.logistics.ods.entities;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * This class holds OdsSerialProduct information
 * @author chanda15
 *
 */
@Entity
@Table(name="SER_PROD_COMB_VW",schema="Z1AK001$")
public class OdsSerialProduct implements Serializable{

	private static final long serialVersionUID = -4215833140310274945L;
	
	@Id
	@Column(name="ORD_CTL_NO")
	private String orderControlNum;
	
	@Column(name="INVC_SPEC_CTL_NO")
	private String invcSpecCtlNum;
	
	@Column(name="PART_NO")
	private String partNum;
	
	@Column(name="MFR_SER_NO")
	private String mfrSerNum;
	
	@Column(name="SER_NO_PFX")
	private String serNumPrefix;
	
	@Temporal(TemporalType.DATE)
	@Column(name="CRTE_TS")
	private Date createdTs;
	
	@Column(name="CRTE_LOGON_ID")
	private String createdId;
	
	@Temporal(TemporalType.DATE)
	@Column(name="LAST_UPDT_TS")
	private Date lastUpdtTs;
	
	@Column(name="LAST_UPDT_LOGON_ID")
	private String lastUpdtId;

	/**
	 * @return the orderControlNum
	 */
	public String getOrderControlNum() {
		return orderControlNum;
	}

	/**
	 * @return the invcSpecCtlNum
	 */
	public String getInvcSpecCtlNum() {
		return invcSpecCtlNum;
	}

	/**
	 * @return the partNum
	 */
	public String getPartNum() {
		return partNum;
	}

	/**
	 * @return the mfrSerNum
	 */
	public String getMfrSerNum() {
		return mfrSerNum;
	}

	/**
	 * @return the serNumPrefix
	 */
	public String getSerNumPrefix() {
		return serNumPrefix;
	}

	/**
	 * @return the createdId
	 */
	public String getCreatedId() {
		return createdId;
	}

	/**
	 * @return the lastUpdtId
	 */
	public String getLastUpdtId() {
		return lastUpdtId;
	}

	/**
	 * @param orderControlNum the orderControlNum to set
	 */
	public void setOrderControlNum(String orderControlNum) {
		this.orderControlNum = orderControlNum;
	}

	/**
	 * @param invcSpecCtlNum the invcSpecCtlNum to set
	 */
	public void setInvcSpecCtlNum(String invcSpecCtlNum) {
		this.invcSpecCtlNum = invcSpecCtlNum;
	}

	/**
	 * @param partNum the partNum to set
	 */
	public void setPartNum(String partNum) {
		this.partNum = partNum;
	}

	/**
	 * @param mfeSerNum the mfeSerNum to set
	 */
	public void setMfrSerNum(String mfrSerNum) {
		this.mfrSerNum = mfrSerNum;
	}

	/**
	 * @param serNumPrefix the serNumPrefix to set
	 */
	public void setSerNumPrefix(String serNumPrefix) {
		this.serNumPrefix = serNumPrefix;
	}

	/**
	 * @param createdId the createdId to set
	 */
	public void setCreatedId(String createdId) {
		this.createdId = createdId;
	}

	/**
	 * @param lastUpdtId the lastUpdtId to set
	 */
	public void setLastUpdtId(String lastUpdtId) {
		this.lastUpdtId = lastUpdtId;
	}

	/**
	 * @return the createdTs
	 */
	public Date getCreatedTs() {
		return createdTs;
	}

	/**
	 * @return the lastUpdtTs
	 */
	public Date getLastUpdtTs() {
		return lastUpdtTs;
	}

	/**
	 * @param createdTs the createdTs to set
	 */
	public void setCreatedTs(Date createdTs) {
		this.createdTs = createdTs;
	}

	/**
	 * @param lastUpdtTs the lastUpdtTs to set
	 */
	public void setLastUpdtTs(Date lastUpdtTs) {
		this.lastUpdtTs = lastUpdtTs;
	}

}
