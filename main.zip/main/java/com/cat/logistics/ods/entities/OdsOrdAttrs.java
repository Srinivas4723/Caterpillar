package com.cat.logistics.ods.entities;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * This class holds common Order Attributes info from ODS
 * @author chanda15
 *
 */
@Embeddable
public class OdsOrdAttrs implements Serializable{

	@Temporal(TemporalType.DATE)
	@Column(name="ORD_STG_DT")
	private Date buildDate;
	
	@Column(name="ORD_STG_CD")
	private String orderStagingCode;

	/**
	 * 
	 * @return build date
	 */
	public Date getBuildDate() {
		return buildDate;
	}

	/**
	 * 
	 * @param  set buildDate
	 */
	public void setBuildDate(Date buildDate) {
		this.buildDate = buildDate;
	}

	/**
	 * 
	 * @return stgcode
	 */
	public String getOrderStagingCode() {
		return orderStagingCode;
	}

	/**
	 * 
	 * @param set orderStagingCode
	 */
	public void setOrderStagingCode(String orderStagingCode) {
		this.orderStagingCode = orderStagingCode;
	}
}
