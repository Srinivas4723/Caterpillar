package com.cat.logistics.ods.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * This class holds order combination information from ODS 
 * @author singhr9
 *
 */
@Entity
@Table(name="ORD_COMB_VW",schema="Z1AK001$")
public class OdsOrderComb implements Serializable{

	private static final long serialVersionUID = -7030858277837916200L;

	@Id
	@Column(name="ORD_CTL_NO")
	private String shpOrderControlNum;
	
	@Column(name="SLS_MDL_NO")
	private String modelNum;

	/**
	 * @return the shpOrderControlNum
	 */
	public String getShpOrderControlNum() {
		return shpOrderControlNum;
	}

	/**
	 * @param shpOrderControlNum the shpOrderControlNum to set
	 */
	public void setShpOrderControlNum(String shpOrderControlNum) {
		this.shpOrderControlNum = shpOrderControlNum;
	}

	/**
	 * @return the modelNum
	 */
	public String getModelNum() {
		return modelNum;
	}

	/**
	 * @param modelNum the modelNum to set
	 */
	public void setModelNum(String modelNum) {
		this.modelNum = modelNum;
	}
	
}
