package com.cat.logistics.ods.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 *  This class holds Order stage history details from ODS
 * @author chanda15
 *
 */
@Entity
@Table(name="ORD_STG_HIST_VW",schema="Z1AK001$")
public class OdsOrderStgHist implements Serializable{

	private static final long serialVersionUID = 5160611393655281971L;

	@Id
	@Column(name="ORD_CTL_NO")
	private String ordCtrlNum;
	
	@Embedded
	private OdsOrdAttrs odsOrdAttr;

	/**
	 * @return the orderControlNum
	 */
	public String getOrdCtrlNum() {
		return ordCtrlNum;
	}

	/**
	 * @param orderControlNum the orderControlNum to set
	 */
	public void setOrdCtrlNum(String orderControlNum) {
		ordCtrlNum = orderControlNum;
	}

	/**
	 * 
	 * @return OdsOrdAttrs obj
	 */
	public OdsOrdAttrs getOdsOrd() {
		return odsOrdAttr;
	}

	/**
	 * 
	 * @param odsOrdAttr
	 */
	public void setOdsOrd(OdsOrdAttrs odsOrd) {
		this.odsOrdAttr = odsOrd;
	}

}
