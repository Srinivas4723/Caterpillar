package com.cat.logistics.ods.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * This class holds Order stage details from ODS
 * @author singhr9
 *
 */
@Entity
@Table(name="ORD_STG_VW",schema="Z1AK001$")
public class OdsOrderStg implements Serializable{

	private static final long serialVersionUID = -8234607203146464099L;

	@Id
	@Column(name="ORD_CTL_NO")
	private String ordCtrlNum;
	
	@Embedded
	private OdsOrdAttrs odsOrd;

	/**
	 * @return the orderControlNum
	 */
	public String getOrderControlNum() {
		return ordCtrlNum;
	}

	/**
	 * @param orderControlNum the orderControlNum to set
	 */
	public void setOrderControlNum(String orderControlNum) {
		ordCtrlNum = orderControlNum;
	}

	/**
	 * @return the ODS order
	 */
	public OdsOrdAttrs getOdsOrd() {
		return odsOrd;
	}

	/**
	 * @param odsOrd
	 */
	public void setOdsOrd(OdsOrdAttrs odsOrd) {
		this.odsOrd = odsOrd;
	}


}
