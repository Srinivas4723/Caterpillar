package com.cat.logistics.ods.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * This class holds Serial number component information for ODS
 * @author singh9
 *
 */
@Entity
@Table(name="SER_CMPNT_VW",schema="Z1AK001$")
public class OdsSerialCmpnt implements Serializable{

	private static final long serialVersionUID = -3066064482393072847L;

	@Id
	@Column(name="ORD_CTL_NO")
	private String ordCtrlNo;
	
	@Embedded
	private OdsSerial odsSerial;

	/**
	 * @return the ordCtrlNo
	 */
	public String getOrderControlNum() {
		return ordCtrlNo;
	}

	
	/**
	 * @param ordCtrlNo the ordCtrlNo to set
	 */
	public void setOrderControlNum(String orderControlNum) {
		this.ordCtrlNo = orderControlNum;
	}


	/**
	 * @return the ods serial
	 */
	public OdsSerial getOdsSerial() {
		return odsSerial;
	}


	/**
	 * @param odsSerial
	 */
	public void setOdsSerial(OdsSerial odsSerial) {
		this.odsSerial = odsSerial;
	}

	
}
