package com.cat.logistics.ods.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * This class holds Order stage details from ODS STAGE VIEW
 * @author ganamr
 *
 */
@Entity
@Table(name="ODS_STG_VW",schema="Z1AK001$")
public class OdsStgVw implements Serializable{

	private static final long serialVersionUID = 1234077469416224440L;

	@Id
	@Column(name="ORD_CTL_NO")
	private String ordCtrlNum;
	
	@Embedded
	private OdsOrdAttrs odsOrd;

	/**
	 * @return the ordCtrlNum
	 */
	public String getOrdCtrlNum() {
		return ordCtrlNum;
	}

	/**
	 * @param ordCtrlNum the ordCtrlNum to set
	 */
	public void setOrdCtrlNum(String ordCtrlNum) {
		this.ordCtrlNum = ordCtrlNum;
	}

	/**
	 * @return the odsOrd
	 */
	public OdsOrdAttrs getOdsOrd() {
		return odsOrd;
	}

	/**
	 * @param odsOrd the odsOrd to set
	 */
	public void setOdsOrd(OdsOrdAttrs odsOrd) {
		this.odsOrd = odsOrd;
	}
}
