package com.cat.logistics.ods.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

/**
 * This class holds common information to embedded in ODS related component information
 * @author chanda15
 *
 */
@Embeddable
public class OdsSerial implements Serializable{

	@Column(name="CMPNT_SER_NO")
	private String serialNum;
	
	@Column(name="CMPNT_TYP")
	private String componentType;

	/**
	 * 
	 * @return the Serial Number
	 */
	public String getSerialNum() {
		return serialNum;
	}

	/**
	 * 
	 * @param serialNum
	 */
	public void setSerialNum(String serialNum) {
		this.serialNum = serialNum;
	}

	/**
	 * 
	 * @return the component Type
	 */
	public String getComponentType() {
		return componentType;
	}

	/**
	 * 
	 * @param componentType
	 */
	public void setComponentType(String componentType) {
		this.componentType = componentType;
	}
}
