package com.cat.logistics.ods.entities;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * This class holds Serial Component History information for ODS
 * @author singhr9
 *
 */
@Entity
@Table(name="SER_CMPNT_HIST_VW",schema="Z1AK001$")
public class OdsSerialCmpntHist implements Serializable{

	private static final long serialVersionUID = 3247704521180577923L;

	@Id
	@Column(name="ORD_CTL_NO")
	private String ordCtrnum;
	
	@Embedded
	private OdsSerial odsSerHst;

	
	/**
	 * @return the ordCtrnum
	 */
	public String getOrdControlNum() {
		return ordCtrnum;
	}


	/**
	 * @param ordCtrnum the ordCtrnum to set
	 */
	public void setOrdControlNum(String orderControlNum) {
		this.ordCtrnum = orderControlNum;
	}

	/**
	 * 
	 * @return the odsSerHst
	 */
	public OdsSerial getOdsSerHst() {
		return odsSerHst;
	}

	/**
	 * 
	 * @param odsSerHst
	 */
	public void setOdsSerHst(OdsSerial odsSerHst) {
		this.odsSerHst = odsSerHst;
	}

}
