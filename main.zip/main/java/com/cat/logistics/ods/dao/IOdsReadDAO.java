package com.cat.logistics.ods.dao;

import java.util.Date;
import java.util.List;

import com.cat.logistics.ods.entities.OdsSerialProduct;
import com.cat.logistics.shared.dao.IGenericJpaDao;
import com.cat.logistics.shared.exception.DaoException;

/**
 *  Interface for OdsReadDAO implmentation class
 * @author chanda15
 *
 */
public interface IOdsReadDAO extends IGenericJpaDao<Object, String> {

	/**
	 * @param mchSerNum
	 * @return the OdsSerialProduct
	 * @throws DaoException
	 */
	OdsSerialProduct getControlNum(String mchSerNum) throws DaoException;
	
	/**
	 * @param ordCntrlNum
	 * @return the Model number
	 * @throws DaoException
	 */
	String getModelNum(String ordCntrlNum) throws DaoException;
	
	/**
	 * @param ordCntrlNum
	 * @return the build date
	 * @throws DaoException
	 */
	Date getBuildDate(String ordCntrlNum) throws DaoException;
	
	/**
	 * @param ordCntrlNum
	 * @return the build date From history
	 * @throws DaoException
	 */
	Date getBuildDateFrmHist(String ordCntrlNum) throws DaoException;
	
	/**
	 * @param ordCntrlNum
	 * @return the list Engine serial numbers
	 * @throws DaoException
	 */
	List<String> getEngineNumbers(String ordCntrlNum) throws DaoException;
	
	/**
	 * @param ordCntrlNum
	 * @return list of Engine numbers from history
	 * @throws DaoException
	 */
	List<String> getEngineNumbersFrmHist(String ordCntrlNum) throws DaoException;

	/**
	 * @param ordCntrlNum
	 * @return Build Date
	 * @throws DaoException
	 */
	Date getBldDtFrmOdsStgVw(String ordCntrlNum) throws DaoException;

	/**
	 * @param ordCntrlNum
	 * @return Build date
	 * @throws DaoException
	 */
	Date getBldDtFrmOdsStgHistVw(String ordCntrlNum) throws DaoException;

}
