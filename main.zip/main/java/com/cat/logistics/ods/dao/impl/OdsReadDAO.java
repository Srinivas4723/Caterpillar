package com.cat.logistics.ods.dao.impl;

import java.util.Date;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.springframework.transaction.annotation.Transactional;

import com.cat.logistics.ods.dao.IOdsReadDAO;
import com.cat.logistics.ods.entities.OdsOrderComb;
import com.cat.logistics.ods.entities.OdsOrderStg;
import com.cat.logistics.ods.entities.OdsOrderStgHist;
import com.cat.logistics.ods.entities.OdsSerialCmpnt;
import com.cat.logistics.ods.entities.OdsSerialCmpntHist;
import com.cat.logistics.ods.entities.OdsSerialProduct;
import com.cat.logistics.ods.entities.OdsStgHistVw;
import com.cat.logistics.ods.entities.OdsStgVw;
import com.cat.logistics.shared.dao.impl.GenericJpaDao;
import com.cat.logistics.shared.exception.DaoException;
import com.cat.logistics.shared.utils.PersistenceConstants;

/**
 * @author singhr9
 *
 */
public class OdsReadDAO extends GenericJpaDao<Object, String> implements IOdsReadDAO {

	public static final Logger LOGGER = LogManager.getLogger(OdsReadDAO.class);

	/**
	 * Get control number and serial number prefix for machine number from ODS
	 * 
	 * @param mchSerNum
	 * @return OdsSerialProduct OdsSerialProduct
	 */
	@SuppressWarnings("unchecked")
	@Override
	@Transactional
	public OdsSerialProduct getControlNum(String mchSerNum) throws DaoException {
		LOGGER.info("Entry method of getControlNum {} {}", PersistenceConstants.METHOD_ENTRY, mchSerNum);
		OdsSerialProduct odsSerProduct = null;
		try {
			Criteria criteria = getOdsSession().createCriteria(OdsSerialProduct.class);
			criteria.add(Restrictions.eq("mfrSerNum", mchSerNum));

			List<OdsSerialProduct> prdList = (List<OdsSerialProduct>) criteria.list();
			if (null != prdList && prdList.size() > 0) {
				odsSerProduct = (OdsSerialProduct) prdList.get(0);
				LOGGER.info("Entry method of getControlNum {}",
						odsSerProduct.getOrderControlNum());
			}
			LOGGER.info("Exit method of getControlNum{}", PersistenceConstants.METHOD_EXIT);
		} catch (Exception daoExc) {
			LOGGER.error("Error in getControlNum {} {}", daoExc.getMessage(), daoExc);
			throw new DaoException(daoExc);
		}
		return odsSerProduct;
	}

	/**
	 * Get Machine model number for order control number from ODS
	 * 
	 * @param ordCntrlNum ordCntrlNum
	 * @return Model Number
	 */
	@SuppressWarnings("unchecked")
	@Override
	@Transactional
	public String getModelNum(String ordCntrlNum) throws DaoException {

		LOGGER.info("Entry method of getModelNum{} {}", PersistenceConstants.METHOD_ENTRY, ordCntrlNum);

		String modelNum = null;
		try {
			Criteria criteria = getOdsSession().createCriteria(OdsOrderComb.class);
			criteria.add(Restrictions.eq("shpOrderControlNum", ordCntrlNum));

			ProjectionList proj = Projections.projectionList();
			proj.add(Projections.property("modelNum"));
			criteria.setProjection(proj);

			List<String> mdlList = (List<String>) criteria.list();
			if (null != mdlList && mdlList.size() > 0) {
				modelNum = mdlList.get(0);
				LOGGER.info("Entry method of getModelNum{} {}", "ModelNum", modelNum);
			}
			LOGGER.info("Exit method of getModelNum {}", PersistenceConstants.METHOD_EXIT);
		} catch (Exception daoExc) {
			LOGGER.error("Error in getConfigData {}", daoExc.getMessage(), daoExc);
			throw new DaoException(daoExc);
		}

		return modelNum;
	}

	/**
	 * Get Machine Build Date for order control number from ODS
	 * 
	 * @param ordCntrlNum ordCntrlNum
	 * @return Date date
	 */
	@Override
	@Transactional
	public Date getBuildDate(String ordCntrlNum) throws DaoException {
		LOGGER.info("Entry method of getBuildDate {} {}", PersistenceConstants.METHOD_ENTRY, ordCntrlNum);
		Date bldDt = null;
		try {
			Criteria criteria = getOdsSession().createCriteria(OdsOrderStg.class);
			bldDt = buildDateCriteria(criteria, ordCntrlNum);
			LOGGER.info("Exit method of getBuildDate {}", PersistenceConstants.METHOD_EXIT);
		} catch (Exception daoExc) {
			LOGGER.error("Error in getBuildDate {}", daoExc.getMessage(), daoExc);
			throw new DaoException(daoExc);
		}

		return bldDt;
	}

	/**
	 * @param criteria
	 * @param ordCntrlNum
	 * @return Build Date
	 */
	@SuppressWarnings("unchecked")
	private Date buildDateCriteria(Criteria criteria, String ordCntrlNum) {
		Date bldDt = null;
		criteria.add(Restrictions.eq("ordCtrlNum", ordCntrlNum));
		criteria.add(Restrictions.eq("odsOrd.orderStagingCode", PersistenceConstants.BUILT));

		ProjectionList proj = Projections.projectionList();
		proj.add(Projections.property("odsOrd.buildDate"));
		criteria.setProjection(proj);

		List<Date> bldDtLst = (List<Date>) criteria.list();
		if (null != bldDtLst && bldDtLst.size() > 0) {
			bldDt = (Date) bldDtLst.get(0);
		}

		return bldDt;
	}

	/**
	 * Get Machine Build Date for order control number from ODS History table
	 * 
	 * @param ordCntrlNum ordCntrlNum
	 * @return Date date
	 */
	@SuppressWarnings("unchecked")
	@Override
	@Transactional
	public Date getBuildDateFrmHist(String ordCntrlNum) throws DaoException {
		LOGGER.info("Entry method of getBuildDateFrmHist {} {}", PersistenceConstants.METHOD_ENTRY, ordCntrlNum);
		Date bldDt = null;
		try {
			Criteria criteria = getOdsSession().createCriteria(OdsOrderStgHist.class);
			criteria.add(Restrictions.eq("ordCtrlNum", ordCntrlNum));
			criteria.add(Restrictions.eq("odsOrdAttr.orderStagingCode", PersistenceConstants.BUILT));

			ProjectionList projs = Projections.projectionList();
			projs.add(Projections.property("odsOrdAttr.buildDate"));
			criteria.setProjection(projs);

			List<Date> bldDts = criteria.list();
			if (null != bldDts && bldDts.size() > 0) {
				bldDt = (Date) bldDts.get(0);
			}
			LOGGER.info("Exit method of getBuildDateFrmHist {}",
					PersistenceConstants.METHOD_EXIT);
		} catch (Exception daoExc) {
			LOGGER.error("Error in getBuildDateFrmHist {}", daoExc.getMessage(), daoExc);
			throw new DaoException(daoExc);
		}
		return bldDt;
	}

	/**
	 * Get Engine Number for order control number from ODS
	 * 
	 * @param ordCntrlNum ordCntrlNum
	 * @return list of engine numbers
	 */
	@SuppressWarnings("unchecked")
	@Override
	@Transactional
	public List<String> getEngineNumbers(String ordCntrlNum) throws DaoException {
		LOGGER.info("Entry method of getEngineNumbers {} {}",PersistenceConstants.METHOD_ENTRY,ordCntrlNum);
		List<String> engList = null;
		try {
			Criteria criteria = getOdsSession().createCriteria(OdsSerialCmpnt.class);
			criteria.add(Restrictions.eq("ordCtrlNo", ordCntrlNum));
			criteria.add(Restrictions.eq("odsSerial.componentType", PersistenceConstants.EN));
			ProjectionList proj = Projections.projectionList();
			proj.add(Projections.property("odsSerial.serialNum"));
			criteria.setProjection(proj);
			engList = criteria.list();
			if (null != engList && engList.size() > 0) {
				for (String engineNumber : engList) {
					LOGGER.info("Entry method of getEngineNumbers {}",engineNumber);
				}
			}
			LOGGER.info("Exit method of getEngineNumbers {}", PersistenceConstants.METHOD_EXIT);
		} catch (Exception daoExc) {
			LOGGER.error("Error in getEngineNumbers {}",  daoExc.getMessage(), daoExc);
			throw new DaoException(daoExc);
		}

		return engList;
	}

	/**
	 * Get Engine Number for order control number from ODS History table
	 * 
	 * @param ordCntrlNum ordCntrlNum
	 * @return List of serial numbers
	 */
	@SuppressWarnings("unchecked")
	@Override
	@Transactional
	public List<String> getEngineNumbersFrmHist(String ordCntrlNum) throws DaoException {
		LOGGER.info("Entry method of getEngineNumbersFrmHist {} {}",PersistenceConstants.METHOD_ENTRY, ordCntrlNum);
		List<String> engns = null;
		try {
			Criteria criteria = getOdsSession().createCriteria(OdsSerialCmpntHist.class);
			criteria.add(Restrictions.eq("ordCtrnum", ordCntrlNum));
			criteria.add(Restrictions.eq("odsSerHst.componentType", PersistenceConstants.EN));
			ProjectionList projVal = Projections.projectionList();
			projVal.add(Projections.property("odsSerHst.serialNum"));
			criteria.setProjection(projVal);
			engns = criteria.list();
			if (null != engns && engns.size() > 0) {
				for (String engineNumber : engns) {
					LOGGER.info("Entry method of getEngineNumbersFrmHist {}", engineNumber);
				}
			}
			LOGGER.info("Entry method of getEngineNumbersFrmHist {}", PersistenceConstants.METHOD_EXIT);
		} catch (Exception daoExc) {
			LOGGER.error("Error in getEngineNumbersFrmHist {}", daoExc.getMessage(), daoExc);
			throw new DaoException(daoExc);
		}
		return engns;
	}

	/**
	 * Get Machine Build Date for order control number from ODS Stage view
	 * 
	 * @param ordCntrlNum ordCntrlNum
	 * @return Date date
	 */
	@Override
	@Transactional
	public Date getBldDtFrmOdsStgVw(String ordCntrlNum) throws DaoException {
		LOGGER.info("Entry method of getBldDtFrmOdsStgVw {}",ordCntrlNum);
		Date bldDt = null;
		try {
			Criteria criteria = getOdsSession().createCriteria(OdsStgVw.class);
			bldDt = buildDateCriteria(criteria, ordCntrlNum);
			LOGGER.info("Exit method of getBldDtFrmOdsStgVw {}",
					PersistenceConstants.METHOD_EXIT);
		} catch (Exception daoExc) {
			LOGGER.error("Error in getBldDtFrmOdsStgVw {}", daoExc.getMessage(),
					daoExc);
			throw new DaoException(daoExc);
		}

		return bldDt;
	}

	/**
	 * Get Machine Build Date for order control number from ODS Stage History view
	 * 
	 * @param ordCntrlNum ordCntrlNum
	 * @return Date date
	 */
	@Override
	@Transactional
	public Date getBldDtFrmOdsStgHistVw(String ordCntrlNum) throws DaoException {
		LOGGER.info("Entry method of getConfigData {}",ordCntrlNum);
		Date bldDt = null;
		try {
			Criteria criteria = getOdsSession().createCriteria(OdsStgHistVw.class);
			bldDt = buildDateCriteria(criteria, ordCntrlNum);

			LOGGER.info("Exit method of getConfigData {}",
					PersistenceConstants.METHOD_EXIT);
		} catch (Exception daoExc) {
			LOGGER.error("Error in getConfigData {}", daoExc.getMessage(),
					daoExc);
			throw new DaoException(daoExc);
		}

		return bldDt;
	}
}
