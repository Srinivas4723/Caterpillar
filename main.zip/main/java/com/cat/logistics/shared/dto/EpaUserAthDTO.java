package com.cat.logistics.shared.dto;

import com.cat.logistics.shared.utils.ServiceConstants;


/*
 * Copyright (c) 2015 Caterpillar Inc. All Rights Reserved.
 *
 * This work contains Caterpillar Inc.'s unpublished
 * proprietary information which may constitute a trade secret
 * and/or be confidential. This work may be used only for the
 * purposes for which it was provided, and may not be copied
 * or disclosed to others. Copyright notice is precautionary
 * only, and does not imply publication.
 */

/**
 * @version 1.0 Jun 2, 2015 7:55:35 PM badamrr
 * @author badamrr
 */
public class EpaUserAthDTO {
	private CWSUserDTO cwsUserDetails;
	
	private String assignedUserRole = ServiceConstants.NOT_ASSIGNED;
	
	private String assignedFacility = ServiceConstants.NOT_ASSIGNED;

	/**
	 * @param cwsUserDetails
	 * @param assignedUserRole
	 * @param assignedFacility
	 */
	public EpaUserAthDTO(CWSUserDTO cwsUserDetails, String assignedUserRole,
			String assignedFacility) {
		super();
		this.cwsUserDetails = cwsUserDetails;
		this.assignedUserRole = assignedUserRole;
		this.assignedFacility = assignedFacility;
	}

	/**
	 * @param cwsUserDetails
	 */
	public EpaUserAthDTO(CWSUserDTO cwsUserDetails) {
		super();
		this.cwsUserDetails = cwsUserDetails;
	}

	/**
	 * 
	 */
	public EpaUserAthDTO() {
	}

	/**
	 *
	 * @return Returns the cwsUserDetails
	 */
	public CWSUserDTO getCwsUserDetails() {
		return cwsUserDetails;
	}

	/**
	 *
	 * @param cwsUserDetails the cwsUserDetails to set
	 */
	public void setCwsUserDetails(CWSUserDTO cwsUserDetails) {
		this.cwsUserDetails = cwsUserDetails;
	}

	/**
	 * @return Returns the assignedUserRole
	 */
	public String getAssignedUserRole() {
		return assignedUserRole;
	}

	/**
	 *
	 * @param assignedUserRole the assignedUserRole to set
	 */
	public void setAssignedUserRole(String assignedUserRole) {
		this.assignedUserRole = assignedUserRole;
	}

	/**
	 * @return Returns the assignedFacility
	 */
	public String getAssignedFacility() {
		return assignedFacility;
	}

	/**
	 *
	 * @param assignedFacility the assignedFacility to set
	 */
	public void setAssignedFacility(String assignedFacility) {
		this.assignedFacility = assignedFacility;
	}
	
	
}
