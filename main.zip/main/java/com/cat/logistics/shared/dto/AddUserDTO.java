package com.cat.logistics.shared.dto;

import java.util.List;

/**
 * This class holds Add User information
 * @author badamrr
 */
public class AddUserDTO {


	private String cwsId;
	private List<String> epaAdminBox;
	private List<String> facilityFormApprovalBox; 
	private List<String> facilityFormCreationBox;
	private List<String> facilityFormViewonlyBox;
	private boolean facilitiesFetchedFromDb;
	private boolean epaPrGrpAdmin;
	private String userAffiliation;
	private String userOrganization;
	private String userPhoneNumber;
	
	
	/**
	 * AddUserDTO
	 * @param cwsId
	 * @param epaAdminBox
	 * @param facilityFormApprovalBox
	 * @param facilityFormCreationBox
	 * @param facilityFormViewonlyBox
	 * @param epaPrGrpAdmin
	 * @param facilitiesFetchedFromDb
	 */
	public AddUserDTO(String cwsId, List<String> epaAdminBox,
			List<String> facilityFormApprovalBox,
			List<String> facilityFormCreationBox,List<String> facilityFormViewonlyBox, boolean epaPrGrpAdmin, boolean facilitiesFetchedFromDb) {
		super();
		this.cwsId = cwsId;
		this.epaAdminBox = epaAdminBox;
		this.facilityFormApprovalBox = facilityFormApprovalBox;
		this.facilityFormCreationBox = facilityFormCreationBox;
		this.facilityFormViewonlyBox = facilityFormViewonlyBox;
		this.facilitiesFetchedFromDb = facilitiesFetchedFromDb;
		this.epaPrGrpAdmin = epaPrGrpAdmin;
	}
	/**
	 * get the cws id
	 * @return Returns the cwsId
	 * @since 1.0 Jun 12, 2015 10:51:19 AM badamrr
	 */
	public String getCwsId() {
		return cwsId;
	}
	/**
	 * @param cwsId the cwsId to set
	 * @since 1.0 Jun 12, 2015 10:51:19 AM badamrr
	 */
	public void setCwsId(String cwsId) {
		this.cwsId = cwsId;
	}
	/**
	 * @return Returns the epaAdminBox
	 * @since 1.0 Jun 12, 2015 10:51:19 AM badamrr
	 */
	public List<String> getEpaAdminBox() {
		return epaAdminBox;
	}
	/**
	 * @param epaAdminBox the epaAdminBox to set
	 */
	public void setEpaAdminBox(List<String> epaAdminBox) {
		this.epaAdminBox = epaAdminBox;
	}
	/**
	 * @return Returns the facilityFormApprovalBox
	 */
	public List<String> getFacilityFormApprovalBox() {
		return facilityFormApprovalBox;
	}
	/**
	 * @param facilityFormApprovalBox the facilityFormApprovalBox to set
	 */
	public void setFacilityFormApprovalBox(List<String> facilityFormApprovalBox) {
		this.facilityFormApprovalBox = facilityFormApprovalBox;
	}
	/**
	 * @return Returns the facilityFormCreationBox
	 */
	public List<String> getFacilityFormCreationBox() {
		return facilityFormCreationBox;
	}
	/**
	 * @param facilityFormCreationBox the facilityFormCreationBox to set
	 */
	public void setFacilityFormCreationBox(List<String> facilityFormCreationBox) {
		this.facilityFormCreationBox = facilityFormCreationBox;
	}
	/**
	 * @return Returns the facilitiesFetchedFromDb
	 */
	public boolean isFacilitiesFetchedFromDb() {
		return facilitiesFetchedFromDb;
	}
	/**
	 * @param facilitiesFetchedFromDb the facilitiesFetchedFromDb to set
	 */
	public void setFacilitiesFetchedFromDb(boolean facilitiesFetchedFromDb) {
		this.facilitiesFetchedFromDb = facilitiesFetchedFromDb;
	}
	/**
	 * @return the facilityFormViewonlyBox
	 */
	public List<String> getFacilityFormViewonlyBox() {
		return facilityFormViewonlyBox;
	}
	/**
	 * @param facilityFormViewonlyBox the facilityFormViewonlyBox to set
	 */
	public void setFacilityFormViewonlyBox(List<String> facilityFormViewonlyBox) {
		this.facilityFormViewonlyBox = facilityFormViewonlyBox;
	}
	/**
	 * @return the epaPrGrpAdmin
	 */
	public boolean isEpaPrGrpAdmin() {
		return epaPrGrpAdmin;
	}
	/**
	 * @param epaPrGrpAdmin the epaPrGrpAdmin to set
	 */
	public void setEpaPrGrpAdmin(boolean epaPrGrpAdmin) {
		this.epaPrGrpAdmin = epaPrGrpAdmin;
	}
	/**
	 * @return User Affiliation
	 */
	public String getUserAffiliation() {
		return userAffiliation;
	}
	/**
	 * @param userAffiliation
	 */
	public void setUserAffiliation(String userAffiliation) {
		this.userAffiliation = userAffiliation;
	}
	/**
	 * @return user Organization
	 */
	public String getUserOrganization() {
		return userOrganization;
	}
	/**
	 * @param userOrganization
	 */
	public void setUserOrganization(String userOrganization) {
		this.userOrganization = userOrganization;
	}
	public String getUserPhoneNumber() {
		return userPhoneNumber;
	}
	public void setUserPhoneNumber(String userPhoneNumber) {
		this.userPhoneNumber = userPhoneNumber;
	}
}
