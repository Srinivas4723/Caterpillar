package com.cat.logistics.shared.dto;


/**
 * This class holds CWS user details 
 * @author ganamr
 *
 */
public class CWSUserDTO {

	private String cwsId;
	
	private String firstName;
	
	private String lastName;
	
	private String middleName;
	
	private String affiliationDescription;
	
	private String organization;
	
	private String phoneNumber;
	

	/**
	 *
	 * @return Returns the cwsId
	 */
	public String getCwsId() {
		return cwsId;
	}

	/**
	 * @param cwsId the cwsId to set
	 */
	public void setCwsId(String cwsId) {
		this.cwsId = cwsId;
	}

	/**
	 * Description of the method.
	 *
	 */
	public String getFirstName() {
		return firstName;
	}

	/**
	 * @param firstName the firstName to set
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	/**
	 * @return Returns the lastName
	 */
	public String getLastName() {
		return lastName;
	}

	/**
	 * @param lastName the lastName to set
	 */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	/**
	 *
	 * @return Returns the middleName
	 */
	public String getMiddleName() {
		return middleName;
	}

	/**
	 * @param middleName the middleName to set
	 */
	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	/**
	 *
	 * @return Returns the affiliationDescription
	 */
	public String getAffiliationDescription() {
		return affiliationDescription;
	}

	/**
	 *
	 * @param affiliationDescription the affiliationDescription to set
	 */
	public void setAffiliationDescription(String affiliationDescription) {
		this.affiliationDescription = affiliationDescription;
	}

	/**
	 *
	 * @return Returns the organization
	 */
	public String getOrganization() {
		return organization;
	}

	/**
	 *
	 * @param organization the organization to set
	 */
	public void setOrganization(String organization) {
		this.organization = organization;
	}

	/**
	 *
	 * @return hash code value
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime
				* result
				+ ((affiliationDescription == null) ? 0
						: affiliationDescription.hashCode());
		result = prime * result + ((cwsId == null) ? 0 : cwsId.hashCode());
		result = prime * result
				+ ((firstName == null) ? 0 : firstName.hashCode());
		result = prime * result
				+ ((lastName == null) ? 0 : lastName.hashCode());
		result = prime * result
				+ ((middleName == null) ? 0 : middleName.hashCode());
		result = prime * result
				+ ((organization == null) ? 0 : organization.hashCode());
		return result;
	}

	
	 /** 
	  * @param obj object
	 */
	@Override
	    public boolean equals(Object obj) {
	        if (obj == null) {
	            return false;
	        }
	        if (getClass() != obj.getClass()) {
	            return false;
	        }
	        
	        CWSUserDTO other = (CWSUserDTO) obj;
		    return equalsVariableValidation(other);

	    }

	/**
	 * @param other
	 * @return boolean true or false
	 */
	private boolean equalsVariableValidation(CWSUserDTO other) {
		return cwsId == other.cwsId && 
		equalsFirstNameValidation(other) && 
		equalsLastNameValidation(other) &&
		equalsMiddleNameValidation(other) &&
		equalsAffliationDescriptionValidation(other) &&
		equalsOrganizationValidation(other) &&
		equalsPhoneNumberValidation(other)
		;
	}
	
	/**
	 * @param other
	 * @return boolean value 
	 */
	private boolean equalsFirstNameValidation(CWSUserDTO other)
	{
		return (firstName == other.firstName || (firstName != null && firstName.equals(other.getFirstName()))) ;
	}
	/**
	 * @param other
	 * @return boolean value 
	 */
	private boolean equalsLastNameValidation(CWSUserDTO other)
	{
		return (lastName == other.lastName || (lastName != null && lastName .equals(other.getLastName())));
	}
	/**
	 * @param other
	 * @return boolean value 
	 */
	private boolean equalsMiddleNameValidation(CWSUserDTO other)
	{
		return (middleName == other.middleName || (middleName != null && middleName .equals(other.getMiddleName())));
	}
	/**
	 * @param other
	 * @return boolean value 
	 */
	private boolean equalsAffliationDescriptionValidation(CWSUserDTO other)
	{
		return (affiliationDescription == other.affiliationDescription || (affiliationDescription != null && affiliationDescription .equals(other.getAffiliationDescription())));
	}
	/**
	 * @param other
	 * @return boolean value 
	 */
	private boolean equalsOrganizationValidation(CWSUserDTO other)
	{
		return (organization == other.organization || (organization != null && organization .equals(other.getOrganization())));
	}

	private boolean equalsPhoneNumberValidation(CWSUserDTO other)
	{
		return (phoneNumber == other.phoneNumber || (phoneNumber != null && phoneNumber .equals(other.getPhoneNumber())));
	}
	
	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	
	
}
