package com.cat.logistics.shared.dto;

import java.io.Serializable;
import java.util.List;

/**
 * This class holds the Mass Upload information for Engine and Machine
 * @author kakars2
 *
 */
public class MassUploadDTO extends GenericUploadDTO implements Serializable {
	
	private static final long serialVersionUID = 664894628749732893L;
	

	private List<MassUploadExcelRowDTO> failList=null;
	private List<MassUploadExcelRowDTO> successList=null;
	
	/**
	 * 
	 * @return failList
	 */
	public List<MassUploadExcelRowDTO> getFailList() {
		return failList;
	}

	/**
	 * 
	 * @param failList
	 */
	public void setFailList(List<MassUploadExcelRowDTO> failList) {
		this.failList = failList;
	}

	/**
	 * 
	 * @return successList
	 */
	public List<MassUploadExcelRowDTO> getSuccessList() {
		return successList;
	}

	/**
	 * 
	 * @param successList
	 */
	public void setSuccessList(List<MassUploadExcelRowDTO> successList) {
		this.successList = successList;
	}

}
