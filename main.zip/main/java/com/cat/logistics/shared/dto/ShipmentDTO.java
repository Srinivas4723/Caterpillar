package com.cat.logistics.shared.dto;

import java.io.Serializable;
import java.util.Date;


/**
 * This class is to hold shipment information
 * @author ganamr
 *
 */
public class ShipmentDTO implements Serializable{	

	private static final long serialVersionUID = 4593031920336337958L;
	
	private long epaSeqNum;
	
	private String invoiceNumber;
	
	private Date shipmentDate;
	
	private String originFacility;
	
	private String arPartNumber;
	
	private String orderNumber;
	
	private String epaCmnt;
	
	private String epaPrdTyp;

	/**
	 * @return the invoiceNumber
	 */
	public String getInvoiceNumber() {
		return invoiceNumber;
	}

	/**
	 * @return the shipmentDate
	 */
	public Date getShipmentDate() {
		return  shipmentDate == null ? null : new Date(shipmentDate.getTime()) ;
	}

	/**
	 * @return the originFacility
	 */
	public String getOriginFacility() {
		return originFacility;
	}

	/**
	 * @param invoiceNumber the invoiceNumber to set
	 */
	public void setInvoiceNumber(String invoiceNumber) {
		this.invoiceNumber = invoiceNumber;
	}

	/**
	 * @param shipmentDate the shipmentDate to set
	 */
	public void setShipmentDate(Date shipmentDate) {
		this.shipmentDate =  shipmentDate == null ? null : new Date(shipmentDate.getTime()) ;
	}

	/**
	 * @param originFacility the originFacility to set
	 */
	public void setOriginFacility(String originFacility) {
		this.originFacility = originFacility;
	}


	/**
	 * @return the arPartNumber
	 */
	public String getArPartNumber() {
		return arPartNumber;
	}

	/**
	 * @param arPartNumber the arPartNumber to set
	 */
	public void setArPartNumber(String arPartNumber) {
		this.arPartNumber = arPartNumber;
	}

	/**
	 * @return the orderNumber
	 */
	public String getOrderNumber() {
		return orderNumber;
	}

	/**
	 * @param orderNumber the orderNumber to set
	 */
	public void setOrderNumber(String orderNumber) {
		this.orderNumber = orderNumber;
	}

	/**
	 * @return the epaSeqNum
	 */
	public long getEpaSeqNum() {
		return epaSeqNum;
	}

	/**
	 * @param epaSeqNum the epaSeqNum to set
	 */
	public void setEpaSeqNum(long epaSeqNum) {
		this.epaSeqNum = epaSeqNum;
	}

	/**
	 * 
	 * @return String epaCmnt
	 */
	public String getEpaCmnt() {
		return epaCmnt;
	}

	/**
	 * 
	 * @param epaCmnt epaCmnt
	 */
	public void setEpaCmnt(String epaCmnt) {
		this.epaCmnt = epaCmnt;
	}

	/**
	 * @return the epaPrdTyp
	 */
	public String getEpaPrdTyp() {
		return epaPrdTyp;
	}

	/**
	 * @param epaPrdTyp the epaPrdTyp to set
	 */
	public void setEpaPrdTyp(String epaPrdTyp) {
		this.epaPrdTyp = epaPrdTyp;
	}

}
