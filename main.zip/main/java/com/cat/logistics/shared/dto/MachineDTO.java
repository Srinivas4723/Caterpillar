package com.cat.logistics.shared.dto;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Set;

import com.cat.logistics.shared.utils.ServiceConstants;

/**
 * This class holds Machine related information
 * @author singhr9
 *
 */
public class MachineDTO extends ShipmentDTO {
	
	private static final long serialVersionUID = -2754041196345760081L;
	
	private String machineSerialNum;
	
	private EngineDTO mchEngine;
	
	private String machineModelNum;
	
	private Date machinebuildDt;
	
	private String epaStatusCdDesc;
	/**
	 * Property for MSO
	 */
	private String msos;
	
	private String machineDescription;
	
	private String machineMfrName;
	
	private String machineFormAction;
	
	private String epaSeqNo;
	
	private Set<String> engineNumbers ;
	
	/**
	 * Property for From Build Date
	 */
	private String fromBuildDate;
	
	/**
	 * Property for Facility Code Description
	 */
	private String facilityCdDescs;
	/**
	 * Property for Epa Status Code Description
	 */
	
	private List<String> message ;
	
	private String successMessage ;
	
	private boolean engInfoVisible = ServiceConstants.FALSE;
	
	private boolean mchInfoVisible = ServiceConstants.FALSE;
	
	private boolean disableEngine = ServiceConstants.TRUE;
	
	private boolean updateOperation = ServiceConstants.FALSE;
	
	private boolean displayShipInfo = ServiceConstants.FALSE;
	
	private String modelmsg;
	
	private String mchOriginFCd;
	
	/**
	 * Property for To Ship Date
	 */
	private String toShippedDate;
	
	/**
	 * Property for To Build Date
	 */
	private String toBuildDate;
	
	/**
	 * Property for fromShipdate
	 */
	private String fromShippedDate;	

	/**
	 * Property for Machine Serial Number
	 */
	private String machineSerialNo;
	/**
	 * Property for Invoice Number
	 */
	private String invoiceNo;
	
	/**
	 * Machine source facility code and Name
	 */
	private String machineSrcFac;
	
	private String oldMchSerilNumber;
	
	/**
	 * Redirect Flag
	 */
	private boolean redirect;
	/**
	 * 
	 */
	public MachineDTO() {
		super();
	}

	/**
	 * Constructor with machine Number and EngineDTO
	 * @param mchSerNum
	 * @param machEngine
	 */
	public MachineDTO(String mchSerNum, EngineDTO machEngine) {
		super();
		this.machineSerialNum = mchSerNum;
		this.mchEngine = machEngine;
	}



	/**
	 * @param machineSerialNum
	 * @param mchEngine
	 * @param updateOperation
	 * @param displayShipInfo
	 */
	public MachineDTO(String machineSerialNum, 
			EngineDTO mchEngine, boolean updateOperation,
			boolean displayShipInfo, String epaSeqNum, Date shipDate,
			String mso, String invoice, String partNum) {
		super();
		this.machineSerialNum = machineSerialNum;
		this.mchEngine = mchEngine;
		this.updateOperation = updateOperation;
		this.displayShipInfo = displayShipInfo;
		this.epaSeqNo = epaSeqNum;
		this.setShipmentDate(shipDate);
		this.setOrderNumber(mso);
		this.setInvoiceNumber(invoice);
		this.setArPartNumber(partNum);
	}

	/**
	 * Constructor with machine Number
	 * @param machEngine
	 */
	public MachineDTO(EngineDTO machEngine) {
		super();
		this.mchEngine = machEngine;
	}

	/**
	 * Constructor with EngineDTO and successmessage
	 * @param machEngine
	 * @param successMsg
	 */
	public MachineDTO(EngineDTO machEngine, String successMsg) {
		super();
		this.mchEngine = machEngine;
		this.successMessage = successMsg;
	}



	/**
	 * @return the machineSerialNum
	 */
	public String getMachineSerialNum() {
		return machineSerialNum;
	}



	/**
	 * @param machineSerialNum the machineSerialNum to set
	 */
	public void setMachineSerialNum(String machineSerialNum) {
		this.machineSerialNum = machineSerialNum;
	}

	/**
	 * @return the machineModelNum
	 */
	public String getMachineModelNum() {
		return machineModelNum;
	}

	/**
	 * @return the machinebuildDt
	 */
	public Date getMachinebuildDt() {
		return  machinebuildDt == null ? null : new Date(machinebuildDt.getTime()) ;
		//return  machinebuildDt;
	}

	/**
	 * @return the machineMfrname
	 */
	public String getMachineMfrName() {
		return machineMfrName;
	}



	/**
	 * @param machineModelNum the machineModelNum to set
	 */
	public void setMachineModelNum(String machineModelNum) {
		this.machineModelNum = machineModelNum;
	}

	/**
	 * @param machinebuildDt the machinebuildDt to set
	 */
	public void setMachinebuildDt(Date machinebuildDt) {
		this.machinebuildDt =  machinebuildDt == null ? null : new Date(machinebuildDt.getTime()) ;
	}


	
	/**
	 * @param machineMfrName
	 */
	public void setMachineMfrName(String machineMfrName) {
		this.machineMfrName = machineMfrName;
	}

	/**
	 * @return the machineDescription
	 */
	public String getMachineDescription() {
		return machineDescription;
	}

	/**
	 * @param machineDescription the machineDescription to set
	 */
	public void setMachineDescription(String machineDescription) {
		this.machineDescription = machineDescription;
	}

	/**
	 * @return the mchEngine
	 */
	public EngineDTO getMchEngine() {
		return mchEngine;
	}

	/**
	 * @param mchEngine the mchEngine to set
	 */
	public void setMchEngine(EngineDTO mchEngine) {
		this.mchEngine = mchEngine;
	}

	/**
	 * @return the message
	 */
	public List<String> getMessage() {
		return message;
	}

	/**
	 * @param message the message to set
	 */
	public void setMessage(List<String> message) {
		this.message = message;
	}
	
	/**
	 * @param msg
	 */
	public void addMessage(String msg) {
		if(null== this.message){
			this.message = new ArrayList<String>();
		}
		this.message.add(msg);
	}

	/**
	 * @return the engInfoVisible
	 */
	public boolean isEngInfoVisible() {
		return engInfoVisible;
	}

	/**
	 * @param engInfoVisible the engInfoVisible to set
	 */
	public void setEngInfoVisible(boolean engInfoVisible) {
		this.engInfoVisible = engInfoVisible;
	}

	/**
	 * @return the mchInfoVisible
	 */
	public boolean isMchInfoVisible() {
		return mchInfoVisible;
	}

	/**
	 * @param mchInfoVisible the mchInfoVisible to set
	 */
	public void setMchInfoVisible(boolean mchInfoVisible) {
		this.mchInfoVisible = mchInfoVisible;
	}

	/**
	 * @return the disableEngine
	 */
	public boolean isDisableEngine() {
		return disableEngine;
	}

	/**
	 * @param disableEngine the disableEngine to set
	 */
	public void setDisableEngine(boolean disableEngine) {
		this.disableEngine = disableEngine;
	}

	/**
	 * @return the machineFormAction
	 */
	public String getMachineFormAction() {
		return machineFormAction;
	}

	/**
	 * @return the successMessage
	 */
	public String getSuccessMessage() {
		return successMessage;
	}

	/**
	 * @param successMessage the successMessage to set
	 */
	public void setSuccessMessage(String successMessage) {
		this.successMessage = successMessage;
	}

	/**
	 * @param machineFormAction the machineFormAction to set
	 */
	public void setMachineFormAction(String machineFormAction) {
		this.machineFormAction = machineFormAction;
	}

	/**
	 * @return the updateOperation
	 */
	public boolean isUpdateOperation() {
		return updateOperation;
	}

	/**
	 * @param updateOperation the updateOperation to set
	 */
	public void setUpdateOperation(boolean updateOperation) {
		this.updateOperation = updateOperation;
	}

	/**
	 * @return the displayShipInfo
	 */
	public boolean isDisplayShipInfo() {
		return displayShipInfo;
	}

	/**
	 * @param displayShipInfo the displayShipInfo to set
	 */
	public void setDisplayShipInfo(boolean displayShipInfo) {
		this.displayShipInfo = displayShipInfo;
	}

	/**
	 * @return the epaSeqNo
	 */
	public String getEpaSeqNo() {
		return epaSeqNo;
	}

	/**
	 * @param epaSeqNo the epaSeqNo to set
	 */
	public void setEpaSeqNo(String epaSeqNo) {
		this.epaSeqNo = epaSeqNo;
	}

	/**
	 * @return the engineNumbers
	 */
	public Set<String> getEngineNumbers() {
		return engineNumbers;
	}

	/**
	 * @param engineNumbers the engineNumbers to set
	 */
	public void setEngineNumbers(Set<String> engineNumbers) {
		this.engineNumbers = engineNumbers;
	}

	/**
	 * @return the modelmsg
	 */
	public String getModelmsg() {
		return modelmsg;
	}

	/**
	 * @param modelmsg the modelmsg to set
	 */
	public void setModelmsg(String modelmsg) {
		this.modelmsg = modelmsg;
	}

	

	/**
	 * @param msos the msos to set
	 */
	public void setMsos(String msos) {
		this.msos = msos;
	}

	/**
	 * @return the machineSerialNo
	 */
	public String getMachineSerialNo() {
		return machineSerialNo;
	}

	/**
	 * @param machineSerialNo the machineSerialNo to set
	 */
	public void setMachineSerialNo(String machineSerialNo) {
		this.machineSerialNo = machineSerialNo;
	}

	/**
	 * @return the invoiceNo
	 */
	public String getInvoiceNo() {
		return invoiceNo;
	}

	/**
	 * @param invoiceNo the invoiceNo to set
	 */
	public void setInvoiceNo(String invoiceNo) {
		this.invoiceNo = invoiceNo;
	}

	/**
	 * @return the epaStatusCdDesc
	 */
	public String getEpaStatusCdDesc() {
		return epaStatusCdDesc;
	}

	/**
	 * @param epaStatusCdDesc the epaStatusCdDesc to set
	 */
	public void setEpaStatusCdDesc(String epaStatusCdDesc) {
		this.epaStatusCdDesc = epaStatusCdDesc;
	}

	/**
	 * @return the fromBuildDate
	 */
	public String getFromBuildDate() {
		return fromBuildDate;
	}

	/**
	 * @param fromBuildDate the fromBuildDate to set
	 */
	public void setFromBuildDate(String fromBuildDate) {
		this.fromBuildDate = fromBuildDate;
	}

	/**
	 * @return the facilityCdDescs
	 */
	public String getFacilityCdDescs() {
		return facilityCdDescs;
	}

	/**
	 * @param facilityCdDescs the facilityCdDescs to set
	 */
	public void setFacilityCdDescs(String facilityCdDescs) {
		this.facilityCdDescs = facilityCdDescs;
	}

	/**
	 * @return the toShippedDate
	 */
	public String getToShippedDate() {
		return toShippedDate;
	}

	/**
	 * @param toShippedDate the toShippedDate to set
	 */
	public void setToShippedDate(String toShippedDate) {
		this.toShippedDate = toShippedDate;
	}

	/**
	 * @return the toBuildDate
	 */
	public String getToBuildDate() {
		return toBuildDate;
	}

	/**
	 * @param toBuildDate the toBuildDate to set
	 */
	public void setToBuildDate(String toBuildDate) {
		this.toBuildDate = toBuildDate;
	}

	/**
	 * @return the fromShippedDate
	 */
	public String getFromShippedDate() {
		return fromShippedDate;
	}

	/**
	 * @param fromShippedDate the fromShippedDate to set
	 */
	public void setFromShippedDate(String fromShippedDate) {
		this.fromShippedDate = fromShippedDate;
	}

	/**
	 * @return the msos
	 */
	public String getMsos() {
		return msos;
	}

	public String getMchOriginFCd() {
		return mchOriginFCd;
	}

	public void setMchOriginFCd(String mchOriginFCd) {
		this.mchOriginFCd = mchOriginFCd;
	}

	/**
	 * @return the machineSrcFac
	 */
	public String getMachineSrcFac() {
		return machineSrcFac;
	}

	/**
	 * @param machineSrcFac the machineSrcFac to set
	 */
	public void setMachineSrcFac(String machineSrcFac) {
		this.machineSrcFac = machineSrcFac;
	}

	/**
	 * @return the oldMchSerilNumber
	 */
	public String getOldMchSerilNumber() {
		return oldMchSerilNumber;
	}

	/**
	 * @param oldMchSerilNumber the oldMchSerilNumber to set
	 */
	public void setOldMchSerilNumber(String oldMchSerilNumber) {
		this.oldMchSerilNumber = oldMchSerilNumber;
	}

	/**
	 * 
	 * @return
	 */
	public boolean isRedirect() {
		return redirect;
	}

	/**
	 * 
	 * @param redirect
	 */
	public void setRedirect(boolean redirect) {
		this.redirect = redirect;
	}
	
	
	
}
