package com.cat.logistics.shared.dto;
/*
 * Copyright (c) 2015 Caterpillar Inc. All Rights Reserved.
 *
 * This work contains Caterpillar Inc.'s unpublished
 * proprietary information which may constitute a trade secret
 * and/or be confidential. This work may be used only for the
 * purposes for which it was provided, and may not be copied
 * or disclosed to others. Copyright notice is precautionary
 * only, and does not imply publication.
 */

/**
 *
 * @version 1.0 May 20, 2015 5:57:44 PM badamrr
 * @author badamrr
 */
public class EpaUserAuthoritiesDTO {

	private String assignedEPAUserRole;
	
	private String cwsId;
	
	private String affiliationDescription;
	
	
	private String lastName;
	
	
	
	private String organization;
	
	private String middleName;
	
	
	
	private String assignedFacilties;
	
	private String firstName;

	/**
	 * @return the assignedEPAUserRole
	 */
	public String getAssignedEPAUserRole() {
		return assignedEPAUserRole;
	}

	/**
	 * @param assignedEPAUserRole the assignedEPAUserRole to set
	 */
	public void setAssignedEPAUserRole(String assignedEPAUserRole) {
		this.assignedEPAUserRole = assignedEPAUserRole;
	}

	/**
	 * @return the cwsId
	 */
	public String getCwsId() {
		return cwsId;
	}

	/**
	 * @param cwsId the cwsId to set
	 */
	public void setCwsId(String cwsId) {
		this.cwsId = cwsId;
	}

	/**
	 * @return the affiliationDescription
	 */
	public String getAffiliationDescription() {
		return affiliationDescription;
	}

	/**
	 * @param affiliationDescription the affiliationDescription to set
	 */
	public void setAffiliationDescription(String affiliationDescription) {
		this.affiliationDescription = affiliationDescription;
	}

	/**
	 * @return the lastName
	 */
	public String getLastName() {
		return lastName;
	}

	/**
	 * @param lastName the lastName to set
	 */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	/**
	 * @return the organization
	 */
	public String getOrganization() {
		return organization;
	}

	/**
	 * @param organization the organization to set
	 */
	public void setOrganization(String organization) {
		this.organization = organization;
	}

	/**
	 * @return the middleName
	 */
	public String getMiddleName() {
		return middleName;
	}

	/**
	 * @param middleName the middleName to set
	 */
	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	/**
	 * @return the assignedFacilties
	 */
	public String getAssignedFacilties() {
		return assignedFacilties;
	}

	/**
	 * @param assignedFacilties the assignedFacilties to set
	 */
	public void setAssignedFacilties(String assignedFacilties) {
		this.assignedFacilties = assignedFacilties;
	}

	/**
	 * @return the firstName
	 */
	public String getFirstName() {
		return firstName;
	}

	/**
	 * @param firstName the firstName to set
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	
}
