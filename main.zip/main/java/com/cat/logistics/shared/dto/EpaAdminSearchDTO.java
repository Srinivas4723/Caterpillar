package com.cat.logistics.shared.dto;

/**
 * This class holds EPA admin search criteria 
 * @author ganamr
 *
 */
public class EpaAdminSearchDTO {

	private String cwsIdList;
	
	private String firstName;
	
	private String lastName;
	
	private String rolesList;
	
	private String facilitiesList;
	

	/**
	 * constructor of EpaAdminSearchDTO
	 */
	public EpaAdminSearchDTO() {
	}


	/**
	 * constructor of EpaAdminSearchDTO
	 * @param cwsIdList
	 * @param firstName
	 * @param lastName
	 * @param rolesList
	 * @param facilitiesList
	 */
	public EpaAdminSearchDTO(String cwsIdList, String firstName,
			String lastName, String rolesList, String facilitiesList) {
		this.cwsIdList = cwsIdList;
		this.firstName = firstName;
		this.lastName = lastName;
		this.rolesList = rolesList;
		this.facilitiesList = facilitiesList;
	}


	/**
	 *
	 * @return Returns the cwsIdList
	 */
	public String getCwsIdList() {
		return cwsIdList;
	}


	/**
	 *
	 * @param cwsIdList the cwsIdList to set
	 */
	public void setCwsIdList(String cwsIdList) {
		this.cwsIdList = cwsIdList;
	}


	/**
	 * @return Returns the firstName
	 */
	public String getFirstName() {
		return firstName;
	}


	/**
	 * @param firstName the firstName to set
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}


	/**
	 * @return Returns the lastName
	 */
	public String getLastName() {
		return lastName;
	}


	/**
	 *
	 * @param lastName the lastName to set
	 */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}


	/**
	 * @return Returns the rolesList
	 */
	public String getRolesList() {
		return rolesList;
	}


	/**
	 *
	 * @param rolesList the rolesList to set
	 */
	public void setRolesList(String rolesList) {
		this.rolesList = rolesList;
	}


	/**
	 * @return Returns the facilitiesList
	 */
	public String getFacilitiesList() {
		return facilitiesList;
	}


	/**
	 *
	 * @param facilitiesList the facilitiesList to set
	 */
	public void setFacilitiesList(String facilitiesList) {
		this.facilitiesList = facilitiesList;
	}
}
