package com.cat.logistics.shared.dto;

import java.io.Serializable;

/**
 * This class holds EPA Facility information
 * @author ganamr
 *
 */
public class EpaFacDTO implements Serializable{

	
	private static final long serialVersionUID = 1857406819952713584L;
	
	private String facCd;
	private String facilityName;
	
	/**
	 * @return facility code
	 */
	public String getFacCd() {
		return facCd;
	}
	/**
	 * @param facCd
	 */
	public void setFacCd(String facCd) {
		this.facCd = facCd;
	}
	/**
	 * @return facility name
	 */
	public String getFacilityName() {
		return facilityName;
	}
	/**
	 * @param facilityName
	 */
	public void setFacilityName(String facilityName) {
		this.facilityName = facilityName;
	}
}
