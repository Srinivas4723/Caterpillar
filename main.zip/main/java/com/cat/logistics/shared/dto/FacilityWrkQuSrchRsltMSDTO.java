package com.cat.logistics.shared.dto;

/**
 * This class holds the Facility workQ search result information for machine and shipment
 * @author ganamr
 *
 */
public class FacilityWrkQuSrchRsltMSDTO {
	private String epaFormStatus;
	private String statusColor;
	private String facCode;
	private String engImprtProvTypCode;
	private String mso;

	private String engineSerialNo;

	private String shipmentDate;

	private String machineSerialNo;
	private String machineBuildDate;
	
	private String engineImportType;
	private String machinePartNo;
	private String invoiceNo;
	private String engineBuildDate;
	private String machineModelNo;
	/**
	 * @return the epaFormStatus
	 */
	public String getEpaFormStatus() {
		return epaFormStatus;
	}
	/**
	 * @param epaFormStatus the epaFormStatus to set
	 */
	public void setEpaFormStatus(String epaFormStatus) {
		this.epaFormStatus = epaFormStatus;
	}
	/**
	 * @return the statusColor
	 */
	public String getStatusColor() {
		return statusColor;
	}
	/**
	 * @param statusColor the statusColor to set
	 */
	public void setStatusColor(String statusColor) {
		this.statusColor = statusColor;
	}
	/**
	 * @return the facCode
	 */
	public String getFacCode() {
		return facCode;
	}
	/**
	 * @param facCode the facCode to set
	 */
	public void setFacCode(String facCode) {
		this.facCode = facCode;
	}
	/**
	 * @return the engImprtProvTypCode
	 */
	public String getEngImprtProvTypCode() {
		return engImprtProvTypCode;
	}
	/**
	 * @param engImprtProvTypCode the engImprtProvTypCode to set
	 */
	public void setEngImprtProvTypCode(String engImprtProvTypCode) {
		this.engImprtProvTypCode = engImprtProvTypCode;
	}
	/**
	 * @return the mso
	 */
	public String getMso() {
		return mso;
	}
	/**
	 * @param mso the mso to set
	 */
	public void setMso(String mso) {
		this.mso = mso;
	}
	/**
	 * @return the engineSerialNo
	 */
	public String getEngineSerialNo() {
		return engineSerialNo;
	}
	/**
	 * @param engineSerialNo the engineSerialNo to set
	 */
	public void setEngineSerialNo(String engineSerialNo) {
		this.engineSerialNo = engineSerialNo;
	}
	/**
	 * @return the shipmentDate
	 */
	public String getShipmentDate() {
		return shipmentDate;
	}
	/**
	 * @param shipmentDate the shipmentDate to set
	 */
	public void setShipmentDate(String shipmentDate) {
		this.shipmentDate = shipmentDate;
	}
	/**
	 * @return the machineSerialNo
	 */
	public String getMachineSerialNo() {
		return machineSerialNo;
	}
	/**
	 * @param machineSerialNo the machineSerialNo to set
	 */
	public void setMachineSerialNo(String machineSerialNo) {
		this.machineSerialNo = machineSerialNo;
	}
	/**
	 * @return the machineBuildDate
	 */
	public String getMachineBuildDate() {
		return machineBuildDate;
	}
	/**
	 * @param machineBuildDate the machineBuildDate to set
	 */
	public void setMachineBuildDate(String machineBuildDate) {
		this.machineBuildDate = machineBuildDate;
	}
	/**
	 * @return the engineImportType
	 */
	public String getEngineImportType() {
		return engineImportType;
	}
	/**
	 * @param engineImportType the engineImportType to set
	 */
	public void setEngineImportType(String engineImportType) {
		this.engineImportType = engineImportType;
	}
	/**
	 * @return the machinePartNo
	 */
	public String getMachinePartNo() {
		return machinePartNo;
	}
	/**
	 * @param machinePartNo the machinePartNo to set
	 */
	public void setMachinePartNo(String machinePartNo) {
		this.machinePartNo = machinePartNo;
	}
	/**
	 * @return the invoiceNo
	 */
	public String getInvoiceNo() {
		return invoiceNo;
	}
	/**
	 * @param invoiceNo the invoiceNo to set
	 */
	public void setInvoiceNo(String invoiceNo) {
		this.invoiceNo = invoiceNo;
	}
	/**
	 * @return the engineBuildDate
	 */
	public String getEngineBuildDate() {
		return engineBuildDate;
	}
	/**
	 * @param engineBuildDate the engineBuildDate to set
	 */
	public void setEngineBuildDate(String engineBuildDate) {
		this.engineBuildDate = engineBuildDate;
	}
	/**
	 * @return the machineModelNo
	 */
	public String getMachineModelNo() {
		return machineModelNo;
	}
	/**
	 * @param machineModelNo the machineModelNo to set
	 */
	public void setMachineModelNo(String machineModelNo) {
		this.machineModelNo = machineModelNo;
	}
	
	
}
