package com.cat.logistics.shared.dto;

import java.io.Serializable;

import com.cat.logistics.shared.utils.ServiceConstants;

/**
 * This class holds the Facility workQ search criteria information for engine and shipment
 * @author ganamr
 *
 */
public class FacilityWorkQueueDTO implements Serializable{
	
	private static final long serialVersionUID = 664894628749732893L;
	/**
	 * Property for Epa Status Code Description
	 */
	private String epaStatusCdDesc;
	/**
	 * Property for Facility Code Description
	 */
	private String facilityCdDescs;
	
	/**
	 * Property for Invoice Number
	 */
	private String invoiceNo;
	
	/**
	 * Property for From Build Date
	 */
	private String fromBuildDate;
	/**
	 * Property for To Build Date
	 */
	/**
	 * Property for MSOS
	 */
	private String msos;
	
	/**
	 * Property for To Ship Date
	 */
	private String toShippedDate;
	/**
	 * Property for fromShipdate
	 */
	private String fromShippedDate;
	
	
	private String toBuildDate;
	
	
	/**
	 * Property for Engine Serial Number
	 */
	private String engineSerialNo = ServiceConstants.EMPTY;
	/**
	 * Property for Machine Serial Number
	 */
	private String machineSerialNo = ServiceConstants.EMPTY;
	/**
	 * Property for Machine Part Number
	 */
	/**
	 * Property for Return From JSP
	 */
	private String retFrmJsp;
	private String machinePartNo;
	/**
	 * Property for Machine Model Number
	 */
	private String machineModelNo;
	
	/**
	 * Property for No Records Found
	 */
	private String noDataForSearch;

	/**
	 * Property for Shipment date
	 */
	private String shipmentDate;
	/**
	 * Property for Machine Build Date
	 */
	private String machineBuildDate;
	/**
	 * Property for Engine Build Date
	 */
	private String engineBuildDate;
	/**
	 * Property for Engine Import Type Code
	 */
	private String engineImportType;
	/**
	 * Property for Engine Import Type Provision Code
	 */
	private String engImprtProvTypCode;
	/**
	 * Property for ESO
	 */
	private String eso;
	/**
	 * Property for Engine Part No
	 */
	private String engineARPartNo;
	/**
	 * Property for Model No
	 */
	private String modelNo;
	/**
	 * Property for Sequence No
	 */
	private Long seqNo;
	/**
	 * Property for Status Color
	 */
	private String statusColor;
	/**
	 * Property for lastUpdtLogonId
	 */
	private String lastUpdtLogonId;
	/**
	 * Property for epaFormStatus
	 */
	private String epaFormStatus;
	/**
	 * Property for xmptFrmBond
	 */
	private String xmptFrmBond;
	
	/**
	 * Property for mfrDateSource
	 */
	private String mfrDateSource;
	
	/**
	 * Property for engMfrName
	 */
	private String engMfrName;
	
	/**
	 * Property for certIndividualSign
	 */
	private String certIndividualSign;
	
	/**
	 * Property for certDate
	 */
	private String certDate;
	
	/**
	 * Property for exemptNum
	 */
	private String exemptNum;
	
	/**
	 * Property for salesModel
	 */
	private String salesModel;
	
	/**
	 * Property for exemptNum
	 */
	private String dlrOrderNo;
	
	/**
	 * Property for engPowerMeasrmt
	 */

	private String engPowerMeasrmt;
	
	/**
	 * Property for mchMfrName
	 */
	private String mchMfrName;
	
	/**
	 * Property for mchTypeDesc
	 */
	private String mchTypeDesc;
	
	/**
	 * Property for engFamilyname
	 */
	private String engFamilyname;
	
	/**
	 * Property for mfrDateType
	 */
	private String mfrDateType;
	
	/**
	 * Property for engMaxPower
	 */
	private String engMaxPower;
	
	/**
	 * Property for sortOrderNo
	 */
	private int sortOrderNo;
	
	
	/**
	 * Property for epaProdTypeCd
	 */
	private String prodTypeCd;
	
	private String buildDateType;
	
	private boolean frmHome;
	
	private String showDelConfrmn; 
	
	/**
	 * Property for epaCmnt
	 */
	private String epaCmnt;
	
	/**
	 * Property for frwdrRefNo
	 */
	private String frwdrRefNo;
	
	
	/**
	 * @return facility workQueue DTO
	 */ 
	public static FacilityWorkQueueDTO getInstance(){
		
		return new FacilityWorkQueueDTO();
	}
	

	/**
	 * @return the epaStatusCdDesc
	 */
	public String getEpaStatusCdDesc() {
		return epaStatusCdDesc;
	}

	/**
	 * @param epaStatusCdDesc the epaStatusCdDesc to set
	 */
	public void setEpaStatusCdDesc(String epaStatusCdDesc) {
		this.epaStatusCdDesc = epaStatusCdDesc;
	}
	
	

	/**
	 * @return the invoiceNo
	 */
	public String getInvoiceNo() {
		return invoiceNo;
	}

	/**
	 * @param facilityCdDescs the facilityCdDescs to set
	 */
	public void setFacilityCdDescs(String facilityCdDescs) {
		this.facilityCdDescs = facilityCdDescs;
	}




	/**
	 * @param invoiceNo the invoiceNo to set
	 */
	public void setInvoiceNo(String invoiceNo) {
		this.invoiceNo = invoiceNo;
	}

	/**
	 * @return the fromBuildDate
	 */
	public String getFromBuildDate() {
		return fromBuildDate;
	}

	/**
	 * @param fromBuildDate the fromBuildDate to set
	 */
	public void setFromBuildDate(String fromBuildDate) {
		this.fromBuildDate = fromBuildDate;
	}

	/**
	 * @return the msos
	 */
	public String getMsos() {
		return msos;
	}

	/**
	 * @param msos the msos to set
	 */
	public void setMsos(String msos) {
		this.msos = msos;
	}

	
	/**
	 * @return the facilityCdDescs
	 */
	public String getFacilityCdDescs() {
		return facilityCdDescs;
	}
	/**
	 * @return the toShippedDate
	 */
	public String getToShippedDate() {
		return toShippedDate;
	}

	/**
	 * @param toShippedDate the toShippedDate to set
	 */
	public void setToShippedDate(String toShippedDate) {
		this.toShippedDate = toShippedDate;
	}

	/**
	 * @return the fromShippedDate
	 */
	public String getFromShippedDate() {
		return fromShippedDate;
	}

	/**
	 * @param fromShippedDate the fromShippedDate to set
	 */
	public void setFromShippedDate(String fromShippedDate) {
		this.fromShippedDate = fromShippedDate;
	}

	/**
	 * @return the toBuildDate
	 */
	public String getToBuildDate() {
		return toBuildDate;
	}

	/**
	 * @param toBuildDate the toBuildDate to set
	 */
	public void setToBuildDate(String toBuildDate) {
		this.toBuildDate = toBuildDate;
	}

	/**
	 * @return the engineSerialNo
	 */
	public String getEngineSerialNo() {
		return engineSerialNo;
	}

	/**
	 * @param engineSerialNo the engineSerialNo to set
	 */
	public void setEngineSerialNo(String engineSerialNo) {
		this.engineSerialNo = engineSerialNo;
	}

	/**
	 * @return the machineSerialNo
	 */
	public String getMachineSerialNo() {
		return machineSerialNo;
	}

	/**
	 * @param machineSerialNo the machineSerialNo to set
	 */
	public void setMachineSerialNo(String machineSerialNo) {
		this.machineSerialNo = machineSerialNo;
	}

	/**
	 * @return the retFrmJsp
	 */
	public String getRetFrmJsp() {
		return retFrmJsp;
	}

	/**
	 * @param retFrmJsp the retFrmJsp to set
	 */
	public void setRetFrmJsp(String retFrmJsp) {
		this.retFrmJsp = retFrmJsp;
	}

	/**
	 * @return the machinePartNo
	 */
	public String getMachinePartNo() {
		return machinePartNo;
	}

	/**
	 * @param machinePartNo the machinePartNo to set
	 */
	public void setMachinePartNo(String machinePartNo) {
		this.machinePartNo = machinePartNo;
	}

	/**
	 * @return the machineModelNo
	 */
	public String getMachineModelNo() {
		return machineModelNo;
	}

	/**
	 * @param machineModelNo the machineModelNo to set
	 */
	public void setMachineModelNo(String machineModelNo) {
		this.machineModelNo = machineModelNo;
	}

	/**
	 * @return the noDataForSearch
	 */
	public String getNoDataForSearch() {
		return noDataForSearch;
	}

	/**
	 * @param noDataForSearch the noDataForSearch to set
	 */
	public void setNoDataForSearch(String noDataForSearch) {
		this.noDataForSearch = noDataForSearch;
	}

	/**
	 * @return the shipmentDate
	 */
	public String getShipmentDate() {
		return shipmentDate;
	}

	/**
	 * @param shipmentDate the shipmentDate to set
	 */
	public void setShipmentDate(String shipmentDate) {
		this.shipmentDate = shipmentDate;
	}

	/**
	 * @return the machineBuildDate
	 */
	public String getMachineBuildDate() {
		return machineBuildDate;
	}

	/**
	 * @param machineBuildDate the machineBuildDate to set
	 */
	public void setMachineBuildDate(String machineBuildDate) {
		this.machineBuildDate = machineBuildDate;
	}

	/**
	 * @return the engineBuildDate
	 */
	public String getEngineBuildDate() {
		return engineBuildDate;
	}

	/**
	 * @param engineBuildDate the engineBuildDate to set
	 */
	public void setEngineBuildDate(String engineBuildDate) {
		this.engineBuildDate = engineBuildDate;
	}

	/**
	 * @return the engineImportType
	 */
	public String getEngineImportType() {
		return engineImportType;
	}

	/**
	 * @param engineImportType the engineImportType to set
	 */
	public void setEngineImportType(String engineImportType) {
		this.engineImportType = engineImportType;
	}

	/**
	 * @return the engImprtProvTypCode
	 */
	public String getEngImprtProvTypCode() {
		return engImprtProvTypCode;
	}

	/**
	 * @param engImprtProvTypCode the engImprtProvTypCode to set
	 */
	public void setEngImprtProvTypCode(String engImprtProvTypCode) {
		this.engImprtProvTypCode = engImprtProvTypCode;
	}

	/**
	 * @return the eso
	 */
	public String getEso() {
		return eso;
	}

	/**
	 * @param eso the eso to set
	 */
	public void setEso(String eso) {
		this.eso = eso;
	}

	/**
	 * @return the engineARPartNo
	 */
	public String getEngineARPartNo() {
		return engineARPartNo;
	}

	/**
	 * @param engineARPartNo the engineARPartNo to set
	 */
	public void setEngineARPartNo(String engineARPartNo) {
		this.engineARPartNo = engineARPartNo;
	}

	/**
	 * @return the modelNo
	 */
	public String getModelNo() {
		return modelNo;
	}

	/**
	 * @param modelNo the modelNo to set
	 */
	public void setModelNo(String modelNo) {
		this.modelNo = modelNo;
	}

	/**
	 * @return the seqNo
	 */
	public Long getSeqNo() {
		return seqNo;
	}

	/**
	 * @param seqNo the seqNo to set
	 */
	public void setSeqNo(Long seqNo) {
		this.seqNo = seqNo;
	}

	/**
	 * @return the statusColor
	 */
	public String getStatusColor() {
		return statusColor;
	}

	/**
	 * @param statusColor the statusColor to set
	 */
	public void setStatusColor(String statusColor) {
		this.statusColor = statusColor;
	}

	/**
	 * @return the lastUpdtLogonId
	 */
	public String getLastUpdtLogonId() {
		return lastUpdtLogonId;
	}

	/**
	 * @param lastUpdtLogonId the lastUpdtLogonId to set
	 */
	public void setLastUpdtLogonId(String lastUpdtLogonId) {
		this.lastUpdtLogonId = lastUpdtLogonId;
	}

	/**
	 * @return the epaFormStatus
	 */
	public String getEpaFormStatus() {
		return epaFormStatus;
	}

	/**
	 * @param epaFormStatus the epaFormStatus to set
	 */
	public void setEpaFormStatus(String epaFormStatus) {
		this.epaFormStatus = epaFormStatus;
	}

	/**
	 * @return the xmptFrmBond
	 */
	public String getXmptFrmBond() {
		return xmptFrmBond;
	}

	/**
	 * @param xmptFrmBond the xmptFrmBond to set
	 */
	public void setXmptFrmBond(String xmptFrmBond) {
		this.xmptFrmBond = xmptFrmBond;
	}

	/**
	 * @return the mfrDateSource
	 */
	public String getMfrDateSource() {
		return mfrDateSource;
	}

	/**
	 * @param mfrDateSource the mfrDateSource to set
	 */
	public void setMfrDateSource(String mfrDateSource) {
		this.mfrDateSource = mfrDateSource;
	}

	/**
	 * @return the engMfrName
	 */
	public String getEngMfrName() {
		return engMfrName;
	}

	/**
	 * @param engMfrName the engMfrName to set
	 */
	public void setEngMfrName(String engMfrName) {
		this.engMfrName = engMfrName;
	}

	/**
	 * @return the certIndividualSign
	 */
	public String getCertIndividualSign() {
		return certIndividualSign;
	}

	/**
	 * @param certIndividualSign the certIndividualSign to set
	 */
	public void setCertIndividualSign(String certIndividualSign) {
		this.certIndividualSign = certIndividualSign;
	}

	/**
	 * @return the certDate
	 */
	public String getCertDate() {
		return certDate;
	}

	/**
	 * @param certDate the certDate to set
	 */
	public void setCertDate(String certDate) {
		this.certDate = certDate;
	}

	/**
	 * @return the exemptNum
	 */
	public String getExemptNum() {
		return exemptNum;
	}

	/**
	 * @param exemptNum the exemptNum to set
	 */
	public void setExemptNum(String exemptNum) {
		this.exemptNum = exemptNum;
	}

	/**
	 * @return the salesModel
	 */
	public String getSalesModel() {
		return salesModel;
	}

	/**
	 * @param salesModel the salesModel to set
	 */
	public void setSalesModel(String salesModel) {
		this.salesModel = salesModel;
	}

	/**
	 * @return the dlrOrderNo
	 */
	public String getDlrOrderNo() {
		return dlrOrderNo;
	}

	/**
	 * @param dlrOrderNo the dlrOrderNo to set
	 */
	public void setDlrOrderNo(String dlrOrderNo) {
		this.dlrOrderNo = dlrOrderNo;
	}

	/**
	 * @return the engPowerMeasrmt
	 */
	public String getEngPowerMeasrmt() {
		return engPowerMeasrmt;
	}

	/**
	 * @param engPowerMeasrmt the engPowerMeasrmt to set
	 */
	public void setEngPowerMeasrmt(String engPowerMeasrmt) {
		this.engPowerMeasrmt = engPowerMeasrmt;
	}

	/**
	 * @return the mchMfrName
	 */
	public String getMchMfrName() {
		return mchMfrName;
	}

	/**
	 * @param mchMfrName the mchMfrName to set
	 */
	public void setMchMfrName(String mchMfrName) {
		this.mchMfrName = mchMfrName;
	}

	/**
	 * @return the mchTypeDesc
	 */
	public String getMchTypeDesc() {
		return mchTypeDesc;
	}

	/**
	 * @param mchTypeDesc the mchTypeDesc to set
	 */
	public void setMchTypeDesc(String mchTypeDesc) {
		this.mchTypeDesc = mchTypeDesc;
	}

	/**
	 * @return the engFamilyname
	 */
	public String getEngFamilyname() {
		return engFamilyname;
	}

	/**
	 * @param engFamilyname the engFamilyname to set
	 */
	public void setEngFamilyname(String engFamilyname) {
		this.engFamilyname = engFamilyname;
	}

	/**
	 * @return the mfrDateType
	 */
	public String getMfrDateType() {
		return mfrDateType;
	}

	/**
	 * @param mfrDateType the mfrDateType to set
	 */
	public void setMfrDateType(String mfrDateType) {
		this.mfrDateType = mfrDateType;
	}

	/**
	 * @return the engMaxPower
	 */
	public String getEngMaxPower() {
		return engMaxPower;
	}

	/**
	 * @param engMaxPower the engMaxPower to set
	 */
	public void setEngMaxPower(String engMaxPower) {
		this.engMaxPower = engMaxPower;
	}

	/**
	 * @return the sortOrderNo
	 */
	public int getSortOrderNo() {
		return sortOrderNo;
	}

	/**
	 * @param sortOrderNo the sortOrderNo to set
	 */
	public void setSortOrderNo(int sortOrderNo) {
		this.sortOrderNo = sortOrderNo;
	}

	/**
	 * @return the prodTypeCd
	 */
	public String getProdTypeCd() {
		return prodTypeCd;
	}

	/**
	 * @param prodTypeCd the prodTypeCd to set
	 */
	public void setProdTypeCd(String prodTypeCd) {
		this.prodTypeCd = prodTypeCd;
	}

	/**
	 * @return the buildDateType
	 */
	public String getBuildDateType() {
		return buildDateType;
	}

	/**
	 * @param buildDateType the buildDateType to set
	 */
	public void setBuildDateType(String buildDateType) {
		this.buildDateType = buildDateType;
	}

	/**
	 * @param facDesc
	 * @return true or false
	 */
	public boolean isFacPresent(String facDesc){
		if(facilityCdDescs.trim().equals(facDesc)){
			return true;
		}
		return false;
	}


	/**
	 * @return true or false
	 */
	public boolean isFrmHome() {
		return frmHome;
	}


	/**
	 * @param frmHome
	 */
	public void setFrmHome(boolean frmHome) {
		this.frmHome = frmHome;
	}
	

	
	private String enableApprove = ServiceConstants.EMPTY;
	/**
	 * Used to make the check box visible for each Facility work queue DTO Result in engine and machine screen.
	 * @return the enableApprove
	 */
	public String getEnableApprove() {
		return enableApprove;
	}

	/**
	 * Used to make the check box visible for each Facility work queue DTO Result in engine and machine screen. 
	 * @param enableApprove the enableApprove to set
	 */
	public void setEnableApprove(String enableApprove) {
		this.enableApprove = enableApprove;
	}
	
	private String enableApproveAndAssign=ServiceConstants.EMPTY;
	/**
	 * Used to enable the Disclaimer option Popup Div, once all the All approve Button validations successful.
	 * @return the enableApproveAndAssign
	 */
	public String getEnableApproveAndAssign() {
		return enableApproveAndAssign;
	}

	/**
	 * Used to enable the Disclaimer option Popup Div, once all the All approve Button validations successful.
	 * @param enableApproveAndAssign the enableApproveAndAssign to set
	 */
	public void setEnableApproveAndAssign(String enableApproveAndAssign) {
		this.enableApproveAndAssign = enableApproveAndAssign;
	}
	
	private String selectedSeqList = ServiceConstants.EMPTY;
	/**
	 * @return the selectedSeqList
	 */
	public String getSelectedSeqList() {
		return selectedSeqList;
	}

	/**
	 * @param selectedSeqList the selectedSeqList to set
	 */
	public void setSelectedSeqList(String selectedSeqList) {
		this.selectedSeqList = selectedSeqList;
	}


	/**
	 * @return the showDelConfrmn
	 */
	public String getShowDelConfrmn() {
		return showDelConfrmn;
	}


	/**
	 * @param showDelConfrmn the showDelConfrmn to set
	 */
	public void setShowDelConfrmn(String showDelConfrmn) {
		this.showDelConfrmn = showDelConfrmn;
	}


	/**
	 * 
	 * @return epaCmnt epa comment
	 */
	public String getEpaCmnt() {
		return epaCmnt;
	}


	/**
	 * set the EPA_CMNT 
	 * @param epaCmnt epa comment
	 */
	public void setEpaCmnt(String epaCmnt) {
		this.epaCmnt = epaCmnt;
	}


	/**
	 * @return the frwdrRefNo
	 */
	public String getFrwdrRefNo() {
		return frwdrRefNo;
	}


	/**
	 * @param frwdrRefNo the frwdrRefNo to set
	 */
	public void setFrwdrRefNo(String frwdrRefNo) {
		this.frwdrRefNo = frwdrRefNo;
	}

}
