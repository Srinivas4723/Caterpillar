package com.cat.logistics.shared.dto;

import java.io.Serializable;
import java.util.Date;

/**
 * This class holds EPA State of issue list information
 * @author ganamr
 *
 */
public class EpaStatesDTO implements Serializable{

	private static final long serialVersionUID = -525384878644600426L;

	private String epaCountrtCode;
	private String epaStateCode;
	private String epaStateName;
	private String crteLogonId;
	private Date creteTs;
	private String lastUpdtLogonId;
	private Date lastUpdtTs;
	/**
	 * @return the epaCountrtCode
	 */
	public String getEpaCountrtCode() {
		return epaCountrtCode;
	}
	/**
	 * @param epaCountrtCode
	 */
	public void setEpaCountrtCode(String epaCountrtCode) {
		this.epaCountrtCode = epaCountrtCode;
	}
	/**
	 * @return the EPA state code
	 */
	public String getEpaStateCode() {
		return epaStateCode;
	}
	/**
	 * @param epaStateCode
	 */
	public void setEpaStateCode(String epaStateCode) {
		this.epaStateCode = epaStateCode;
	}
	/**
	 * @return EPA State name
	 */
	public String getEpaStateName() {
		return epaStateName;
	}
	/**
	 * @param epaStateName
	 */
	public void setEpaStateName(String epaStateName) {
		this.epaStateName = epaStateName;
	}
	/**
	 * @return get create Logon id
	 */
	public String getCrteLogonId() {
		return crteLogonId;
	}
	/**
	 * @param crteLogonId
	 */
	public void setCrteLogonId(String crteLogonId) {
		this.crteLogonId = crteLogonId;
	}
	/**
	 * @return create time stamp
	 */
	public Date getCreteTs() {
		return  creteTs == null ? null : new Date(creteTs.getTime()) ;
		//return  creteTs;
	}
	/**
	 * @param creteTs
	 */
	public void setCreteTs(Date creteTs) {
		this.creteTs =  creteTs == null ? null : new Date(creteTs.getTime()) ;
	}
	/**
	 * @return last update logon id
	 */
	public String getLastUpdtLogonId() {
		return lastUpdtLogonId;
	}
	/**
	 * @param lastUpdtLogonId
	 */
	public void setLastUpdtLogonId(String lastUpdtLogonId) {
		this.lastUpdtLogonId = lastUpdtLogonId;
	}
	/**
	 * @return the last updated time stamp
	 */
	public Date getLastUpdtTs() {
		return  lastUpdtTs == null ? null : new Date(lastUpdtTs.getTime()) ;
	}
	/**
	 * @param lastUpdtTs
	 */
	public void setLastUpdtTs(Date lastUpdtTs) {
		this.lastUpdtTs =  lastUpdtTs == null ? null : new Date(lastUpdtTs.getTime()) ;
	}
	
	
	
}
