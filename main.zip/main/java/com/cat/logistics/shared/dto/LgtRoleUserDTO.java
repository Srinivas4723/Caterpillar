package com.cat.logistics.shared.dto;

import java.io.Serializable;
import java.util.Set;

/**
 * DTO to manage user with their permissions associated 
 * 
 * @author sebastian.g.ducci
 *
 */
public class LgtRoleUserDTO implements Serializable{

	private static final long serialVersionUID = 5329872691223775396L;

	private String roleName;
	
	private Set<String> permissions;
	
	
	/**
	 * @param roleName
	 * @param permissions
	 */
	public LgtRoleUserDTO(String roleName, Set<String> permissions){
		this.roleName = roleName;
		this.permissions = permissions;
	}
	

	/**
	 * @return role Name
	 */
	public String getRoleName() {
		return roleName;
	}

	/**
	 * @param roleName
	 */
	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}

	/**
	 * @return the permissions
	 */
	public Set<String> getPermissions() {
		return permissions;
	}

	/**
	 * @param permissions
	 */
	public void setPermissions(Set<String> permissions) {
		this.permissions = permissions;
	}

	/**
	 * 
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((permissions == null) ? 0 : permissions.hashCode());
		result = prime * result
				+ ((roleName == null) ? 0 : roleName.hashCode());
		return result;
	}

	
	
}
