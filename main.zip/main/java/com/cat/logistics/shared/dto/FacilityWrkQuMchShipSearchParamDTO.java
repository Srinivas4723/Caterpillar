package com.cat.logistics.shared.dto;

/**
 * This class holds the Facility workQ search criteria information for Machine and shipment
 * @author ganamr
 *
 */
public class FacilityWrkQuMchShipSearchParamDTO {
	private String facilityCdDescs;
	private String epaStatusCdDesc;
	private String invoiceNo;
	private String noDataForSearch;
	private String msos;
	private String shipmentDate;
	
	private String engineBuildDate;
	
	
	private String toShippedDate;
	
	private String fromShippedDate;
	private String toBuildDate;
	private String fromBuildDate;
	
	private String machineSerialNo;
	private String machineBuildDate;
	
	private String engineSerialNo;
	private String engineImportType;
	private String machineModelNo;
	private String engImprtProvTypCode;
	private String retFrmJsp;
	private String machinePartNo;
	/**
	 * @return the facilityCdDescs
	 */
	public String getFacilityCdDescs() {
		return facilityCdDescs;
	}
	/**
	 * @param facilityCdDescs the facilityCdDescs to set
	 */
	public void setFacilityCdDescs(String facilityCdDescs) {
		this.facilityCdDescs = facilityCdDescs;
	}
	/**
	 * @return the epaStatusCdDesc
	 */
	public String getEpaStatusCdDesc() {
		return epaStatusCdDesc;
	}
	/**
	 * @param epaStatusCdDesc the epaStatusCdDesc to set
	 */
	public void setEpaStatusCdDesc(String epaStatusCdDesc) {
		this.epaStatusCdDesc = epaStatusCdDesc;
	}
	/**
	 * @return the invoiceNo
	 */
	public String getInvoiceNo() {
		return invoiceNo;
	}
	/**
	 * @param invoiceNo the invoiceNo to set
	 */
	public void setInvoiceNo(String invoiceNo) {
		this.invoiceNo = invoiceNo;
	}
	/**
	 * @return the noDataForSearch
	 */
	public String getNoDataForSearch() {
		return noDataForSearch;
	}
	/**
	 * @param noDataForSearch the noDataForSearch to set
	 */
	public void setNoDataForSearch(String noDataForSearch) {
		this.noDataForSearch = noDataForSearch;
	}
	/**
	 * @return the msos
	 */
	public String getMsos() {
		return msos;
	}
	/**
	 * @param msos the msos to set
	 */
	public void setMsos(String msos) {
		this.msos = msos;
	}
	/**
	 * @return the shipmentDate
	 */
	public String getShipmentDate() {
		return shipmentDate;
	}
	/**
	 * @param shipmentDate the shipmentDate to set
	 */
	public void setShipmentDate(String shipmentDate) {
		this.shipmentDate = shipmentDate;
	}
	/**
	 * @return the engineBuildDate
	 */
	public String getEngineBuildDate() {
		return engineBuildDate;
	}
	/**
	 * @param engineBuildDate the engineBuildDate to set
	 */
	public void setEngineBuildDate(String engineBuildDate) {
		this.engineBuildDate = engineBuildDate;
	}
	/**
	 * @param toShippedDate the toShippedDate to set
	 */
	public void setToShippedDate(String toShippedDate) {
		this.toShippedDate = toShippedDate;
	}
	/**
	 * @return the toShippedDate
	 */
	public String getToShippedDate() {
		return toShippedDate;
	}
	/**
	 * @param fromShippedDate the fromShippedDate to set
	 */
	public void setFromShippedDate(String fromShippedDate) {
		this.fromShippedDate = fromShippedDate;
	}
	/**
	 * @return the fromShippedDate
	 */
	public String getFromShippedDate() {
		return fromShippedDate;
	}
	/**
	 * @param toBuildDate the toBuildDate to set
	 */
	public void setToBuildDate(String toBuildDate) {
		this.toBuildDate = toBuildDate;
	}
	/**
	 * @return the toBuildDate
	 */
	public String getToBuildDate() {
		return toBuildDate;
	}
	/**
	 * @param fromBuildDate the fromBuildDate to set
	 */
	public void setFromBuildDate(String fromBuildDate) {
		this.fromBuildDate = fromBuildDate;
	}
	/**
	 * @return the fromBuildDate
	 */
	public String getFromBuildDate() {
		return fromBuildDate;
	}
	
	/**
	 * @return the machineSerialNo
	 */
	public String getMachineSerialNo() {
		return machineSerialNo;
	}
	/**
	 * @param machineSerialNo the machineSerialNo to set
	 */
	public void setMachineSerialNo(String machineSerialNo) {
		this.machineSerialNo = machineSerialNo;
	}
	/**
	 * @return the machineBuildDate
	 */
	public String getMachineBuildDate() {
		return machineBuildDate;
	}
	/**
	 * @param machineBuildDate the machineBuildDate to set
	 */
	public void setMachineBuildDate(String machineBuildDate) {
		this.machineBuildDate = machineBuildDate;
	}
	/**
	 * @return the engineSerialNo
	 */
	public String getEngineSerialNo() {
		return engineSerialNo;
	}
	/**
	 * @param engineSerialNo the engineSerialNo to set
	 */
	public void setEngineSerialNo(String engineSerialNo) {
		this.engineSerialNo = engineSerialNo;
	}
	/**
	 * @return the engineImportType
	 */
	public String getEngineImportType() {
		return engineImportType;
	}
	/**
	 * @param engineImportType the engineImportType to set
	 */
	public void setEngineImportType(String engineImportType) {
		this.engineImportType = engineImportType;
	}
	/**
	 * @return the machineModelNo
	 */
	public String getMachineModelNo() {
		return machineModelNo;
	}
	/**
	 * @param machineModelNo the machineModelNo to set
	 */
	public void setMachineModelNo(String machineModelNo) {
		this.machineModelNo = machineModelNo;
	}
	/**
	 * @return the engImprtProvTypCode
	 */
	public String getEngImprtProvTypCode() {
		return engImprtProvTypCode;
	}
	/**
	 * @param engImprtProvTypCode the engImprtProvTypCode to set
	 */
	public void setEngImprtProvTypCode(String engImprtProvTypCode) {
		this.engImprtProvTypCode = engImprtProvTypCode;
	}
	/**
	 * @return the retFrmJsp
	 */
	public String getRetFrmJsp() {
		return retFrmJsp;
	}
	/**
	 * @param retFrmJsp the retFrmJsp to set
	 */
	public void setRetFrmJsp(String retFrmJsp) {
		this.retFrmJsp = retFrmJsp;
	}
	/**
	 * @return the machinePartNo
	 */
	public String getMachinePartNo() {
		return machinePartNo;
	}
	/**
	 * @param machinePartNo the machinePartNo to set
	 */
	public void setMachinePartNo(String machinePartNo) {
		this.machinePartNo = machinePartNo;
	}

	
	
	
}
