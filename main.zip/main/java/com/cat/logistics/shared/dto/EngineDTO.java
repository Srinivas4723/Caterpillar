package com.cat.logistics.shared.dto;

import java.util.Date;

import com.cat.logistics.epa.dto.FieldName;
import com.cat.logistics.epa.dto.StatusField;
import com.cat.logistics.shared.utils.ServiceConstants;


/**
 * This class holds Engine related information
 * @author ganamr
 *
 */
public class EngineDTO extends ShipmentDTO{

	private static final long serialVersionUID = -2323899073794978981L;
	
	@FieldName(name="ENG_SER_NO")
	@StatusField
	private String engineSerialNumber;
	@FieldName(name="ENG_MFR")
	@StatusField
	private String engineManfacturer;
	@FieldName(name="ENG_MDL")
	@StatusField
	private String engineModelNumber;
	@FieldName(name="ENG_BLD_MON")
	@StatusField
	private Date engineBuildDate;
	
	private String engBuildDate;

	private String buildDataSource;
	@FieldName(name="EPA_IMP_TYPE")
	@StatusField
	private String engineImportTypeCode;
	
	//@FieldName(name="EPA_IMP_PROV")
	private String engineProvisionTypeCode;
	@FieldName(name="EPA_IMP_PROV_ENG")
	@StatusField
	private String engImpProv;
	@FieldName(name="EPA_IMP_PROV_EQU")
	@StatusField
	private String engProvEqu;
	private String naicForBondIssuer;
	private String policyNumber;
	private String stateOfIssue;
	private String explBuildDataSrcOthr;
	private String locationOfStorage;
	private String otherExemption;
	@FieldName(name="EPA_FAMILY")
	private String engineFamilyName;
	@FieldName(name="ENG_EXEMPT_NO")
	private String epaExemptionApprNo;
	@FieldName(name="EPA_MAX_PWR")
	private String engineMaxPower;
	@FieldName(name="EPA_MAX_PWR_UOM")
	private String unitOfMeasure;
	private String buildDateType;
	private String statusCd;
	
	private String isExemptFromBond = ServiceConstants.YES;
	private String exemptFromBond;
	
	private String caseNumber;
	private String ccrNumber;
	private String adtlEngSerNum;
	
	private String isCoreReturnId;

	/**
	 * @return the value
	 */
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	private String formStatus;
	private String statusColor;
	private String action;
	private String operation;
	private Boolean isExemptBond;
	private String modelmsg;
	private String nohtscode;// not using has to remove -Rajashekhar
	private String showenginfo;
	private String impcdprovcdvalid;
	
	private String facErrMsg; // this can be removed once after CR1311 -Rajashekhar
	private String epaStatusCd;
	private String epaEngineMnfDate;
	private String xmptFrmBond;
	private String certIndividualSign;
	private String certDate;
	private String lastUpdtLogonId;
	private String errMessage;  // added part of CR 1311 
	private String errPopupMsg; // added part of CR 1311
	private String isUpdRedirct;
	private String isSkipValidtion;
	private String epaFrmStatusDes;
	private String redirectPage;
	private String oldEngSerilNum;
	/**
	 * Property for fromShipdate
	 */
	private String fromShippedDate;
	/**
	 * Property for To Ship Date
	 */
	private String toShippedDate;
	/**
	 * Property for From Build Date
	 */
	private String fromBuildDate;
	/**
	 * Property for To Build Date
	 */
	private String toBuildDate;
	/**
	 * Property for Facility Code Description
	 */
	private String facilityCdDescs;
	/**
	 * Property for Epa Status Code Description
	 */
	private String epaStatusCdDesc;
	/**
	 * Property for ESO
	 */
	private String eso;
	/**
	 * Property for Engine Serial Number
	 */
	private String engineSerialNo;
	/**
	 * Property for Invoice Number
	 */
	private String invoiceNo;
	
	
	private boolean redirect;
	
	
	/**
	 * @param engineSerialNumber
	 */
	public EngineDTO(String engineSerialNumber) {
		super();
		this.engineSerialNumber = engineSerialNumber;
	}
	
	
	/**
	 * EngineDTO
	 */
	public EngineDTO() {
		super();
	}
	/**
	 * @return the engineSerialNumber
	 */
	public String getEngineSerialNumber() {
		return engineSerialNumber;
	}
	/**
	 * @param engineSerialNumber the engineSerialNumber to set
	 */
	public void setEngineSerialNumber(String engineSerialNumber) {
		this.engineSerialNumber = engineSerialNumber;
	}
	/**
	 * @return the engineManfacturer
	 */
	public String getEngineManfacturer() {
		return engineManfacturer;
	}
	/**
	 * @param engineManfacturer the engineManfacturer to set
	 */
	public void setEngineManfacturer(String engineManfacturer) {
		this.engineManfacturer = engineManfacturer;
	}
	/**
	 * @return the engineModelNumber
	 */
	public String getEngineModelNumber() {
		return engineModelNumber;
	}
	/**
	 * @param engineModelNumber the engineModelNumber to set
	 */
	public void setEngineModelNumber(String engineModelNumber) {
		this.engineModelNumber = engineModelNumber;
	}

	/**
	 * @return the buildDataSource
	 */
	public String getBuildDataSource() {
		return buildDataSource;
	}
	/**
	 * @param buildDataSource the buildDataSource to set
	 */
	public void setBuildDataSource(String buildDataSource) {
		this.buildDataSource = buildDataSource;
	}


	/**
	 * @return the engineImportTypeCode
	 */
	public String getEngineImportTypeCode() {
		return engineImportTypeCode;
	}
	/**
	 * @param engineImportTypeCode the engineImportTypeCode to set
	 */
	public void setEngineImportTypeCode(String engineImportTypeCode) {
		this.engineImportTypeCode = engineImportTypeCode;
	}
	/**
	 * @return the engineProvisionTypeCode
	 */
	public String getEngineProvisionTypeCode() {
		return engineProvisionTypeCode;
	}
	/**
	 * @param engineProvisionTypeCode the engineProvisionTypeCode to set
	 */
	public void setEngineProvisionTypeCode(String engineProvisionTypeCode) {
		this.engineProvisionTypeCode = engineProvisionTypeCode;
	}
	/**
	 * @return the naicForBondIssuer
	 */
	public String getNaicForBondIssuer() {
		return naicForBondIssuer;
	}
	/**
	 * @param naicForBondIssuer the naicForBondIssuer to set
	 */
	public void setNaicForBondIssuer(String naicForBondIssuer) {
		this.naicForBondIssuer = naicForBondIssuer;
	}
	/**
	 * @return the policyNumber
	 */
	public String getPolicyNumber() {
		return policyNumber;
	}
	/**
	 * @param policyNumber the policyNumber to set
	 */
	public void setPolicyNumber(String policyNumber) {
		this.policyNumber = policyNumber;
	}
	/**
	 * @return the stateOfIssue
	 */
	public String getStateOfIssue() {
		return stateOfIssue;
	}
	/**
	 * @return the locationOfStorage
	 */
	public String getLocationOfStorage() {
		return locationOfStorage;
	}
	/**
	 * @param locationOfStorage the locationOfStorage to set
	 */
	public void setLocationOfStorage(String locationOfStorage) {
		this.locationOfStorage = locationOfStorage;
	}
	/**
	 * @return the otherExemption
	 */
	public String getOtherExemption() {
		return otherExemption;
	}
	/**
	 * @param otherExemption the otherExemption to set
	 */
	public void setOtherExemption(String otherExemption) {
		this.otherExemption = otherExemption;
	}
	/**
	 * @return the engineFamilyName
	 */
	public String getEngineFamilyName() {
		return engineFamilyName;
	}
	/**
	 * @param engineFamilyName the engineFamilyName to set
	 */
	public void setEngineFamilyName(String engineFamilyName) {
		this.engineFamilyName = engineFamilyName;
	}
	/**
	 * @return the epaExemptionApprNo
	 */
	public String getEpaExemptionApprNo() {
		return epaExemptionApprNo;
	}
	/**
	 * @param epaExemptionApprNo the epaExemptionApprNo to set
	 */
	public void setEpaExemptionApprNo(String epaExemptionApprNo) {
		this.epaExemptionApprNo = epaExemptionApprNo;
	}
	/**
	 * @return the engineMaxPower
	 */
	public String getEngineMaxPower() {
		return engineMaxPower;
	}
	/**
	 * @return true or false
	 */
	public boolean isRedirect() {
		return redirect;
	}


	/**
	 * @param redirect
	 */
	public void setRedirect(boolean redirect) {
		this.redirect = redirect;
	}


	/**
	 * @param engineMaxPower the engineMaxPower to set
	 */
	public void setEngineMaxPower(String engineMaxPower) {
		this.engineMaxPower = engineMaxPower;
	}



	/**
	 * @return the unitOfMeasure
	 */
	public String getUnitOfMeasure() {
		return unitOfMeasure;
	}
	/**
	 * @param unitOfMeasure the unitOfMeasure to set
	 */
	public void setUnitOfMeasure(String unitOfMeasure) {
		this.unitOfMeasure = unitOfMeasure;
	}

	/**
	 * @param stateOfIssue the stateOfIssue to set
	 */
	public void setStateOfIssue(String stateOfIssue) {
		this.stateOfIssue = stateOfIssue;
	}
	/**
	 * @return the action
	 */
	public String getAction() {
		return action;
	}
	/**
	 * @param action the action to set
	 */
	public void setAction(String action) {
		this.action = action;
	}
	/**
	 * @return the operation
	 */
	public String getOperation() {
		return operation;
	}
	/**
	 * @param operation the operation to set
	 */
	public void setOperation(String operation) {
		this.operation = operation;
	}
	/**
	 * @return the isExemptBond
	 */
	public Boolean getIsExemptBond() {
		return isExemptBond;
	}
	/**
	 * @param isExemptBond the isExemptBond to set
	 */
	public void setIsExemptBond(Boolean isExemptBond) {
		this.isExemptBond = isExemptBond;
	}
	
	/**
	 * @return the modelmsg
	 */
	public String getModelmsg() {
		return modelmsg;
	}
	/**
	 * @param modelmsg the modelmsg to set
	 */
	public void setModelmsg(String modelmsg) {
		this.modelmsg = modelmsg;
	}
	/**
	 * @return the nohtscode
	 */
	public String getNohtscode() {
		return nohtscode;
	}
	/**
	 * @param nohtscode the nohtscode to set
	 */
	public void setNohtscode(String nohtscode) {
		this.nohtscode = nohtscode;
	}
	/**
	 * @return the showenginfo
	 */
	public String getShowenginfo() {
		return showenginfo;
	}
	/**
	 * @param showenginfo the showenginfo to set
	 */
	public void setShowenginfo(String showenginfo) {
		this.showenginfo = showenginfo;
	}
	
	/**
	 * @return the impcdprovcdvalid
	 */
	public String getImpcdprovcdvalid() {
		return impcdprovcdvalid;
	}
	/**
	 * @param impcdprovcdvalid the impcdprovcdvalid to set
	 */
	public void setImpcdprovcdvalid(String impcdprovcdvalid) {
		this.impcdprovcdvalid = impcdprovcdvalid;
	}
	/**
	 * @return the formStatus
	 */
	public String getFormStatus() {
		return formStatus;
	}
	/**
	 * @param formStatus the formStatus to set
	 */
	public void setFormStatus(String formStatus) {
		this.formStatus = formStatus;
	}
	/**
	 * @return the engineBuildDate
	 */
	public Date getEngineBuildDate() {
		return  engineBuildDate == null ? null : new Date(engineBuildDate.getTime()) ;
		//return  engineBuildDate;
	}
	/**
	 * @param engineBuildDate the engineBuildDate to set
	 */
	public void setEngineBuildDate(Date engineBuildDate) {
		this.engineBuildDate =  engineBuildDate == null ? null : new Date(engineBuildDate.getTime()) ;
	}
	/**
	 * @return the explBuildDataSrcOthr
	 */
	public String getExplBuildDataSrcOthr() {
		return explBuildDataSrcOthr;
	}
	/**
	 * @param explBuildDataSrcOthr the explBuildDataSrcOthr to set
	 */
	public void setExplBuildDataSrcOthr(String explBuildDataSrcOthr) {
		this.explBuildDataSrcOthr = explBuildDataSrcOthr;
	}
	/**
	 * @return the statusColor
	 */
	public String getStatusColor() {
		return statusColor;
	}
	/**
	 * @param statusColor the statusColor to set
	 */
	public void setStatusColor(String statusColor) {
		this.statusColor = statusColor;
	}
	/**
	 * @return the buildDateType
	 */
	public String getBuildDateType() {
		return buildDateType;
	}
	/**
	 * @param buildDateType the buildDateType to set
	 */
	public void setBuildDateType(String buildDateType) {
		this.buildDateType = buildDateType;
	}
	/**
	 * @return the isExemptFromBond
	 */
	public String getIsExemptFromBond() {
		return isExemptFromBond;
	}
	/**
	 * @param isExemptFromBond the isExemptFromBond to set
	 */
	public void setIsExemptFromBond(String isExemptFromBond) {
		this.isExemptFromBond = isExemptFromBond;
	}
	
	/**
	 * @return the exemptFromBond
	 */
	public String getExemptFromBond() {
		return exemptFromBond;
	}

	/**
	 * @param exemptFromBond the exemptFromBond to set
	 */
	public void setExemptFromBond(String exemptFromBond) {
		this.exemptFromBond = exemptFromBond;
	}

	/**
	 * @return the facErrMsg
	 */
	public String getFacErrMsg() {
		return facErrMsg;
	}


	/**
	 * @param facErrMsg the facErrMsg to set
	 */
	public void setFacErrMsg(String facErrMsg) {
		this.facErrMsg = facErrMsg;
	}


	/**
	 * @return epaStatusCd
	 */
	public String getEpaStatusCd() {
		return epaStatusCd;
	}


	/**
	 * @param epaStatusCd
	 */
	public void setEpaStatusCd(String epaStatusCd) {
		this.epaStatusCd = epaStatusCd;
	}


	/**
	 * @return the epaEngineMnfDate
	 */
	public String getEpaEngineMnfDate() {
		return epaEngineMnfDate;
	}


	/**
	 * @param epaEngineMnfDate the epaEngineMnfDate to set
	 */
	public void setEpaEngineMnfDate(String epaEngineMnfDate) {
		this.epaEngineMnfDate = epaEngineMnfDate;
	}


	/**
	 * @return the xmptFrmBond
	 */
	public String getXmptFrmBond() {
		return xmptFrmBond;
	}


	/**
	 * @param xmptFrmBond the xmptFrmBond to set
	 */
	public void setXmptFrmBond(String xmptFrmBond) {
		this.xmptFrmBond = xmptFrmBond;
	}


	/**
	 * @return the certIndividualSign
	 */
	public String getCertIndividualSign() {
		return certIndividualSign;
	}


	/**
	 * @param certIndividualSign the certIndividualSign to set
	 */
	public void setCertIndividualSign(String certIndividualSign) {
		this.certIndividualSign = certIndividualSign;
	}


	/**
	 * @return the certDate
	 */
	public String getCertDate() {
		return certDate;
	}


	/**
	 * @param certDate the certDate to set
	 */
	public void setCertDate(String certDate) {
		this.certDate = certDate;
	}


	/**
	 * @return the lastUpdtLogonId
	 */
	public String getLastUpdtLogonId() {
		return lastUpdtLogonId;
	}


	/**
	 * @param lastUpdtLogonId the lastUpdtLogonId to set
	 */
	public void setLastUpdtLogonId(String lastUpdtLogonId) {
		this.lastUpdtLogonId = lastUpdtLogonId;
	}


	/**
	 * @return the fromShippedDate
	 */
	public String getFromShippedDate() {
		return fromShippedDate;
	}


	/**
	 * @param fromShippedDate the fromShippedDate to set
	 */
	public void setFromShippedDate(String fromShippedDate) {
		this.fromShippedDate = fromShippedDate;
	}


	/**
	 * @return the toShippedDate
	 */
	public String getToShippedDate() {
		return toShippedDate;
	}


	/**
	 * @param toShippedDate the toShippedDate to set
	 */
	public void setToShippedDate(String toShippedDate) {
		this.toShippedDate = toShippedDate;
	}


	/**
	 * @return the fromBuildDate
	 */
	public String getFromBuildDate() {
		return fromBuildDate;
	}


	/**
	 * @param fromBuildDate the fromBuildDate to set
	 */
	public void setFromBuildDate(String fromBuildDate) {
		this.fromBuildDate = fromBuildDate;
	}


	/**
	 * @return the toBuildDate
	 */
	public String getToBuildDate() {
		return toBuildDate;
	}


	/**
	 * @param toBuildDate the toBuildDate to set
	 */
	public void setToBuildDate(String toBuildDate) {
		this.toBuildDate = toBuildDate;
	}


	/**
	 * @return the facilityCdDescs
	 */
	public String getFacilityCdDescs() {
		return facilityCdDescs;
	}


	/**
	 * @param facilityCdDescs the facilityCdDescs to set
	 */
	public void setFacilityCdDescs(String facilityCdDescs) {
		this.facilityCdDescs = facilityCdDescs;
	}


	/**
	 * @return the epaStatusCdDesc
	 */
	public String getEpaStatusCdDesc() {
		return epaStatusCdDesc;
	}


	/**
	 * @param epaStatusCdDesc the epaStatusCdDesc to set
	 */
	public void setEpaStatusCdDesc(String epaStatusCdDesc) {
		this.epaStatusCdDesc = epaStatusCdDesc;
	}


	/**
	 * @return the eso
	 */
	public String getEso() {
		return eso;
	}


	/**
	 * @param eso the eso to set
	 */
	public void setEso(String eso) {
		this.eso = eso;
	}


	/**
	 * @return the engineSerialNo
	 */
	public String getEngineSerialNo() {
		return engineSerialNo;
	}


	/**
	 * @param engineSerialNo the engineSerialNo to set
	 */
	public void setEngineSerialNo(String engineSerialNo) {
		this.engineSerialNo = engineSerialNo;
	}


	/**
	 * @return the invoiceNo
	 */
	public String getInvoiceNo() {
		return invoiceNo;
	}


	/**
	 * @param invoiceNo the invoiceNo to set
	 */
	public void setInvoiceNo(String invoiceNo) {
		this.invoiceNo = invoiceNo;
	}


	/**
	 * @return eng impProv code
	 */
	public String getEngImpProv() {
		return engImpProv;
	}


	/**
	 * @param engImpProv
	 */
	public void setEngImpProv(String engImpProv) {
		this.engImpProv = engImpProv;
	}


	/**
	 * @return engine provCd
	 */
	public String getEngProvEqu() {
		return engProvEqu;
	}


	/**
	 * @param engProvEqu
	 */
	public void setEngProvEqu(String engProvEqu) {
		this.engProvEqu = engProvEqu;
	}


	/**
	 * @return the errMessage
	 */
	public String getErrMessage() {
		return errMessage;
	}


	/**
	 * @param errMessage the errMessage to set
	 */
	public void setErrMessage(String errMessage) {
		this.errMessage = errMessage;
	}


	/**
	 * @return the errPopupMsg
	 */
	public String getErrPopupMsg() {
		return errPopupMsg;
	}


	/**
	 * @param errPopupMsg the errPopupMsg to set
	 */
	public void setErrPopupMsg(String errPopupMsg) {
		this.errPopupMsg = errPopupMsg;
	}


	/**
	 * @return the isUpdRedirct
	 */
	public String getIsUpdRedirct() {
		return isUpdRedirct;
	}


	/**
	 * @param isUpdRedirct the isUpdRedirct to set
	 */
	public void setIsUpdRedirct(String isUpdRedirct) {
		this.isUpdRedirct = isUpdRedirct;
	}


	/**
	 * @return the isSkipValidtion
	 */
	public String getIsSkipValidtion() {
		return isSkipValidtion;
	}


	/**
	 * @param isSkipValidtion the isSkipValidtion to set
	 */
	public void setIsSkipValidtion(String isSkipValidtion) {
		this.isSkipValidtion = isSkipValidtion;
	}


	/**
	 * @return the epaFrmStatusDes
	 */
	public String getEpaFrmStatusDes() {
		return epaFrmStatusDes;
	}


	/**
	 * @param epaFrmStatusDes the epaFrmStatusDes to set
	 */
	public void setEpaFrmStatusDes(String epaFrmStatusDes) {
		this.epaFrmStatusDes = epaFrmStatusDes;
	}


	/**
	 * @return the redirectPage
	 */
	public String getRedirectPage() {
		return redirectPage;
	}


	/**
	 * @param redirectPage the redirectPage to set
	 */
	public void setRedirectPage(String redirectPage) {
		this.redirectPage = redirectPage;
	}


	/**
	 * @return the oldEngSerilNum
	 */
	public String getOldEngSerilNum() {
		return oldEngSerilNum;
	}


	/**
	 * @param oldEngSerilNum the oldEngSerilNum to set
	 */
	public void setOldEngSerilNum(String oldEngSerilNum) {
		this.oldEngSerilNum = oldEngSerilNum;
	}


	/**
	 * @return the statusCd
	 */
	public String getStatusCd() {
		return statusCd;
	}


	/**
	 * @param statusCd statusCd
	 */
	public void setStatusCd(String statusCd) {
		this.statusCd = statusCd;
	}
	
	/**
	 * 
	 * @return
	 */
	public String getEngBuildDate() {
		return engBuildDate;
	}

	/**
	 * 
	 * @param engBuildDate
	 */
	public void setEngBuildDate(String engBuildDate) {
		this.engBuildDate = engBuildDate;
	}


	/**
	 * @return the caseNumber
	 */
	public String getCaseNumber() {
		return caseNumber;
	}


	/**
	 * @param caseNumber the caseNumber to set
	 */
	public void setCaseNumber(String caseNumber) {
		this.caseNumber = caseNumber;
	}


	/**
	 * @return the ccrNumber
	 */
	public String getCcrNumber() {
		return ccrNumber;
	}


	/**
	 * @param ccrNumber the ccrNumber to set
	 */
	public void setCcrNumber(String ccrNumber) {
		this.ccrNumber = ccrNumber;
	}


	/**
	 * @return the isCoreReturnId
	 */
	public String getIsCoreReturnId() {
		return isCoreReturnId;
	}


	/**
	 * @param isCoreReturnId the isCoreReturnId to set
	 */
	public void setIsCoreReturnId(String isCoreReturnId) {
		this.isCoreReturnId = isCoreReturnId;
	}


	public String getAdtlEngSerNum() {
		return adtlEngSerNum;
	}


	public void setAdtlEngSerNum(String adtlEngSerNum) {
		this.adtlEngSerNum = adtlEngSerNum;
	}


	
	
	
}
