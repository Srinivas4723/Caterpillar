package com.cat.logistics.shared.dto;

/**
 * @author ganamr
 *
 */
public class GenericUploadDTO {
	
	private long grRecsCount=0;
	private long suceessCnt=0;
	private long requestedCnt=0;
	private String startTime=null;
	private byte[] errStream = null;
	private byte [] succeStream = null;
	private String endTime=null;
	private String fileName=null;
	private String excelErrMsg;
	/**
	 * @return the grRecsCount
	 */
	public long getGrRecsCount() {
		return grRecsCount;
	}
	/**
	 * @param grRecsCount the grRecsCount to set
	 */
	public void setGrRecsCount(long grRecsCount) {
		this.grRecsCount = grRecsCount;
	}
	/**
	 * @return the suceessCnt
	 */
	public long getSuceessCnt() {
		return suceessCnt;
	}
	/**
	 * @param suceessCnt the suceessCnt to set
	 */
	public void setSuceessCnt(long suceessCnt) {
		this.suceessCnt = suceessCnt;
	}
	/**
	 * @return the requestedCnt
	 */
	public long getRequestedCnt() {
		return requestedCnt;
	}
	/**
	 * @param requestedCnt the requestedCnt to set
	 */
	public void setRequestedCnt(long requestedCnt) {
		this.requestedCnt = requestedCnt;
	}
	/**
	 * @return the startTime
	 */
	public String getStartTime() {
		return startTime;
	}
	/**
	 * @param startTime the startTime to set
	 */
	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}
	/**
	 * @return the errStream
	 */
	public byte[] getErrStream() {
		return errStream;
	}
	/**
	 * @param errStream the errStream to set
	 */
	public void setErrStream(byte[] errStream) {
		this.errStream = errStream;
	}
	/**
	 * @return the succeStream
	 */
	public byte[] getSucceStream() {
		return succeStream;
	}
	/**
	 * @param succeStream the succeStream to set
	 */
	public void setSucceStream(byte[] succeStream) {
		this.succeStream = succeStream;
	}
	/**
	 * @return the endTime
	 */
	public String getEndTime() {
		return endTime;
	}
	/**
	 * @param endTime the endTime to set
	 */
	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}
	/**
	 * @return the fileName
	 */
	public String getFileName() {
		return fileName;
	}
	/**
	 * @param fileName the fileName to set
	 */
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	/**
	 * @return the excelErrMsg
	 */
	public String getExcelErrMsg() {
		return excelErrMsg;
	}
	/**
	 * @param excelErrMsg the excelErrMsg to set
	 */
	public void setExcelErrMsg(String excelErrMsg) {
		this.excelErrMsg = excelErrMsg;
	}	
	
}
