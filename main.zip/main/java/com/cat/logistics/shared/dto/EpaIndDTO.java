package com.cat.logistics.shared.dto;

import java.io.Serializable;

/**
 * This class holds Epa Import Type information
 * @author ganamr
 *
 */
public class EpaIndDTO implements Serializable{

	private static final long serialVersionUID = -338786720925359282L;

	private String engImpTypCd;
	
	private String engImpTypDesc;
	
	private String crteTs;
	
	private String crteLogonId;

	/**
	 * @return engine import type code
	 */
	public String getEngImpTypCd() {
		return engImpTypCd;
	}

	/**
	 * @param engImpTypCd
	 */
	public void setEngImpTypCd(String engImpTypCd) {
		this.engImpTypCd = engImpTypCd;
	}

	/**
	 * @return engine import type description
	 */
	public String getEngImpTypDesc() {
		return engImpTypDesc;
	}

	/**
	 * @param engImpTypDesc
	 */
	public void setEngImpTypDesc(String engImpTypDesc) {
		this.engImpTypDesc = engImpTypDesc;
	}

	/**
	 * @return create time stamp
	 */
	public String getCrteTs() {
		return crteTs;
	}

	/**
	 * @param crteTs
	 */
	public void setCrteTs(String crteTs) {
		this.crteTs = crteTs;
	}

	/**
	 * @return create logon id
	 */
	public String getCrteLogonId() {
		return crteLogonId;
	}

	/**
	 * @param crteLogonId
	 */
	public void setCrteLogonId(String crteLogonId) {
		this.crteLogonId = crteLogonId;
	}
}
