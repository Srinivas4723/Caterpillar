package com.cat.logistics.shared.dto;

import java.util.ArrayList;
import java.util.List;

/**
 * MassUploadExcelRowDTO object to hold excel data
 * @author kakars2
 *
 */
public class MassUploadExcelRowDTO {

	private String shipFcltyCd;
	private String serialNumber;
	private String partNumber;
	private String shippingDt;
	private String invoiceNo;
	private String orderNo;
	private List<String> errorMsgs = new ArrayList<String>();
	private String overrideError;
	private boolean isFieldsError=false;
	private boolean isSerNoWarng=false;
	
	/**
	 *  
	 * @return shipFcltyCd
	 */
	public String getShipFcltyCd() {
		return shipFcltyCd;
	}
	/**
	 * 
	 * @param shipFcltyCd
	 */
	public void setShipFcltyCd(String shipFcltyCd) {
		this.shipFcltyCd = shipFcltyCd;
	}
	/**
	 * 
	 * @return shippingDt
	 */
	public String getShippingDt() {
		return shippingDt;
	}
	/**
	 * 
	 * @param shippingDt
	 */
	public void setShippingDt(String shippingDt) {
		this.shippingDt = shippingDt;
	}
	/**
	 * 
	 * @return overrideError
	 */
	public String getOverrideError() {
		return overrideError;
	}
	/**
	 * 
	 * @param overrideError
	 */
	public void setOverrideError(String overrideError) {
		this.overrideError = overrideError;
	}
	/**
	 * 
	 * @return errorMsgs
	 */
	public List<String> getErrorMsgs() {
		return errorMsgs;
	}
	/**
	 * 
	 * @param errorMsgs
	 */
	public void setErrorMsgs(List<String> errorMsgs) {
		this.errorMsgs = errorMsgs;
	}
	/**
	 * 
	 * @return serialNumber
	 */
	public String getSerialNumber() {
		return serialNumber;
	}
	/**
	 * 
	 * @param serialNumber
	 */
	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}
	/**
	 * 
	 * @return partNumber
	 */
	public String getPartNumber() {
		return partNumber;
	}
	/**
	 * 
	 * @param partNumber
	 */
	public void setPartNumber(String partNumber) {
		this.partNumber = partNumber;
	}
	/**
	 * 
	 * @return invoiceNo
	 */
	public String getInvoiceNo() {
		return invoiceNo;
	}
	/**
	 * 
	 * @param invoiceNo
	 */
	public void setInvoiceNo(String invoiceNo) {
		this.invoiceNo = invoiceNo;
	}
	/**
	 * 
	 * @return orderNo
	 */
	public String getOrderNo() {
		return orderNo;
	}
	/**
	 * 
	 * @param orderNo
	 */
	public void setOrderNo(String orderNo) {
		this.orderNo = orderNo;
	}
	/**
	 * 
	 * @return isFieldsError
	 */
	public boolean isFieldsError() {
		return isFieldsError;
	}
	/**
	 * 
	 * @param isFieldsError
	 */
	public void setFieldsError(boolean isFieldsError) {
		this.isFieldsError = isFieldsError;
	}
	/**
	 * 
	 * @return boolean
	 */
	public boolean isSerNoWarng() {
		return isSerNoWarng;
	}
	/**
	 * 
	 * @param isSerNoWarng
	 */
	public void setSerNoWarng(boolean isSerNoWarng) {
		this.isSerNoWarng = isSerNoWarng;
	}
	
	
}
