package com.cat.logistics.shared.dto;


/**
 * This class holds the Facility workQ search criteria information for engine and shipment
 * @author ganamr
 *
 */
public class FacilityWrkQuEngShipSearchParamDTO {
	private String seqNo;
	private String facilityCdDescs;
	private String noDataForSearch;
	private String invoiceNo;
	private String toBuildDate;
	private String fromShippedDate;
	private String engineSerialNo;

	private String epaStatusCdDesc;
	
	
	private String toShippedDate;
	
	private String engineARPartNo;
	
	
	private String modelNo;
	private String shipmentDate;
	private String retFrmJsp;
	private String fromBuildDate;
	
	private String engImportTypCode;
	private String engImportProvTypCode;
	private String buildDate;
	private String eso;
	
	public FacilityWrkQuEngShipSearchParamDTO() {
		super();
	}

	/**
	 * @return the seqNo
	 */
	public String getSeqNo() {
		return seqNo;
	}

	/**
	 * @param seqNo the seqNo to set
	 */
	public void setSeqNo(String seqNo) {
		this.seqNo = seqNo;
	}

	/**
	 * @return the facilityCdDescs
	 */
	public String getFacilityCdDescs() {
		return facilityCdDescs;
	}

	/**
	 * @param facilityCdDescs the facilityCdDescs to set
	 */
	public void setFacilityCdDescs(String facilityCdDescs) {
		this.facilityCdDescs = facilityCdDescs;
	}

	/**
	 * @return the noDataForSearch
	 */
	public String getNoDataForSearch() {
		return noDataForSearch;
	}

	/**
	 * @param noDataForSearch the noDataForSearch to set
	 */
	public void setNoDataForSearch(String noDataForSearch) {
		this.noDataForSearch = noDataForSearch;
	}

	/**
	 * @return the invoiceNo
	 */
	public String getInvoiceNo() {
		return invoiceNo;
	}

	/**
	 * @param invoiceNo the invoiceNo to set
	 */
	public void setInvoiceNo(String invoiceNo) {
		this.invoiceNo = invoiceNo;
	}

	/**
	 * @return the toBuildDate
	 */
	public String getToBuildDate() {
		return toBuildDate;
	}

	/**
	 * @param toBuildDate the toBuildDate to set
	 */
	public void setToBuildDate(String toBuildDate) {
		this.toBuildDate = toBuildDate;
	}

	/**
	 * @return the fromShippedDate
	 */
	public String getFromShippedDate() {
		return fromShippedDate;
	}

	/**
	 * @param fromShippedDate the fromShippedDate to set
	 */
	public void setFromShippedDate(String fromShippedDate) {
		this.fromShippedDate = fromShippedDate;
	}

	/**
	 * @return the engineSerialNo
	 */
	public String getEngineSerialNo() {
		return engineSerialNo;
	}

	/**
	 * @param engineSerialNo the engineSerialNo to set
	 */
	public void setEngineSerialNo(String engineSerialNo) {
		this.engineSerialNo = engineSerialNo;
	}

	/**
	 * @return the epaStatusCdDesc
	 */
	public String getEpaStatusCdDesc() {
		return epaStatusCdDesc;
	}

	/**
	 * @param epaStatusCdDesc the epaStatusCdDesc to set
	 */
	public void setEpaStatusCdDesc(String epaStatusCdDesc) {
		this.epaStatusCdDesc = epaStatusCdDesc;
	}

	/**
	 * @return the toShippedDate
	 */
	public String getToShippedDate() {
		return toShippedDate;
	}

	/**
	 * @param toShippedDate the toShippedDate to set
	 */
	public void setToShippedDate(String toShippedDate) {
		this.toShippedDate = toShippedDate;
	}

	/**
	 * @return the engineARPartNo
	 */
	public String getEngineARPartNo() {
		return engineARPartNo;
	}

	/**
	 * @param engineARPartNo the engineARPartNo to set
	 */
	public void setEngineARPartNo(String engineARPartNo) {
		this.engineARPartNo = engineARPartNo;
	}

	/**
	 * @return the modelNo
	 */
	public String getModelNo() {
		return modelNo;
	}

	/**
	 * @param modelNo the modelNo to set
	 */
	public void setModelNo(String modelNo) {
		this.modelNo = modelNo;
	}

	/**
	 * @return the shipmentDate
	 */
	public String getShipmentDate() {
		return shipmentDate;
	}

	/**
	 * @param shipmentDate the shipmentDate to set
	 */
	public void setShipmentDate(String shipmentDate) {
		this.shipmentDate = shipmentDate;
	}

	/**
	 * @return the retFrmJsp
	 */
	public String getRetFrmJsp() {
		return retFrmJsp;
	}

	/**
	 * @param retFrmJsp the retFrmJsp to set
	 */
	public void setRetFrmJsp(String retFrmJsp) {
		this.retFrmJsp = retFrmJsp;
	}

	/**
	 * @return the fromBuildDate
	 */
	public String getFromBuildDate() {
		return fromBuildDate;
	}

	/**
	 * @param fromBuildDate the fromBuildDate to set
	 */
	public void setFromBuildDate(String fromBuildDate) {
		this.fromBuildDate = fromBuildDate;
	}

	/**
	 * @return the engImportTypCode
	 */
	public String getEngImportTypCode() {
		return engImportTypCode;
	}

	/**
	 * @param engImportTypCode the engImportTypCode to set
	 */
	public void setEngImportTypCode(String engImportTypCode) {
		this.engImportTypCode = engImportTypCode;
	}

	/**
	 * @return the engImportProvTypCode
	 */
	public String getEngImportProvTypCode() {
		return engImportProvTypCode;
	}

	/**
	 * @param engImportProvTypCode the engImportProvTypCode to set
	 */
	public void setEngImportProvTypCode(String engImportProvTypCode) {
		this.engImportProvTypCode = engImportProvTypCode;
	}

	/**
	 * @return the buildDate
	 */
	public String getBuildDate() {
		return buildDate;
	}

	/**
	 * @param buildDate the buildDate to set
	 */
	public void setBuildDate(String buildDate) {
		this.buildDate = buildDate;
	}

	/**
	 * @return the eso
	 */
	public String getEso() {
		return eso;
	}

	/**
	 * @param eso the eso to set
	 */
	public void setEso(String eso) {
		this.eso = eso;
	}
	
}
