package com.cat.logistics.shared.dto;

import java.io.Serializable;

/**
 * This class holds Epa Provision Type information
 * @author ganamr
 *
 */
public class EpaImpDTO implements Serializable{

	
	private static final long serialVersionUID = -5847547551479329904L;
	
	private String engProvTypCd;
	
	private String engProvTypDesc;
	
	private String crteLogonId;
	
	private String creteTs;

	/**
	 * @return engine provision Type code
	 */
	public String getEngProvTypCd() {
		return engProvTypCd;
	}

	/**
	 * @param engProvTypCd
	 */
	public void setEngProvTypCd(String engProvTypCd) {
		this.engProvTypCd = engProvTypCd;
	}

	/**
	 * @return Engine Provision Type description
	 */
	public String getEngProvTypDesc() {
		return engProvTypDesc;
	}

	/**
	 * @param engProvTypDesc
	 */
	public void setEngProvTypDesc(String engProvTypDesc) {
		this.engProvTypDesc = engProvTypDesc;
	}

	/**
	 * @return create Logon id
	 */
	public String getCrteLogonId() {
		return crteLogonId;
	}

	/**
	 * @param crteLogonId
	 */
	public void setCrteLogonId(String crteLogonId) {
		this.crteLogonId = crteLogonId;
	}

	/**
	 * @return create time stamp
	 */
	public String getCreteTs() {
		return creteTs;
	}

	/**
	 * @param creteTs
	 */
	public void setCreteTs(String creteTs) {
		this.creteTs = creteTs;
	}
	
	

}
