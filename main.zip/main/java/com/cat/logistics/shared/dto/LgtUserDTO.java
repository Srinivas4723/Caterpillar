package com.cat.logistics.shared.dto;

import java.io.Serializable;
import java.util.List;

/**
 * Data transfer Object to encapsulate the logistics user information to view layer 
 * 
 * @author sebastian.g.ducci
 *
 */
public class LgtUserDTO implements Serializable {

	private static final long serialVersionUID = 328339675439206102L;
	
	private String userName;
	private String roleDescription;
	private String facilityCode;
	private String roleCode;
	
	private List<Long> rolesId; 
	private List<String> rolesName;
	
	public LgtUserDTO() {}
	
	/**
	 * @param userName
	 * @param roleDescription
	 * @param facilityCode
	 */
	public LgtUserDTO(String userName, String roleDescription,String facilityCode) {
		this.userName = userName;
		this.roleDescription = roleDescription;
		this.facilityCode = facilityCode;
	}
	
	/**
	 * @param userName
	 * @param roleDescription
	 * @param facilityCode
	 * @param roleCode
	 */
	public LgtUserDTO(String userName, String roleDescription,String facilityCode , String roleCode) {
		this.userName = userName;
		this.roleDescription = roleDescription;
		this.facilityCode = facilityCode;
		this.roleCode = roleCode;
	}
	
	/**
	 * @return roles Id
	 */
	public List<Long> getRolesId() {
		return rolesId;
	}

	/**
	 * @param rolesId
	 */
	public void setRolesId(List<Long> rolesId) {
		this.rolesId = rolesId;
	}

	/**
	 * @return user Name 
	 */
	public String getUserName() {
		return userName;
	}

	/**
	 * @param userName
	 */
	public void setUserName(String userName) {
		this.userName = userName;
	}

	/**
	 * @return roles Name
	 */
	public List<String> getRolesName() {
		return rolesName;
	}

	/**
	 * @param rolesName
	 */
	public void setRolesName(List<String> rolesName) {
		this.rolesName = rolesName;
	}

	/**
	 * @return role Description
	 */
	public String getRoleDescription() {
		return roleDescription;
	}

	/**
	 * @param roleDescription
	 */
	public void setRoleDescription(String roleDescription) {
		this.roleDescription = roleDescription;
	}

	/**
	 * @return facility Code
	 */
	public String getFacilityCode() {
		return facilityCode;
	}

	/**
	 * @param facilityCode
	 */
	public void setFacilityCode(String facilityCode) {
		this.facilityCode = facilityCode;
	}

	/**
	 * @return role Code
	 */
	public String getRoleCode() {
		return roleCode;
	}

	/**
	 * @param roleCode
	 */
	public void setRoleCode(String roleCode) {
		this.roleCode = roleCode;
	}
	
}
