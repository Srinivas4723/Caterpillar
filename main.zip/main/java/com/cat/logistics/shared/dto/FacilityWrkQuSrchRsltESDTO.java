package com.cat.logistics.shared.dto;

/**
 * This class holds the Facility workQ search result information for engine and shipment
 * @author ganamr
 *
 */
public class FacilityWrkQuSrchRsltESDTO {
	private String epaFormStatus;
	private String facCode;
	private String statusColor;
	
	private String engineSerialNo;
	private String engineARPartNo;
	private String eso;
	private String modelNo;
	private String shipmentDate;
	private String invoiceNo;
	private String buildDate;
	private String engImportTypCode;
	private String engImportProvTypCode;
	private String prevActOwner;
	
	private int sortOrderNo;

	/**
	 * @return the epaFormStatus
	 */
	public String getEpaFormStatus() {
		return epaFormStatus;
	}

	/**
	 * @param epaFormStatus the epaFormStatus to set
	 */
	public void setEpaFormStatus(String epaFormStatus) {
		this.epaFormStatus = epaFormStatus;
	}

	/**
	 * @return the facCode
	 */
	public String getFacCode() {
		return facCode;
	}

	/**
	 * @param facCode the facCode to set
	 */
	public void setFacCode(String facCode) {
		this.facCode = facCode;
	}

	/**
	 * @return the statusColor
	 */
	public String getStatusColor() {
		return statusColor;
	}

	/**
	 * @param statusColor the statusColor to set
	 */
	public void setStatusColor(String statusColor) {
		this.statusColor = statusColor;
	}

	/**
	 * @return the engineSerialNo
	 */
	public String getEngineSerialNo() {
		return engineSerialNo;
	}

	/**
	 * @param engineSerialNo the engineSerialNo to set
	 */
	public void setEngineSerialNo(String engineSerialNo) {
		this.engineSerialNo = engineSerialNo;
	}

	/**
	 * @return the engineARPartNo
	 */
	public String getEngineARPartNo() {
		return engineARPartNo;
	}

	/**
	 * @param engineARPartNo the engineARPartNo to set
	 */
	public void setEngineARPartNo(String engineARPartNo) {
		this.engineARPartNo = engineARPartNo;
	}

	/**
	 * @return the eso
	 */
	public String getEso() {
		return eso;
	}

	/**
	 * @param eso the eso to set
	 */
	public void setEso(String eso) {
		this.eso = eso;
	}

	/**
	 * @return the modelNo
	 */
	public String getModelNo() {
		return modelNo;
	}

	/**
	 * @param modelNo the modelNo to set
	 */
	public void setModelNo(String modelNo) {
		this.modelNo = modelNo;
	}

	/**
	 * @return the shipmentDate
	 */
	public String getShipmentDate() {
		return shipmentDate;
	}

	/**
	 * @param shipmentDate the shipmentDate to set
	 */
	public void setShipmentDate(String shipmentDate) {
		this.shipmentDate = shipmentDate;
	}

	/**
	 * @return the invoiceNo
	 */
	public String getInvoiceNo() {
		return invoiceNo;
	}

	/**
	 * @param invoiceNo the invoiceNo to set
	 */
	public void setInvoiceNo(String invoiceNo) {
		this.invoiceNo = invoiceNo;
	}

	/**
	 * @return the buildDate
	 */
	public String getBuildDate() {
		return buildDate;
	}

	/**
	 * @param buildDate the buildDate to set
	 */
	public void setBuildDate(String buildDate) {
		this.buildDate = buildDate;
	}

	/**
	 * @return the engImportTypCode
	 */
	public String getEngImportTypCode() {
		return engImportTypCode;
	}

	/**
	 * @param engImportTypCode the engImportTypCode to set
	 */
	public void setEngImportTypCode(String engImportTypCode) {
		this.engImportTypCode = engImportTypCode;
	}

	/**
	 * @return the engImportProvTypCode
	 */
	public String getEngImportProvTypCode() {
		return engImportProvTypCode;
	}

	/**
	 * @param engImportProvTypCode the engImportProvTypCode to set
	 */
	public void setEngImportProvTypCode(String engImportProvTypCode) {
		this.engImportProvTypCode = engImportProvTypCode;
	}

	/**
	 * @return the prevActOwner
	 */
	public String getPrevActOwner() {
		return prevActOwner;
	}

	/**
	 * @param prevActOwner the prevActOwner to set
	 */
	public void setPrevActOwner(String prevActOwner) {
		this.prevActOwner = prevActOwner;
	}

	/**
	 * @return the sortOrderNo
	 */
	public int getSortOrderNo() {
		return sortOrderNo;
	}

	/**
	 * @param sortOrderNo the sortOrderNo to set
	 */
	public void setSortOrderNo(int sortOrderNo) {
		this.sortOrderNo = sortOrderNo;
	}

	
	
}
