package com.cat.logistics.shared.dao.impl;

import java.io.Serializable;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.transaction.annotation.Transactional;

import com.cat.logistics.shared.dao.IGenericJpaDao;
import com.cat.logistics.shared.exception.DaoException;

/**
 * Generic DAO 
 *
 * @param <T>
 * @param <K>
 */
public class GenericJpaDao<T, K extends Serializable> implements IGenericJpaDao<T, K> {

	private Class<T> clazz;
	
	
	private EntityManager entityManager;
	
	private EntityManager tisEntityManager;
	
	private EntityManager odsEntityManager;
	
	private EntityManager mdwEntityManager;
	
	/*private EntityManager glEntityManager;
	
	private EntityManager glTISEntityManager;
	
	private EntityManager eccnEntityManager;*/
  
	/**
	 * @return glEntityManager
	 *//*
	public EntityManager getGlEntityManager() {
		return glEntityManager;
	}
	
	*//**
	 * @param glEntityManager
	 *//*
	@PersistenceContext(unitName="achUnit")
	@Qualifier(value="entityManagerFactoryGl")
	public void setGlEntityManager(EntityManager glEntityManager) {
		this.glEntityManager = glEntityManager;
	}*/

	/**
	 * 
	 */
	@SuppressWarnings("unchecked")
	public GenericJpaDao(){
		Type t = getClass().getGenericSuperclass();
		ParameterizedType pt = (ParameterizedType) t;
		clazz = (Class) pt.getActualTypeArguments()[0];
		
	}

	/**
	 * @return the clazz
	 */
	public Class<T> getClazz() {
		return clazz;
	}

	/**
	 * @param clazz the clazz to set
	 */
	public void setClazz(Class<T> clazz) {
		this.clazz = clazz;
	}

	/**
	 * @return the entityManager
	 */
	public EntityManager getEntityManager() {
		return entityManager;
	}

	/**
	 * @param entityManager the entityManager to set
	 */
	
	@PersistenceContext(unitName="epaUnit")
	@Qualifier(value="entityManagerFactoryEPA")
	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	/**
	 * @return
	 */
	public EntityManager getTisEntityManager() {
		return tisEntityManager;
	}

	/**
	 * @param tisEntityManager
	 */
	@PersistenceContext(unitName="tisUnit")
	@Qualifier(value="entityManagerFactoryTis")
	public void setTisEntityManager(EntityManager tisEntityManager) {
		this.tisEntityManager = tisEntityManager;
	}
	
	/**
	 * @return
	 */
	public EntityManager getOdsEntityManager() {
		return odsEntityManager;
	}

	/**
	 * @param odsEntityManager
	 */
	@PersistenceContext(unitName="odsUnit")
	@Qualifier(value="entityManagerFactoryOds")
	public void setOdsEntityManager(EntityManager odsEntityManager) {
		this.odsEntityManager = odsEntityManager;
	}
	
	/**
	 * @return
	 */
	public EntityManager getMdwEntityManager() {
		return mdwEntityManager;
	}

	/**
	 * @param mdwEntityManager
	 */
	@PersistenceContext(unitName="mdwUnit")
	@Qualifier(value="entityManagerFactoryMdw")
	public void setMdwEntityManager(EntityManager mdwEntityManager) {
		this.mdwEntityManager = mdwEntityManager;
	}
	
	/**
	 * @return glTISEntityManager
	 *//*
	public EntityManager getGlTISEntityManager() {
		return glTISEntityManager;
	}

	*//**
	 * @param glTISEntityManager
	 *//*
	@PersistenceContext(unitName="achTISUnit")
	@Qualifier(value="entityManagerFactoryTISGl")
	public void setGlTISEntityManager(EntityManager glTISEntityManager) {
		this.glTISEntityManager = glTISEntityManager;
	}*/

	/**
	 * @return the session
	 */
	public Session getSession() {
		return (Session) getEntityManager().getDelegate();
	}
	
	/**
	 * @return the session
	 */
	/*public Session getGLSession() {
		return (Session) getGlEntityManager().getDelegate();
	}
	
	*//**
	 * @return achTisSession
	 *//*
	public Session getAchTISSession() {
		return (Session) getGlTISEntityManager().getDelegate();
	}*/
	
	/**
	 * @return the Tis session
	 */
	public Session getTisSession() {
		return (Session) getTisEntityManager().getDelegate();
	}
	
	/**
	 * @return the ODS session
	 */
	public Session getOdsSession() {
		return (Session) getOdsEntityManager().getDelegate();
	}
	
	/**
	 * @return the MDW session
	 */
	public Session getMdwSession() {
		return (Session) getMdwEntityManager().getDelegate();
	}

	/**
	 * @param entity
	 */
	@Override
	@Transactional(value="transactionManagerEPA")
	public void persist(T entity) throws DaoException {
		try {
			entityManager.persist(entity);
		} catch (Exception e) {
			throw new DaoException(e);
		}
	}
	
	/**
	 * @param entity
	 */
	/*@Override
	@Transactional(value ="transactionManagerGl")
	public void persistGL(T entity) throws DaoException {
		try {
			glEntityManager.persist(entity);
		} catch (Exception e) {
			throw new DaoException(e);
		}
	}*/
	
	
	/**
	 * @param entity
	 */
	@Override
	@Transactional(value="transactionManagerEPA")
	public void merge(T entity) throws DaoException {
		try {
			entityManager.merge(entity);
		} catch (Exception e) {
			throw new DaoException(e);
		}
	}
	
	/**
	 * @param entity entity
	 */
	@Override
	@Transactional
	public void remove(final T entity) throws DaoException {
		try {
			entityManager.remove(entityManager.contains(entity) ? entity : entityManager.merge(entity));
		} catch (Exception e) {
			throw new DaoException(e);
		}
	}
	
	/**
	 *  @param id id
	 *  @return T T
	 */
	@Override
	@Transactional
	public T findById(K id) throws DaoException {
		try {
			return entityManager.find(clazz, id);
		} catch (Exception e) {
			throw new DaoException(e);
		}
	}

	/**
	 * @return the List
	 */
	@SuppressWarnings("unchecked")
	@Override
	@Transactional
	public List<T> findAll() throws DaoException {
		try {
			return entityManager.createQuery("from " + clazz.getName()).getResultList();
		} catch (Exception e) {
			throw new DaoException(e);
		}
	}

	/**
	 * @param id
	 */
	@Override
	@Transactional
	public void deleteById(final K id) throws DaoException {
		try {
			final T entity = findById(id);
			remove(entity);
		} catch (Exception e) {
			throw new DaoException(e);
		}
		
	}

	/**
	 * flush 
	 */
	@Override
	@Transactional
	public void flush() throws DaoException {
		try {
			entityManager.flush();
		} catch (Exception e) {
			throw new DaoException(e);
		}
	}
	/**Gets the entity from PMT_ALLOC_DTA table
	 * 
	 * @param id 
	 * @return the entity
	 * @throws DaoException 
	 */
	/*@Override
	@Transactional(value = "transactionManagerGl")
	public T findByIdGl(K id) throws DaoException {
		try {
			return glEntityManager.find(clazz, id);
		} catch (Exception e) {
			throw new DaoException(e);
		}
	}
	*//**
	 * Removes the entity from PMT_ALLOC_DTA table
	 * 
	 * @param entity
	 * @throws DaoException
	 *//*
	@Override
	@Transactional(value = "transactionManagerGl")
	public void removePayAllocEntity(T entity) throws DaoException {

		try {

			glEntityManager.remove(glEntityManager.contains(entity) ? entity
					: glEntityManager.merge(entity));

		} catch (Exception e) {
			throw new DaoException(e);
		}

	}

	*//**
	 * @return eccnEntityManager
	 *//*
	public EntityManager getECCNEntityManager() {
		return eccnEntityManager;
	}

	*//**
	 * @param eccnEntityManager
	 *//*
	@PersistenceContext(unitName="eccnUnit")
	@Qualifier(value="entityManagerFactoryECCN")
	public void setECCNEntityManager(EntityManager eccnEntityManager) {
		this.eccnEntityManager = eccnEntityManager;
	}
	
	*//**
	 * @return the ECCN session
	 *//*
	public Session getECCNSession() {
		return (Session) getECCNEntityManager().getDelegate();
	}*/

	
	
	
}