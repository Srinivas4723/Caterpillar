package com.cat.logistics.shared.security;

import java.util.Collection;
import java.util.Map;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.User;

import com.cat.logistics.shared.dto.LgtRoleUserDTO;
import com.cat.logistics.shared.utils.ServiceConstants;

/**
 * Security entity to save the user information under spring security technology
 * 
 * @author sebastian.g.ducci
 *
 */
public class LgtUserSecurity extends User {

	private static final long serialVersionUID = 328339675439206102L;

	private Map<String, LgtRoleUserDTO> mapFacilityRolePermission;
	
	private boolean isProductGroupAdmin = false;
	
	/**
	 * @param username
	 * @param enabled
	 * @param accountNonExpired
	 * @param credentialsNonExpired
	 * @param accountNonLocked
	 * @param authorities
	 */
	public LgtUserSecurity(String username, String password, boolean enabled,
			boolean accountNonExpired, boolean credentialsNonExpired,
			boolean accountNonLocked,
			Collection<? extends GrantedAuthority> authorities) {
		super(username, password, enabled, accountNonExpired, credentialsNonExpired,
				accountNonLocked, authorities);
	}

	/**
	 * fetches Facility Role permission 
	 * @return Logon role user dto
	 */
	public Map<String, LgtRoleUserDTO> getMapFacilityRolePermission() {
		return mapFacilityRolePermission;
	}

	/**
	 * @param mapFacilityRolePermission
	 */
	public void setMapFacilityRolePermission(
			Map<String, LgtRoleUserDTO> mapFacilityRolePermission) {
		this.mapFacilityRolePermission = mapFacilityRolePermission;
	}

	/**
	 * LgtUserSecurity.isProductGroupAdmin
	 * Description of the method.
	 *
	 * @return Returns the isProductGroupAdmin
	 * @since 1.0 Jun 18, 2015 6:53:05 PM badamrr
	 */
	public boolean isProductGroupAdmin() {
		return isProductGroupAdmin;
	}

	/**
	 * LgtUserSecurity.setProductGroupAdmin
	 * Description of the method.
	 *
	 * @param isProductGroupAdmin the isProductGroupAdmin to set
	 * @since 1.0 Jun 18, 2015 6:53:05 PM badamrr
	 */
	public void setProductGroupAdmin(boolean isProductGroupAdmin) {
		this.isProductGroupAdmin = isProductGroupAdmin;
	}

	/**
	 * Default hash code mechanism 
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + (isProductGroupAdmin ? ServiceConstants.INT_1231 : ServiceConstants.INT_1237);
		result = prime
				* result
				+ ((mapFacilityRolePermission == null) ? 0
						: mapFacilityRolePermission.hashCode());
		return result;
	}

	 /**
	 * @see org.springframework.security.core.userdetails.User#equals(java.lang.Object)
	 * @param obj
	 */
	@Override
	    public boolean equals(Object obj) {
	        if (obj == null) {
	            return false;
	        }
	        if (getClass() != obj.getClass()) {
	            return false;
	        }
	        LgtUserSecurity other = (LgtUserSecurity) obj;
		    return isProductGroupAdmin == other.isProductGroupAdmin && 
	        		(mapFacilityRolePermission == other.mapFacilityRolePermission || (mapFacilityRolePermission != null && mapFacilityRolePermission.equals(other.getMapFacilityRolePermission()))); 
	    }

}
