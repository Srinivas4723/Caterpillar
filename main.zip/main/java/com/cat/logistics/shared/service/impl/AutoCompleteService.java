package com.cat.logistics.shared.service.impl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cat.logistics.epa.dao.IEpaDataConfigDAO;
import com.cat.logistics.epa.dao.IEpaEngineDAO;
import com.cat.logistics.epa.dao.IEpaFacilityDAO;
import com.cat.logistics.epa.dao.IEpaImportTypeDAO;
import com.cat.logistics.epa.dao.IEpaProvisionTypeDAO;
import com.cat.logistics.epa.dao.IEpaShipmentDAO;
import com.cat.logistics.epa.dao.IEpaStatusDAO;
import com.cat.logistics.epa.dao.IEpaUserAthDAO;
import com.cat.logistics.epa.entities.EpaDataCnfgr;
import com.cat.logistics.epa.entities.EpaFac;
import com.cat.logistics.epa.entities.EpaImportType;
import com.cat.logistics.epa.entities.EpaProvisionType;
import com.cat.logistics.epa.entities.EpaState;
import com.cat.logistics.epa.entities.EpaStatus;
import com.cat.logistics.epa.entities.EpaUserAth;
import com.cat.logistics.shared.exception.DaoException;
import com.cat.logistics.shared.exception.ServiceException;
import com.cat.logistics.shared.service.IAutoCompleteService;
import com.cat.logistics.shared.utils.AlphanumComparator;
import com.cat.logistics.shared.utils.MasterData;
import com.cat.logistics.shared.utils.PersistenceConstants;
import com.cat.logistics.shared.utils.ServiceConstants;
import com.cat.logistics.shared.utils.ServiceUtils;

/**
 * This class is used populate for all the auto populated data.
 * 
 * @author ganamr
 *
 */
@Service
public class AutoCompleteService implements IAutoCompleteService {

	private IEpaFacilityDAO epaFacilityDAO;
	private IEpaStatusDAO epaStatusDAO;
	private IEpaShipmentDAO epaShipmentDAO;
	public static final Logger LOGGER = LogManager.getLogger(AutoCompleteService.class);

	@Autowired
	private IEpaEngineDAO epaEngineDAO;

	@Autowired
	private IEpaImportTypeDAO epaImportTypeDAO;

	@Autowired
	private IEpaProvisionTypeDAO epaProvisionTypeDAO;

	@Autowired
	private IEpaUserAthDAO epaUserAthDAO;

	@Autowired
	IEpaDataConfigDAO dataConfgDAO;

	/**
	 * fetches the facility codes from EpaFac
	 * 
	 * @return list of facilities
	 * @throws ServiceException
	 */
	@Override
	public List<String> getAllFacilityCdNm() throws ServiceException {
		LOGGER.info("Entry method of getAllFacilityCdNm {}",
				ServiceConstants.METHOD_ENTRY);
		List<String> facCdNmList = new ArrayList<String>();
		List<EpaFac> epaFacList = null;
		String concatString = null;
		epaFacList = epaFacilityDAO.getAllFacilities();
		for (EpaFac epaFac : epaFacList) {
			concatString = epaFac.getFacCd() + ServiceConstants.HIPHEN + epaFac.getFacilityName();
			facCdNmList.add(concatString);
			MasterData.addFacility(
					ServiceUtils.concatenate(epaFac.getFacCd(), ServiceConstants.HIPHEN, epaFac.getFacilityName()),
					epaFac.getFacCd());
		}
		facCdNmList.remove(ServiceConstants.DEFAULT_FAC);
		Collections.sort(facCdNmList, new AlphanumComparator());
		LOGGER.info("Exit method of getAllFacilityCdNm {}",
				ServiceConstants.METHOD_EXIT);
		return facCdNmList;
	}

	/**
	 * fetches status related info from EPASTATUS
	 * 
	 * @return list of status desc
	 * @throws ServiceException
	 */
	@Override
	public List<String> getAllStatusCdDesc() throws ServiceException {
		LOGGER.info("Entry method of getAllStatusCdDesc {}",
				ServiceConstants.METHOD_ENTRY);
		List<String> statCdDesList = new ArrayList<String>();
		List<EpaStatus> epaStatusList = null;
		try {
			epaStatusList = epaStatusDAO.getAllStatus();
			for (EpaStatus epaStatus : epaStatusList) {
				if (!ServiceUtils.isNullOrEmpty(epaStatus.getEpaStatusCd())) {
					statCdDesList.add(epaStatus.getEpaStatusDesc());
					MasterData.addStatusCodesMap(epaStatus.getEpaStatusDesc(), epaStatus.getEpaStatusCd());
				}
			}
		} catch (DaoException e) {
			LOGGER.error("Error in getAllStatusCdDesc {}", e.getMessage(), e);
			throw new ServiceException(e);
		}
		LOGGER.info("Exit method of getAllStatusCdDesc {}",
				ServiceConstants.METHOD_EXIT);
		return statCdDesList;
	}

	/**
	 * fetches invoice related data from shipment dao
	 * 
	 * @return list of invoice numbers
	 * @throws ServiceException
	 */
	@Override
	public List<String> getAllInvoiceNos() throws ServiceException {
		List<String> invoiceList = null;
		invoiceList = epaShipmentDAO.getAllInvoiceNo();
		return invoiceList;
	}

	/**
	 * fetches Order numbers from shipment dao
	 * 
	 * @return list of engine order numbers
	 * @throws ServiceException
	 */
	@Override
	public List<String> getAllEsos() throws ServiceException {
		List<String> esoList = epaShipmentDAO.getAllEsos();
		return esoList;
	}

	/**
	 * @return the epaFcilityDAO
	 */
	public IEpaFacilityDAO getEpaFacilityDAO() {
		return epaFacilityDAO;
	}

	/**
	 * @param epaFacilityDAO
	 */
	@Autowired
	public void setEpaFacilityDAO(IEpaFacilityDAO epaFacilityDAO) {
		this.epaFacilityDAO = epaFacilityDAO;
	}

	/**
	 * @return the epaStatusDAO
	 */
	public IEpaStatusDAO getEpaStatusDAO() {
		return epaStatusDAO;
	}

	/**
	 * @param epaStatusDAO
	 */
	@Autowired
	public void setEpaStatusDAO(IEpaStatusDAO epaStatusDAO) {
		this.epaStatusDAO = epaStatusDAO;
	}

	/**
	 * @return the epaShipmentDAO
	 */
	public IEpaShipmentDAO getEpaShipmentDAO() {
		return epaShipmentDAO;
	}

	/**
	 * @param epaShipmentDAO
	 */
	@Autowired
	public void setEpaShipmentDAO(IEpaShipmentDAO epaShipmentDAO) {
		this.epaShipmentDAO = epaShipmentDAO;
	}

	/**
	 * This method fetch sorted list of Engine Import Types
	 * 
	 * @return List of import types
	 */
	@Override
	public List<String> getImportTypes() {
		LOGGER.info("Entry method of getImportTypes {}",
				PersistenceConstants.METHOD_ENTRY);
		List<EpaImportType> epaImportTypes = null;
		List<String> epaImportTypList = null;
		if (null == MasterData.getImportTypeMap() || MasterData.getImportTypeMap().size() == 0) {
			epaImportTypes = epaImportTypeDAO.getAllImportCodeList();
			for (EpaImportType impTyp : epaImportTypes) {
				MasterData.addImportType(impTyp.getImportTypeCode(), ServiceUtils.concatenate(
						impTyp.getImportTypeCode(), ServiceConstants.DOT, impTyp.getImportTypeDescription()));
			}
		}
		epaImportTypList = new ArrayList<String>(MasterData.getImportTypeMap().values());
		Collections.sort(epaImportTypList, new AlphanumComparator());
		LOGGER.info("Exit method of getImportTypes {}",
				PersistenceConstants.METHOD_EXIT);
		return epaImportTypList;
	}

	/**
	 * This method fetch sorted list of Engine Provision Types
	 * 
	 * @return List of Provision types
	 */
	@Override
	public List<String> getProvisionTypes() {
		LOGGER.info("Entry method of getProvisionTypes {}",
				PersistenceConstants.METHOD_ENTRY);
		List<EpaProvisionType> epaProvisionTypes = null;
		List<String> epaProvTypList = null;
		if (null == MasterData.getProvisionTypeMap() || MasterData.getProvisionTypeMap().size() == 0) {
			epaProvisionTypes = epaProvisionTypeDAO.getAllImportProvisionList();
			for (EpaProvisionType provsnTyp : epaProvisionTypes) {
				MasterData.addprovisionType(provsnTyp.getProvisionTypeCode(),
						ServiceUtils.concatenate(provsnTyp.getProvisionTypeCode(), ServiceConstants.DOT,
								provsnTyp.getProvisionTypeDescription()));
			}
		}
		epaProvTypList = new ArrayList<String>(MasterData.getProvisionTypeMap().values());
		Collections.sort(epaProvTypList, new AlphanumComparator());
		LOGGER.info("Exit method of getProvisionTypes {}",
				ServiceConstants.METHOD_EXIT);
		return epaProvTypList;
	}

	/**
	 * This method fetch sorted list of Facilities for a user
	 * 
	 * @return List of facilities
	 */
	@Override
	public List<String> getfacilitiesForUser(String cwsId) {
		LOGGER.info("Entry method of getfacilitiesForUser {}",
				ServiceConstants.METHOD_ENTRY);
		Set<String> userFacilities = new HashSet<String>();
		List<String> usrFac = new ArrayList<String>();

		List<EpaUserAth> usrFacList = epaUserAthDAO.getLstEpaUserAthByCwsId(cwsId);
		for (EpaUserAth userFac : usrFacList) {
			userFacilities.add(ServiceUtils.concatenate(userFac.getEpaFac().getFacCd(), ServiceConstants.HIPHEN,
					userFac.getEpaFac().getFacilityName()));
		}
		usrFac.addAll(userFacilities);
		usrFac.remove(ServiceConstants.DEFAULT_FAC);
		Collections.sort(usrFac, new AlphanumComparator());
		LOGGER.info("Exit method of getfacilitiesForUser {}",
				ServiceConstants.METHOD_EXIT);
		return usrFac;
	}

	/**
	 * This method fetch sorted list of States
	 * 
	 * @return State of issue list
	 */
	@Override
	public List<String> getStateList() {
		LOGGER.info("Entry method of getStateList {}",
				ServiceConstants.METHOD_ENTRY);
		List<String> stateList = new ArrayList<String>();
		List<EpaState> stateOfIssueList = epaEngineDAO.getStateOfIssueList();

		for (EpaState epaState : stateOfIssueList) {
			stateList.add(ServiceUtils.concatenate(epaState.getId().getEpaStateCd(), ServiceConstants.HIPHEN,
					epaState.getEpaStateNme()));
		}
		Collections.sort(stateList, new AlphanumComparator());
		LOGGER.info("Exit method of getStateList {}",
				ServiceConstants.METHOD_EXIT);
		return stateList;
	}

	/**
	 * fetches Engine Manufacturer information
	 * 
	 * @return List of Engine Manufacturers
	 */
	@Override
	public List<String> getEngManufacturerList() {
		LOGGER.info("Entry method of getEngManufacturerList {}",
				ServiceConstants.METHOD_ENTRY);
		List<String> engMfrList = new ArrayList<String>();
		try {
			List<EpaDataCnfgr> engMfrEntityList = dataConfgDAO.getValueByCnfgrType(ServiceConstants.ID_MFR);
			String strMfr = engMfrEntityList.get(0).getCnfgrVal();
			engMfrList = ServiceUtils.convertStringToListByDel(strMfr, ServiceConstants.SEMI_COLON,
					ServiceConstants.FALSE);
		} catch (DaoException eMfr) {
			LOGGER.error("Error in getEngManufacturerList {}", PersistenceConstants.EXCP_GET_EPA_CNFG, eMfr);
		}
		Collections.sort(engMfrList, new AlphanumComparator());
		LOGGER.info("Exit method of getEngManufacturerList {}",
				ServiceConstants.METHOD_EXIT);
		return engMfrList;
	}

	/**
	 * Fetch all Facility code and Machine Facility name from the EPA Master
	 * Facility table
	 * 
	 * @return List of Facility code and Machine Facility name
	 */
	@Override
	public List<String> getAllMacFacilityCdNm() throws ServiceException {
		LOGGER.info("Entry method of getAllMacFacilityCdNm {}",
				ServiceConstants.METHOD_ENTRY);
		List<String> macFacCdNmList = new ArrayList<String>();
		List<EpaFac> epaFacList = null;
		String concatString = null;
		epaFacList = epaFacilityDAO.getAllFacilities();
		for (EpaFac epaFac : epaFacList) {
			concatString = epaFac.getFacCd() + ServiceConstants.HIPHEN + epaFac.getMachineMfrName();
			macFacCdNmList.add(concatString);
		}
		macFacCdNmList.remove(ServiceConstants.DEFAULT_FAC);
		Collections.sort(macFacCdNmList, new AlphanumComparator());
		LOGGER.info("Exit method of getAllMacFacilityCdNm {}",
				ServiceConstants.METHOD_EXIT);
		return macFacCdNmList;
	}

	/**
	 * This method fetch sorted list of Facilities and machine facility code for a
	 * user
	 * 
	 * @param cwsId Corporate login Id
	 * @return List of facilities
	 */
	@Override
	public List<String> getMacfacilitiesForUser(String cwsId) {
		LOGGER.info("Entry method of getMacfacilitiesForUser {}",
				ServiceConstants.METHOD_ENTRY);
		Set<String> userMachFacilities = new HashSet<String>();
		List<String> usrMacFac = new ArrayList<String>();

		List<EpaUserAth> usrFacList = epaUserAthDAO.getLstEpaUserAthByCwsId(cwsId);
		for (EpaUserAth userFac : usrFacList) {
			userMachFacilities.add(ServiceUtils.concatenate(userFac.getEpaFac().getFacCd(), ServiceConstants.HIPHEN,
					userFac.getEpaFac().getMachineMfrName()));
		}
		usrMacFac.addAll(userMachFacilities);
		usrMacFac.remove(ServiceConstants.DEFAULT_FAC);
		Collections.sort(usrMacFac, new AlphanumComparator());
		LOGGER.info("Exit method of getMacfacilitiesForUser {}",
				ServiceConstants.METHOD_EXIT);
		return usrMacFac;
	}

	/**
	 * Returns the list of approved EPA Form status for Selected Form status Mass
	 * Approval Feature
	 * 
	 * @param statusCd, List of selected Status code like
	 * @return List<String> contains the EPA Status code which are eligible. For
	 *         Ready to Approve. Like All the Not-started and Ready to Approve
	 *         Status Output is No Color - Not Started RED - NOT STARTED Orange -
	 *         Ready for approval Red - Ready for approval For Completed, Its
	 *         completed , Output is Green - Completed
	 */
	@Override
	public List<String> getAllStatusCdForDesc(List<String> statusCd) throws ServiceException {
		LOGGER.info("Entry method of getAllStatusCdForDesc {}", ServiceConstants.METHOD_ENTRY);
		List<String> filterStatCdList = new ArrayList<String>();
		List<EpaStatus> allEpaStatusList = null;
		try {

			allEpaStatusList = epaStatusDAO.getAllStatus();
			for (EpaStatus epaStatus : allEpaStatusList) {
				if (!ServiceUtils.isNullOrEmpty(epaStatus.getEpaStatusCd())
						&& ServiceUtils.containsString(epaStatus.getEpaStatusDesc(), statusCd)) {
					filterStatCdList.add(epaStatus.getEpaStatusDesc());
				}
			}
		} catch (DaoException e) {
			LOGGER.error("Error in getAllStatusCdForDesc {}", e.getMessage(), e);
			throw new ServiceException(e);
		}
		LOGGER.info("Exit method of getAllStatusCdForDesc {}", ServiceConstants.METHOD_EXIT);
		return filterStatCdList;
	}
}
