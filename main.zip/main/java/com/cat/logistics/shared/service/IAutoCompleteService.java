package com.cat.logistics.shared.service;

import java.util.List;

import com.cat.logistics.shared.exception.ServiceException;

/**
 * interface for AutoCompleteService 
 * @author ganamr
 *
 */
public interface IAutoCompleteService {
	/**
	 * @return list of facility codes
	 * @throws ServiceException
	 */
	public List<String> getAllFacilityCdNm() throws ServiceException;
	/**
	 * @return list of all status codes
	 * @throws ServiceException
	 */
	public List<String> getAllStatusCdDesc() throws ServiceException;
	/**
	 * @return list of all invoice no's
	 * @throws ServiceException
	 */
	public List<String> getAllInvoiceNos() throws ServiceException;
	/**
	 * @return list of order numbers
	 * @throws ServiceException
	 */
	public List<String> getAllEsos() throws ServiceException;
	/**
	 * @return list of provision types
	 */
	public List<String> getProvisionTypes();
	/**
	 * @return list of import types
	 */
	public List<String> getImportTypes();
	/**
	 * @param cwsId
	 * @return list facilities for user level
	 */
	public List<String> getfacilitiesForUser(String cwsId);
	/** 
	 * @return list of state list
	 */
	public List<String> getStateList();
	/**
	 * @return List of Engine Manufacturers
	 */
	public List<String> getEngManufacturerList();
	
	/**
	 * Fetch all Facility code and Machine Facility name from the EPA Master Facility table
	 * @return list of facility codes and machine facility name
	 * @throws ServiceException
	 */
	public List<String> getAllMacFacilityCdNm() throws ServiceException;
	/**
	 * This method fetch sorted list of Facilities and machine facility code for a user
	 * @param cwsId Corporate login Id
	 * @return facilities list
	 */
	List<String> getMacfacilitiesForUser(String cwsId);
	
	
	/**
	 * Returns the list of approved EPA Form status for Selected Form status Mass Approval Feature
	 * @param statusCd, List of selected Status code like
	 * @return List<String> contains the EPA Status code which are eligible.
	 * For Ready to Approve. Like All the Not-started and Ready to Approve Status
	 * 	Output is 
	  		No Color - Not Started
			RED - NOT STARTED
			Orange - Ready for approval
			Red - Ready for approval
	 * For Completed, Its completed , Output is Green - Completed
	 */
	public List<String> getAllStatusCdForDesc(List<String> statusCd)throws ServiceException;
	
	
}
