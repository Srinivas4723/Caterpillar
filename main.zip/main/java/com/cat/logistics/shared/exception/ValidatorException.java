package com.cat.logistics.shared.exception;

import java.util.List;


/**
 * Exception for validation failure 
 * 
 * @author singhr9
 */
public class ValidatorException extends Exception{

	private static final long serialVersionUID = -1177207235071207680L;

	private List<String> errorMsgs;
	private String errorCode;
	private Object object;

	
	/**
	 * ValidatorException
	 */
	public ValidatorException() {

	}

	/**
	 * @param errMsgs
	 */
	public ValidatorException(List<String> errMsgs) {

		this.errorMsgs = errMsgs;
	}

	/**
	 * @param errMsgs
	 * @param errorCode
	 */
	public ValidatorException(List<String> errMsgs, String errorCode) {
		this.errorMsgs = errMsgs;
		this.errorCode = errorCode;
	}
	
	/**
	 * @param errMsgs
	 * @param errorCode
	 * @param object
	 */
	public ValidatorException(List<String> errMsgs, String errorCode,Object object) {
		this.errorMsgs = errMsgs;
		this.errorCode = errorCode;
		this.object = object;
	}
	
	/**
	 * @param errMsgs
	 * @param object
	 */
	public ValidatorException(List<String> errMsgs, Object object) {
		this.errorMsgs = errMsgs;
		this.object = object;
	}

	/**
	 * @return error Msgs
	 */
	public List<String> getErrorMsgs() {
		return errorMsgs;
	}

	/**
	 * @param errorMsgs
	 */
	public void setErrorMsgs(List<String> errorMsgs) {
		this.errorMsgs = errorMsgs;
	}

	/**
	 * @return error Code
	 */
	public String getErrorCode() {
		return errorCode;
	}

	/**
	 * @param errorCode
	 */
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	/**
	 * @return the object
	 */
	public Object getObject() {
		return object;
	}

	/**
	 * @param object the object to set
	 */
	public void setObject(Object object) {
		this.object = object;
	}


	
}
