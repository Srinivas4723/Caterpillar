package com.cat.logistics.shared.exception;


/**
 * Exception for service layer 
 * 
 */
public class ServiceException extends Exception{

	private static final long serialVersionUID = -2924285332062795814L;

	/**
	 * Instantiates a new Service Exception.
	 */
	public ServiceException() {
		super();
	}

	/**
	 * Instantiates a new Service Exception.
	 *
	 * @param message the message
	 * @param cause the cause
	 */
	public ServiceException(String message, Throwable cause) {
		super(message, cause);
	}

	/**
	 * Instantiates a new Service Exception.
	 *
	 * @param message the message
	 */
	public ServiceException(String message) {
		super(message);
	}

	/**
	 * Instantiates a new Service Exception.
	 *
	 * @param cause the cause
	 */
	public ServiceException(Throwable cause) {
		super(cause);
	}
	
}
