package com.cat.logistics.shared.utils;

import java.util.Arrays;
import java.util.List;

/**
 * This class holds String literal values used over Persistent layer
 * 
 * @author ganamr
 * 
 */
public interface PersistenceConstants {

	static final String SUPP_LOAD_ALIAS = "suppLoad";
	static final String FACILITIES = "FACILITIES";
	static final String FACILITY = "FACILITY";
	static final String MCH_SER_NUM = "MCH_SER_NUM";
	static final String MCH_PART_NUM = "MCH_PART_NUM";
	static final String SHP_DATE = "SHP_DATE";
	static final String INVOICE_ID = "INVOICE_ID";
	static final String ROLES = "ROLES";
	static final int ZERO = 0;
	static final int SEVENTEEN = 17;
	static final String ASTERISK = "*";
	static final CharSequence SPACE = " ";
	static final CharSequence EMPTY_STRING = "";
	static final String STR_SPACE = " ";
	static final String TWO_SPACES = "  ";
	static final String COMMA = ",";
	static final String ROLES_CACHED = "ROLES_CACHED";
	static final String FACILITIES_CACHED = "FACILITIES_CACHED";
	static final String HIPHEN = "-";
	static final String VALID_EPA_USERS = "VALID_EPA_USERS";
	static final String FULL_STOP = ".";
	static final String YES = "YES";

	static final String IS_ASSIGNED = "is assigned to both ";
	static final String AND = "AND";
	static final boolean TRUE = true;
	static final boolean FALSE = false;
	static final String ALPHA_Y = "Y";
	static final String Y_ALPHABET = "Y";
	static final String M_VAR = "M";
	static final String E_VAR = "E";
	static final String NO = "NO";
	static final String MSO = "MSO";
	static final String AUTOCOMPLETE_NEW_LINE = "[ ]*,[\\r\\n]*[ ]*";
	static final String LOGON_ID = "LOGON_ID";
	static final String USER_NAME = "USER_NAME";
	static final String PROD_GRP_ADMIN = "PROD_GRP_ADMIN";
	static final String ALPHA_N = "N";
	static final int FIVE = 5;
	static final int ONE = 1;
	static final String USER_FAC = "USER_FAC";
	static final String UNDERSCORE = "_";
	static final String BUILT = "BUILT";

	/* EPA MACHINE DAO CONSTANTS */
	static final String FAC_CD_VAR = "epaFac.facCd";
	static final String ORD_NUM_VAR = "orderNum";
	static final String MACH_SER_NUM_VAR = "machineSerialNum";
	static final String ENG_SER_NUM_VAR = "engineSerialNum";
	static final String ORG_SHP_DT = "origShipDate";
	static final String EPA_PROD_TYP = "epaProdTypeCode";
	static final String MACHINE_VAR = "M";
	static final String MTD_IS_EPA_MCHNO = "isEpaMachineNumber";
	static final String MTD_UPD_MCH_NUM = "updateMachineNumber";
	static final String EPAMCH_UPD_MCHNUM = "EpaMachine.updateMachineNum";
	static final String MCH_NUM = "machineNumber";
	static final String MTD_SEARCH_MCH_SHIP = "searchMachineShipments";
	static final String EPA_MCH = "epaMachine";
	static final String EPA_MCH_MFR_DATE = "epaMachine.mchMfrDate";
	static final String MTD_GET_ENG_BY_STATUS = "getEnginesListByStatusList";
	static final String EPA_STATUS = "epaStatus";
	static final String EPA_STAT = "epaStat";
	static final String EPA_STATCD = "epaStat.epaStatusCd";
	static final String MTD_GET_ENGINES = "getEngines";

	// EPAATHLVLDAO
	static final String ATH_LVL_DESC_VAR = "epaAthLvlDesc";
	static final String EXCP_ROLE_BY_DESC = "Exception reading AthLvlDesc";
	static final String EXCP_GET_ALL_ROLES = "Exception reading Auth Levels";
	static final String EXCP_GET_AUTH_DESC = "Exception reading Auth Descriptions";
	static final String MTD_ROLE_BY_DESC = "getRoleByDescription";
	static final String MTD_GET_ALL_ROLES = "getAllRoles";
	static final String MTD_GET_ATH_DESC = "getAuthorityDescriptions";

	// EPACONFIGDAO
	static final String MTD_GET_EPA_CNFG = "getEpaConfig";
	static final String MTD_GET_SUPRT_MAILS = "getSupportMails";
	static final String MTD_LOG_PRCS_TM = "logProcessTimes";
	static final String MTD_GET_JO_FREQ = "getJobFreq";
	static final String MTD_GET_HTS_FREQ = "getHtsJobFreq";
	static final String MTD_GET_LST_SCCS = "getLstSccsTm";
	static final String MTD_SAVE_LST_SCCS_TM = "saveLstSccsTm";
	static final String EXCP_GET_EPA_CNFG = "Exception reading config data";
	static final String EXCP_GET_VAL_BY_CFG_TYP = "Exception reading config data";
	static final String EXCP_GET_SUPRT_MAILS = "Exception reading support mail ids";
	static final String EXCP_LOG_PRCS_TM = "Exception loggingg start/end timestamps";
	static final String EXCP_JOB_FRQ = "Exception reading job freq";
    static final String MTD_GET_IGNR_FAC_LIST = "getIgnrFacList";

	// CONFIGDATADAO
	static final String MTD_GET_CNFG_DTA = "getConfigData";
	static final String EXCP_GET_CNFG_DTA = "Exception reading nonclassifiable parts data";
	
	// HTSCodeDAO 
	static final String HTS_CD_MNTR = "getHtsChngdParts";
	static final String EXCP_HTS_CD_MNTR = "Exception reading hts clsfc records";
	
	// HELPER
	static final String STA_CRI = "statusCriteria";
	static final String FETCH_MCH_INFO = "fetchMsngInfo";
	static final String ADD_SHPM_CRI = "addShmntCrit";
	static final String ADD_LIST_CRI = "addListCrit";
	static final String ADD_DT_CRI = "addDtCrit";

	// PARTSERIALDAO
	static final String MTD_GET_PART_SER_NUM = "getPartSerialNums";
	static final String EXCP_GET_PART_SER_NUM = "Exception reading part serial numbers";

	// SHPMNTDAO
	static final String MTD_GET_SHPMNTS = "getShipmentParts";
	static final String MTD_GET_SHPMNT_ENG = "getShipmentEngineInfo";
	static final String EXCP_GET_SHPMNTS = "Exception reading shipment parts from TIS";
	static final String EXCP_GET_SHPMNT_ENG = "Exception fetching shipment engine records	";

	/* BATCH JOB CONSTANTS */
	static final String LAST_UDT_TS_VAR = "lstTm";
	static final String SUPP_LAST_UDT_TS_VAR = "lastUpdtTmstmp";
	static final String SUPP_LD_ORIG_CTRY_CD_VAR = "suppLoad.originCtry";
	static final String SUPP_LD_ORIG_FAC_CD_VAR = "suppLoad.origFacCd";
	static final String SUPP_LD_DEST_CTRY_CD_VAR = "suppLoad.destCtry";
	static final String SUPP_RECV_FAC_CD_VAR = "rcvgFac";
	static final String SUPP_LD_ALIAS = "suppLoad";
	static final String SUPP_LD_LAST_UPDT_TMS = "suppLoad.lastUpdtTmstmp";

	static final String CTRY_CD_US = "US";
	static final String CODE_TYP_VAR = "cdTyp";
	static final String CD_TYP_237 = "237";
	static final String CD_KEY_VAL_VAR = "cdKeyVal";
	static final String PRT_NUM_PART_ID_VAR = "partId";
	static final String PRT_NUM_SEQ_VAR = "seqNum";
	static final String PRT_NUM_SUPP_CD_VAR = "suppCd";
	static final String PRT_NUM_LD_TMSTMP_VAR = "suppLdTmstmp";
	static final String PRT_NUM_INVC_NUM_VAR = "invoiceNum";
	static final String PRT_NUM_VAR = "partNumber";
	static final String EXCPT_HTS_CD = "excpHtsCode";
	static final String EPA_BATCH_JOB = "EPA_BATCH_JOB";
	static final String EPA_BATCH_JOB_WND = "EPA_BATCH_JOB_WNDS";
	static final String HTS_BATCH_JOB = "HTS_BATCH_JOB";
	static final String JOB_STATUS = "JOB_STATUS";
	static final String JOB_PROCESS_TIMES = "JOB_PROCESS_TIMES";
	static final String RUN_TIMES = "RUN_TIMES";
	static final String IGNR_FAC_LIST = "IGNR_FAC_LIST";
	static final String ALLOW_ORG_FAC_LIST = "ALLOW_ORG_FAC_LIST";
	static final String KEY_DESC = "Batch job start/end timestamps";
	static final String JOB_RUN_FREQ = "JOB_RUN_FREQUENCY";
	static final String JOB_RUN_TIMES = "JOB_RUN_TIMES";
	static final String LST_SUCCS_TM = "LST_SUCCS_TM";
	static final String SUCCESS = "SUCCESS";
	static final String ID_KEY_TYPE = "id.keyType";
	static final String ID_CONFIG_TYPE = "id.configType";
	static final String SUPPORT_MAIL_IDS = "SUPPORT_MAIL_IDS";
	public static final String THE_APPLICATION = "EPA";
	public static final String LOG_PROPERTIES = "properties/epa_batch_log";
	public static final String METHOD_ENTRY = "Entry to Method ";
	public static final String METHOD_EXIT = "Exit from Method ";
	public static final String PROCESS_SER_SEQ_NO = "Processing For Engine/Machine/Sequence/Control No:";
	public static final String FRW_SLASH = "/";
	public static final String EN = "EN";
	public static final String STATUS_CD = "STATUS_CD";
	public static final String MISSING_DATA = "MD";
	public static final String STATUS_COLOR = "STATUS_COLOR";
	public static final String RED = "Red";
	public static final String ORANGE = "Orange";
	public static final String GREEN = "Green";
	public static final String NO_COLOR = "No color";
	public static final String SUBMITTEDTOBROKER = "STB";
	public static final String MISSING_INFO = "MI";
	public static final String COMPLETED = "CMP";

	/* EPA ENGINE DAO CONSTANTS */
	static final String MTD_GET_STATEOF_ISSUE_LIST = "getStateOfIssueList";
	static final String EPA_STATE_FINDALL = "EpaState.findAll";
	static final String MTD_SAVE_ENGINE_INFO = "saveEngineInfo";
	static final String MTD_SAVE_ENGINE_INFO_LIST = "saveEngineInfoList";
	static final String MTD_UPDATE_ENGINE_NUMBER = "updateEngineNumber";
	static final String EPA_ENGINE_UPDATE_ENGINENUM = "EpaEngine.updateEngineNum";
	static final String ENGINE_NUMBER = "engineNumber";
	static final String EPA_SEQ_NO = "epaSeqNo";
	static final String MTD_GET_ENGINE_INFO = "getEngineInfo";
	static final String MTD_GET_EPAENGINE_NUMBERS = "getEpaEnginesNumbers";
	static final String EPA_SHIPMENT = "epaShipment";
	static final String EPA_SHIPMENT_SEQ_NO = "epaShipment.epaSeqNum";
	static final String MTD_IS_EPAENG_NUM = "isEpaEngineNumber";
	static final String MTD_SEARCH_ENG_SHIPMNTS = "searchEngineShipments";
	static final String EPA_ENGINES = "epaEngines";
	static final String EPA_ENG = "epaEngine";
	static final String EPA_ENG_MNF_DATE = "epaEngine.epaEngineMnfDate";
	static final String MTD_ADD_ENG_SHIPNT_CRI = "addEngShmntCrit";
	static final String MTD_IS_RCRD_EXIST = "isRecordsExists";
	static final String RCD_LAST_UPD_LOGON_ID = "rcdLog.lastUpdtLogonId";
	static final String EPA_STATUS_CD = "epaStatus.epaStatusCd";

	/* EPA SHIPMENT DAO CONSTANTNTS */
	static final String MTD_GET_EPA_SHIP_BY_MCHORENG = "getEpaShipmentbyMachOrEngNum";
	static final String EPA_MACHINS = "epaMachines";
	static final String EPA_SEQ_NUM = "epaSeqNum";
	static final String MTD_GET_ALL_INVC = "getAllInvoiceNo";
	static final String MTD_GET_ALL_ESO = "getAllEsos";
	static final String MTD_INSERT_SHIP_ENGMCH = "insertShipmentEngMch";

	String MTD_INSERT_SHIP_ENGMCH_LIST = "insertShipmentEngMchList";

	static final String MTD_SAVE_ENGMCH = "saveEngMch";
	static final String MTD_SET_ENGMCH = "setEngMach";
	static final String MTD_MERGE_SHIP_ENGMCH = "mergeShipmentEngMch";
	static final String MTD_EPA_SHIP_BY_SEQNO = "getEpaShipmentBySeqNum";
	static final String MTD_CHECK_FOR_SHIP = "checkForShpmnt";
	static final String PART_NUM = "partNum";
	static final String SUPP_LD_TS = "suppLdTs";
	static final String SUPP_ITEM_SEQNO = "suppItemSeqNum";

	/* EPA FACILITY DAO CONSTANTS */
	static final String MTD_GET_ALL_FACILIS = "getAllFacilities";
	static final String MTD_GET_ALL_FAC_CODES = "getAllFacilityCodes";
	static final String FAC_CD = "facCd";
	static final String MTD_GET_FAC_DETAIL = "getFacilityDetail";
	static final String MTD_GET_FAC = "getFacility";
	static final String EPA_USER_ATHS = "epaUserAths";
	static final String MTD_GET_FAC_DESC = "getfacilityDesc";
	static final String FAC_NAME = "facilityName";
	static final String MTD_FAC_BY_SUPPCD = "getFacBySuppCd";

	/* SHIPMENT DAO CONSTANTS */
	static final String MTD_GET_SHIP_PARTS = "getShipmentParts";
	static final String MTD_GET_SHIP_ENGINFO = "getShipmentEngineInfo";

	/* EPA HTS CNFGR DAO CONSTANTS */
	static final String HTS_CD = "htsCode";
	static final String MTD_HTS_CONFGR_BY_CD = "getHtsConfgrByCode";
	static final String MTD_HTS_CONFGR_BY_CDS = "getHtsConfgrByCodes";
	static final String EXCP_HTS_CONFGR_BY_CD = "Exception reading hts config by code";
	static final String EXCP_HTS_CONFGR_BY_CDS = "Exception reading hts config by codes";

	/* EPA HTS EXCP CNFGR DAO CONSTANTS */
	static final String MTD_EP_HTS_EXCP_CONFGR = "getEpHtsExcpConfgr";
	static final String EXCP_EP_HTS_EXCP_CONFGR = "Exception reading EPA hts config by code";

	/* EPA IMPORT TYPE DAO CONSTANTS */
	static final String MTD_GET_ALL_IMPORT_CD_LST = "getAllImportCodeList";
	static final String MTD_GET_IMPORT_DESC = "getImportDesc";
	static final String IMPORT_TYPE_CD = "importTypeCode";
	static final String IMPORT_TYPE_DESC = "importTypeDescription";

	/* EPA PROVISION TYPE DAO CONSTANTS */
	static final String MTD_GET_ALL_IMPORT_PROVISION_LST = "getAllImportProvisionList";
	static final String MTD_GET_IMPORT_PROVISION_DESC = "getImportProvisionDesc";
	static final String EXCP_GET_IMPORT_PROVISION_DESC = "Exception reading import provision desc";
	static final String PROVISION_TYPE_CD = "provisionTypeCode";
	static final String PROVISION_TYPE_DESC = "provisionTypeDescription";

	/* EPA STATUS DAO CONSTANTS */
	static final String MTD_GET_ALL_STATUS = "getAllStatus";
	static final String EXCP_GET_ALL_STATUS = "Exception getting all status";
	static final String MTD_GET_ALL_STATUS_CD_DESC = "getAllStatusCdDesc";

	/* EPA USER AUTH DAO CONSTANTS */
	static final String MTD_GET_LST_EPA_USERATH_BY_CWSID = "getLstEpaUserAthByCwsId";
	static final String MTD_GET_LST_EPA_USERATH_BY_CWSID_FAC = "getLstEpaUserAthByCwsIdAndFacilty";
	static final String MTD_GET_PAG_LST_EPA_USERATH = "getPaginationLstEpaUserAth";
	static final String MTD_GET_ROW_COUNT = "getRowCount";
	static final String MTD_GET_EPA_USER_AUTH = "getEPAUserAuthorities";
	static final String MTD_GET_FAC_BY_CWSID_ROLE = "getFacilitiesByCwsIdRole";
	static final String MTD_DELETE = "delete";
	static final String MTD_GET_LST_EPA_USERATH_BY_CWSIDROLE_FAC = "getLstEpaUserAthByCwsIdRoleFacility";
	static final String MTD_SAVE_USER_AUTH = "saveUserAuthorties";
	static final String MTD_DELETE_BY_USERID = "deleteByUserId";
	static final String MTD_GET_NON_ADM_FAC_AUTH = "getNonAdminFacilityAuthorities";
	static final String EPA_USER = "epaUser";
	static final String EPA_FAC = "epaFac";
	static final String EPA_USER_CWSID = "epaUserCwsId";
	static final String ID_EPA_USER_CWSID = "id.epaUserCwsId";
	static final String ID_EPA_ATHLVL_CD = "id.epaAthLvlCd";
	static final String ID_FAC_CD = "id.facCd";
	static final String EPAUSER_EPA_USER_CWSID = "epaUser.epaUserCwsId";
	static final String EPAFAC_FAC_CD = "epaFac.facCd";
	static final String EPA_ATH_LVL = "epaAthLvl";
	static final String EPA_ATHLVL_EPA_ATHLVL_CD = "epaAthLvl.epaAthLvlCd";

	/* EPA USER DAO CONSTANTS */
	static final String MTD_GET_EPA_USER_BY_USERNAME = "getEpaUserByUserName";
	static final String MTD_USER_EXISTS = "userExists";

	/* USER ROLE ACCESS DAO CONSTANTS */
	static final String MTD_GET_EPA_ACCESS_LST = "getEPAAccessList";
	static final String MTD_GET_EPA_AUTH_ACC_LVLS = "getEPAAuthorityAccessLevels";

	/* EPA DATA CONFIG DAO CONSTANTS */
	static final String MTD_GET_ENG_MFR_LST = "getEngMfrList";
	static final String MTD_GET_VAL_BY_CFG_TYP = "getValueByCnfgrTypes";

	String MTD_GET_CNFGR_TYPES = "getValueByCnfgrTypes";
	static final String DATA_CONFIG_TYPE = "id.cnfgrTyp";

	static final String ENG_SER_NUM = "id.engineSerialNum";
	static final String MCH_SER_NUM_ID = "id.machineSerialNum";
	static final String CHCK_ENGSHIP_CMP_STB = "checkEngShipIsCMPORSTB";
	static final String DEL_SHIPMNTS_BY_SEQNUM = "deleteShipmtsbySeqNum";
	static final String IS_ENGSHIP_STATUS_CMP_STB = "isEngShipStatusCmpORStb";
	static final String DEL_SHIPMNTS = "deleteShipments";
	static final String CNFGR_VALUE = "cnfgrVal";

	static final String SUMMARIZE_ALLOC_AMT = "summarizeAllocationAccount";
	static final String GET_ALLOCATIONS_PROCESSING = "getAllocationsForProcessing";

	// ACH Constants
	public static final int INT_0 = 0;
	public static final int INT_1 = 1;
	public static final int INT_2 = 2;
	public static final int INT_3 = 3;
	public static final int INT_4 = 4;

	public static final String ACH_PMT_REF_NO = "pk.pmtRefNo";
	public static final String ACH_SHIPMENT_REF_NO = "shpRefNo";
	public static final String ACH_PMT_TYPE = "pk.pmtTyp";
	public static final String ACH_SUPP_IND = "pk.suplInd";
	public static final String ACH_PMT_REF_DATE = "pmtRefDt";

	public static final String ACH_TOT_ENT_AMT = "totEntAmt";
	public static final String ACH_IMP_ENT_NO = "id.impEntNo";
	public static final String ACH_PMT_YR = "acctgYr";
	public static final String ACH_PMT_MON = "acctgMo";
	public static final String ACH_PMT_WEEK = "acctgOrdInd";
	public static final String ACH_PRC_IND = "procInd";
	public static final String ACH_DIST_AMT = "acctDistAmt";
	public static final String ACH_GRIEF_PRC_IND = "G";
	public static final String ACH_PRCSD_PRC_IND = "P";

	public static final String ACH_ACCT_FAC_CD = "acctFacCd";
	public static final String ACH_GL_CTL_ACCT_NO = "glCtlAcctNo";
	public static final String ACH_GL_SUB_ACCT_NO = "glSubAcctNo";
	public static final String ACH_GL_SUB_SUB_ACCT_NO = "glSubSubAcctNo";

	public static final String SRCH_GRV_PMT = "searchGrievedPayments";
	public static final String GET_DIST_YYMMWEEK = "getDistinctYyMmWe";
	public static final String SRCH_PMT_SMRY = "searchPaymentSummary";
	public static final String UPDT_PMT_SMRY = "updatePaymentSummary";
	public static final String EMP_STRING = "";

	public static final String FLD_FACILITY_CODE = "facCode";
	public static final String FLD_JRNL_ETRY = "journelEntry";
	public static final String FLD_IP_NUM = "ipEntryNumber";
	public static final String FLD_EFF_DT = "effectDate";
	public static final String FLD_OBSRV_DT = "obsertionDate";
	public static final String FLD_JENTY_EFF_DT = "effectiveDate";
	public static final String FLD_JENTY_OBS_DT = "observationDate";
	public static final String FLD_JENTY_FAC_CODE = "facilityCode";

	public static final String FLD_CTR_ACC_NO = "cntrlAccountNum";
	public static final String MTD_IS_VLD_FAC = "isValidFacilityCode";
	public static final String FLD_SUB_ACC_NO = "subAccountNum";
	public static final String SUB_SUB_ACC_NO = "subSubAccountNum";

	public static final String MTD_SRCH_ACC_DIS = "searchAccountingDistribution";
	public static final String MTD_TOT_AMT = "getTotalPaymentAmt";
	public static final String MTD_DIS_SRCH_DT = "getDistinctSearchData";
	public static final String MTD_ADD_ALLOC = "addPaymentAllocation";
	public static final String MTD_UPD_ALLOC = "addPaymentAllocation";
	public static final String SELECT = "Select";
	static final String UPDATE_PROC_IND = "PmtAllocDta.updateProcInd";
	static final String NEW_PROC_IND = "newProcInd";
	static final String YEAR = "year";
	static final String MONTH = "month";
	static final String WEEK = "week";
	static final String YEARQUERY = "yearQuery";
	static final String MONTHQUERY = "monthQuery";
	static final String ACH_PMT_WEEK_QUERY = "acctgOrdIndquery";
	static final String PAYMENT_TYPE = "paymentType";
	static final String PROC_IND = "procInd";
	static final String GL_GET_ALLOCATIONS_FOR_GL_PROCESSING = "getAllocsForGLProcess";
	static final String GL_GET_MONTH_YEAR = "getMonthAndYear";
	static final String UPDATE_PMT_ALLOC_DTA_FOR_ROLLOVER_GRIEFS = "PmtAllocDta.updateForRollOvrAndGrief";
	static final String UPDATE_PMT_ALLOC_DTA_ROLL_GRIEF = "PmtAllocDta.updateForRollOver";
	static final String GL_UPDATE_PMT_ALLOC_RECORDS = "updatePmtAllocRecords";
	static final String MTD_IS_VAL_ACC = "isvalidAccountCode";
	public static final String ACH_GL_YEAR = "acctgYr";
	public static final String ACH_GL_MONTH = "acctgMo";
	static final String GL_PMT_ALLOC_UPDATE_PMTS_POSTED_GL = "PmtAllocDta.updateForPmtsPostedToGL";
	public static final String MTD_LOG_END_TM = "logEndTime";
	public static final String MTD_SRCH_JOB_STATUS = "srchJobWthStatus";
	public static final String PK_APP_NM = "pk.appNm";
	public static final String PK_PROC_NM = "pk.procNm";
	public static final String STAT_IND = "statInd";
	static final String SUM_AMT = "sumAmount";
	static final String CURR_TIM_STMP = "currTimStmp";
	static final String LAST_UPD_TIM_STMP = "lastUpdTimStmp";
	static final String LOGONID = "logonId";
	static final String RESET_PROC_IND = "resetProcInd";
	static final String CWC_LOG_ID = "crtLoginId";
	static final String UPDATE_ALLOC_DATA = "updateAllocationData";
	static final String UPDATE_ALLOC_DATA_ROLL = "updatePmtAllocRecordsRollover";
	static final String FETCH_ALL_CNFG_DTA = "fetchAllAccConfigData";
	static final String FETCH_CNFG_TBL_DTA = "fetchConfigTableData";
	static final String CNFGR_TBL_DTA_PK_ID = "id.cnfgrDtaKey";
	static final String CNFGR_TBL_PK_ID = "id.cnfgrTblKey";
	static final String PMT_REF_NO = "pmtRefNo";
	static final String PROC_IND_P = "P";
	static final String CNFGR_DTA_KEY = "cnfgrDtaKey";
	static final String APP_NAME = "id.appName";
	static final Object GL = "GL";
	static final String KEY = "KEY";
	static final String VALUE = "VALUE";
	static final String CNFGR_DATA = "cnfgrData";
	static final String PROC_IND_R = "R";
	static final String CNFGR_SEQ_NO = "id.cnfgrSeqNo";
	public static final long LONG_1 = 1;
	static final String MAIL_USR_GRP = "BUSINESS";
	static final Object FAC_SUM_ACCT_NO_DUTY = "FAC_SUM_ACCT_NO_DUTY";
	final static int HASHCODE = 17;
	static final String GET_BLD_DT_ODS_STG_VW = "getBldDtFrmOdsStgVw";
	static final String GET_BLD_DT_ODS_STG_HIST_VW = "getBldDtFrmOdsStgHistVw";
	static final String GET_BLD_DT_MDW_DET_HIST = "getBldDtFrmMdwBldDetHist";
	static final String SER_NUM_PRFIX = "serialNumPrefix";
	static final String SER_NUM_BODY = "serialNumBody";
	static final String BLD_DATE = "buildDate";

	String RCDLOG_LASTUDT_TS = "rcdLog.lastUpdtTs";
	String INVLD_VALUE = "INVALID VALUE";
	String ALIS_EPA_STATUS = "epaEngines.epaStatus";
	String CMP_VAR = "CMP";
	/* FTA MASSUPLD CONSTANTS */
	static final String FTA_MANUL_UPLD = "SOLICIT";
	static final String VAR_N = "N";
	static final String MTD_SAVE_SOLICIT_DTA = "saveSolicitReqData";
	static final String MTD_SAVE_DUTY_DTA = "saveDutyRateData";
	static final String MTD_GET_DUPL_SOLICTLIST = "getDupSolctList";
	static final String MTD_GET_DUPL_DUTYRATE = "getDupDutyRateList";
	static final String MTD_GET_DUTYRATE_LIST = "getDutyRateList";
	static final String MTD_DLT_DUTYRATE_LIST = "deleteDutyRateList";
	static final String MTD_CHK_DUTYRATE_LIST = "checkuDupDutyRate";
	static final String PR_KEY_ID = "id";
	static final String PR_ID_CTRY = "id.ctryCd";
	static final String PR_CTRY_CD = "ctryCd";
	static final String PR_ID_HTS = "id.htsCd";
	static final String DTY_RATE = "dutyRate";
	static final String MTD_GET_CERT_TYPELIST = "getCertTypeList";
	static final String CNFGR_ID = "id.cnfgrId";
	static final Object KEY_CERT_TYPE = "VALD_AGRMNT_TYP";
	static final Object FAC_CODE_LIST = "BA_FAC_PLANT_XREF";
	static final String FTA_CNFGR_VALUE = "cnfgrData";
	static final Object KEY_PART_TYPE = "VALD_PART_TYP";
	static final Object KEY_EXCL_CTRY = "XCLD_DUTY_CTRY";
	static final String MTD_GET_PART_TYPELIST = "getPartTypeList";
	static final String MTD_GET_EXC_CTRY_LST = "getExcCtryList";
	static final String MTD_GET_SUPP_DATA = "getSuppTData";
	static final String ALPHA_L = "L";
	static final String ALPHA_G = "G";
	static final String ALPHA_C = "C";
	static final String ALPHA_R = "R";
	static final String SUPP_CD = "suppCd";
	static final String ADR_TYPE = "adrTyp";
	static final String SUPP_CD_TYPE = "suppCdTyp";

	// TPP constants
	public static final String MTHD_GET_REGIONS = "getAllRegions";
	public static final String MTHD_SRCH_TPP_USERS = "srchTppUsers";
	public static final String MTHD_SRCH_REGION_FLDS = "searchRegionFields";
	public static final String MTHD_GET_REGION_ID = "getRegionId";
	public static final String MTHD_MSTR_CONFIG_FLDS = "getMasterConfigFields";
	public static final String TPP_REGION_ID = "pk.regionId";
	public static final String TPP_REGION_NAME = "regionName";
	public static final String MTHD_DEL_REGION_FLDS = "deleteRegionFlds";
	public static final String REGION_ID = "regionId";
	public static final String DEL_REGION_FLDS_DET = "RegionField.delRegFldsDetail";
	public static final String MTHD_SAVE_FLDS = "saveAssignedFields";
	public static final String MTHD_GT_ALL_AVL_FLDS = "getAllAvailbleFlds";
	public static final String MTHD_UPDT_HDR = "updtHeader";

	public static final String MTD_GT_COUNTRY_OF_LOAD_LST = "getCountryOfLoadLst";
	public static final String MTD_GT_ASSGND_REGN_USER = "getAssgndRegnsOfUser";
	public static final String MTD_GT_REGN_FLDS_FR_HDR = "getRegnFldsForHeader";
	public static final String MTD_GT_REGN_FLDS_FR_DTL = "getRegnFldsForDtls";
	public static final String DESK_ID_FK = "desk.deskId";
	public static final String DESK_ID_PK = "deskId";
	public static final String DESK_NM = "deskName";
	public static final String FLD_ID_PK = "fldId";
	public static final String FLD_NM = "fldNm";
	public static final String REGN_CLCTN = "regionFieldCollection";

	public static final String MTD_GT_TRNSPORT_MODE_LIST = "getTransportModeList";
	public static final String MTD_GT_CNTRY_OF_LOAD_LST = "getCountryOfLoadList";
	public static final String MTD_GT_NOTE_CD_LST = "getNoteCodesList";
	public static final String MTD_GT_FRCST_DMSTC_CTGRY_LST = "getFrcstdDmstcCtgryList";
	public static final String MTD_LD_FRCST_WQ = "loadForeCastWQ";
	public static final String MTD_LD_FRCST_DTLS = "loadForeCastDetails";
	public static final String MTD_SAVE_FRCST_DTLS = "saveFrcstDtls";
	public static final String MTD_GT_DFLT_REGN = "getDfltRegn";
	public static final String MTD_GT_DFLT_DESK_FOR_REGN = "getDfltDeskFrRegn";
	public static final String MTD_GT_STATUS_LST = "getStatusLst";
	public static final String TPP_TRANS_MNGR = "transactionManagerTPP";
	public static final String USER_ID = "userId";
	public static final String REGN = "region";
	public static final String DESK = "desk";
	public static final String DEF_REGN = "defRegion";
	public static final String DEF_DESK = "defDesk";
	public static final String MTD_GT_CBM_SQM_VAL = "getCbmAndFrcstSQMValOfShpmnt";
	public static final String PPM_SHP = "ppmShp";
	public static final String PPM_SHP_ALIAS = "ppmShpAlias";
	public static final String PPM_SHP_SHP_NO = "ppmShp.id.ppmShpNo";
	public static final String PPM_SHP_SRS_SYS_ID = "ppmShp.id.srcSysId";
	public static final String PPM_CNTR_WIDE = "genPpmCntrDet.ppmCntrWide";
	public static final String PPM__CNTR_LGTH = "genPpmCntrDet.ppmCntrLgth";
	public static final String PPM_CNTR_HGT = "genPpmCntrDet.ppmCntrHgt";
	public static final String CNTR_LGTH = "ctrlLngth";
	public static final String CNTR_HGT = "ctrlHgt";
	public static final String CNTR_WIDE = "ctrlWide";
	public static final String TPP_USER_ID = "userId";
	public static final String SEL_USR_REGION = "USER_REGION.getAssignedRegion";
	public static final String MTHD_SRCH_USR_REGNS = "searchUserRegions";
	public static final String EXC_SRCHUSR_REGNS = "Exception occurred while fetching assigned regions for ";

	public static final String MTD_PPM_SHP_DTLS = "getPpmShpDtls";
	public static final String MTD_UPD_PPM_SHP_DTLS = "updatePpmShpDtls";
	public static final String ID = "id";
	public static final String String_7 = "7";
	public static final String ALL = "ALL";
	public static final String COL_ID = "colId";
	public static final String COL_NM = "colName";
	public static final String CNTRY_OF_LD = "cntryOfLdId";
	public static final String CNTRY_OF_LD_NM = "cntryOfLdName";
	public static final String FRSCT_DOM_CTGRY_ID = "frcstDomCtgryId";
	public static final String FRSCT_DOM_CTGRY_NM = "frcstDomCtgryName";
	public static final String FRSCT_DM_CTGRY_ID = "frcstdDmstcCtgryId";
	public static final String FRSCT_DM_CTGRY_NM = "frcstdDmstcCtgryName";
	public static final String NT_CDS_ID = "noteCodesId";
	public static final String NT_CDS_NM = "noteCodesName";
	public static final String PPM_SHP_FRSCT_DET = "ppmFrsctDets";
	public static final String PPM_FRSCT_DET_ALS = "ppmFrsctDetAlias";
	public static final String PPM_SHP_RLSE_DET = "ppmRlseDets";
	public static final String PPM_SHP_BOOK_DET = "ppmBookDets";
	public static final String PPM_RLSE_DET_ALS = "ppmRlseDetAlias";
	public static final String PPM_BOOK_DET_ALS = "ppmBookDetAlias";
	public static final String PPM_FRSCT_STAT = "ppmFrsctDetAlias.frsctStat";
	public static final String SRS_SYS_ID = "id.srcSysId";
	public static final String SHP_SRC = "shipSource";
	public static final String SHP_NO = "id.ppmShpNo";
	public static final String PPM_SRC_SYS_ID = "srcSysId";
	public static final String PPM_SHP_NO = "ppmShpNo";
	public static final String FRSCT_MSO = "mso";
	public static final String LST_CRTE_DT_TM = "lastCrteDtTm";

	public static final String FRSCT_ALS_TRNSP_MD = "ppmFrsctDetAlias.frsctTrnspModeCd";
	public static final String RLSE_ALS_TRNSP_MD = "ppmRlseDetAlias.rlseTrnspModeCd";
	public static final String BOOK_ALS_TRNSP_MD = "ppmBookDetAlias.bookTrnspModeCd";
	public static final String TRNSP_MD = "transportMode";
	public static final String FRSCT_ALS_DOM_CTGRY = "ppmFrsctDetAlias.frcstDomCtgry";
	public static final String RLSE_ALS_DOM_CTGRY = "ppmRlseDetAlias.rlseDomCtgry";
	public static final String BOOK_ALS_DOM_CTGRY = "ppmBookDetAlias.bookDomCtgry";
	public static final String FRSCT_DOM_CTGRY = "domesticCategory";
	public static final String FRSCT_ALS_DOM_CARR_NM = "ppmFrsctDetAlias.frsctDomCarrNm";
	public static final String RLSE_ALS_DOM_CARR_NM = "ppmRlseDetAlias.rlseDomCarrNm";
	public static final String BOOK_ALS_DOM_CARR_NM = "ppmBookDetAlias.bookDomCarrNm";
	public static final String FRSCT_DMSTC_CARR = "domesticCarrier";
	public static final String PRT_ENT_CTRY = "ppmShpCommonProps.prtEntCtry";
	public static final String CNTR_OF_LD = "countryOfLoad";
	public static final String SCAC_CD = "ppmShpCommonProps.scacCd";
	public static final String OCEN_CARR = "oceanCarrier";
	public static final String RLSE_OCEN_CARR = "rlseOceanCarrier";
	public static final String BOOK_OCEN_CARR = "bookOceanCarrier";
	public static final String FRSCT_ALS_STAT = "ppmFrsctDetAlias.frsctStat";
	public static final String RLSE_ALS_STAT = "ppmRlseDetAlias.rlseStat";
	public static final String FRSCT_ALS_NT_CD = "ppmFrsctDetAlias.frsctNotesCd";
	public static final String FRSCT_ALS_SEQ_ID = "ppmFrsctDetAlias.frsctSeqId";
	public static final String RLSE_ALS_SEQ_ID = "ppmRlseDetAlias.rlseSeqId";
	public static final String BOOK_ALS_SEQ_ID = "ppmBookDetAlias.bookSeqId";
	public static final String GEN_EST_ARVL_POL = "ppmShpCommonProps.pickFromDtTs";
	
	public static final String NT_CDS = "noteCodes";
	public static final String SEQ_ID = "seqId";
	public static final String RLSE_SEQ_ID = "rlseSeqId";
	public static final String ACT_RTS_DT = "ppmShpCommonProps.actRtsDt";

	public static final String ARTS = "arts";
	public static final String CMT_SHP_DT = "ppmShpCommonProps.cmitShpDt";
	public static final String CSD = "csd";
	public static final String MODEL = "model";
	public static final String MDL_ID = "ppmShpCommonProps.mdlId";
	public static final String XREF = "ppmShpCommonProps.xref";
	public static final String XREF_DTO = "xref";
	public static final String XREF_TYPE = "ppmShpCommonProps.xrefTyp";
	public static final String XREF_TYPE_DTO = "xrefType";
	public static final String DLR_CD = "ppmShpCommonProps.dlrCd";
	public static final String DEALER_CODE = "dealerCode";
	public static final String DLR_NM = "ppmShpCommonProps.dlrNm";
	public static final String DEALER_NAME = "dealerName";
	public static final String SHP_TO_CUST_CD = "ppmShpCommonProps.shpToCustCd";
	public static final String SHIP_TO = "shipTo";
	public static final String ORD_SHP_FRM_LOC_CD = "ppmShpCommonProps.ordShpFromLocCd";
	public static final String POL = "pol";
	public static final String POD = "pod";
	public static final String DEST_CNTRY = "destinationCountry";
	public static final String FWDR_CD = "ppmShpCommonProps.fwdrCd";
	public static final String FWDR = "forwarder";

	public static final String EST_ARVL_POL = "estArrivalPOL";

	public static final String PPM_SHP_FRM_LOC_CD = "ppmShpCommonProps.ppmShpFromLocCd";

	public static final String PORT_OF_LD = "portOfLoad";
	public static final String SHP_TO_CNTRY = "ppmShpCommonProps.shpToCtry";
	public static final String FRSCT_ALS_PERMT_REQ_DAY = "ppmFrsctDetAlias.frsctPermitReqtDay";
	public static final String RLSE_ALS_PERMT_REQ_DAY = "ppmRlseDetAlias.rlsePermitReqtDay";
	public static final String BOOK_ALS_PERMT_REQ_DAY = "ppmBookDetAlias.bookPermitReqtDay";
	public static final String FRSCT_ALS_XCPT_LOG_STAT = "ppmFrsctDetAlias.frsctXcptLogStat";
	public static final String PERMT_REQ_DAY = "permitRequirement";
	public static final String XCPT_LOG_STAT = "exceptionLogged";
	public static final String TLM_NM = "ppmShpCommonProps.tlmNm";
	public static final String TLM_NM_TRD_LNE_MGR = "tlmNm";

	public static final String MTD_GT_LTST_SEQ_ID = "getLatestSeqId";
	public static final String STAT_ID = "statusId";
	public static final String STAT_NM = "statusName";
	public static final String TRNS_MD_ID = "trnsModeId";
	public static final String TRNSPORT_MODE_ID = "transportModeId";
	public static final String TRNS_MD_NM = "trnsModeName";
	public static final String TRNSPORT_MODE_NAME = "transportModeName";
	public static final String MTD_ORD_DET_TO_PPM_SHP_HST = "insertOrdDetToPpmShpHst";
	public static final String MTD_GT_ASSGND_DESKS_OF_REGN = "getAssgndDesksOfRegn";
	public static final String FAC_LOC = "facLoc";
	public static final String PPM_SHP_FAC_LOC = "ppmShpCommonProps.facLoc";
	public static final String MTD_GT_PRJCTN_LST = "getProjectionList";
	public static final String FORECAST = "FORECAST";
	public static final String BOOKING = "BOOKING";
	public static final String RELEASE = "RELEASE";
	public static final String NEW = "NEW";
	public static final String CAT_REGION = "catRegn";
	public static final String CAT_REGION_TL_REGN_ALIAS = "tlRegnVAlias";

	public static final String MTHD_DEL_USR_REGIONS = "deleteUserRegions";
	public static final String DEL_USR_REGIONS = "UserRegion.deleteUsrRegions";
	public static final String USR_ID = "userId";
	public static final String MTHD_SAVE_REGNS = "saveAssignedRegions";

	public static final String TPP_DEF_REG = "defReg";
	public static final String TPP_DEF_REGION = "defRegion";
	public static final String TPP_DEF_DESK = "defDesk";
	public static final String PPM_SHP_TO_CD = "ppmShpCommonProps.ppmShpToCd";
	public static final String SHIP_SRC_NM = "shipSourceName";
	public static final String TRD_LN_ANLST = "tradeLaneAnalyst";

	public static final String FLD_HDR_IND_COL = "fldHeaderInd";
	public static final String FLD_CNFG_SCR_COL="cnfgScr";
	public static final String REG_FLD_HDR_IND_COL = "headerInd";
	public static final String FLD_CONFG_SCR_COL = "pk.configScr";
	public static final String FLD_CONFG_SCR_PAR = "configScr";
	public static final String TPP_FLD_CONF_SCN_NO = "N";
	public static final String TPP_FORECST_ORDR_STG = "Forecast";
	public static final String TPP_REL_ORDR_STG = "Release";
    public static final String TPP_SUMM_CONFG_SCN = "Summary";
	public static final String TPP_DETAIL_CONFG_SCN = "Detail";
	public static final String TPP_FLD_CONF_SCN_YES = "Y";

	public static final String FRSCT_SMRY = "Forecast Summary";
	public static final String FRSCT_DTL = "Forecast Detail";
	public static final String FLD_NM_PK = "pk.fldNm";
	public static final String Y = "Y";
	public static final String PORT_CD = "portCd";
	public static final String MTD_GT_PORT_OF_LOAD_LST = "getPortOfLoadLst";
	public static final String MTD_SAVE_CMNT = "saveComment";
	public static final String MTD_DELETE_CMNT = "deleteComment";
	public static final String MTD_LOAD_CMNTS = "loadComments";
	public static final String MTD_GT_LTST_CMNT_ID = "getLtstCmntId";
	public static final String STATUS = "status";
	public static final int INT_5 = 5;
	public static final int INT_6 = 6;
	public static final int INT_7 = 7;
	public static final int INT_8 = 8;
	public static final int INT_9 = 9;
	public static final int INT_10 = 10;
	public static final int INT_11 = 11;
	public static final int INT_12 = 12;
	public static final int INT_13 = 13;
	public static final int INT_14 = 14;
	public static final int INT_15 = 15;
	public static final int INT_16 = 16;
	public static final int INT_17 = 17;
	public static final int INT_18 = 18;
	public static final int INT_19 = 19;
	public static final int INT_20 = 20;
	public static final int INT_21 = 21;
	public static final int INT_22 = 22;
	public static final int INT_23 = 23;
	public static final int INT_24 = 24;
	public static final int INT_25 = 25;
	public static final int INT_26 = 26;
	public static final int INT_27 = 27;
	public static final int INT_28 = 28;
	public static final int INT_29 = 29;
	public static final int INT_30 = 30;
	public static final int INT_31 = 31;
	public static final int INT_32 = 32;
	public static final int INT_33 = 33;
	public static final int INT_34 = 34;
	public static final int INT_35 = 35;
	public static final int INT_36 = 36;
	public static final int INT_37 = 37;
	public static final int INT_38 = 38;
	public static final int INT_39 = 39;
	public static final int INT_40 = 40;
	public static final int INT_41 = 41;
	public static final int INT_42 = 42;
	public static final int INT_43 = 43;
	public static final int INT_44 = 44;
	public static final int INT_45 = 45;
	public static final int INT_47 = 47;
	public static final int INT_48 = 48;
	public static final int INT_49 = 49;
	public static final int INT_50 = 50;
	public static final int INT_51 = 51;
	public static final int INT_52 = 52;
	public static final int INT_53 = 53;
	public static final int INT_54 = 54;
	public static final int INT_55 = 55;
	public static final int INT_56 = 56;
	public static final int INT_57 = 57;
	public static final int INT_58 = 58;
	public static final int INT_59 = 59;
	public static final int INT_60 = 60;
	public static final int INT_61 = 61;
	public static final int INT_62 = 62;
	public static final int INT_63 = 63;
	public static final int INT_64 = 64;
	public static final int INT_65 = 65;
	public static final int INT_66 = 66;
	public static final int INT_69 = 69;
	public static final int INT_73 = 73;
	public static final int INT_74 = 74;
	public static final int INT_999 = 999;
	
	public static final String REQ_FLDS = "requiredFlds";
	public static final List<String> REQ_FLDS_DTL_CONFIG_SCN = Arrays.asList(
			"Port Of Load", "Ocean Carrier", "CBM", "Est Arrival POL",

			"Est Transit Time", "Status");
	public static final List<String> REQ_FLDS_REL_BKNG_DTL_CNFG_SCN = Arrays.asList(
			"Port Of Load", "Ocean Carrier", "CBM", "Est Arrival POL",
			"Est Transit Time", "Status","Vessel","Voyage","ETA At POD","Exp Transit Time");
	

	public static final String PPM_CMNT_ID = "cmntId";
	public static final String ZERO_STR = "0";
	public static final String MTD_VRFY_MSO_RLS = "verifyMsoRules";
	public static final String ERR_VRFY_MSO_RLS = "Exception occurred while veryfying rule for origin shipment facility code-";
	public static final String MTD_VRFY_DFLT_MSO_RLS = "verifyDefaultMsoRule";
	public static final String MTD_GET_MSO_RLS = "getMsoRule";
	public static final String MTD_ADD_OFFSET = "addOffset";
	public static final String ACT_RTS_DT_KY = "ACT_RTS_DT";
	public static final String CMIT_SHP_DT_KY = "CMIT_SHP_DT";
	public static final String EST_RTS_DT_KY = "EST_RTS_DT";
	public static final String ACT_FST_SHP_DT_KY = "ACT_FST_SHP_DT";
	public static final String ACT_FNL_SHP_DT_KY = "ACT_FNL_SHP_DT";
	public static final String MSO_DFLT = "DFLT";
	public static final String FRCST_RPT_CNFG_NM = "FORECAST";
	public static final String MSO_ENT_EXT_DT_FMT = "yyMMdd";
	public static final String LAST_CRTE_DT_TM = "lastCrteDtTm";
	public static final String PORT_NM = "portNm";
	public static final String CTRY = "ctry";
	public static final String MTD_LD_PPM_SHP = "loadPpmShp";

	public static final String FRSCT_EST_RTS_DT = "ppmShpCommonProps.estRtsDt";
	public static final String ACT_FST_SHP_DT = "ppmShpCommonProps.actFstShpDt";
	public static final String ACT_FNL_SHP_DT = "ppmShpCommonProps.actFnlShpDt";
	public static final String EST_RTS_DT = "estRtsDate";

	public static final String TL_REGN_V = "tlRegnV";
	public static final String TL_REGN_V_ALIAS = "tlRegnVAlias";
	static final String TARGTYP_PK_ORIG = "targTypPk.orig";
	static final String TARGTYP_PK_DEST = "targTypPk.dest";
	static final String TARGTYP_PK_SCAC_CD = "targTypPk.scacCd";
	static final String TARGTYP_PK_TGT_TYP_CD = "targTypPk.tgtTypeCd";
	static final String CNFG_HIER_TGT_TYPE_CD_PK = "pk.tgtTypCd";
	static final String COMB = "comb";
	static final String CNFG_HIER_PK = "pk.hier";
	public static final String OCN_WND_BUFF_PK_LOC_TYPE = "pk.locType";
	public static final String OCN_WND_BUFF_PK_LOC_ID = "pk.locId";
	static final String TGT_TYPE_CODE = "tgtTypCd";
	static final String HIER = "hier";
	static final String FRSCT_PICK_TO_DT = "ppmShpCommonProps.pickToDtTs";
	static final String PICK_TO_DT = "pickToDt";
	static final String FRSCT_DEL_FRM_DT = "ppmShpCommonProps.delFromDtTs";
	static final String DEL_FRM_DT = "delFrmDt";
	static final String FRSCT_DEL_TO_DT = "ppmShpCommonProps.delToDtTs";
	static final String DEL_TO_DT = "delToDt";
	public static final String MTD_LD_PPM_FRSCT_DET_SRC = "loadPpmFrsctDetSource";
	public static final String MTD_GET_CNFG_HIRECH = "getCnfgHirerchy";
	public static final String MTD_GT_CARR_BUFF = "getPreCarrBuffDays";
	public static final String MTD_GT_TRN__CARR_BUFF = "getTrnstBuffDays";
	public static final String TRG_INTRNPC = "INTRNPC";
	public static final String TRG_INTRNOC = "INTRNOC";
	public static final String LAST_CRTE_BY_USER_NM ="ppmFrsctDetAlias.rcrdCrteLogDtls.lastCrteByUserNm";
	public static final String RLSE_LAST_CRTE_BY_USER_NM ="ppmRlseDetAlias.rcrdCrteLogDtls.lastCrteByUserNm";
	public static final String BOOK_LAST_CRTE_BY_USER_NM ="ppmBookDetAlias.rcrdCrteLogDtls.lastCrteByUserNm";
	public static final String LT_CRTE_DT_TM ="tppRcrdLogDtls.lastCrteDtTm";
	public static final String LAST_CRTE_BY_USR_NM = "lastCrteByUserNm";
	public static final String DOLLER = "$";
	
	static final String MTD_GET_CNFG_DTA_BY_IDKEYCNTRL = "getCnfgDtaByIdKeyCntrl";
	static final String CNFGR_DTACNTRL = "cnfgrDtaCtl";
	
	public static final List<String> TPP_EXC_FORCST_DET_CNFG = Arrays.asList(
			"Vessel", "Voyage");
	static final String MTD_INSRT_UPDT_CNFGR_DTA = "insertOrUpdateConfigDta";
	static final String ID_CNFG_SEQ = "id.cnfgrDtaSeq";
	static final String MTD_DELET_CONFIG_DATA = "deleteConfigurtnDta";
	static final String MTD_GET_MAX_SEQ_VAL = "getMaxSeqValue";
	static final String MTD_CHEK_DUPLICT_CNFG_DTA = "checkuDuplictCnfgDta";
	static final String MTD_GET_CTRY_LIST = "getCtryList";
	static final String MTD_GET_CTRY = "getCtry";
	
	public static final String RLS_SMRY = "Release Summary";
	public static final String BOOK_SMRY = "Booking Summary";
	public static final String BOOK_DTL = "Booking Detail";
	public static final String RLS_DTL = "Release Detail";
	
	public static final String RLSE_RPT_CNFG_NM = "RELEASE";
	public static final String RLSE_GET_SEAR_RSL = "getSearchResultsForReports";
	public static final String CON_LSTOBJ_DTOLST = "convertObjLstToDToLst";
	public static final String RLSE_AGENT_CD = "ppmRlseDetAlias.rlseAgntCd";
	public static final String RLSE_AGNT_CD = "agentCode";
	public static final String RLSE_INLND_MDE = "ppmRlseDetAlias.rlseInlndMde";
	public static final String INLND_MDE = "inlandMode";
	public static final String PC_CTGRY = "precarriageCategory";
	public static final String RLSE_PC_CTGRY = "ppmRlseDetAlias.rlsePcCtgry";
	public static final String RLSE_PC_CARR = "ppmRlseDetAlias.rlsePcCarr";
	public static final String PC_CARR = "precarriageCarrier";
	public static final String RLSE_POL = "ppmRlseDetAlias.rlsePol";
	public static final String RLSE_PPM_CARR_NM = "ppmRlseDetAlias.rlsePpmCarrNm";
	public static final String RLSE_VSL_NM = "ppmRlseDetAlias.rlseVslNm";
	public static final String RLSE_VOY_NM = "ppmRlseDetAlias.rlseVoyNm";
	public static final String RLSE_TRNST_TM="ppmRlseDetAlias.rlseTrnstTm";
    public static final String BOOK_TRNST_TM="ppmBookDetAlias.bookTrnstTm";
	
	public static final String VSL_NM = "vessel";
	public static final String VOY_NM = "voyage";
	public static final String EXP_TRNST_TM = "expTransitTime";
	public static final String RLSE_CUT_OFF_DT = "ppmRlseDetAlias.rlseCutOffDt";
	public static final String CUT_OFF_DT = "CutOff";
	public static final String CUT_OFF_DT_TS = "CutOffTs";
	public static final String RLSE_ETD = "ppmRlseDetAlias.rlseEtd";
	public static final String ETD = "etd";
	public static final String ETD_TS = "etdTs";
	public static final String RLSE_NOTES_CD = "ppmRlseDetAlias.rlseNotesCd";
	public static final String RLSE_TRNSHP_PRT = "ppmRlseDetAlias.rlseTrnshpPrt";
	public static final String	RLSE_TRNSHP_ETA = "ppmRlseDetAlias.rlseTrnshpEta";
	public static final String RLSE_ETA_FINAL_POD = "ppmRlseDetAlias.rlseEtaFinalPod";
	public static final String TRNSHP_PRT = "transhipPort";
	public static final String TRNSHP_ETA = "transhipETA";
	public static final String TRNSHP_ETA_TS= "transhipETATs";
	public static final String ETA_FINAL_POD="etaAtPOD";
	public static final String RLSE_SPT_QOT_STAT="ppmRlseDetAlias.rlseSptQotStat";
	public static final String RLSE_XCPT_LOG_STAT="ppmRlseDetAlias.rlseXcptLogStat";
	public static final String RLSE_SHP_FLOOR_STAT="ppmRlseDetAlias.rlseShpFloorStat";
	public static final String SPT_QOT_STAT="spotQuoteRequested";
	public static final String SHP_FLOOR_STAT="informShippingFloor";
	
	public static final String BOOK_ALS_STAT = "ppmBookDetAlias.bookStat";
	
	public static final String BOOK_RPT_CNFG_NM = "BOOKING";
	public static final String ORD_STAGE = "ordStage";
	public static final int INT_46 = 46;
	public static final long LONG_0 = 0;
	public static final String BOOK_NOTES_CD = "ppmBookDetAlias.bookNotesCd";
	public static final String BOOK_POL = "ppmBookDetAlias.bookPol";
	public static final String BOOK_PARTY = "ppmBookDetAlias.bookPrty";
	public static final String BOOK_INFORM_FRWDR = "ppmBookDetAlias.bookShpFwdStat";
	public static final String BOOK_ETD = "ppmBookDetAlias.bookEtd";
	public static final String BOOK_REF = "ppmBookDetAlias.bookRef";
	public static final String BOOK_VSL_NM = "ppmBookDetAlias.bookVslNm";
	public static final String BOOK_VOY_NM = "ppmBookDetAlias.bookVoyNm";
	public static final String BOOK_XCPT_LOG_STAT = "ppmBookDetAlias.bookXcptLogStat";
	public static final String BOOK_PPM_CARR_NM = "ppmBookDetAlias.bookPpmCarrNm";
	public static final String BOOK_CUT_OFF_DT = "ppmBookDetAlias.bookCutOffDt";
	public static final String BOOK_TRNSHP_PRT= "ppmBookDetAlias.bookTrnshpPrt";
	public static final String BOOK_TRNSHP_ETA= "ppmBookDetAlias.bookTrnshpEta";
	public static final String BOOK_ETA_FINAL_POD= "ppmBookDetAlias.bookEtaFinalPod";

	public static final String BOOK_SPT_QOT_STAT= "ppmBookDetAlias.bookSptQotStat";
	public static final String BOOKING_PARTY = "bookingParty";
	public static final String INFORM_FORWARDER = "informForwarder";
	static final String NOT_HEDER_H = "NOT-H";
	static final Object ALPHA_H = "H";

	public static final String EA_POL_FORMT = "yyMMdd";

	public static final String BOOK_SEQ_ID = "bookSeqId";
	public static final String FRSCT_SEQ_ID = "frsctSeqId";
	public static final String BOOK_STAT = "bookStat";
	public static final String CAT_REGN_CD = "ppmShpCommonProps.catRegnCd";
	public static final String RLSE_STAT = "rlseStat";
	public  static final String BOOKING_REF = "bookingReference";
	public static final String REGN_PROP = "regn";
	public static final String TL_REGN_V_ALIAS_CAT_REGN = "tlRegnVAlias.catRegn";
	public static final String MTD_GT_BOOK_RPRT_RSLTS = "getBookRprtRslts";
	public static final String MTD_GT_RLSE_RPRT_RSLTS = "getRlseRprtRslts";
	public static final String MTD_LD_BOOKING_DTLS = "loadBookingDetails";
	public static final String MTD_SAVE_BOOK_DTLS = "saveBookDtls";
	public static final String MTD_LD_PPM_BOOK_DET_SRC = "loadPpmBookDetSource";
	public static final String MTD_LD_RLSE_DTLS = "loadReleaseDetails";
	public static final String MTD_LD_PPM_RLSE_DET_SRC = "loadPpmRlseDetSource";
	public static final String MTD_SAVE_RLSE_DTLS = "saveRlseDtls";
	public static final String SRS_SYS_NAME = "sourceSystemName";
	static final int INT_71 = 71;
	static final int INT_70 = 70;
	static final int INT_67 = 67;
	static final int INT_68 = 68;
	public static final String FRSCT_STAT = "frsctStat";
	public static final String MTD_GT_FRSCT_RPRT_RSLTS = "getForecastRprtRslts";
	public static final String CALCULATE_FAC_CONFG_RULES="calculateFacConfgRules";
	public static final String MTD_DELETE_PPM_SHP_HST = "delete";
	public static final String MTD_DELETE_FRCST_DTLS = "deleteFrcstDtls";
	public static final String DFLT_TRNSP_MODE = "ppmShpCommonProps.dfltTrnspModeCd";
	public static final String DFLT_TRANSP_MODE = "dfltTranspMode";
	public static final int INT_72 = 72;
	static final String MTD_FETCH_LWQ_CNFGR_DTA = "fetchLwqCnfgData";
	static final String MTD_INSRT_UPDT_LWQ_CNFGR_DTA = "insrtOrUpdLwqConfigDta";
	static final String MTD_DELET_LWQ_CONFIG_DATA = "deleteLwqCnfgDta";
	static final String MTD_CHEK_LWQ_DUPLICT_CNFG_DTA = "checkDuplctLwqCnfgDta";
	


	static final String MTD_SAVE_ACE_XPT_HDR_DTA = "saveAceXptDtaHdrData";
	static final String MTD_SAVE_ACE_XPT_LN_DTA = "saveAceXptDtaLnData";
	static final String MTD_ACE_COMMIT_DET = "commitDetails";
	static final String MTD_GET_DUPL_ACE_XPT_HDR = "getDupAceXptDtaHdrList";
	static final String MTD_GET_DUPL_ACE_XPT_LN = "getDupAceXptDtaLnList";
	
	static final String MTD_UPDATE_ORIG_SHP_DT = "updateOrigShipDate";
	static final String ORIG_SHP_DT_IS_NULL = "Orig Ship Date is null";
	
	public static final String PPM_SHP_ORD_STAT = "ppmShpCommonProps.ordStat";
	static final String CANCEL = "C";
	public static final String INLND_TRANS_MODE = "inlandTransportMode";
	public static final String FRCST_TRANS_MODE = "forecastTransportMode";
	public static final String RLSE_TRANS_MODE = "releaseTransportMode";
	public static final String BOOK_TRANS_MODE = "bookingTransportMode";
	
	public static final String PPM_SHP_ORD_CARR_SCAC = "ppmShpCommonProps.ordCarrScac";
	public static final String ORD_CARR_SCAC = "orderOceanCarrier";
	public static final String PPM_SHP_ORD_POL = "ppmShpCommonProps.ordPol";
	public static final String ORD_POL = "orderPOL";
	public static final String FRSCT_ACTV_IND = "frsctActvInd";
	public static final String SEQ_NUM = "seqNum";
	public static final String SAVE_MULT_ROUTER = "saveMultipleRoutes";
	public static final String MTD_DELETE_ROUTE = "deleteMultipleRoutes";
	public static final String MTD_LD_MULT_ROUTES = "loadMultipleRoutes";
	public static final String ACTV_IND = "frsctActvInd";
	public static final String MTHD_GT_ASGND_AVL_FLDS = "getAssignedAvailbleFlds";
	public static final String MULTIPLE_UPDATE = "Multiple";
	public static final String DETAIL = "Detail";
	public static final String TILDE = "\\~";
	public static final String TPP_DOLLER = "\\$";
	public static final String CMNT_ID = "cmntId";
	public static final String PPM_MULT_FRSCT = "ppmMultFrscts";
	public static final String PPM_MULT_FRSCT_ALS = "ppmMultFrsctsAlias";	
	public static final String MULT_ROUTE_ACTV_IND = "ppmMultFrsctsAlias.frsctActvInd";
	public static final String MULT_ROUTE_POL = "ppmMultFrsctsAlias.frsctShpFromLocCd";
	public static final String MULT_ROUTE_OCN = "ppmMultFrsctsAlias.frsctScacCd";
	public static final String HDR_IND = "headerInd";
	public static final String MTD_UPDATE_MULT_ROUTES = "updateMultRouteLstActive";
	static final String FORWARDER_REF_NUM_VAR = "fwdrRefNo";
	static final String YYMMDD = "yyMMdd";
	static final String FORECAST_STAT = "FRSCT_STAT";
	static final String RELEASE_STAT = "RLSE_STAT";
	static final String BOOKING_STAT = "BOOK_STAT";
	static final String RLSD_STAT = "Released";

	static final String MTD_GET_DEST_LIST_DTA = "getDestList";
	static final String MTD_GET_ORIG_LIST_DTA = "getOrigList";
	static final String MTD_GET_ORIG_DEST_LIST_DTA = "getOrigDestList";
	static final String MTD_GET_ETA_DTA = "getETA";
	static final String MTD_GET_MSO_DTA = "getMSODetails";
	

	static final String MTD_GET_POL_CD_LIST_DTA = "getPolCdList";
	static final String MTD_GET_POD_CD_LIST_DTA = "getPodCdList";
	static final String MTD_GET_DEST_CD_LIST_DTA = "getDestCdList";
	static final String MTD_GET_ORIG_CD_LIST_DTA = "getOrigCdList";

	static final String OD_TYPE_PLANT_POL = "PLANT_POL";
	static final String OD_TYPE_POL_POD = "POL_POD";
	static final String OD_TYPE_POD_DEALER = "POD_DEALER";
	

	static final String POL_CD_LIST_QUERY_STRING = "select distinct T2.POL_CITY_CD as \"POL_CD\" FROM INTLSTG.SHPM_T T2 where NULLIF(T2.POL_CITY_CD, '') IS NOT NULL";
	static final String POD_CD_LIST_QUERY_STRING = "select distinct T2.POD_CITY_CD as \"POD_CD\" FROM INTLSTG.SHPM_T T2 where NULLIF(T2.POD_CITY_CD, '') IS NOT NULL";
	static final String DEST_CD_LIST_QUERY_STRING = "select distinct T1.CD as \"DEST\" FROM INTLSTG.SHPM_LN_ITM_PTY_T T1 where T1.PTY_TYP in ('Broker') AND NULLIF(T1.CD, '') IS NOT NULL";
	static final String ORIG_CD_LIST_QUERY_STRING = "select distinct T1.CD as \"ORIGIN\" FROM INTLSTG.SHPM_LN_ITM_PTY_T T1 where T1.PTY_TYP in ('Supplier') AND NULLIF(T1.CD, '') IS NOT NULL";

	static final String DEST_LIST_QUERY_STRING = "Select distinct DEST from LDMANLT.PRDCT_TRNST_TM where ORIG = '%s'  AND DEST <> '%s' AND OD_TYPE = '%s' ";
	static final String ORIG_LIST_QUERY_STRING = "Select distinct ORIG from LDMANLT.PRDCT_TRNST_TM where DEST = '%s'  AND ORIG <> '%s' AND OD_TYPE = '%s' ";

	static final String ORIG_DEST_FILTER_QUERY_STRING = "Select ORIG, DEST, MIN(COALESCE(OVRD_NO_DAY, NO_DAY)) AS NO_DAY from LDMANLT.PRDCT_TRNST_TM where ORIG in ('%s') AND DEST in ('%s')  Group by ORIG, DEST";
	static final String ETA_QUERY_STRING = "Select MIN(COALESCE(OVRD_NO_DAY, NO_DAY)) AS NO_DAY from LDMANLT.PRDCT_TRNST_TM where ORIG = '%s' AND DEST = '%s'  Group by ORIG, DEST";
	static final String MSO_SEARCH_QUERY_STRING = "SELECT * FROM (SELECT SHP_SRC, ORD_DLR_CD, POL_CITY_CD, POD_CITY_CD, COALESCE(PLT_SHP_DT, APRX_ORD_RTS_DT) as PLT_SHP_DT , MAX_CARGO_RCVD_POL_UTC_DT, MAX_MLSTN_POD_ARVL_UTC_DT, LM_DELIV_DT FROM LDMANLT.SIMPLE_VIZ_ORDERS_T A LEFT JOIN LDMANLT.TLM_OCEAN_SVIZ B ON A.SHP_ORD_CTL_NO = B.MSO_NO_SRC LEFT JOIN LDMANLT.TLM_LASTMI_SVIZ C ON A.SHP_ORD_CTL_NO = C.MSO_NO_SRC WHERE A.SHP_ORD_CTL_NO LIKE '%s'  ORDER BY A.LAST_UPDT_TS DESC) WHERE ROWNUM = 1";
}

