package com.cat.logistics.shared.utils;


import java.text.SimpleDateFormat;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


/**
 * Utility methods for EPA Class
 * 
 * @version 1.0 May 26, 2015 9:41:07 PM badamrr
 * @author badamrr
 */
public class EPAUtils {

	/**
	 * Private constructor to prevent creating object of this class.
	 */
	public EPAUtils() {

	}

	public static String concatenate(String... values) {
		StringBuilder appendedString = new StringBuilder();
		for (String value : values) {
			appendedString.append(value);
		}
		return appendedString.toString();
	}

	public static boolean isNullOrEmpty(String value) {
		return (null == value || value.isEmpty());
	}
	
	public static boolean isListEmpty(List list) {
		return (null == list || list.isEmpty());
	}
	
	/**
	 * validates if a string contains special chars
	 * @param engSer
	 * @return
	 */
	public static boolean chkSpclChrs(String engSer){
		Pattern p = Pattern.compile("[^a-z0-9 ]", Pattern.CASE_INSENSITIVE);
		Matcher m = p.matcher(engSer);
		boolean b = m.find();
		return b;
	}
	
	/**
	 * @param value
	 * @param length
	 * @return true or false
	 */
	public static boolean checkLenth(String value,int length){
		boolean flag = true;
		if(value != null && value.length() > length){
			flag = false;
		}
		return flag;
		
	}
	
	/**
	 * Formats the java.util date
	 * 
	 * @param pattern
	 * @param date
	 * @return formated date
	 */
	public static String formatDate(String pattern, java.util.Date date) {
		SimpleDateFormat formatter = new SimpleDateFormat(pattern);
		return formatter.format(date);
	}


}
