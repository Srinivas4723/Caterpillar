package com.cat.logistics.shared.utils;


/**
 * This is class is to populates status color base status description
 * @author singh9
 *
 */
public class StatusColor {

	/**
	 * Property for Status Description
	 */
	private String statusDesc;
	/**
	 * Property for True or False
	 */
	private boolean flag;
	
	
	/**
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = ServiceConstants.INT_31;
		int result = ServiceConstants.INT_1;
		result = prime * result + (flag ? ServiceConstants.INT_1231 : ServiceConstants.INT_1237);
		result = prime * result
				+ ((statusDesc == null) ? ServiceConstants.INT_0 : statusDesc.hashCode());
		return result;
	}


	
	/**
	 * default equals method
	 * @see java.lang.Object#equals(java.lang.Object)
	 * @param obj
	 */
	@Override
	    public boolean equals(Object obj) {
	        if (obj == null) {
	            return false;
	        }
	        if (getClass() != obj.getClass()) {
	            return false;
	        }
	        final StatusColor other = (StatusColor) obj;
	        if (
	        		(this.statusDesc == null) ? (other.statusDesc != null) : !this.statusDesc.equals(other.statusDesc) || this.flag != other.flag ) {
	            return false;
	        }
	        return true;
	    }


	/**
	 * @param statusDesc
	 * @param flag
	 */
	public StatusColor(String statusDesc, boolean flag){
		this.statusDesc = statusDesc;
		this.flag = flag;
	}

}
