package com.cat.logistics.shared.utils;

/**
 * This interface contains all the constant related to the MassUploadExcel
 * 
 * @author kakars2
 * 
 */
public interface MassUploadConstants {
    
    String[] MASS_UPLOAD_HEADER = { "Shipping Facility Code*(2 charcter Fac. Code)", "Serial Number*", "Part Number", "Shipment Date(DD-MMM-YYYY)", "Invoice Number", "Order Number", "Error Message",
	    "Override Error and Create New Entry (Y/N)" };
    
    String[] PROPERTY_NAMES = { "ShipFcltyCd", "SerialNumber", "PartNumber", "ShippingDt", "InvoiceNo", "OrderNo", "ErrorMsgs", "OverrideError" };
    
    String EXCEL_EXT_XLS = ".xls";
    String EXCEL_EXT_XLSX = ".xlsx";
    String errMsgProp = "getErrorMsgs";
    String overMsgProp = "getOverrideError";
    String STAR = "*";
    String EXCEL_REQ = "No file chosen. Please select the valid excel file. You can download the standard template by using Download Template link";
    String ERROR_EXCEL = "Invalid File. Please upload the EPA records in the standard template only.";
    
    String ERROR_EXCEL_FTA = "Invalid File. Please upload the FTA records in the standard template only.";
    
    String[] FTA_MASS_UPLOAD_HEADER = { "Supplier Code", "Part Number*", "Agreement Type*", "Cert Year*", "Part Type", "Part Description", "Error Message" };
    
    String[] FTA_PROPERTY_NAMES = { "SuppCd", "CatIdNo20", "CertTyp", "CertYr", "PartTyp", "PartDesc", "ErrorMsgs" };
    
    String[] DUTY_RATE_MASS_UPLOAD_HEADER = { "HTS Code*", "Country Code*", "Country Name", "Duty Rate(%)*", "Error Message" };
    
    String[] DUTY_RATE_PROPERTY_NAMES = { "HtsCd", "CtryCd", "CtryNm", "DutyRate", "ErrorMsgs" };
    
    String EXCEL_WORKSHEET_NAME = "FTA Solicitation Upload File";
    String EXCEL_WORKSHEET_NAME_DUTY = "Duty Rate Upload File";
    
    String CON_G = "G";
    
    String ACE_ERROR_EXCEL = "Invalid File. Please upload the ACE Portal records in the standard template only.";
    
    String[] ACE_PORTAL_MASS_UPLOAD_HEADER = { "ITN", "Shipment Reference Number", "Country of Ultimate Destination Code", "EEI Filing Date", "Export Date", "Routed Transaction Indicator",
	    "Shipment Value", "Shipment Weight (KG)", "Last AES Action Code", "Foreign Port of Unlading", "Import Entry Number", "Inbond Type Code", "Foreign Trade Zone ID", "Hazmat Indicator",
	    "Filing Option Type Code", "Late File Indicator", "Filer Name", "Filer ID Number", "USPPI EIN", "USPPI ID Number", "USPPI Company Name", "USPPI Contact Name", "USPPI Address Line 1",
	    "USPPI Address Line 2", "USPPI City", "USPPI Country", "Forwarding Agent City", "Forwarding Agent Company Name", "Forwarding Agent ID Number", "Intermediate Consignee City",
	    "Intermediate Consignee Country", "Intermediate Consignee Company Name", "Ultimate Consignee Address Line 1", "Ultimate Consignee Address Line 2", "Ultimate Consignee City",
	    "Ultimate Consignee State", "Ultimate Consignee Country", "Ultimate Consignee Company Name", "Ultimate Consignee Contact Name", "Ultimate Consignee ID Number",
	    "Ultimate Consignee Type Code", "Mode of Transportation Code", "Original ITN", "Port of Export Code", "Related Company Indicator", "Self-Filer Indicator", "Shipment Status Code",
	    "U.S. State of Origin", "Export Information Code", "Conveyance Name", "Commodity Line Number", "Export Control Classification Number", "Export License Number", "License Type Code",
	    "License Value", "Commodity Description", "HTS/Schedule B Number", "Commodity Line Value", "Quantity 1", "Unit of Measure Code (Quantity 1)", "Quantity 2",
	    "Unit of Measure Code (Quantity 2)", "Commodity Line Gross Weight (KG)", "Origin of Goods D/F Indicator", "Used Vehicle Indicator", "VIN/Product ID", "Equipment Number", "Seal Number",
	    "Transportation Reference Number", "DDTC Eligible Party Certification Indicator", "DDTC ITAR Exemption Number", "DDTC Quantity", "DDTC Registration Number", "DDTC SME Indicator",
	    "DDTC Unit of Measure", "DDTC USML Category Code", "Error Message" };
    String ACE_PORTAL_EXCEL_WORKSHEET_NAME = "Filer Transactions";
    
    String[] ACE_PORTAL_PROPERTY_NAMES = { "AesItn", "ShpRefNo", "DestCtryCd", "EeiFileDt", "XptDt", "RteXptTrnInd", "ShpVal", "ShpWt", "AesActnCd", "FgnPortUnldl", "ImpEntNo", "InbndTypCd",
	    "FgnTrdZnInd", "HzrdMatlInd", "FileOptTypCd", "LateFileInd", "FilerNm", "FilerIdNo", "UsppiEin", "UsppiIdNo", "UsppiNm", "UsppiCntctNm", "UsppiAdr1", "UsppiAdr2", "UsppiCity",
	    "UsppiCtry", "FwdrAgntCity", "FwdrAgntCoNm", "FwdrAgntIdNo", "IntmedCnsgneCity", "IntmedCnsgneCtry", "IntmedCnsgneCoNm", "UltCnsgneAdr1", "UltCnsgneAdr2", "UltCnsgneCity",
	    "UltCnsgneState", "UltCnsgneCtry", "UltCnsgneCoNm", "UltCnsgneCntctNm", "UltCnsgneIdNo", "UltCnsgneCd", "TrnspModeCd", "OrigItn", "ExitPortCd", "RelInd", "SelfFilerInd", "ShpStatCd",
	    "UsStateOrig", "XptInfoCd", "ConvyNm", "CmdtyLnNo", "XptCtlClsNo", "XptLicNo", "XptLicCd", "LicVal", "CmdtyDesc", "HrmnzTrfSchNo", "CmdtyLineVal", "Qty1Uom", "UomCd1", "Qty2Uom",
	    "UomCd2", "CmdtyLnGrsWt", "CooDfInd", "UsedVehInd", "VinId", "EqpNo", "CntrSealNo", "TrnspRefNo", "EligPtyCertInd", "ItarXmptNo", "DdtcQty", "DdtcRegNo", "DdtcSmeInd", "DdtcUom",
	    "DdtcUsmlCtgryCd", "ErrorMsgs" };
    
    /* Generic Constants */
    String ERROR_EXCEL_GENERIC = "Invalid File. Please upload the records in the standard template only.";
    
    String EXCEL_VALID_ROWS = "VALID_ROWS";
    String EXCEL_DUP_ROWS = "DUPLICATE_ROWS";

	String[] BOM_ANALYSIS_MASS_UPLOAD_HEADER = { "Part Number*", "Facility Code*", "Engineering Change", "Agreement Types", "Error Message" };
	String[] BOM_ANALYSIS_PROPERTY_NAMES = { "PartNumber", "FacilityCode", "EngineeringChange", "AgreementType", "ErrorMessage" };
	String EXCEL_WORKSHEET_NAME_BOM = "BOM Upload File";
	
	String[] ECCN_UPLOAD_HEADER = { "PART_NO*", "PART_NM*", "PART_TYP", "DSGN_CTL_CD", "DWG_VERS_CTL_TYP", "ENGR_DWG_VERS", "PART_SVC_LVL", "MANAGER_NAME", "BUS_EMAIL_ADR", "ECCN", "ENGR_MDL_NO" };
	String[] ECCN_PROPERTY_NAMES = { "PartNumber", "PartName", "PartType", "DsgnCtlCode", "DwgVersCtlType", "EngrDwgVers", "PartSvcLvl", "ManagerName", "BusEmailAddr", "Eccn", "EngrMdlNo" };
	 String EXCEL_WORKSHEET_NAME_ECCN = "Sheet1";
}
