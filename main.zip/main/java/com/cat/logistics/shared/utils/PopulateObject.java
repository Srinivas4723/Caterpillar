package com.cat.logistics.shared.utils;

import java.beans.PropertyDescriptor;

/**
 * 
 * @author kakars2
 *
 */
public class PopulateObject {
	
	/**
	 * @param obj
	 * @param variableName
	 * @param variableValue
	 */
		public void invokeSetter(Object obj, String variableName, Object variableValue) {
			PropertyDescriptor objPropertyDescriptor;
			try {
				objPropertyDescriptor = new PropertyDescriptor(variableName,
						obj.getClass());	
				objPropertyDescriptor.getWriteMethod().invoke(obj, variableValue);
				
			} catch (Exception e) {
				e.printStackTrace();
			} 
	
		}
		
		/**
		 * 
		 * @param obj
		 * @param variableName
		 * @return Object Object
		 */

	   public Object invokeGetter(Object obj, String variableName){
		   PropertyDescriptor objPropertyDescriptor;
		   Object variableValue=null;
			try {
				objPropertyDescriptor = new PropertyDescriptor(variableName, obj.getClass());
				variableValue = objPropertyDescriptor.getReadMethod().invoke(obj);
			} catch (Exception e) {
				e.printStackTrace();
			}
			return variableValue;
	   }	   
	  
}
