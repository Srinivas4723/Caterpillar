package com.cat.logistics.shared.utils;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Field;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collection;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.StringTokenizer;
import java.util.TreeSet;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.http.HttpSession;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.cat.logistics.epa.dto.StatusOrd;
import com.cat.logistics.epa.job.utils.BatchConstants;
import com.cat.logistics.epa.job.utils.Utils;
import com.cat.logistics.shared.exception.ServiceException;
import com.cat.logistics.shared.security.LgtUserSecurity;



/**
 * Utility methods for Service Module
 * 
 * @author singhr9
 */
public class ServiceUtils {
    
    private static String currentEnvironment = null;
    
    public static final Logger LOGGER = LogManager.getLogger(ServiceUtils.class);
    
    /**
     * Private constructor to prevent creating object of this class.
     */
    public ServiceUtils() {
	
    }
    
    /**
     * @return current Environment
     */
    public static String getCurrentEnvironment() {
	if (checkForNullAndNoLength(currentEnvironment)) {
	    setCurrentEnvironment();
	}
	return currentEnvironment;
    }
    
    /**
     * @param value
     * @return boolean value
     */
    public static boolean isNullOrEmpty(String value) {
	if (value != null && !value.isEmpty() && value != "null") {
	    return false;
	}
	else {
	    return true;
	}
    }
    
    /**
     * @param strLst
     * @return List data in stringFormat
     */
    public static String listToString(List<String> strLst) {
	StringBuffer strBuff = new StringBuffer();
	if (strLst != null && strLst.size() > 0) {
	    for (String str : strLst) {
		strBuff.append(str.trim() + ServiceConstants.COMMA);
	    }
	    strBuff.deleteCharAt(strBuff.length() - 1);
	}
	return strBuff.toString();
    }
    
    /**
     * @param values
     * @return concatenated string
     */
    public static String concatenate(String... values) {
	StringBuilder appendedString = new StringBuilder();
	for (String value : values) {
	    appendedString.append(value);
	}
	return appendedString.toString();
    }
    
    /**
     * This method split the string based on delimiter and returns Nth value starting with 0
     * 
     * @param exp
     * @param delimiter
     * @return split value of string
     */
    public static String splitNgetNthValue(String exp, String delimiter, int nthVal) {
	String value = null;
	if (null != exp && null != delimiter) {
	    String[] valueArray = exp.split(delimiter);
	    if (valueArray.length > nthVal) {
		value = valueArray[nthVal].trim();
	    }
	}
	return value;
    }
    
    /**
     * @param exp
     * @param format
     * @return formated date
     * @throws ParseException
     */
    public static Date convertStringTodate(String exp, String format) throws ParseException {
	
	DateFormat formatter = new SimpleDateFormat(format);
	Date date = (Date) formatter.parse(exp);
	
	return date;
    }
    
    /**
     * 
     * This method takes the input and searched for it in application.properties file
     * 
     * @param propName
     * @return property value
     * @since 1.0 May 26, 2015 9:44:00 PM badamrr
     */
    public static final String getProperty(String propName) {
	String propValue = null;
	if (propName != null) {
	    propValue = getServiceProperty(propName);
	}
	return propValue;
    }
    
    public static String getServiceProperty(String propName) {
		String propValue = null;
		Properties prop = new Properties();
		InputStream iStream = null;
		if (propName != null) {
			try {
				iStream = ServiceUtils.class.getClassLoader().getResourceAsStream(ServiceConstants.SERVICE_PROPERTIES);
				prop.load(iStream);
				propValue = prop.getProperty(propName);
			} catch (IOException e) {
				LOGGER.error("Exit getProperty", e);
			}
		}
		return propValue;
	}
    
    /**
     * @param inputData
     * @return input List
     */
    public static List<String> convertToList(String inputData) {
	List<String> inputList = null;
	inputData = inputData.trim();
	if (inputData.isEmpty()) {
	    inputList = new ArrayList<String>();
	}
	else {
	    inputList = Arrays.asList(inputData.split(PersistenceConstants.AUTOCOMPLETE_NEW_LINE));
	}
	return inputList;
    }
    
    /**
     * @param inputData
     * @return split List
     */
    public static List<String> splitStringToList(String inputData) {
	List<String> splitList = convertStringToListByDel(inputData, ",", ServiceConstants.TRUE);
	return splitList;
    }
    
    /**
     * 
     * @param inputStr
     * @return List of String
     */
    public static List<String> convertStringToList(String inputStr) {
	String subString = null;
	String inputData = null;
	List<String> convertedList = new ArrayList<String>();
	List<String> commaList = convertStringToListByDel(inputStr, ",", ServiceConstants.FALSE);
	Iterator<String> it = commaList.iterator();
	while (it.hasNext()) {
	    inputData = it.next();
	    if (inputData != null && !inputData.trim().equals("")) {
		if (inputData.indexOf("-") != -1) {
		    subString = inputData.substring(0, inputData.indexOf("-"));
		    convertedList.add(subString.trim());
		}
		else if (inputData.indexOf(".") != -1) {
		    subString = inputData.substring(0, inputData.indexOf("."));
		    convertedList.add(subString.trim());
		}
	    }
	}
	
	return convertedList;
    }
    
    /**
     * @param inputData
     * @return converted String in List format
     */
    public static List<String> convertStringToListByDel(String inputData, String delimtr, boolean uppercase) {
	List<String> convertedList = new ArrayList<String>();
	if (inputData != null && !inputData.trim().equals("")) {
	    StringTokenizer strTk = new StringTokenizer(inputData, delimtr);
	    while (strTk.hasMoreElements()) {
		String str = (String) strTk.nextElement();
		if (uppercase) {
		    convertedList.add(str.trim().toUpperCase());
		}
		else {
		    convertedList.add(str.trim());
		}
	    }
	}
	return convertedList;
    }
    
    /**
     * @param descs
     * @return converted List
     */
    public static List<String> convertDescToCode(List<String> descs) {
	List<String> convertedList = new ArrayList<String>();
	String subString;
	for (String desc : descs) {
	    if (desc.indexOf("-") != -1) {
		subString = desc.substring(0, desc.indexOf("-"));
		convertedList.add(subString.trim());
	    }
	}
	return convertedList;
    }
    
    /**
     * @param str
     * @return boolean value true or false for numeric check
     */
    public static boolean isNumeric(String str) {
	return str.matches("-?\\d+(\\.\\d+)?");
    }
    
    /**
     * @return Http Session
     */
    public static HttpSession getSession() {
	ServletRequestAttributes attr = (ServletRequestAttributes) RequestContextHolder.currentRequestAttributes();
	HttpSession session = attr.getRequest().getSession();
	return session;
    }
    
    /**
     * @param assignFacilitiesLst
     * @param enteredFacs
     * @return originalFac List
     */
    public static List<String> deleteManualEnteredFac(List<String> assignFacilitiesLst, List<String> enteredFacs) {
	List<String> copy = new ArrayList<String>(enteredFacs);
	for (String enterFac : enteredFacs) {
	    if (!assignFacilitiesLst.contains(enterFac)) {
		copy.remove(enterFac);
	    }
	}
	return copy;
    }
    
    /**
     * @param inputList
     * @return output List
     */
    public static Set<String> trimSetValues(Set<String> inputList) {
	Set<String> outputList = new HashSet<String>();
	for (String value : inputList) {
	    outputList.add(value.trim());
	}
	return outputList;
    }
    
    /**
     * @param theString
     * @return true or false
     */
    public static boolean checkForNullAndNoLength(String theString) {
	return (theString == null) || (theString.trim().length() == 0);
    }
    
    /**
     * setCurrentEnvironment
     */
    public static void setCurrentEnvironment() {
	try {
		String currentEnv = System.getProperty("ENVIRONMENT");
	    if (currentEnv.equalsIgnoreCase("PROD")) {
		currentEnvironment = ServiceConstants.PRODUCTION;
	    }
	    else if (currentEnv.equalsIgnoreCase("QA")) {
		currentEnvironment = ServiceConstants.QA;
	    }
	    else if (currentEnv.equalsIgnoreCase("TEST")) {
		currentEnvironment = ServiceConstants.TEST;
	    }
	    else {
		currentEnvironment = ServiceConstants.DEV;
	    }
	}
	catch (Exception e) {
	    currentEnvironment = ServiceConstants.DEV;
	    e = null;
	}
    }
    
    /**
     * @return List of Status code in Map format
     */
    public static Map<String, String> getStatusCds() {
	Map<String, String> status = new HashMap<String, String>();
	
	status.put(ServiceConstants.SUBMITTEDTOBROKER, ServiceConstants.STB);
	status.put(ServiceConstants.NOT_STARTED, ServiceConstants.NS);
	status.put(ServiceConstants.WORK_IN_PROGRESS, ServiceConstants.WIP);
	status.put(ServiceConstants.MISSING_DATA, ServiceConstants.MD);
	status.put(ServiceConstants.COMPLETED, ServiceConstants.CMP);
	status.put(ServiceConstants.READY_FOR_APPROVAL, ServiceConstants.RFA);
	status.put(ServiceConstants.MISSING_SER_INFO, ServiceConstants.MI);
	return status;
    }
    
    /**
     * @return Status Colors Map
     */
    public static Map<StatusColor, String> getStatusColors() {
	Map<StatusColor, String> statusColMap = new HashMap<StatusColor, String>();
	statusColMap.put(new StatusColor(ServiceConstants.NOT_STARTED, true), ServiceConstants.NO_COLOR);
	statusColMap.put(new StatusColor(ServiceConstants.NOT_STARTED, false), ServiceConstants.RED);
	statusColMap.put(new StatusColor(ServiceConstants.MISSING_DATA, true), ServiceConstants.ORANGE);
	statusColMap.put(new StatusColor(ServiceConstants.MISSING_DATA, false), ServiceConstants.RED);
	statusColMap.put(new StatusColor(ServiceConstants.WORK_IN_PROGRESS, true), ServiceConstants.ORANGE);
	statusColMap.put(new StatusColor(ServiceConstants.WORK_IN_PROGRESS, false), ServiceConstants.RED);
	statusColMap.put(new StatusColor(ServiceConstants.READY_FOR_APPROVAL, true), ServiceConstants.ORANGE);
	statusColMap.put(new StatusColor(ServiceConstants.READY_FOR_APPROVAL, false), ServiceConstants.RED);
	statusColMap.put(new StatusColor(ServiceConstants.COMPLETED, true), ServiceConstants.GREEN);
	statusColMap.put(new StatusColor(ServiceConstants.SUBMITTEDTOBROKER, false), ServiceConstants.GREEN);
	statusColMap.put(new StatusColor(ServiceConstants.MISSING_SER_INFO, true), ServiceConstants.ORANGE);
	statusColMap.put(new StatusColor(ServiceConstants.MISSING_SER_INFO, false), ServiceConstants.RED);
	return statusColMap;
    }
    
    /**
     * @return status colors in order
     */
    public static Map<StatusOrd, Integer> getStatusSortOrd() {
	Map<StatusOrd, Integer> statusOrdMap = new HashMap<StatusOrd, Integer>();
	statusOrdMap.put(new StatusOrd(ServiceConstants.RED, ServiceConstants.NOT_STARTED), Integer.valueOf(1));
	statusOrdMap.put(new StatusOrd(ServiceConstants.RED, ServiceConstants.MISSING_DATA), Integer.valueOf(2));
	statusOrdMap.put(new StatusOrd(ServiceConstants.RED, ServiceConstants.WORK_IN_PROGRESS), Integer.valueOf(ServiceConstants.INT_3));
	statusOrdMap.put(new StatusOrd(ServiceConstants.RED, ServiceConstants.READY_FOR_APPROVAL), Integer.valueOf(ServiceConstants.INT_4));
	statusOrdMap.put(new StatusOrd(ServiceConstants.ORANGE, ServiceConstants.MISSING_DATA), Integer.valueOf(ServiceConstants.INT_5));
	statusOrdMap.put(new StatusOrd(ServiceConstants.ORANGE, ServiceConstants.WORK_IN_PROGRESS), Integer.valueOf(ServiceConstants.INT_6));
	statusOrdMap.put(new StatusOrd(ServiceConstants.ORANGE, ServiceConstants.READY_FOR_APPROVAL), Integer.valueOf(ServiceConstants.INT_7));
	statusOrdMap.put(new StatusOrd(ServiceConstants.NO_COLOR, ServiceConstants.NOT_STARTED), Integer.valueOf(ServiceConstants.INT_8));
	statusOrdMap.put(new StatusOrd(ServiceConstants.GREEN, ServiceConstants.COMPLETED), Integer.valueOf(ServiceConstants.INT_9));
	statusOrdMap.put(new StatusOrd(ServiceConstants.GREEN, ServiceConstants.SUBMITTEDTOBROKER), Integer.valueOf(ServiceConstants.INT_10));
	statusOrdMap.put(new StatusOrd(ServiceConstants.ORANGE, ServiceConstants.MISSING_SER_INFO), Integer.valueOf(ServiceConstants.INT_11));
	statusOrdMap.put(new StatusOrd(ServiceConstants.RED, ServiceConstants.MISSING_SER_INFO), Integer.valueOf(ServiceConstants.INT_12));
	
	return statusOrdMap;
    }
    
    /**
     * @param pattern
     * @param date
     * @return formated date
     */
    public static String formatDate(String pattern, Date date) {
	SimpleDateFormat formatter = new SimpleDateFormat(pattern);
	return formatter.format(date);
    }
    
    /**
     * @param str
     * @param format
     * @return split value
     */
    public static String split(String str, String format) {
	return str != null ? str.split(format)[0] : null;
    }
    
    /**
     * @param engineImportTypeCodeList
     * @return ImpTypeCd List
     */
    public static Map<String, String> getEngImpTypeCdListPDFFormat(List<String> engineImportTypeCodeList) {
	Map<String, String> engImpTypeCdList = new HashMap<String, String>();
	for (String impList : engineImportTypeCodeList) {
	    String codeDesc[] = impList.split("\\.");
	    engImpTypeCdList.put(impList, ServiceConstants.RGB1 + codeDesc[0].toLowerCase());
	}
	return engImpTypeCdList;
    }
    
    /**
     * @param engineProvisionTypeCodeList
     * @return ProvTypeCd List
     */
    public static Map<String, String> getEngProvTypeCdListPDFFormat(List<String> engineProvisionTypeCodeList) {
	Map<String, String> engProvCodeList = new HashMap<String, String>();
	for (String provList : engineProvisionTypeCodeList) {
	    String codeDesc[] = provList.split("\\.");
	    engProvCodeList.put(provList, ServiceConstants.RGB2 + codeDesc[0].toLowerCase());
	}
	return engProvCodeList;
    }
    
    /**
     * @param data
     * @return blank value
     */
    public static String getBlankIfNull(String data) {
	return (data == null) ? " " : data;
    }
    
    /**
     * 
     * @return boolean
     */
    public static boolean isProductGrpAdm() {
	boolean prdGrpAdm = false;
	Authentication auth = SecurityContextHolder.getContext().getAuthentication();
	LgtUserSecurity lgtUser = (LgtUserSecurity) auth.getPrincipal();
	if (lgtUser.isProductGroupAdmin()) {
	    prdGrpAdm = true;
	}
	return prdGrpAdm;
    }
    
    /**
     * 
     * @param date
     * @param format
     * @return String
     */
    public static String convertDateToString(Date date, String format) {
	String stringDate = null;
	if (null != date) {
	    SimpleDateFormat sdf = new SimpleDateFormat(format);
	    stringDate = sdf.format(date);
	}
	return stringDate;
    }
    
    /**
     * @param str
     * @return boolean
     */
    public static boolean isAlphaNumeric(String str) {
	String pattern = "^[a-zA-Z0-9\\s\\-]*$";
	if (str.matches(pattern)) {
	    return true;
	}
	return false;
    }
    
    /**
     * @param str
     * @return boolean
     */
    public static boolean isStrictAlphaNumeric(String str) {
	String pattern = "^[a-zA-Z0-9]*$";
	if (str.matches(pattern)) {
	    return true;
	}
	return false;
    }
    
    /**
     * 
     * @param str
     * @param maxLgth
     * @param strict
     * @return boolean
     */
    public static boolean validateStrLength(String str, int maxLgth, boolean strict) {
	boolean valid = false;
	if (strict && !EPAUtils.isNullOrEmpty(str) && str.length() == maxLgth) {
	    valid = true;
	}
	else if (!strict && !EPAUtils.isNullOrEmpty(str) && str.length() <= maxLgth) {
	    valid = true;
	}
	
	return valid;
    }
    
    /**
     * Converts the input data String which contains the comma separated values in which there is
     * suffix of - to a Hashtable. Example Orange-NotStarted,Red-Ready For Approval will be
     * converted as Hashtable <Orange,NotStarted> <Red,Ready For Approval>
     * 
     * @param inputStr contains the information of EPA Form status like Orange-NotStarted,Red-Ready
     *            For Approval,...
     * @return Hashtable<String, String> convertedList
     */
    public static Hashtable<String, String> convertStringToHashtable(String inputStr) {
	Hashtable<String, String> output = new Hashtable<String, String>();
	if (null != inputStr) {
	    List<String> commaSepList = convertStringToListByDel(inputStr, ",", ServiceConstants.FALSE);
	    Iterator<String> iter = commaSepList.iterator();
	    while (iter.hasNext()) {
		inputStr = iter.next();
		if (inputStr != null && !inputStr.trim().equals("") && inputStr.indexOf("-") != -1) {
		    output.put(inputStr.split("-")[0], inputStr.split("-")[1]);
		}
	    }
	}
	return output;
    }
    
    /**
     * Converts the List of data which has suffix - to a Hastable separated. Example List of Input
     * contains Orange-NotStarted,Red-Ready For Approval will be converted as Hashtable
     * <Orange,NotStarted> <Red,Ready For Approval>
     * 
     * @param descs contains list of String in the format like Orange-NotStarted,Red-Ready For
     *            Approval
     * @return Hashtable<String, String> converted List
     */
    public static Hashtable<String, String> convertDescToCodeHashtable(List<String> descs) {
	Hashtable<String, String> output = new Hashtable<String, String>();
	if (null != descs) {
	    for (String desc : descs) {
		if (desc.indexOf("-") != -1) {
		    output.put(desc.split("-")[0], desc.split("-")[1]);
		}
	    }
	}
	return output;
    }
    
    /**
     * @param inputDate
     * @return true or false
     */
    public static String getMonth(Date inputDate) {
	String month = "";
	if (inputDate != null)// Input date format is: 2015-08-01 00:00:00.0
	{
	    SimpleDateFormat inputFormat = new SimpleDateFormat(ServiceConstants.DATE_FORMAT_STYLE_3);
	    month = inputFormat.format(inputDate).split(" ")[0].split("-")[1];
	}
	return month;
    }
    
    /**
     * @param inputDate
     * @return true or false
     */
    public static String getYear(Date inputDate) {
	String year = "";
	if (inputDate != null)// Input date format is: 2015-08-01 00:00:00.0
	{
	    SimpleDateFormat inputFormat = new SimpleDateFormat(ServiceConstants.DATE_FORMAT_STYLE_3);
	    year = inputFormat.format(inputDate).split(" ")[0].split("-")[0];
	}
	return year;
    }
    
    /**
     * @param stringDate
     * @param stringPattern
     * @return the date
     */
    public static Date stringToDateConversion(String stringDate, String stringPattern) {
	DateFormat formatter;
	formatter = new SimpleDateFormat(stringPattern);
	Date buildDate = null;
	try {
	    buildDate = (Date) formatter.parse(stringDate);
	}
	catch (ParseException e) {
		LOGGER.error("Error in stringToDateConversion {}", e.getMessage(), e);
	}
	return buildDate;
    }
    
    /**
     * @param data
     * @return String value
     */
    public static String getNAIfNull(String data) {
	return (data == null) ? ServiceConstants.NOT_APPLICABLE : (getBlankIfNull(data).equalsIgnoreCase(" ") ? ServiceConstants.NOT_APPLICABLE : data);
    }
    
    /**
     * @param inputDateFormat
     * @param outputDateFormat
     * @param inputDate
     * @return converted value
     */
    public static String dateConversion(String inputDateFormat, String outputDateFormat, String inputDate) {
	String outputDate = null;
	if (inputDateFormat != null && outputDateFormat != null && inputDate != null) {
	    SimpleDateFormat inputFormat = new SimpleDateFormat(inputDateFormat);
	    SimpleDateFormat outputFormat = new SimpleDateFormat(outputDateFormat);
	    Date date;
	    try {
		date = inputFormat.parse(inputDate);
		outputDate = outputFormat.format(date);
	    }
	    catch (ParseException e) {
	    	LOGGER.error("Error in dateConversion {}", e.getMessage(), e);
	    }
	}
	return outputDate;
    }
    
    /**
     * @param newSerilNumber
     * @param oldSerilNumber
     * @return true or false
     */
    public static boolean isRequiredValidation(String newSerilNumber, String oldSerilNumber) {
	boolean isValidtnReq = false;
	if (null != newSerilNumber && null != oldSerilNumber && newSerilNumber.equalsIgnoreCase(oldSerilNumber)) {
	    isValidtnReq = true;
	    
	}
	return isValidtnReq;
    }
    
    /**
     * Check if the Input string data has any of the List of string
     * 
     * @param inputString
     * @param statusCd
     * @return boolean
     */
    public static boolean containsString(String inputString, List<String> statusCd) {
	boolean valid = false;
	if (null != statusCd && null != inputString) {
	    Iterator<String> it = statusCd.iterator();
	    while (it.hasNext()) {
		String data = it.next();
		if (inputString.contains(data)) {
		    valid = true;
		    break;
		}
	    }
	}
	return valid;
    }
    
    /**
     * Returns true if this List is empty
     * 
     * @param list
     * @return true or false
     */
    public static boolean isNullOrEmpty(List<?> list) {
	if (list != null && !list.isEmpty()) {
	    return false;
	}
	else {
	    return true;
	}
    }
    
    /**
     * 
     * @param str the value
     * @param size the size
     * @param padChar the pad character
     * @return string
     */
    public static String leftPad(String str, int size, String padChar) {
	
	int length = ServiceConstants.INT_0;
	StringBuffer value = new StringBuffer(ServiceConstants.EMPTY);
	if (!isNullOrEmpty(str)) {
	    length = str.length();
	    value.append(str);
	}
	
	if (length < size) {
	    int pads = size - length;
	    while (pads > 0) {
		value.insert(ServiceConstants.INT_0, padChar);
		pads--;
	    }
	}
	return value.toString();
    }
    
    /**
     * validates if a string contains special chars
     * 
     * @param engSer
     * @return
     */
    public static boolean chkSpclChrs(String engSer) {
	Pattern p = Pattern.compile("[^a-z0-9 ]", Pattern.CASE_INSENSITIVE);
	Matcher m = p.matcher(engSer);
	boolean b = m.find();
	return b;
    }
    
    /**
     * converts into Long type list with comma separated from the given input string
     * 
     * @param inputData
     * @return split List
     */
    public static List<Long> splitStringToLongList(String inputData) {
	List<Long> splitList = new ArrayList<Long>();
	for (String seq : inputData.split(ServiceConstants.COMMA))
	    splitList.add(Long.parseLong(seq));
	return splitList;
    }
    
    /**
     * Convert Eng Build Date to MMM-YYYY
     * 
     * @param engBuildDate
     * @return buildDate
     */
    public static String formateEngBuildDate(String engBuildDate, String format) {
	DateFormat targetFormat = new SimpleDateFormat(ServiceConstants.MMM_YYYY);
	DateFormat origFormat = new SimpleDateFormat(format);
	String formattedDate = null;
	if (null != engBuildDate) {
	    try {
		Date date = origFormat.parse(engBuildDate);
		formattedDate = targetFormat.format(date);
		formattedDate = formattedDate.toUpperCase();
	    }
	    catch (ParseException e) {
	    	LOGGER.error("Error in formateEngBuildDate {}", e.getMessage(), e);
		return engBuildDate;
	    }
	}
	return formattedDate;
    }
    
    /**
     * @param val String val
     * @return trimmed values
     */
    public static String trimVal(String val) {
	
	if (!isNullOrEmpty(val)) {
	    val = val.trim();
	}
	return val;
    }
    
    /**
     * Returns Max Date for Validation
     * 
     * @param format
     * @param formatType
     * @return
     */
    public static Date getMaxDate(String format, String formatType) {
	Date date = null;
	SimpleDateFormat dateFrmt = new SimpleDateFormat(format);
	try {
	    if (ServiceConstants.FORMAT_TYPE1.equals(formatType)) {
		date = dateFrmt.parse(ServiceConstants.MAX_DATE_FRMT1);
	    }
	    
	    if (ServiceConstants.FORMAT_TYPE2.equals(formatType)) {
		date = dateFrmt.parse(ServiceConstants.MAX_DATE_FRMT2);
	    }
	    
	}
	catch (Exception e) {
		LOGGER.error("Error in getMaxDate {}", e.getMessage(), e);
	}
	return date;
    }
    
    /**
     * It gives the suffix by taking input prefix
     * 
     * @param preFix
     * @param value
     * @return String value
     */
    public static String getSubStrByPrfix(String preFix, String value) {
	String suffixStr = null;
	if (null != preFix && null != value) {
	    int serPrfxSize = preFix.length();
	    suffixStr = value.substring(serPrfxSize);
	}
	return suffixStr;
    }
    
    /**
     * This is used to get date as String based on pattern.
     * 
     * @param date
     * @param srcPattern
     * @param destPattern
     * @return String
     * @throws ParseException
     */
    public static String getRegionSpfDate(String date, String srcPattern, String destPattern) throws ParseException {
	
	DateFormat formatter = new SimpleDateFormat(srcPattern);
	String formatDate = formatDate(destPattern, (java.util.Date) formatter.parse(date));
	return formatDate;
    }
    
    /**
     * This is used to get all the variables of an class type
     * 
     * @param type
     * @return
     */
    public static Collection<Field> getAllFields(Class<?> type) {
	TreeSet<Field> fields = new TreeSet<Field>(new Comparator<Field>() {
	    @Override
	    public int compare(Field o1, Field o2) {
		int res = o1.getName().compareTo(o2.getName());
		if (0 != res) {
		    return res;
		}
		res = o1.getDeclaringClass().getSimpleName().compareTo(o2.getDeclaringClass().getSimpleName());
		if (0 != res) {
		    return res;
		}
		res = o1.getDeclaringClass().getName().compareTo(o2.getDeclaringClass().getName());
		return res;
	    }
	});
	for (Class<?> c = type; c != null; c = c.getSuperclass()) {
	    fields.addAll(Arrays.asList(c.getDeclaredFields()));
	}
	return fields;
    }
    
    /**
     * This is used to get current timestamp
     * 
     * @return
     */
    public static Timestamp getCurrentTimeStamp() {
	return new Timestamp(System.currentTimeMillis());
    }
    
    /**
     * This is used to copy matching variables from first object to second object
     * 
     * @param obj1
     * @param obj2
     */
    public static void copyAllFields(Object obj1, Object obj2) throws ServiceException {
	for (Field obj1Field : getAllFields(obj1.getClass())) {
	    obj1Field.setAccessible(true);
	    String obj1name = obj1Field.getName();
	    Object obj1value = null;
	    
	    for (Field obj2Field : getAllFields(obj2.getClass())) {
		obj2Field.setAccessible(true);
		String obj2name = obj2Field.getName();
		
		String obj1ValStr = "";
		String obj1Type = "";
		String obj2Type = "";
		try {  
		    obj1value = obj1Field.get(obj1);
		    
		    obj1Type = obj1Field.getType().getName();
		    obj2Type = obj2Field.getType().getName();
		    if (obj1name.equalsIgnoreCase(obj2name)) {
			
			if (obj1Type.equalsIgnoreCase("java.lang.String")) {
			    obj1ValStr = (String) obj1value;
			}
			
			popObj2OfStringType(obj2, obj1value, obj2Field, obj1Type, obj2Type);
			
			popObj2OfDateType(obj2, obj2Field, obj1ValStr, obj2Type);
			
			popObj2OfNumericType(obj2, obj2Field, obj1ValStr, obj2Type);
			
		    }
		}
		catch (Exception e) {
		    // logger.fatalEvent(ServiceUtils.class, "copyAllFields", e.getMessage(), e);
		    // //Disabling log to improve performance.
		    throw new ServiceException(obj1name);
		}
	    }
	}
    }

    /**
     * Populate Object 2 of numeric type
     * @param obj2
     * @param obj2Field
     * @param obj1ValStr
     * @param obj2Type
     * @throws IllegalAccessException
     */
    private static void popObj2OfNumericType(Object obj2, Field obj2Field, String obj1ValStr, String obj2Type) throws IllegalAccessException {
	if (obj2Type.equalsIgnoreCase("java.lang.Long") || obj2Type.equalsIgnoreCase("long")) {
	    Long tempLong = 0L;
	    if (obj1ValStr != null && obj1ValStr.length() > 0) {
		tempLong = Long.parseLong(obj1ValStr.replaceAll("[$, ]", ""));
	    }
	    obj2Field.set(obj2, tempLong);
	}
	else if (obj2Type.equalsIgnoreCase("java.math.BigDecimal")) {
	    BigDecimal tempBG = new BigDecimal("0");
	    if (obj1ValStr != null && obj1ValStr.length() > 0) {
		tempBG = new BigDecimal(obj1ValStr.replaceAll("[^\\d.]", ""));
	    }
	    obj2Field.set(obj2, tempBG);
	}
    }

    /**
     * Populate Object 2 of date type
     * @param obj2
     * @param obj2Field
     * @param obj1ValStr
     * @param obj2Type
     * @throws ParseException
     * @throws IllegalAccessException
     */
    private static void popObj2OfDateType(Object obj2, Field obj2Field, String obj1ValStr, String obj2Type) throws ParseException, IllegalAccessException {
	if (obj2Type.equalsIgnoreCase("java.util.Date")) {
	    DateFormat formatter = new SimpleDateFormat("dd-MMM-yyyy");
	    Date date = (Date) formatter.parse(obj1ValStr);
	    obj2Field.set(obj2, date);
	}
	else if (obj2Type.equalsIgnoreCase("java.sql.Timestamp")) {
	    Timestamp timeStamp = Timestamp.valueOf(obj1ValStr);
	    obj2Field.set(obj2, timeStamp);
	}
    }

    /**
     * Populate Object 2 of string type
     * @param obj2
     * @param obj1value
     * @param obj2Field
     * @param obj1Type
     * @param obj2Type
     * @throws ParseException
     * @throws IllegalAccessException
     */
    private static void popObj2OfStringType(Object obj2, Object obj1value, Field obj2Field, String obj1Type, String obj2Type) throws ParseException, IllegalAccessException {
	if (obj2Type.equalsIgnoreCase("java.lang.String")) {
	    String str = " ";
	    
	    if (obj1value != null) {
		str = String.valueOf(obj1value);
	    }
	    
	    if (obj1Type.equalsIgnoreCase("java.util.Date")) {
		DateFormat originalFormat = new SimpleDateFormat("EEE MMM dd HH:mm:ss zzz yyyy");
		DateFormat targetFormat = new SimpleDateFormat("dd-MMM-yyyy");
		Date date = (Date) originalFormat.parse(str);
		String dateStr = targetFormat.format(date);
		obj2Field.set(obj2, dateStr);
	    }
	    else {
		obj2Field.set(obj2, str);
	    }
	}
    }
    
    /**
     * 
     * This method takes the input and searched for it in application.properties file
     * 
     * @param propName
     * @return property value
     * @author nemica
     */
    public static final String getAceProperty(String propName) {
	String propValue = null;
	Properties prop = null;
	if (propName != null) {
	    propValue = getAceServiceProperty(propName);
	}
	return propValue;
    }
    
    public static String getAceServiceProperty(String propName) {
		String propValue = null;
		Properties prop = new Properties();
		InputStream iStream = null;
		if (propName != null) {
			try {
				iStream = ServiceUtils.class.getClassLoader().getResourceAsStream(ServiceConstants.ACE_SERVICE_PROPERTIES);
				prop.load(iStream);
				propValue = prop.getProperty(propName);
			} catch (IOException e) {
				LOGGER.error("Exit getProperty", e);
			}
		}
		return propValue;
	}
    
    /**
     * @return
     */
    public static int getMaxCPUThreads() {
	int cores = Runtime.getRuntime().availableProcessors();
	LOGGER.info("Entry method of getMaxCPUThreads {}",String.format(ServiceConstants.MAX_CPU_THREADS, cores));
	return cores;
    }
    
    /**.
     * @return ACE tempDir
     */
    public static File getAceTempDir() {
	
	String propName = ServiceConstants.ACE_TEMP_FILE_PATH + ServiceConstants.UNDERSCORE + getCurrentEnvironment();
	String tempDirPath = ServiceUtils.getAceProperty(propName);
	
	if (!getCurrentEnvironment().equalsIgnoreCase(ServiceConstants.DEV)) {
	    tempDirPath = Utils.getNASpath() + tempDirPath;
	}
	File tempDir = new File(tempDirPath);
	if (!tempDir.exists())
	    tempDir.mkdirs();
	
	return tempDir;
    }
    
    /**
     * Write Grief workbook to disk
     * @param griefWorkBook
     * @param errFilePath
     * @throws IOException
     */
    public static void writeWrkBookToFile(SXSSFWorkbook griefWorkBook,String errFilePath) throws IOException{ 
	ByteArrayOutputStream baos = new ByteArrayOutputStream();
	
	griefWorkBook.write(baos);
	
	baos.close(); // close the ByteArrayOutputStream
	
	griefWorkBook.dispose(); // dispose of temporary files backing this workbook on disk
	
	File tempFile = new File(errFilePath);
	tempFile.createNewFile();
	
	FileOutputStream fos = new FileOutputStream(tempFile);
	fos.write(baos.toByteArray());
	fos.close();
    }
    
    public static Date getTodaysDate() {
		Calendar cal = Calendar.getInstance();
		cal.setTime(new Date());
		cal.set(Calendar.HOUR_OF_DAY, 0);
		cal.set(Calendar.MINUTE, 0);
		cal.set(Calendar.SECOND, 0);
		cal.set(Calendar.MILLISECOND, 0);

		return cal.getTime();
	}
	
	public static Date getCurrentYearStartDate() {
		Calendar cal = Calendar.getInstance();
		cal.set(Calendar.DAY_OF_YEAR, 1);    
		cal.set(Calendar.HOUR_OF_DAY, 0);
		cal.set(Calendar.MINUTE, 0);
		cal.set(Calendar.SECOND, 0);
		cal.set(Calendar.MILLISECOND, 0);

		return cal.getTime();
	}

	public static Date addDaysToDate(Date oldDate, int days) {

		Calendar cal = Calendar.getInstance();
		cal.setTime(oldDate);
		 
		// Add Days
		cal.add(Calendar.DATE, days);
		 
		return cal.getTime();
	}

	public static long getDateDiffInDays(Date date1, Date date2) {

	    long diff = date2.getTime() - date1.getTime();
	    return TimeUnit.DAYS.convert(diff, TimeUnit.MILLISECONDS);
	}
    
	public static boolean checkIfItsSunday(Date startDate) {
	    Calendar startCal = Calendar.getInstance();
	    startCal.setTime(startDate);    
	    
	    if (startCal.get(Calendar.DAY_OF_WEEK) == Calendar.SUNDAY) {
	        return true;
	    }

	    return false;
	}
	public static Timestamp getTimeStamp() {
		Calendar calendar = Calendar.getInstance();
		return new Timestamp(calendar.getTime().getTime());
	}
}
