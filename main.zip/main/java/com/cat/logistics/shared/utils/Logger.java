/*
 * package com.cat.logistics.shared.utils;
 * 
 * import cat.cis.tuf.common.directory.Person; import
 * cat.cis.tuf.common.logging.EventDispatcher; import
 * cat.cis.tuf.common.logging.FatalEvent; import
 * cat.cis.tuf.common.logging.InformationalEvent; import
 * cat.cis.tuf.common.logging.LoggerConfiguration; import
 * cat.cis.tuf.common.logging.TraceEvent; import
 * cat.cis.tuf.common.logging.UsageEvent; import
 * cat.cis.tuf.common.logging.WarningEvent; import
 * cat.cis.tuf.common.util.Counter; import cat.cis.tuf.common.util.TUFUtils;
 * import cat.cis.tuf.server.util.TUFServerUtil;
 * 
 *//**
	 * 
	 * Copyright (c) 2011 Caterpillar Inc. All Rights Reserved. This work contains
	 * Caterpillar Inc.'s unpublished proprietary information which may constitute a
	 * trade secret and/or be confidential. This work may be used only for the
	 * purposes for which it was provided, and may not be copied or disclosed to
	 * others. Copyright notice is precautionary only, and does not imply
	 * publication.
	 * 
	 * @author singhr9
	 */
/*
 * public class Logger implements ILogger {
 * 
 *//**
	 * value indicating THE_APPLICATION
	 */
/*
 * public static final String THE_APPLICATION =
 * ServiceConstants.THE_APPLICATION;
 * 
 *//**
	 * Comment for <code>INSTANCE</code>
	 */
/*
 * private static ILogger instance = null;
 * 
 *//**
	 * Logger constructor comment.
	 */
/*
 * private Logger() { super(); init(); }
 * 
 *//**
	 * FatalEvent - creates a new logging event and sends it off to be logged.
	 * Creation date: (9/20/01 12:02:54 PM)
	 * 
	 * @param classReference class type as parameter
	 * @param methodName     type of String
	 * @param message        String
	 * @param e              exception
	 */
/*
 * @SuppressWarnings("unchecked") public void fatalEvent(Class classReference,
 * String methodName, String message, Exception e) { try { new
 * FatalEvent(THE_APPLICATION, Counter.getNext(), classReference .getName(),
 * methodName, message, getDetails(e)); } catch (Exception ee) {
 * ee.getMessage(); }
 * 
 * }
 * 
 *//**
	 * getInstance returns the Singleton instance of this class Creation date:
	 * (9/20/01 12:02:54 PM)
	 * 
	 * @return Logger instance
	 */
/*
 * public static ILogger getInstance() { if (instance == null) { instance = new
 * Logger(); } return instance; }
 * 
 *//**
	 * @param log log
	 */
/*
 * public static void setMockLogger(ILogger log) { instance = log; }
 * 
 *//**
	 * InformationalEvent - creates a new logging event and sends it off to be
	 * logged. Creation date: (9/20/01 12:02:54 PM)
	 * 
	 * @param classReference class type as parameter
	 * @param methodName     type String
	 * @param message        type String
	 * 
	 */
/*
 * @SuppressWarnings("unchecked") public void informationalEvent(Class
 * classReference, String methodName, String message) { try { new
 * InformationalEvent(THE_APPLICATION, Counter.getNext(),
 * classReference.getName(), methodName, message); } catch (Exception e) {
 * e.getMessage(); }
 * 
 * }
 * 
 *//**
	 * init() - Sets up the logging framework for THE_APPLICATION.
	 * 
	 * If other directories or applications are going to be used for logging,
	 * 
	 * then entries must be made to initialize their logging.
	 * 
	 */
/*
 * protected void init() {
 * 
 * LoggerConfiguration lc = new LoggerConfiguration(THE_APPLICATION,
 * TUFServerUtil.getInstance().getProperties(ServiceConstants.LOG_PROPERTIES));
 * EventDispatcher.register(lc);
 * 
 * }
 * 
 *//**
	 * TraceEvent - creates a new logging event and sends it off to be logged.
	 * 
	 * 
	 * @param requestId      type Int
	 * @param classReference class type as param
	 * @param methodName     type String
	 * @param begin          type boolean
	 */
/*
 * @SuppressWarnings("unchecked") public void traceEvent(int requestId, Class
 * classReference, String methodName, boolean begin) {
 * 
 * try { new TraceEvent(THE_APPLICATION, requestId, classReference.getName(),
 * methodName, begin);
 * 
 * } catch (Exception e) { e.getMessage(); } }
 * 
 *//**
	 * UsageEvent - creates a new logging event and sends it off to be logged.
	 * Creation date: (9/20/01 12:02:54 PM)
	 * 
	 * @param classReference class ref
	 * @param person         person
	 * @param elapsed        time
	 * 
	 */
/*
 * 
 * @SuppressWarnings("unchecked") public void usageEvent(Class classReference,
 * Person person, long elapsed) { try { new UsageEvent(THE_APPLICATION,
 * Counter.getNext(), classReference .getName(), person, elapsed); } catch
 * (Exception e) { e.getMessage(); }
 * 
 * }
 * 
 *//**
	 * WarningEvent - creates a new logging event and sends it off to be logged.
	 * Creation date: (9/20/01 12:02:54 PM)
	 * 
	 * @param classReference class ref
	 * @param methodName     method name
	 * @param message        message
	 * 
	 */
/*
 * 
 * @SuppressWarnings("unchecked") public void warningEvent(Class classReference,
 * String methodName, String message) { try { new WarningEvent(THE_APPLICATION,
 * Counter.getNext(), classReference .getName(), methodName, message); } catch
 * (Exception e) { e.getMessage(); } }
 * 
 *//**
	 * @param e exception
	 * @return String exception details
	 *//*
		 * private String getDetails(Exception e) { String details =
		 * ServiceConstants.DETAILS +
		 * TUFUtils.getInstance().generateExceptionDetails(e); return details; }
		 * 
		 * }
		 */