/*
 * package com.cat.logistics.shared.utils;
 * 
 *//**
	 * 
	 * Copyright (c) 2011 Caterpillar Inc. All Rights Reserved. This work contains
	 * Caterpillar Inc.'s unpublished proprietary information which may constitute a
	 * trade secret and/or be confidential. This work may be used only for the
	 * purposes for which it was provided, and may not be copied or disclosed to
	 * others. Copyright notice is precautionary only, and does not imply
	 * publication.
	 * 
	 * @author arumuk
	 */
/*
 * import cat.cis.tuf.common.directory.Person;
 * 
 *//**
	 * This class is used Loggging the statements using TUF Logging Mechanism.
	 * 
	 * @author singhr9
	 * 
	 */
/*
 * public interface ILogger {
 *//**
	 * @param classReference cr
	 * @param methodName     method
	 * @param message        message
	 * @param e              exception
	 */
/*
 * @SuppressWarnings("unchecked") void fatalEvent(Class classReference, String
 * methodName, String message, Exception e);
 * 
 *//**
	 * @param requestId      request
	 * @param classReference classs
	 * @param methodName     method
	 * @param begin          begin
	 */
/*
 * @SuppressWarnings("unchecked") void traceEvent(int requestId, Class
 * classReference, String methodName, boolean begin);
 * 
 *//**
	 * @param classReference classref
	 * @param methodName     method
	 * @param message        message
	 */
/*
 * @SuppressWarnings("unchecked") void informationalEvent(Class classReference,
 * String methodName, String message);
 * 
 *//**
	 * @param classReference class
	 * @param person         person
	 * @param elapsed        elapsed
	 */
/*
 * @SuppressWarnings("unchecked") void usageEvent(Class classReference, Person
 * person, long elapsed);
 * 
 *//**
	 * @param classReference class ref
	 * @param methodName     method
	 * @param message        message
	 *//*
		 * @SuppressWarnings("unchecked") void warningEvent(Class classReference, String
		 * methodName, String message);
		 * 
		 * }
		 */