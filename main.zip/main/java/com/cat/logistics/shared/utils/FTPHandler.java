package com.cat.logistics.shared.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;

import org.apache.commons.net.ftp.FTP;
import org.apache.commons.net.ftp.FTPClient;
import org.apache.commons.net.ftp.FTPConnectionClosedException;
import org.apache.commons.net.ftp.FTPReply;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import com.cat.logistics.epa.job.utils.BatchConstants;

import com.cat.googletink.util.EncryptAndDecryptApplication;

public class FTPHandler {

	public static final Logger LOGGER = LogManager.getLogger(FTPHandler.class);
	@Autowired
	private FTPClient ftpClient;

	private String ftpHostName;
	private String ftpDirectory;
	private String ftpUserName;
	private String ftpPassword;

	/**
	 * Constructor
	 * 
	 * @param config
	 */
	public FTPHandler(String ftpHostName, String ftpDirectory, String ftpUserName, String ftpPassword) {
		this.ftpHostName = ftpHostName;
		this.setFtpDirectory(ftpDirectory);
		this.ftpUserName = ftpUserName;
		this.ftpPassword = EncryptAndDecryptApplication.decrypt(System.getProperty("tink.serverKeyset"),
				System.getProperty("tink.associateKeyset"),ftpPassword);
	}

	/**
	 * 
	 * Connects to the FTP server
	 * 
	 * @return
	 * @throws FTPException
	 * @throws ApplicationException Runtime exception in the form of
	 *                              ApplicationException
	 */
	public int connect() throws FTPException {
		int error = -1;
		LOGGER.info("Entry method connecting to FTP using Local Passive Mode ");
		error = disconnect();
		if (error == ServiceConstants.INT_0) {
			try {
				String hostName = ftpHostName;
				ftpClient.connect(hostName);
				ftpClient.enterLocalPassiveMode();
				LOGGER.info("Changed to Local Passive Mode ");
				int replyCode = ftpClient.getReplyCode();
				LOGGER.info("Reply Code for connecting to FTP Server ");
				if (!FTPReply.isPositiveCompletion(ftpClient.getReplyCode())) {
					String ftpMessageC = ftpClient.getReplyString();
					ftpClient.disconnect();
					LOGGER.error("Unable to connect to ftpServer ", new FTPException(ftpMessageC));
					throw new FTPException(ftpMessageC);
				} else {
					error = ServiceConstants.INT_0;
				}
			} catch (IOException ioex) {
				LOGGER.error("There are some problem while connecting ", ioex);
				throw new FTPException(ioex.getMessage() + ServiceConstants.CON_FTP_ST, ioex);
			}
		} else {
			LOGGER.warn(ServiceConstants.CONNECT, ServiceConstants.CON_MSG);
		}
		return error;
	}

	public void storeFile(File fileName, String eccnFileNameExt) throws IOException {
		LOGGER.info("Entry method of Store File we received the fileName ");

		InputStream inputStream = new FileInputStream(fileName);
		try {
			connectToFtpServer(ServiceConstants.BINARY);
			// ftpClient.changeWorkingDirectory(ServiceConstants.OUTBOX);
			boolean done = ftpClient.storeFile(eccnFileNameExt + fileName.getName(), inputStream);
			if (done) {
				LOGGER.info("Store File {} ", fileName.getName());
				fileName.delete();
			}
		} catch (FTPException e) {
			LOGGER.error("Exception while saving the file  ", e);
			// emailSender.sendEmail(ServiceConstants.ECCN_TECH_EXCEPTION);
			e.printStackTrace();
		} finally {
			try {
				ftpClient.disconnect();
			} catch (FTPConnectionClosedException e) {
				LOGGER.error("Unable to disconnect the ftp server  ", e);
			}
		}

	}

	/**
	 * If connected to an FTP server it disconnects from it
	 * 
	 * @return 0 - If able to successfully disconnect from the server -1 - If there
	 *         is an error disconnecting
	 * @return
	 * @throws FTPException
	 */
	public int disconnect() throws FTPException {
		int error = -1;
		if (ftpClient != null && ftpClient.isConnected()) {
			try {
				ftpClient.disconnect();
				error = isPositiveComp();
			} catch (IOException ioexe) {
				LOGGER.fatal("Error in disconnect {} {}", ServiceConstants.MTD_DISCNCT,
						(ServiceConstants.IO_EXC_OCRD + ioexe.getMessage()), (Exception) ioexe);
				throw new FTPException(ioexe.getMessage() + ServiceConstants.IO_EXC_MSG, ioexe);
			} catch (Exception exce) {
				LOGGER.fatal("Error in disconnect {} {}", ServiceConstants.MTD_DISCNCT,
						(ServiceConstants.IO_EXC_OCRD + exce.getMessage()), (Exception) exce);
				throw new FTPException(exce.getMessage() + ServiceConstants.IO_EXC_MSG, exce);

			}
		} else {
			error = ServiceConstants.INT_0;
		}
		return error;
	}

	/**
	 * @return
	 * @throws FTPException
	 */
	private int isPositiveComp() throws FTPException {
		int error = -1;
		if (!FTPReply.isPositiveCompletion(ftpClient.getReplyCode())) {
			String ftpMsg = ftpClient.getReplyString();
			LOGGER.error("Error while calling isPositiveComp",
					new FTPException(ftpMsg));
			throw new FTPException(ftpMsg);
		} else {
			LOGGER.error("Error in isPositiveComp", "successfully connected ");
			error = ServiceConstants.INT_0;
		}
		return error;
	}

	/**
	 * Performs all setup functions. Connect to the FTP server, go to the passed
	 * directory, and set passive move
	 * 
	 * - directory where files will be put
	 * 
	 * @return 0 if successful -1 if there was an error and error will be logged
	 * @throws FTPException
	 * @throws IOException
	 * @throws FTPException
	 */
	public int connectToFtpServer(String ftpFlTyp) throws FTPException {
		int error = -1;
		error = connect();
		if (error == ServiceConstants.INT_0) {
			error = tryLogin();
			if (error == ServiceConstants.INT_0 && changeFileTransferMode(ftpFlTyp) == ServiceConstants.INT_0) {
				if (!FTPReply.isPositiveCompletion(ftpClient.getReplyCode())) {
					String ftpMessage = ftpClient.getReplyString();
					LOGGER.error("Could not connect to FTP Server ", new FTPException(ftpMessage));
					throw new FTPException(ftpMessage);
				} else {
					error = ServiceConstants.INT_0;
				}
			}
		} else {
			LOGGER.warn(ServiceConstants.CNCT_TO_FTP_SRVR,
					ServiceConstants.FTP_CON_FLR);

		}
		return error;
	}

	/**
	 * 
	 * Attempts to log into the server
	 * 
	 * @return
	 * @throws FTPException
	 * @throws ApplicationException Runtime exception in the form of
	 *                              ApplicationException
	 */
	private int tryLogin() throws FTPException {
		int error = -1;
		String username = ftpUserName;
		String password = EncryptAndDecryptApplication.decrypt(System.getProperty("tink.serverKeyset"),
				System.getProperty("tink.associateKeyset"),ftpPassword);
		try {
			ftpClient.login(username, password);
			if (!FTPReply.isPositiveCompletion(ftpClient.getReplyCode())) {
				String ftpMessage = ftpClient.getReplyString();
				ftpClient.logout();
				disconnect();
				throw new FTPException(ftpMessage);
			} else {
				error = ServiceConstants.INT_0;
			}
		} catch (IOException ioe) {
			LOGGER.error("Error in tryLogin", ioe);
			throw new FTPException(ioe.getMessage(), ioe);
		}
		return error;
	}

	/**
	 * Change the file transfer mode between ASCII and Binary
	 * 
	 * @return int - 0 if successful -1 if unsuccessful
	 * @throws FTPException
	 * @throws ApplicationException Runtime exception in the form of
	 *                              ApplicationException
	 * @throws FTPException
	 */
	private int changeFileTransferMode(String ftpFileType) throws FTPException {
		int error = -1;
		try {
			if ("BINARY".equalsIgnoreCase(ftpFileType.toString())) {
				ftpClient.setFileType(FTP.BINARY_FILE_TYPE);
			} else {
				ftpClient.setFileType(FTP.ASCII_FILE_TYPE);
			}
			error = isPositiveComp();
		} catch (IOException ioe) {
			LOGGER.error("(ServiceConstants.EXC_OCCRD" + "ioe.getMessage())", (Exception) ioe);
			throw new FTPException(ioe.getMessage(), ioe);
		}
		return error;
	}

	/**
	 * @return the ftpDirectory
	 */
	public String getFtpDirectory() {
		return ftpDirectory;
	}

	/**
	 * @param ftpDirectory the ftpDirectory to set
	 */
	public void setFtpDirectory(String ftpDirectory) {
		this.ftpDirectory = ftpDirectory;
	}

}
