package com.cat.logistics.shared.utils;

/**
 * Class that defines the constant variables used while fetching from the property file key values.
 * @author gantash
 *
 */
public interface MessageConstants 
{
	String LOGISTICS_ERROR_ISENGINE="logistics.error.isEngine";
	String LOGISTICS_ERROR_ISMACHINE="logistics.error.isMachine";
	String LOGISTICS_ERROR_DUPLICATEENGINE="logistics.error.duplicateEngine";
	String LOGISTICS_ERROR_DUPLICATEMACHINE="logistics.error.duplicateMachine";
	String LOGISTICS_MESSAGE_NO_IMPORTINFO="logistics.message.noImportInfo";
	String LOGISTICS_MESSAGE_NO_ENGNUMBER="logistics.message.noEngNumber";
	String LOGISTICS_MESSAGE_INVALID_ENGMCH="logistics.message.invalidEngMch";
	String LOGISTICS_MESSAGE_INVALID_ENGMCH2="logistics.message.invalidEngMch2";
	String LOGISTICS_ERROR_NO_SERIALNUM_EED="logistics.error.noseriNuminEED";
	String LOGISTICS_ERROR_INVALID_IMPORTPROVISION="logistics.error.invalidImportProvision";
	String LOGISTICS_MESSAGE_SAVESUCCESS="logistics.message.SaveSuccess";
	String LOGISTICS_MESSAGE_SUBMITSUCCESS="logistics.message.SubmitSuccess";
	String LOGISTICS_MESSAGE_APPROVESUCCESS="logistics.message.ApproveSuccess";
	
	String LOGISTICS_ERROR_NO_ACCESS = "logistics.error.noaccessforfac";
	String LOGISTICS_ERROR_SUBMTD_TO_BRKR = "logistics.error.submtdtobroker";
	String LOGISTICS_ERROR_CMP_FRM = "logistics.error.compltdForm";
	String LOGISTICS_ERROR_INDIDUAL_ENG ="logistics.error.individualEng";
	String DISP_MCH_MASS_UPLOAD_PAGE="displayMSMassUploadPage";
	String DISP_ENG_MASS_UPLOAD_PAGE="displayMSMassUploadPage";
	String DOWN_MASS_UPLOAD_TEMPLATE="downloadMassUploadTemplate";
	String MASS_UPLOAD_FILE_NM="EPA_Import_Form_Upload_Template.xlsx";
	String MTD_PROC_ES_MASS_EXCEL = "processESMassUploadExcel";
	String MTD_PROC_MS_MASS_EXCEL ="processMSMassUploadExcel";
	String MTD_DWLOAD_ERR_REPORT ="downloadErrorReport";
	String MTD_DWLOAD_SUCC_REPORT ="downloadSuccessReport";
	String MTD_POP_SERV_RESP ="addReportToServletResponse";
	String MTD_VALD_FILE_FORMAT ="validateUploadFileFormat";
	
	String LOGISTICS_ERROR_ENGASMCH = "logistics.error.engMapsAsMCH";
	String MTD_GET_SOLICT_ERR_RPT = "getPrtsSolicitErrRprt";
	String MTD_GET_DUTYRATE_ERR_RPT = "getDutyRateErrRprt";
	
	String MTD_POPULT_RPRT_RESPNSE = "populteReprtToRespns";
	String MTD_POPULT_DTY_RPRT_RESPNSE = "populteDtyRateRptRes";
	String MTD_GET_SOLICT_SUCC_RPT = "getPrtsSccsRpt";
	String MTD_GET_DUTYRATE_SUCC_RPT = "getPrtsSccsRpt";
	

	String MTD_GET_ACE_PORTAL_ERR_RPT = "getAcePortalErrRprt";
	String MTD_GET_ACE_PORTAL_SUCC_RPT = "getAcePortalSccsRpt";
	String MTD_GET_BOMANALY_ERR_RPT = "getDutyRateErrRprt";	
	
	String MTD_POPULT_BOM_ANALY_RESPNSE = "populteBomAnalyRptRes";
	String MTD_GET_BOM_ANALY_ERR_RPT = "getBomAnalyErrRprt";
	String MTD_GET_BOM_ANALY_SUCC_RPT = "getBomAnalySccsRpt";
	
	
}
