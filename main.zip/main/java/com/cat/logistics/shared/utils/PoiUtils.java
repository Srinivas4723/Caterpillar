package com.cat.logistics.shared.utils;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;




/**
 * get the wookbook
 * @author kakars2
 *
 */
public final class PoiUtils {

	public static final Logger LOGGER = LogManager.getLogger(PoiUtils.class);
	/**
	 * constructor
	 */
	public PoiUtils() {
		
    }

	/**
	 * get FileExtension
	 * @param fileName String fileName
	 * @return ext String extension
	 */
    public static String getFileExtension(String fileName) {
    	LOGGER.info("Entry method of getFileExtension {}", ServiceConstants.METHOD_ENTRY);
    	String ext = "";
    	if (null!=fileName) {
            int len = fileName.trim().lastIndexOf(".");
            ext = fileName.trim().substring(len);
        }
    	LOGGER.info("Exit method of getFileExtension {}", ServiceConstants.METHOD_EXIT);
        return ext;
    }

    /**
     * get HSSFWorkbook
     * @return hssfworkbook
     */
    public static Workbook getHSSFWorkbook() {
        return new HSSFWorkbook();
    }

    /**
     * get XSSFWorkbook
     * @return xssfworkbook
     */
    public static Workbook getXSSFWorkbook() {
        return new XSSFWorkbook();
    }
}
