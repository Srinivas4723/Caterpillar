package com.cat.logistics.shared.utils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * This class acts as container for master data like facility details, import Type codes
 * details etc.
 * 
 * @author chanda2
 * 
 */
public class MasterData {

	private static Map<String, String> authorityLevelsMap = new HashMap<String, String>();

	private static Map<String, String> faciltiesMap = new HashMap<String, String>();
	
	private static Map<String, Set<String>> faciltiesByUser = new HashMap<String, Set<String>>();
	
	private static Map<String, String> importTypeMap = new HashMap<String, String>();
		
	private static Map<String, String> provisionTypeMap = new HashMap<String, String>();
	
	private static Map<String, Map<String,Set<String>>> configMap = new HashMap<String, Map<String,Set<String>>>();
	
	private static Map<String, String> statusCodesMap = new HashMap<String, String>();
	
	/**
	 * @param authDesc
	 * @param authCode
	 */
	public static void addAuthorityLevel(String authDesc, String authCode) {
		authorityLevelsMap.put(authDesc, authCode);
	}

	/**
	 * @param authDesc
	 * @return Authority Code
	 */
	public static String getAuthorityCode(String authDesc) {
		return (String) authorityLevelsMap.get(authDesc);
	}


	/**
	 * @return Authority Level
	 */
	@SuppressWarnings("unchecked")
	public static Map getAuthorityLevels() {
		return authorityLevelsMap;
	}

	/**
	 * @param authorityLevels
	 */
	@SuppressWarnings("unchecked")
	public static void setAuthorityLevels(Map authorityLevels) {
		MasterData.authorityLevelsMap = authorityLevels;
	}
	
	/**
	 * @param authorityDescList
	 * @return List of AuthorityCodes
	 */
	public static List<String> getAuthorityCodes(List<String> authorityDescList) {
		List<String> authorityCodes = new ArrayList<String>();
		for(String authorityDesc: authorityDescList) {
			authorityCodes.add(authorityLevelsMap.get(authorityDesc));
		}
		return authorityCodes;
	}
	
	
	/**
	 * @param facilityDetails
	 * @param facilityCode
	 */
	public static void addFacility(String facilityDetails, String facilityCode) {
		faciltiesMap.put(facilityDetails, facilityCode);
	}

	/**
	 * @param facilityDetails
	 * @return facilities map
	 */
	public static String getFacilityCode(String facilityDetails) {
		return (String) faciltiesMap.get(facilityDetails);
	}


	/**
	 * @return facilities Map
	 */
	@SuppressWarnings("unchecked")
	public static Map getFacilities() {
		return faciltiesMap;
	}

	/**
	 * @param facilities
	 */
	@SuppressWarnings("unchecked")
	public static void setFacilities(Map facilities) {
		MasterData.faciltiesMap = facilities;
	}
	
	/**
	 * @param facilityDetailsList
	 * @return list of facilityCodes
	 */
	public static List<String> getFacilityCodes(List<String> facilityDetailsList) {
		List<String> facilityCodes = new ArrayList<String>();
		for(String facDesc: facilityDetailsList) {
			facilityCodes.add(faciltiesMap.get(facDesc));
		}
		return facilityCodes;
	}

	/**
	 * @return the importTypeMap
	 */
	public static Map<String, String> getImportTypeMap() {
		return importTypeMap;
	}

	/**
	 * @return the provisionTypeMap
	 */
	public static Map<String, String> getProvisionTypeMap() {
		return provisionTypeMap;
	}

	/**
	 * @param importTypeMap the importTypeMap to set
	 */
	public static void setImportTypeMap(Map<String, String> importTypeMap) {
		MasterData.importTypeMap = importTypeMap;
	}

	/**
	 * @param provisionTypeMap the provisionTypeMap to set
	 */
	public static void setProvisionTypeMap(Map<String, String> provisionTypeMap) {
		MasterData.provisionTypeMap = provisionTypeMap;
	}
	
	/**
	 * @param importTypeCode
	 * @param importTypeDetails
	 */
	public static void addImportType(String importTypeCode, String importTypeDetails) {
		importTypeMap.put(importTypeCode,importTypeDetails);
	}
	
	/**
	 * @param provisionTypeCode
	 * @param provisionTypeDetails
	 */
	public static void addprovisionType(String provisionTypeCode,String provisionTypeDetails) {
		provisionTypeMap.put( provisionTypeCode,provisionTypeDetails);
	}

	/**
	 * @return the faciltiesByUser
	 */
	public static Map<String, Set<String>> getFaciltiesByUser() {
		return faciltiesByUser;
	}

	/**
	 * @param faciltiesByUser the faciltiesByUser to set
	 */
	public static void setFaciltiesByUser(Map<String, Set<String>> faciltiesByUser) {
		MasterData.faciltiesByUser = faciltiesByUser;
	}
	
	
	/**
	 * @param cwsId
	 * @param facilities
	 */
	public static void addFaciltiesByUser(String cwsId, Set<String> facilities) {
		faciltiesByUser.put(cwsId, facilities) ;
	}

	/**
	 * @return the configMap
	 */
	public static Map<String, Map<String, Set<String>>> getConfigMap() {
		return configMap;
	}

	/**
	 * @param configMap the configMap to set
	 */
	public static void setConfigMap(Map<String, Map<String, Set<String>>> configMap) {
		MasterData.configMap = configMap;
	}
	
	/**
	 * @param configType 
	 */
	public static void addConfigMap(String configType, HashMap<String,Set<String>> config) {
		configMap.put(configType, config);
	}

	

	/**
	 * @return the statusCodesMap
	 */
	public static Map<String, String> getStatusCodesMap() {
		return statusCodesMap;
	}

	/**
	 * @param statusCodesMap the statusCodesMap to set
	 */
	public static void setStatusCodesMap(Map<String, String> statusCodesMap) {
		MasterData.statusCodesMap = statusCodesMap;
	}

	
	/**
	 * @param statusCodeDesc
	 * @param statusCode
	 */
	public static void addStatusCodesMap(String statusCodeDesc, String statusCode) {
		statusCodesMap.put(statusCodeDesc, statusCode);
	}
}
