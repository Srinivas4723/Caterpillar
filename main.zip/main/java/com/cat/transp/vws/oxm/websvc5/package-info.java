@javax.xml.bind.annotation.XmlSchema(namespace = "http://websvc5.cat.com")
package com.cat.transp.vws.oxm.websvc5;
