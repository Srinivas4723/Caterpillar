
package com.cat.transp.vws.oxm.websvc5;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="msgRcvdTS" type="{http://www.w3.org/2001/XMLSchema}dateTime"/>
 *         &lt;element name="srcSysId" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="outMsgKeyVal" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="msgTyp" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="srcSysKeyVal" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="otgngMsgFileNm" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="gtnFileNm" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "msgRcvdTS",
    "srcSysId",
    "outMsgKeyVal",
    "msgTyp",
    "srcSysKeyVal",
    "otgngMsgFileNm",
    "gtnFileNm"
})
@XmlRootElement(name = "insertOutgoingFileData")
public class InsertOutgoingFileData {

    @XmlElement(required = true, nillable = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar msgRcvdTS;
    @XmlElement(required = true, nillable = true)
    protected String srcSysId;
    @XmlElement(required = true, nillable = true)
    protected String outMsgKeyVal;
    @XmlElement(required = true, nillable = true)
    protected String msgTyp;
    @XmlElement(required = true, nillable = true)
    protected String srcSysKeyVal;
    @XmlElement(required = true, nillable = true)
    protected String otgngMsgFileNm;
    @XmlElement(required = true, nillable = true)
    protected String gtnFileNm;

    /**
     * Gets the value of the msgRcvdTS property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getMsgRcvdTS() {
        return msgRcvdTS;
    }

    /**
     * Sets the value of the msgRcvdTS property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setMsgRcvdTS(XMLGregorianCalendar value) {
        this.msgRcvdTS = value;
    }

    /**
     * Gets the value of the srcSysId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSrcSysId() {
        return srcSysId;
    }

    /**
     * Sets the value of the srcSysId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSrcSysId(String value) {
        this.srcSysId = value;
    }

    /**
     * Gets the value of the outMsgKeyVal property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOutMsgKeyVal() {
        return outMsgKeyVal;
    }

    /**
     * Sets the value of the outMsgKeyVal property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOutMsgKeyVal(String value) {
        this.outMsgKeyVal = value;
    }

    /**
     * Gets the value of the msgTyp property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMsgTyp() {
        return msgTyp;
    }

    /**
     * Sets the value of the msgTyp property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMsgTyp(String value) {
        this.msgTyp = value;
    }

    /**
     * Gets the value of the srcSysKeyVal property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSrcSysKeyVal() {
        return srcSysKeyVal;
    }

    /**
     * Sets the value of the srcSysKeyVal property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSrcSysKeyVal(String value) {
        this.srcSysKeyVal = value;
    }

    /**
     * Gets the value of the otgngMsgFileNm property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOtgngMsgFileNm() {
        return otgngMsgFileNm;
    }

    /**
     * Sets the value of the otgngMsgFileNm property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOtgngMsgFileNm(String value) {
        this.otgngMsgFileNm = value;
    }

    /**
     * Gets the value of the gtnFileNm property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGtnFileNm() {
        return gtnFileNm;
    }

    /**
     * Sets the value of the gtnFileNm property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGtnFileNm(String value) {
        this.gtnFileNm = value;
    }

}
