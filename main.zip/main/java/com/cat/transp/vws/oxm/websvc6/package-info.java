@javax.xml.bind.annotation.XmlSchema(namespace = "http://websvc6.cat.com")
package com.cat.transp.vws.oxm.websvc6;
