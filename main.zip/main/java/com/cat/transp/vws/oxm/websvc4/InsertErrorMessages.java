
package com.cat.transp.vws.oxm.websvc4;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="srcSysId" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="msgRcvdTS" type="{http://www.w3.org/2001/XMLSchema}dateTime"/>
 *         &lt;element name="srcSysKeyVal" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="errCd" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="errDet" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "srcSysId",
    "msgRcvdTS",
    "srcSysKeyVal",
    "errCd",
    "errDet"
})
@XmlRootElement(name = "insertErrorMessages")
public class InsertErrorMessages {

    @XmlElement(required = true, nillable = true)
    protected String srcSysId;
    @XmlElement(required = true, nillable = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar msgRcvdTS;
    @XmlElement(required = true, nillable = true)
    protected String srcSysKeyVal;
    @XmlElement(required = true, nillable = true)
    protected String errCd;
    @XmlElement(required = true, nillable = true)
    protected String errDet;

    /**
     * Gets the value of the srcSysId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSrcSysId() {
        return srcSysId;
    }

    /**
     * Sets the value of the srcSysId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSrcSysId(String value) {
        this.srcSysId = value;
    }

    /**
     * Gets the value of the msgRcvdTS property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getMsgRcvdTS() {
        return msgRcvdTS;
    }

    /**
     * Sets the value of the msgRcvdTS property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setMsgRcvdTS(XMLGregorianCalendar value) {
        this.msgRcvdTS = value;
    }

    /**
     * Gets the value of the srcSysKeyVal property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSrcSysKeyVal() {
        return srcSysKeyVal;
    }

    /**
     * Sets the value of the srcSysKeyVal property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSrcSysKeyVal(String value) {
        this.srcSysKeyVal = value;
    }

    /**
     * Gets the value of the errCd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getErrCd() {
        return errCd;
    }

    /**
     * Sets the value of the errCd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setErrCd(String value) {
        this.errCd = value;
    }

    /**
     * Gets the value of the errDet property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getErrDet() {
        return errDet;
    }

    /**
     * Sets the value of the errDet property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setErrDet(String value) {
        this.errDet = value;
    }

}
