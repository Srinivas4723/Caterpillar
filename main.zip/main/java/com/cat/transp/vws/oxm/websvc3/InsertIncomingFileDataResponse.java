
package com.cat.transp.vws.oxm.websvc3;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.cat.transp.vws.oxm.errorhandling.WebServiceReturn;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="insertIncomingFileDataReturn" type="{http://errorhandling.cat.com}WebServiceReturn"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "insertIncomingFileDataReturn"
})
@XmlRootElement(name = "insertIncomingFileDataResponse")
public class InsertIncomingFileDataResponse {

    @XmlElement(required = true, nillable = true)
    protected WebServiceReturn insertIncomingFileDataReturn;

    /**
     * Gets the value of the insertIncomingFileDataReturn property.
     * 
     * @return
     *     possible object is
     *     {@link WebServiceReturn }
     *     
     */
    public WebServiceReturn getInsertIncomingFileDataReturn() {
        return insertIncomingFileDataReturn;
    }

    /**
     * Sets the value of the insertIncomingFileDataReturn property.
     * 
     * @param value
     *     allowed object is
     *     {@link WebServiceReturn }
     *     
     */
    public void setInsertIncomingFileDataReturn(WebServiceReturn value) {
        this.insertIncomingFileDataReturn = value;
    }

}
