@javax.xml.bind.annotation.XmlSchema(namespace = "http://websvc4.cat.com")
package com.cat.transp.vws.oxm.websvc4;
