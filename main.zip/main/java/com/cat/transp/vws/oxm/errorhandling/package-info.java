@javax.xml.bind.annotation.XmlSchema(namespace = "http://errorhandling.cat.com")
package com.cat.transp.vws.oxm.errorhandling;
