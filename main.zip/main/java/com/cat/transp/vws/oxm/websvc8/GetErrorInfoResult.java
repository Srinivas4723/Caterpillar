
package com.cat.transp.vws.oxm.websvc8;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

import com.cat.transp.vws.oxm.errorhandling.WebServiceReturn;


/**
 * <p>Java class for GetErrorInfoResult complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="GetErrorInfoResult">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="emailAdrValue" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="emailReqdIndValue" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="errLvlValue" type="{http://www.w3.org/2001/XMLSchema}double"/>
 *         &lt;element name="wsReturnObject" type="{http://errorhandling.cat.com}WebServiceReturn"/>
 *         &lt;element name="errMsgValue" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "GetErrorInfoResult", propOrder = {
    "emailAdrValue",
    "emailReqdIndValue",
    "errLvlValue",
    "wsReturnObject",
    "errMsgValue"
})
public class GetErrorInfoResult {

    @XmlElement(required = true, nillable = true)
    protected String emailAdrValue;
    @XmlElement(required = true, nillable = true)
    protected String emailReqdIndValue;
    protected double errLvlValue;
    @XmlElement(required = true, nillable = true)
    protected WebServiceReturn wsReturnObject;
    @XmlElement(required = true, nillable = true)
    protected String errMsgValue;

    /**
     * Gets the value of the emailAdrValue property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEmailAdrValue() {
        return emailAdrValue;
    }

    /**
     * Sets the value of the emailAdrValue property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEmailAdrValue(String value) {
        this.emailAdrValue = value;
    }

    /**
     * Gets the value of the emailReqdIndValue property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEmailReqdIndValue() {
        return emailReqdIndValue;
    }

    /**
     * Sets the value of the emailReqdIndValue property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEmailReqdIndValue(String value) {
        this.emailReqdIndValue = value;
    }

    /**
     * Gets the value of the errLvlValue property.
     * 
     */
    public double getErrLvlValue() {
        return errLvlValue;
    }

    /**
     * Sets the value of the errLvlValue property.
     * 
     */
    public void setErrLvlValue(double value) {
        this.errLvlValue = value;
    }

    /**
     * Gets the value of the wsReturnObject property.
     * 
     * @return
     *     possible object is
     *     {@link WebServiceReturn }
     *     
     */
    public WebServiceReturn getWsReturnObject() {
        return wsReturnObject;
    }

    /**
     * Sets the value of the wsReturnObject property.
     * 
     * @param value
     *     allowed object is
     *     {@link WebServiceReturn }
     *     
     */
    public void setWsReturnObject(WebServiceReturn value) {
        this.wsReturnObject = value;
    }

    /**
     * Gets the value of the errMsgValue property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getErrMsgValue() {
        return errMsgValue;
    }

    /**
     * Sets the value of the errMsgValue property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setErrMsgValue(String value) {
        this.errMsgValue = value;
    }

}
