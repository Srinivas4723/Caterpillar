
package com.cat.transp.vws.oxm.websvc4;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.cat.transp.vws.oxm.errorhandling.WebServiceReturn;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="insertErrorMessagesReturn" type="{http://errorhandling.cat.com}WebServiceReturn"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "insertErrorMessagesReturn"
})
@XmlRootElement(name = "insertErrorMessagesResponse")
public class InsertErrorMessagesResponse {

    @XmlElement(required = true, nillable = true)
    protected WebServiceReturn insertErrorMessagesReturn;

    /**
     * Gets the value of the insertErrorMessagesReturn property.
     * 
     * @return
     *     possible object is
     *     {@link WebServiceReturn }
     *     
     */
    public WebServiceReturn getInsertErrorMessagesReturn() {
        return insertErrorMessagesReturn;
    }

    /**
     * Sets the value of the insertErrorMessagesReturn property.
     * 
     * @param value
     *     allowed object is
     *     {@link WebServiceReturn }
     *     
     */
    public void setInsertErrorMessagesReturn(WebServiceReturn value) {
        this.insertErrorMessagesReturn = value;
    }

}
