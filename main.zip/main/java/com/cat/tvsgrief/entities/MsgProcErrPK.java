package com.cat.tvsgrief.entities;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Embeddable;

/**
 * @author marigs
 *
 */
@Embeddable
public class MsgProcErrPK implements Serializable{

	private static final long serialVersionUID = 1L;
	
	@Column(name="ERR_CD")
	private String errCd;
	
	@Column(name="ERR_RCVD_TS")
	private Timestamp errRcvdTs;


	public String getErrCd() {
		return errCd;
	}

	public void setErrCd(String errCd) {
		this.errCd = errCd;
	}

	public Timestamp getErrRcvdTs() {
		return errRcvdTs;
	}

	public void setErrRcvdTs(Timestamp errRcvdTs) {
		this.errRcvdTs = errRcvdTs;
	}

	
	

}
