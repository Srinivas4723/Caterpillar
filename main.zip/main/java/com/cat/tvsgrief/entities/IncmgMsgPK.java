package com.cat.tvsgrief.entities;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Embeddable;

/**
 * @author marigs
 *
 */
@Embeddable
public class IncmgMsgPK implements Serializable{

	private static final long serialVersionUID = 1L;
	
	@Column(name="SRC_SYS_ID")
	private String srcSysId;
	
	@Column(name="SRC_SYS_KEY_VAL")
	private String srcSysKeyVal;
	
	@Column(name="MSG_RCVD_TS")
	private Timestamp msgRcvdTs;	
	

	public String getSrcSysId() {
		return srcSysId;
	}

	public void setSrcSysId(String srcSysId) {
		this.srcSysId = srcSysId;
	}

	public String getSrcSysKeyVal() {
		return srcSysKeyVal;
	}

	public void setSrcSysKeyVal(String srcSysKeyVal) {
		this.srcSysKeyVal = srcSysKeyVal;
	}

	public Timestamp getMsgRcvdTs() {
		return msgRcvdTs;
	}

	public void setMsgRcvdTs(Timestamp msgRcvdTs) {
		this.msgRcvdTs = msgRcvdTs;
	}	

}
