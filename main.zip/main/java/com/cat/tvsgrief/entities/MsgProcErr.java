package com.cat.tvsgrief.entities;

import java.io.Serializable;
import java.sql.Date;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.OneToOne;
import javax.persistence.Table;

/**
 * @author marigs
 *
 */
@Entity
@Table(name="MSG_PROC_ERR", schema="TVS")
public class MsgProcErr implements Serializable{

	private static final long serialVersionUID = 1L;
	
	@EmbeddedId
	private MsgProcErrPK msgProcErrPK;
	
	@Column(name="PROC_ERR_STAT")
	private String procErrStat;
	
	@Column(name="RSPBL_ANAL_ID")
	private String rspblAnalId;
	
	@Column(name="ANAL_UPDT_CMNT")
	private String analUpdtCmnt;
	
	@Column(name="ANAL_UPDT_TS")
	private Timestamp analUpdtTs;
	
	@Column(name="LAST_CHG_BY_USER_NM")
	private String lastChgByUserNm;
	
	@Column(name="LAST_CHG_DT_TM")
	private Date lastChgDtTm;
	
	@Column(name="ERR_DET")
	private String errDet;
	
	@OneToOne
	@JoinColumns({
		@JoinColumn(name="SRC_SYS_ID", referencedColumnName="SRC_SYS_ID"),
		@JoinColumn(name="SRC_SYS_KEY_VAL", referencedColumnName="SRC_SYS_KEY_VAL"),
		@JoinColumn(name="MSG_RCVD_TS", referencedColumnName="MSG_RCVD_TS")
	})
	private IncmgMsg incmgMsg;

	public MsgProcErrPK getMsgProcErrPK() {
		return msgProcErrPK;
	}

	public void setMsgProcErrPK(MsgProcErrPK msgProcErrPK) {
		this.msgProcErrPK = msgProcErrPK;
	}

	public String getProcErrStat() {
		return procErrStat;
	}

	public void setProcErrStat(String procErrStat) {
		this.procErrStat = procErrStat;
	}

	public String getRspblAnalId() {
		return rspblAnalId;
	}

	public void setRspblAnalId(String rspblAnalId) {
		this.rspblAnalId = rspblAnalId;
	}

	public String getAnalUpdtCmnt() {
		return analUpdtCmnt;
	}

	public void setAnalUpdtCmnt(String analUpdtCmnt) {
		this.analUpdtCmnt = analUpdtCmnt;
	}

	public Timestamp getAnalUpdtTs() {
		return analUpdtTs;
	}

	public void setAnalUpdtTs(Timestamp analUpdtTs) {
		this.analUpdtTs = analUpdtTs;
	}

	public String getLastChgByUserNm() {
		return lastChgByUserNm;
	}

	public void setLastChgByUserNm(String lastChgByUserNm) {
		this.lastChgByUserNm = lastChgByUserNm;
	}

	public Date getLastChgDtTm() {
		return lastChgDtTm;
	}

	public void setLastChgDtTm(Date lastChgDtTm) {
		this.lastChgDtTm = lastChgDtTm;
	}

	public String getErrDet() {
		return errDet;
	}

	public void setErrDet(String errDet) {
		this.errDet = errDet;
	}

	public IncmgMsg getIncmgMsg() {
		return incmgMsg;
	}

	public void setIncmgMsg(IncmgMsg incmgMsg) {
		this.incmgMsg = incmgMsg;
	}

}
