package com.cat.tvsgrief.entities;

import java.io.Serializable;
import java.sql.Date;
import java.sql.Timestamp;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.OneToOne;
import javax.persistence.Table;

/**
 * @author marigs
 *
 */
@Entity
@Table(name="INCMG_MSG", schema="TVS")
public class IncmgMsg implements Serializable{

	private static final long serialVersionUID = 1L;
	
	@EmbeddedId
	private IncmgMsgPK incmgMsgPK;
	
	@Column(name="LAST_CHG_BY_USER_NM")
	private String lastChgByUserNm;
	
	@Column(name="LAST_CHG_DT_TM")
	private Date lastChgDtTm;
	
	@Column(name="MAX_ERR_LVL")
	private Double maxErrLvl;	
	
	@Column(name="INCMG_MSG_FILE_NM")
	private String incmgMsgFileNm;
	
	@Column(name="MSG_PROC_CMPLT_TS")
	private Timestamp msgProcCmltTs; 
	
	@OneToOne(mappedBy="incmgMsg", cascade=CascadeType.ALL)	
	private MsgProcErr msgProcErr;
	
	public IncmgMsgPK getIncmgMsgPK() {
		return incmgMsgPK;
	}

	public void setIncmgMsgPK(IncmgMsgPK incmgMsgPK) {
		this.incmgMsgPK = incmgMsgPK;
	}

	public String getLastChgByUserNm() {
		return lastChgByUserNm;
	}

	public void setLastChgByUserNm(String lastChgByUserNm) {
		this.lastChgByUserNm = lastChgByUserNm;
	}

	public Date getLastChgDtTm() {
		return lastChgDtTm;
	}

	public void setLastChgDtTm(Date lastChgDtTm) {
		this.lastChgDtTm = lastChgDtTm;
	}

	public Double getMaxErrLvl() {
		return maxErrLvl;
	}

	public void setMaxErrLvl(Double maxErrLvl) {
		this.maxErrLvl = maxErrLvl;
	}

	public String getIncmgMsgFileNm() {
		return incmgMsgFileNm;
	}

	public void setIncmgMsgFileNm(String incmgMsgFileNm) {
		this.incmgMsgFileNm = incmgMsgFileNm;
	}

	
	public MsgProcErr getMsgProcErr() {
		return msgProcErr;
	}

	public void setMsgProcErr(MsgProcErr msgProcErr) {
		this.msgProcErr = msgProcErr;
	}

	public Timestamp getMsgProcCmltTs() {
		return msgProcCmltTs;
	}

	public void setMsgProcCmltTs(Timestamp msgProcCmltTs) {
		this.msgProcCmltTs = msgProcCmltTs;
	}
	
}
