/**
 * 
 */
package com.cat.autoeccn.dao.impl;

import java.sql.Timestamp;
import java.util.List;

/**
 * @author addansn
 *
 */
public interface GetSeqNumberDAO {

	public List<String> getSeqNo(Timestamp startTS, Timestamp endTs);

	Timestamp getLstSuccTS();

	void updateLstSuccTS(Timestamp succTs);
}
