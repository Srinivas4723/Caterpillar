/**
 * 
 */
package com.cat.autoeccn.dao.impl;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import com.cat.googletink.util.EncryptAndDecryptApplication;
import com.cat.logistics.epa.job.dto.AutoEccnDTO;
import com.cat.logistics.epa.job.utils.ApplicationException;
import com.cat.logistics.epa.job.utils.BatchConstants;
import com.cat.logistics.epa.job.utils.Utils;


/**
 * @author addansn
 *
 */
public class GetSeqNumberDAOImpl implements GetSeqNumberDAO {
	
	private static Connection connection = null;
	public static final Logger LOGGER = LogManager.getLogger(GetSeqNumberDAOImpl.class);
	
	@Autowired
	AutoEccnDTO autoEccnDTO;

	Connection conn;

	String eccnQuery = "select seq_no from AUTO_ECCN.PARTS_UPLOAD_DETAILS where LAST_UPDT_TS between ? and ?";
	String lastSuccessTS = "select TYP_VAL1 from AUTO_ECCN.ECCN_CNFGR where cnfgr_type='AUTO_ECCN_JOB' AND TYP_KEY='LST_SUCC_TS'";
	String updtLastSuccessTS = "UPDATE AUTO_ECCN.ECCN_CNFGR SET TYP_VAL1=?, LAST_UPDT_TS=SYSDATE, LAST_UPDT_LOGON_ID='ECCN_APP' where cnfgr_type='AUTO_ECCN_JOB' AND TYP_KEY='LST_SUCC_TS'";


	@Override
	public List<String> getSeqNo(Timestamp startTS, Timestamp endTs) {

		LOGGER.info("Entry method of getSeqNo {}", BatchConstants.METHOD_ENTRY);
		ResultSet rs = null;
		List<String> seqList = new ArrayList<String>();
		PreparedStatement preparedStatement = null;
		try {
			conn = getECCNConnection();
			preparedStatement = conn.prepareStatement(eccnQuery);
			preparedStatement.setTimestamp(1, startTS);
			preparedStatement.setTimestamp(2, endTs);
			rs = preparedStatement.executeQuery();
			while (rs.next()) {
				seqList.add(rs.getString(1));
			}

		} catch (Exception ex) {
			ex.printStackTrace();
		}
		LOGGER.info("Exit method of getSeqNo List- {}",BatchConstants.METHOD_EXIT);
		return seqList;
	}

	@Override
	public Timestamp getLstSuccTS() {

		LOGGER.info("Entry method of getLstSuccTS {}",BatchConstants.METHOD_ENTRY);
		ResultSet rs = null;
		Timestamp lstSucc = null;
		String succTs = null;
		PreparedStatement preparedStatement = null;
		try {
			conn = getECCNConnection();
			preparedStatement = conn.prepareStatement(lastSuccessTS);
			rs = preparedStatement.executeQuery();
			while (rs.next()) {
				succTs = rs.getString(1);
				lstSucc = Utils.getFrmTmstmp(Timestamp.valueOf(succTs));
				// lstSucc = Utils.convertStringToTimestamp(succTs);
			}

		} catch (Exception ex) {
			ex.printStackTrace();
		}
		LOGGER.info("Exit method of getLstSuccTS {}",BatchConstants.METHOD_EXIT);
		return lstSucc;
	}

	@Override
	public void updateLstSuccTS(Timestamp succTs) {
		
		LOGGER.info("Entry method of updateLstSuccTS {}",BatchConstants.METHOD_ENTRY);
		PreparedStatement preparedStatement = null;
		try {
			conn = getECCNConnection();
			preparedStatement = conn.prepareStatement(updtLastSuccessTS);
			preparedStatement.setString(1, String.valueOf(succTs));
			preparedStatement.executeUpdate();
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		LOGGER.info("Exit method of updateLstSuccTS {}",BatchConstants.METHOD_EXIT);
	}
	
	/**
	 * Obtains a jdbc connection to backend database
	 * 
	 * @return Connection connection to backend database
	 * @throws ApplicationException
	 */
	private Connection getECCNConnection() {
		LOGGER.info("Entry method of getECCNConnection {}",BatchConstants.METHOD_ENTRY);
		try {
			if (connection != null && !connection.isClosed()) {
				return connection;
			}
			String dburl = autoEccnDTO.getDburl();
			String user = autoEccnDTO.getEccnuser();
			String password = EncryptAndDecryptApplication.decrypt(System.getProperty("tink.serverKeyset"),
					System.getProperty("tink.associateKeyset"),autoEccnDTO.getEccnkey());
			Class.forName(autoEccnDTO.getDriver());
			connection = DriverManager.getConnection(dburl, user, password);
			LOGGER.info("Exit method of getECCNConnection {}","DB connection established successfully");
		} catch (Exception e) {
			LOGGER.error("Error in getECCNConnection {}", e.getMessage(), e);
		}
		return connection;
	}
}
